THEME
---------

The default theme is located in the '_theme_default' folder.

You should make a copy of this folder and update your settings to point to your new theme folder. This will ensure future updates won`t break your edits.

Theme folder names should start '_theme' to be recognised by the system.

Refer to the default template for reference.


CACHE:
-------------

If enabled, contains cache files.

Advanced Users: If you wish to change the location of the cache folder, see the following file:

control/classes/class.cache.php

Cache can be disabled in your admin control panel.

System > General Settings > Settings Menu > Cache Control