THEME
---------

The default theme is located in the '_theme_default' folder.

You should make a copy of this folder and update your settings to point to your new theme folder. This will ensure future updates won`t break your edits.

Theme folder names should start '_theme' to be recognised by the system.

Refer to the default template for reference.