<?php

//------------------------------------------------------------------------------
// LANGUAGE FILE
// Edit with care. Make a backup first before making changes.
//
// [1] Apostrophes should be escaped. eg: it\'s christmas.
// [2] Take care when editing arrays as they are spread across multiple lines
//
// If you make a mistake and you see a parse error, revert to backup file
//------------------------------------------------------------------------------


$public_footer             = 'Return to Top of Page';
$public_footer2            = 'Questions, issues? Send Us a Message';
$public_footer3            = 'Send Message';
$public_footer4            = 'Your Name';
$public_footer5            = 'Your Email';
$public_footer6            = 'Your Message';

?>
