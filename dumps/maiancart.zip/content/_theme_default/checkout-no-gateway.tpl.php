      <?php
      /*
        DISPLAYS INSTRUCTIONS IF NONE GATEWAY PAYMENT METHOD WAS CHOSEN
      */
      ?>
      <h1><?php echo $this->H1; ?></h1>
      
      <p class="msg"><?php echo $this->P_MSG; ?></p>
      
      <div class="noGateway">
        <h2 class="title">
         <span><?php echo $this->TEXT[0]; ?></span>
        </h2>
        
        <div class="formFieldWrapper">
        <div class="noGatewayInstructions">
        <?php
        // Displays payment instructions for payment option..
        echo $this->PAY_INSTRUCTIONS; 
        ?>
        </div>
        </div>
              
        <p class="bottom"></p>
      </div>