<?php
// PRODUCT DESCRIPTION TEMPLATE FILE
// If required you can recall any value from the product table via the $this->PDATA array..
// This is for advanced users only..to see the contents of the array use print_r.
// print_r($this->PDATA)
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=<?php echo $this->CHARSET; ?>" />
<title><?php echo mc_cleanDataEnt($this->PDATA['pName']); ?></title>
<base href="<?php echo $this->BASE_PATH; ?>/" />
<link rel="stylesheet" href="<?php echo $this->BASE_PATH; ?>/<?php echo $this->THEME_FOLDER; ?>/css/stylesheet.css" type="text/css" />
</head>

<body class="windowBody">      

<div class="windowArea">
  
  <h1 class="prodDesc"><span class="desc">&nbsp;</span><?php echo $this->TEXT[0]; ?></h1>
      
  <div id="descriptionMessage">
  <?php 
  echo $this->TEXT[1]; 
  ?>
  </div>

</div>

</body>
</html>