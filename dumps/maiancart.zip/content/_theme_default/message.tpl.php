<!DOCTYPE html>
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=<?php echo $this->CHARSET; ?>" />
<title><?php echo $this->TITLE; ?></title>
<base href="<?php echo $this->BASE_PATH; ?>/" />
<link rel="stylesheet" href="<?php echo $this->BASE_PATH.'/'.$this->THEME_FOLDER; ?>/css/stylesheet.css" type="text/css" />
<link rel="SHORTCUT ICON" href="<?php echo $this->BASE_PATH; ?>/favicon.ico" />
</head>

<body>

<div class="responseHandlers">
      
 <div class="top">
   <p><b><?php echo $this->TEXT[0]; ?></b><br /><br /><?php echo $this->TEXT[1]; ?></p>
 </div>
 
 <div class="bottom">
  <p>&#8226; <a href="<?php echo $this->BASE_PATH; ?>"><?php echo $this->TEXT[2]; ?></a> &#8226;</p>
 </div>
 
</div>

</body>
</html>