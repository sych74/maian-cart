      <script type="text/javascript">
      //<![CDATA[
      jQuery(document).ready(function() {
       jQuery('#from').datepicker({
         changeMonth: true,
         changeYear: true,
         monthNamesShort: <?php echo $this->CALENDAR[0]; ?>,
         dayNamesMin: <?php echo $this->CALENDAR[1]; ?>,
         firstDay: '<?php echo $this->CALENDAR[2]; ?>',
         dateFormat: '<?php echo $this->CALENDAR[3]; ?>',
         isRTL: false
       });
       jQuery('#to').datepicker({
         changeMonth: true,
         changeYear: true,
         monthNamesShort: <?php echo $this->CALENDAR[0]; ?>,
         dayNamesMin: <?php echo $this->CALENDAR[1]; ?>,
         firstDay: '<?php echo $this->CALENDAR[2]; ?>',
         dateFormat: '<?php echo $this->CALENDAR[3]; ?>',
         isRTL: false
       });
       jQuery('#slider-range').slider({
         range: true,
         min: <?php echo $this->SLIDER_CONFIG['min']; ?>,
         max: <?php echo $this->SLIDER_CONFIG['max']; ?>,
         values: [<?php echo $this->SLIDER_CONFIG['start']; ?>,<?php echo $this->SLIDER_CONFIG['end']; ?>],
         slide: function(event,ui) {
           jQuery('#price1').val(ui.values[0]);
           jQuery('#price2').val(ui.values[1]);
           jQuery('#sliderAmount').html(ui.values[0]+' - '+ui.values[1]);
         }
       });
       jQuery('#sliderAmount').html(jQuery('#slider-range').slider('values',0)+' - '+jQuery('#slider-range').slider('values',1));
      });
      //]]>
      </script>

      <h1><?php echo $this->TEXT[0]; ?></h1>
      
      <p class="msg"><?php echo $this->TEXT[1]; ?>:</p>
      
      <form method="get" action="<?php echo $this->URL; ?>">
      
      <div class="advancedSearch">
        <h2 class="title">
         <span><?php echo $this->TEXT[11]; ?></span>
        </h2>
        
        <div class="searchWrapper">
        
          <div class="left">
            <label><?php echo $this->TEXT[2]; ?>:</label>
            <input type="text" class="box" name="keys" value="<?php echo $this->TEXT[12]; ?>" /><br /><br />
            
			<label><?php echo $this->TEXT[4]; ?>:</label>
            <select name="cat" onchange="if(this.value!='0'){loadCatBrands(this.value)}">
              <option value="0">- - - - - -</option>
              <?php 
              // CATEGORIES
              // html/html-option-tags.htm
              echo $this->CATEGORIES; 
              ?>
            </select><br /><br />
			
			<label><?php echo $this->TEXT[6]; ?>: <span id="sliderAmount" class="sliderAmount"></span></label>
            <div id="slider-range"></div><br />
			
			<label><?php echo $this->TEXT[14]; ?>:</label>
            <select name="sortby">
              <?php 
              // SORT BY
              // html/html-option-tags.htm
              echo $this->SORT_BY; 
              ?>
            </select>
          </div>
          <div class="right">
            <label><?php echo $this->TEXT[3]; ?>:</label>
            <input type="text" class="box2" name="from" id="from" value="" /> - <input type="text" class="box2" name="to" value="" id="to" /><br /><br />
			
			<label><?php echo $this->TEXT[15]; ?>:</label>
            <select name="brand">
              <option value="0">- - - - - -</option>
			  <?php 
              // BRANDS
              // html/html-option-tags.htm
              echo $this->BRANDS; 
              ?>
            </select><br /><br />
			
			<label><?php echo $this->TEXT[13]; ?>:</label>
			<?php
			// FILTERS
			// Downloads box filter only displays if there is at least 1 product download..
			?>
            <?php echo ($this->IS_DOWNLOADS=='yes' ? '<input type="checkbox" name="download" value="yes" /> '.$this->TEXT[5].'&nbsp;&nbsp;&nbsp;' : ''); ?><input type="checkbox" name="stock" value="yes" /> <?php echo $this->TEXT[7]; ?>&nbsp;&nbsp;&nbsp;<input type="checkbox" name="specials" value="yes" /> <?php echo $this->TEXT[16]; ?>
          </div>
          <p>
            <input type="hidden" name="adv" value="1" />
            <input type="hidden" name="price1" id="price1" value="0.00" />
            <input type="hidden" name="price2" id="price2" value="0.00" />
            <input type="submit" class="button" value="<?php echo $this->TEXT[8]; ?> &raquo;" title="<?php echo $this->TEXT[8]; ?>" />
          </p>
        </div>
        
        <p class="bottom"></p>
        
      </div>  
      </form>
