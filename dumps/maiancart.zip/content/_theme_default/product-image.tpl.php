<?php
// PRODUCT IMAGE TEMPLATE FILE
// If required you can recall any value from the product table via the $this->PDATA array..
// This is for advanced users only..to see the contents of the array use print_r.
// print_r($this->PDATA)
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=<?php echo $this->CHARSET; ?>" />
<title><?php echo mc_cleanDataEnt($this->PDATA['pName']); ?></title>
<base href="<?php echo $this->BASE_PATH; ?>/" />
<link rel="stylesheet" href="<?php echo $this->BASE_PATH; ?>/<?php echo $this->THEME_FOLDER; ?>/css/stylesheet.css" type="text/css" />
</head>

<body class="windowBody">      

<div class="windowArea">
 
 <h1 class="imageDesc"><span class="img">&nbsp;</span><?php echo $this->TEXT[0]; ?></h1>
      
 <div id="imageWrapper">
   
  <?php
  // Loading remote image..
  if ($this->REMOTE=='yes') {
  ?> 
  <p><img src="<?php echo $this->IMG; ?>" alt="<?php echo $this->TEXT[1]; ?>" title="<?php echo $this->TEXT[1]; ?>" /></p>
  <?php
  } else {
  ?> 
  <p><img src="content/products/<?php echo $this->IMG; ?>" alt="<?php echo $this->TEXT[1]; ?>" title="<?php echo $this->TEXT[1]; ?>" /></p>
  <?php
  }
  ?>

 </div>

</div>

</body>
</html>