<!DOCTYPE html>
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=<?php echo $this->CHARSET; ?>" />
<title><?php echo $this->TITLE; ?></title>
<base href="<?php echo $this->BASE_PATH; ?>/" />
<link rel="stylesheet" href="<?php echo $this->BASE_PATH.'/'.$this->THEME_FOLDER; ?>/css/stylesheet.css" type="text/css" />
</head>

<body>

<div id="offlineWrapper">

  <h1><?php echo $this->TEXT[1]; ?></h1>
  
  <div class="offline">
    <?php echo $this->TEXT[0]; ?>
  </div>  

</div>

</body>
</html>
