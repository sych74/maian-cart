     <h1><?php echo $this->TEXT[0]; ?></h1>
     
     <?php
     // Only show filter bar if at least 1 result was found..
     if ($this->SEARCH_COUNT>0) {
     ?>
     <p class="searchFilter">
       
       <span class="left">
        <span class="link">
         <a rel="nofollow" href="#" title="<?php echo $this->TEXT[3]; ?>" onclick="saveSearch('<?php echo $this->TEXT[4]; ?>','<?php echo $this->URL; ?>','<?php echo $this->ERROR_JS[0]; ?>');return false"><?php echo $this->TEXT[3]; ?></a>
         <a rel="nofollow" class="adv_search" href="<?php echo $this->ADVANCED_SEARCH_URL; ?>" title="<?php echo $this->TEXT[5]; ?>"><?php echo $this->TEXT[5]; ?></a>
        </span> 
       </span>
       
       <span class="right">
        <select name="cats" onchange="if(this.value!=0){location=this.options[this.selectedIndex].value}" style="margin-right:20px">
        <option value="0"><?php echo $this->TEXT[1]; ?></option>
        <option value="0">- - - - - -</option>
         <?php
         // CATEGORIES
         // html/html-option-tags.htm
         echo $this->CATEGORIES;
         ?>
        </select>
        
        <select name="filters" onchange="if(this.value!=0){location=this.options[this.selectedIndex].value}">
         <option value="0"><?php echo $this->TEXT[2]; ?></option>
         <option value="0">- - - - - -</option>
         <?php
         // FILTER OPTIONS
         // html/html-option-tags.htm
         echo $this->FILTER_OPTIONS;
         ?>
        </select>
       </span>
       
       <br class="clear" />
     
     </p>
     <?php
     }
     ?>
     
     <div class="categoryProducts">
      <ul>
      <?php
      // SEARCH_RESULTS
      // html/categories/category-product.htm
      echo $this->SEARCH_RESULTS;
      ?>
      </ul>
      <br class="clear" />
     </div>
     
     <?php
     // Displays page numbers..
     // html/page-numbers.htm
     echo $this->PAGINATION;
     ?>
