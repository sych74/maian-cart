<!DOCTYPE html>
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=<?php echo $this->CHARSET; ?>" />
<title><?php echo $this->TITLE; ?></title>
<base href="<?php echo $this->BASE_PATH; ?>/" />
<link rel="stylesheet" href="<?php echo $this->BASE_PATH.'/'.$this->THEME_FOLDER; ?>/css/stylesheet.css" type="text/css" />
<link rel="SHORTCUT ICON" href="<?php echo $this->BASE_PATH; ?>/favicon.ico" />
</head>

<body>

<div class="responseMessage">
      
 <div class="top">
   <p><b class="big"><?php echo $this->TEXT[0]; ?></b><br /><br /><?php echo $this->TEXT[1]; ?></p>
 </div>
 
 <div class="bottom">
  <p>&lt; <a href="<?php echo $this->BASE_PATH; ?>" title="<?php echo $this->TEXT[2]; ?>"><?php echo $this->TEXT[2]; ?></a> &gt;</p>
 </div>
 
</div>

</body>
</html>