<!DOCTYPE html>
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=<?php echo $this->CHARSET; ?>" />
<title><?php echo $this->TITLE; ?></title>
<base href="<?php echo $this->BASE_PATH; ?>/" />
<?php
// Loads meta refresh. DO NOT remove!!
if ($this->META_REFRESH) {
?>
<meta http-equiv="refresh" content="4;url=<?php echo $this->META_REFRESH; ?>" />
<?php
}
?>
<link rel="stylesheet" href="<?php echo $this->BASE_PATH.'/'.$this->THEME_FOLDER; ?>/css/stylesheet.css" type="text/css" />
<link rel="SHORTCUT ICON" href="<?php echo $this->BASE_PATH; ?>/favicon.ico" />
</head>

<body>

<div class="responseHandlers">
      
 <div class="top">
   <p><b><?php echo $this->TEXT[0]; ?></b><br /><br /><?php echo $this->TEXT[1]; ?></p>
 </div>
 
 <div class="bottom">
  <p><img src="<?php echo $this->THEME_FOLDER; ?>/images/connecting.gif" alt="" title="" /></p>
 </div>
 
</div>

</body>
</html>