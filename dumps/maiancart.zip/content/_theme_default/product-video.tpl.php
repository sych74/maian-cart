<?php
// PRODUCT VIDEO TEMPLATE FILE
// If required you can recall any value from the product table via the $this->PDATA array..
// This is for advanced users only..to see the contents of the array use print_r.
// print_r($this->PDATA)
//
// For configuration options for FlowPlayer visit:
// http://flowplayer.org/
//
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=<?php echo $this->CHARSET; ?>" />
<title><?php echo mc_cleanDataEnt($this->PDATA['pName']); ?></title>
<base href="<?php echo $this->BASE_PATH; ?>/" />
<link rel="stylesheet" href="<?php echo $this->BASE_PATH; ?>/<?php echo $this->THEME_FOLDER; ?>/css/stylesheet.css" type="text/css" />
<script type="text/javascript" src="<?php echo $this->BASE_PATH; ?>/<?php echo $this->THEME_FOLDER; ?>/js/jquery.js"></script>
<script type="text/javascript" src="<?php echo $this->BASE_PATH; ?>/<?php echo $this->THEME_FOLDER; ?>/js/plugins/jquery.flowplayer.js"></script>
</head>

<body class="windowBody">      

<div class="windowArea">     

  <h1 class="prodDesc"><span class="video">&nbsp;</span><?php echo $this->TEXT[0]; ?></h1>
      
  <div id="videoWrapper">
  <?php
  // If there is a product video specified, display it..
  if ($this->PRODUCT_VIDEO) {
  ?>
  <p style="text-align:center;margin: 0px auto">
  <a rel="nofollow" href="<?php echo $this->BASE_PATH; ?>/content/video/<?php echo $this->PRODUCT_VIDEO; ?>" style="margin:0px auto;display:block;width:<?php echo $this->VIDEO_PARAMS[0]; ?>px;height:<?php echo $this->VIDEO_PARAMS[1]; ?>px" id="player"></a> 
  </p>

  <script type="text/javascript">
  //<![CDATA[
  jQuery(document).ready(function() {
    flowplayer("player", "<?php echo $this->THEME_FOLDER; ?>/flowPlayer/flowplayer-3.2.2.swf", {
      plugins: { 
        controls: {
          autoHide: false
        }
      }
    });
  });
  //]]>
  </script>

  <p class="desc">
    <?php echo $this->PRODUCT_DESC; ?>
  </p>
  <?php
  // Else show message about no product video..
  } else {
  ?>
  <img src="<?php echo $this->THEME_FOLDER; ?>/images/no-product-video.gif" alt="<?php echo $this->TEXT[1]; ?>" title="<?php echo $this->TEXT[1]; ?>" /><br /><br />
  <?php 
    echo $this->TEXT[1];
  }
  ?>
  </div>

</div>

</body>
</html>