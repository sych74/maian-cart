//============================================
// Maian Cart
// General Javascript Functions
// Written by David Ian Bennett
// http://www.maianscriptworld.co.uk
//============================================

//=======================================
// GIFT CERTIFICATES
//=======================================

function mc_highlightGiftValue(id) {
  jQuery(".giftCertificates li").each(function() {
    jQuery(this).find('span.value_bold').removeClass('value_bold').addClass('value');
  });
  jQuery('#mc-gcode-'+id).find('span.value').removeClass('value').addClass('value_bold');
}

function resetErrBox(box) {
  jQuery(box).removeClass('box_err').addClass('box');
}

//=======================================
// LOAD PRODUCT IMAGE INTO VIEWER
//=======================================

function productImageViewer(thumb,picture,url,switcher) {
  jQuery('#displayImg').attr('src',thumb);
  jQuery('#displayImg').attr('data-zoom-image',picture);
  jQuery('#imgLink').attr('href',url);
  // Is elevate zoom enabled?
  if (switcher=='yes') {
    var ez = jQuery('#displayImg').data('elevateZoom');	  
    ez.swaptheimage(thumb,picture);
  }
}

function viewProductZoom(link,url,product,stock) {
  jQuery(link).colorbox({
   iframe: true,
   title: function() {
    if (stock!='0') {
      return '<a class=\'colorbox_details\' href=\''+url+'\' title=\''+product+'\'>'+product+'</a>';
	} else {
	  return product;
	}
   }
  });
  return false;
}

//==================================
// MENU TOGGLE
//==================================

function toggleChildren(id,theme) {
  jQuery(document).ready(function() {
   jQuery('#cat_sub_'+id).toggle('slow');
   // Change image..
   if (jQuery('#click_img_'+id).attr('src')==theme+'/images/children.png') {
    jQuery('#click_img_'+id).attr('src',theme+'/images/children-close.png');
   } else {
    jQuery('#click_img_'+id).attr('src',theme+'/images/children.png');
   }
  }); 
}

function toggleInfants(id,theme) {
  jQuery(document).ready(function() {
   jQuery('#cat_sub_child_'+id).toggle('slow');
   // Change image..
   if (jQuery('#click_img_inf_'+id).attr('src')==theme+'/images/infants.png') {
    jQuery('#click_img_inf_'+id).attr('src',theme+'/images/infants-close.png');
   } else {
    jQuery('#click_img_inf_'+id).attr('src',theme+'/images/infants.png');
   }
  }); 
}

//=========================
// SEARCH ACTION
//=========================

function searchStore(baseurl,field) {
  if (jQuery('#store_search_box').val()=='' || jQuery('#store_search_box').val()==field) {
    jQuery('#store_search_box').val('');
	jQuery('#store_search_box').focus();
    return false;
  }
  window.location = baseurl+'/?keys='+jQuery('#store_search_box').val();
}

function saveSearch(article,page,text) {
  if (window.sidebar) {
    window.sidebar.addPanel(article,page,"");
  } else if (document.all) {
    window.external.AddFavorite(page,article);
  } else {
    mc_alertBox(text);
    return false;
  }
}

function mcKeyCodeEvent(e) {
  var unicode = (e.keyCode ? e.keyCode : e.charCode);
  return unicode;
}

//===============================
// REFRESH QTY BOXES
//===============================

function refreshQtyOptions(stock,threshold) {
  var newstock = parseInt(stock);
  var thresh   = parseInt(threshold);
  if (newstock>thresh) {
    var newstock = thresh;
  }
  // Do nothing if the quantity drop down doesn`t exist..
  if (jQuery('#qty').length < 0 || document.getElementById('qty')==null || document.getElementById('qty')=='undefined') {
    return false;
  }
  document.getElementById('qty').options.length = 0;
  if (newstock==0) {
    jQuery('#qty').html('<option value="0">0</option>');
  } else {
    var select = '';
    for (var i=0; i<newstock; i++) {
      select += '<option value="'+(i+1)+'">'+(i+1)+'</option>';
    } 
    jQuery('#qty').html(select);
  }
}

//======================================================
// LOADS MP3 FLASH PLAYER FOR MP3 PREVIEW TRACK
//======================================================

function playMP3(mp3,id) {
  var flashvars = {
   mp3: ''+mp3+'',
   width: '20',
   height: '20',
   showslider: 0,
   buttonwidth: 20,
   loadingcolor: 'ffffff',
   bgcolor: 'fbfbfb',
   bgcolor1: 'dd3647',
   bgcolor2: '0e644e',
   buttoncolor: 'ffffff',
   buttonovercolor: 'e5e5e5',
   textcolor: 'ffffff'
  };
  var params = {
   wmode: 'transparent',
   movie: 'content/swf/music_player.swf',
   bgcolor: '#fbfbfb'
  };
  var attributes = {};
  swfobject.embedSWF('content/swf/music_player.swf','musicPlayer'+id,'20','20','9.0.0','content/swf/expressInstall.swf',flashvars,params,attributes);
}

//======================
// VALID E-MAIL
//======================

function isValidEmailAddress(email) {
  var pattern = new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);
  return pattern.test(email);
}

//========================
// MISCELLANEOUS
//========================

function stateLoader(value,state) {
  switch (state) {
    case 'init':
	var flds = ['bill','ship'];
	for (var i=0; i<flds.length; i++) {
	  // US..
	  if (jQuery('select[name="'+flds[i]+'_9"]').val()=='184') {
	    jQuery('input[name="'+flds[i]+'_6"]').prop('disabled',true).hide();
		jQuery('#'+flds[i]+'_canstates').prop('disabled',true).hide();
	    jQuery('#'+flds[i]+'_usstates').prop('disabled',false).show();
	  // Canada..
	  } else if (jQuery('select[name="'+flds[i]+'_9"]').val()=='31') {
	    jQuery('input[name="'+flds[i]+'_6"]').prop('disabled',true).hide();
		jQuery('#'+flds[i]+'_usstates').prop('disabled',true).hide();
	    jQuery('#'+flds[i]+'_canstates').prop('disabled',false).show();
	  // Other..
	  } else {
	    jQuery('#'+flds[i]+'_usstates').prop('disabled',true).hide();
		jQuery('#'+flds[i]+'_canstates').prop('disabled',true).hide();
	    jQuery('input[name="'+flds[i]+'_6"]').prop('disabled',false).show();
	  }
	}
	break;
	case 'bill':
	case 'ship':
	if (value=='184') {
	  jQuery('input[name="'+state+'_6"]').prop('disabled',true).hide();
	  jQuery('#'+state+'_canstates').prop('disabled',true).hide();
	  jQuery('#'+state+'_usstates').prop('disabled',false).show();
	} else if (value=='31') {
	  jQuery('input[name="'+state+'_6"]').prop('disabled',true).hide();
	  jQuery('#'+state+'_usstates').prop('disabled',true).hide();
	  jQuery('#'+state+'_canstates').prop('disabled',false).show();
	} else {
	  jQuery('#'+state+'_usstates').prop('disabled',true).hide();
	  jQuery('#'+state+'_canstates').prop('disabled',true).hide();
	  jQuery('input[name="'+state+'_6"]').prop('disabled',false).show();
	}
	if (state=='bill') {
	  if (value=='184') {
	    jQuery('input[name="ship_6"]').prop('disabled',true).hide();
	    jQuery('#ship_canstates').prop('disabled',true).hide();
	    jQuery('#ship_usstates').prop('disabled',false).show();
	  } else if (value=='31') {
	    jQuery('input[name="ship_6"]').prop('disabled',true).hide();
	    jQuery('#ship_usstates').prop('disabled',true).hide();
	    jQuery('#ship_canstates').prop('disabled',false).show();
	  } else {
	    jQuery('#ship_usstates').prop('disabled',true).hide();
	    jQuery('#ship_canstates').prop('disabled',true).hide();
	    jQuery('input[name="ship_6"]').prop('disabled',false).show();
	  }
	}
	break;
  }
}

function mc_divScroller(div,off) {
  var offset = jQuery('#'+div).offset().top;
  jQuery(document).ready(function() {
    jQuery('html,body').animate({
      scrollTop: parseInt(offset-off)
    });
  });
}

function copyFromBilling(theme,reload) {
  for (var i=1; i<10; i++) {
    if (i==9) {
      jQuery('#addresses select[name="ship_'+i+'"]').val(jQuery('#addresses select[name="bill_'+i+'"]').val());
	  // Only force a reload of shipping area if shipping is applicable..
	  if (reload=='yes') {
        reloadRegions(jQuery('#addresses select[name="ship_'+i+'"]').val(),theme);
	  }
    } else {
	  // Standard boxes..
      jQuery('#addresses input[name="ship_'+i+'"]').val(jQuery('#addresses input[name="bill_'+i+'"]').val());
	  if (jQuery('#addresses select[name="ship_'+i+'"]')) {
	    jQuery('#addresses select[name="ship_'+i+'"]').val(jQuery('#addresses select[name="bill_'+i+'"]').val());
	  }
	  // US States..
	  if (jQuery('#addresses select[id="ship_usstates"]')) {
	    jQuery('#addresses select[id="ship_usstates"]').val(jQuery('#addresses select[id="bill_usstates"]').val());
	  }
	  // Canadian States..
	  if (jQuery('#addresses select[id="ship_canstates"]')) {
	    jQuery('#addresses select[id="ship_canstates"]').val(jQuery('#addresses select[id="bill_canstates"]').val());
	  }
    }
  }
}

function mc_checkRequiredFields(msg) {
  var cnt = 0;
  for (var i=1; i<10; i++) {
    // Skip phone and second address fields..
    if (i!=4 && i!=8 && i!=6) {
      if (jQuery('#addresses input[name="ship_'+i+'"]').val()=='' || jQuery('#addresses input[name="bill_'+i+'"]').val()==''
          || jQuery('#addresses select[name="ship_'+i+'"]').val()=='0' || jQuery('#addresses select[name="bill_'+i+'"]').val()=='0') {
        jQuery.prompt(msg, { 
          buttons: { Close: true },
          focus: 2,
          submit: function(e,v,m,f) {
            if (v) {
              mc_divScroller('addresses',80);
            }
          },
          top: '30%' 
        });
        return false;
      }  
    }
	// Additional checks for state box..
	if (i==6) {
	  var ship_state = (jQuery('#addresses select[name="ship_9"]').val()=='184' ? jQuery('#addresses select[name="ship_6"]').val() : jQuery('#addresses input[name="ship_6"]').val());
	  var bill_state = (jQuery('#addresses select[name="bill_9"]').val()=='184' ? jQuery('#addresses select[name="bill_6"]').val() : jQuery('#addresses input[name="bill_6"]').val());
	  if (ship_state=='' || ship_state=='0' || bill_state=='' || bill_state=='0') {
	    jQuery.prompt(msg, { 
          buttons: { Close: true },
          focus: 2,
          submit: function(e,v,m,f) {
            if (v) {
              mc_divScroller('addresses',80);
            }
          },
          top: '30%' 
        });
        return false;
	  }
	}
  }
  return true;
}

function confirmMessage(txt,url) {
  jQuery.prompt(txt, { 
    buttons: { OK: true, Cancel: false },
    focus: 2,
    submit: function(e,v,m,f) {
      if (v) {
        window.location = url;
      }
    },
    top: '30%' 
  });
  return false;
}

//--------------------------------------------
// ALTERNATIVE ALERT BOX
// via Impromptu
//--------------------------------------------

function mc_alertBox(text) {
  jQuery.prompt(text, { 
    buttons: { Close: true },
    focus: 2,
    top: '30%' 
  });
}