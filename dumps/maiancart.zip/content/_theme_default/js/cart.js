//============================================
// Maian Cart
// JS/JQuery/JSON Functions
// Written by David Ian Bennett
// http://www.maianscriptworld.co.uk
//
// Incorporating jQuery library
// Copyright (c) John Resig
// http://jquery.com/
//
//============================================

//--------------------------------------------
// LOAD BRANDS
//--------------------------------------------

function loadCatBrands(cat) {
  jQuery(document).ready(function() {
   jQuery.ajax({
    url: 'index.php',
    data: 'p=advanced-search&loadCatBrands='+cat,
    dataType: 'html',
    success: function (data) {
	  if (data!='none') {
	    jQuery('select[name="brand"]').html(data);
	  } else {
	    jQuery('select[name="brand"]').html('<option value="0">- - - - - -</option>');
	  }
    }
   });
  });
  return false;
}

//--------------------------------------------
// CLEAR RECENT ITEMS
//--------------------------------------------

function clearRecentView(text) {
  jQuery.prompt(text, { 
    buttons: { OK: true, Cancel: false },
    focus: 2,
    submit: function(e,v,m,f) { 
     if (v) { 
      jQuery(document).ready(function() { 
       jQuery.ajax({
        url: 'index.php',
        data: 'clearView=yes',
        dataType: 'html',
        success: function (data) {
          jQuery('#recentView').hide('slow');
        }
       });
      }); 
     } 
    },
    top: '30%'
  });
}

//--------------------------------------------
// NEWSLETTER SUBSCRIBE / UNSUBSCRIBE
//--------------------------------------------

function newsletterSignup() {
  var type = jQuery('input[name=newstype]:checked').val();
  jQuery(document).ready(function() {  
    if (jQuery('#newsletter').val()=='') {
      jQuery('#newsletter').focus();
      return false;
    }
    jQuery.ajax({
      url: 'index.php',
      data: 'news='+jQuery('#newsletter').val()+'&todo='+(type=='sub' || type=='unsub' ? type : 'sub'),
      dataType: 'json',
      success: function (data) {
        // Read incoming json and update html elements..
        switch (data['type']) {
          case 'error':
          mc_alertBox(data['message']);
          break;
          case 'ok':
          mc_alertBox(data['message']);
          jQuery('#newsletter').val('');
          break;
        }
      }
    }); 
  });
}

//-----------------------------------------------------------------------
// SHIPPING COUNTRY & REGION
// The following relate to the shipping options on the checkout page
//-----------------------------------------------------------------------

function reloadRegions(def_country,theme) {
  // Reset selectors...
  reloadShippingSelectors();
  // Is default set..
  if (def_country>0) {
    var country = def_country;
    jQuery('#countries').val(def_country);
    jQuery('#addresses select[name="bill_9"]').val(def_country);
  } else {
    if (jQuery('#countries').val()==0) {
      jQuery('#areas').html('<option value="0">- - - - - - - - - -</option>');
      return false;
    }
    var country = jQuery('#countries').val();
  }
  jQuery(document).ready(function() { 
    jQuery.ajax({
      url: 'index.php',
      data: 'p=update-regions&c='+country,
      dataType: 'json',
      success: function(data) {
        var resCount = 0;
        // Clear previous restriction blocks..
        jQuery('.cartWrapper .restricted').each(function(){
          jQuery(this).remove();
          ++resCount;
        });
        // Now make product images visible again..
        if (resCount>0) {
          jQuery('.cartWrapper .preview a').each(function(){
            jQuery(this).css('display','inline');
          });
        }
        switch (data['html']) {
          case 'restriction-block':
          jQuery('#loader').html('');
          jQuery('#countries').val('0');
          jQuery('#areas').html('<option value="0">- - - - - - - - - -</option>');
          // Highlight products as restricted..
          var products = data['html_no'].split('#####');
          for (var i=0; i<products.length; i++) {
            jQuery('#'+products[i]+' .preview a').css('display','none');
            jQuery('#'+products[i]+' .preview').append('<div class="restricted"><img src="'+theme+'/images/restricted.png" alt="" title="" /><br />'+data['areas']+'</div>');
          }
          mc_alertBox(data['text']);
          break;
          default:
          jQuery('#areas').html('');
          jQuery('#loader').html('');
          jQuery('#sysMsgShip').hide('slow');
          // Only show alert message if an area is found..
          if (data['areas']>0) {
            jQuery('#areas').html(data['html']);
            // Don`t show the selection message if default is set..
            if (def_country>0) {
              return false;
            }
          } else {
            jQuery('#areas').html(data['html']);
            jQuery('#sysMsgShip').html(data['html_no']);
            jQuery('#sysMsgShip').show('slow');
          }
          break;
        }
      }
    });  
  });
}

function loadShipOptions(theme) {
  jQuery('#loader').html('<img src="'+theme+'/images/adding.gif" id="gimage" alt="" title="" />');
  var countries = jQuery('#countries').val();
  var areas     = jQuery('#areas').val();
  jQuery(document).ready(function() { 
    jQuery.ajax({
      url: 'index.php',
      data: 'p=load-ship-options&c='+countries+'&a='+areas,
      dataType: 'json',
      success: function(data) {
        switch (data['options']) {
          case 'yes':
          jQuery('#loader').html('');
          jQuery('#selectors').hide();
          jQuery('#ship_options').hide();
          jQuery('#ship_options').html(data['html']);
          jQuery('#ship_options').slideDown('slow');
          jQuery('#textInstructions').html(data['instr']);
          // Show totals if shipping count is 1..
          if (data['count']=='1') {
            showTotals(data['selection'],data['cod']);
          }
          break;
          case 'no':
          jQuery('#loader').html('');
          jQuery('#ship_options').hide();
          jQuery('#sysMsgShip').html(data['text']);
          jQuery('#sysMsgShip').slideDown('slow');
          break;
          case 'invalid':
          mc_alertBox(data['text']);
          jQuery('#loader').html('');
          reloadShippingSelectors();
          break;
        }
      }
    });
  });
}

function closeShippingMessage() {
  jQuery(document).ready(function() {
    jQuery('#sysMsgShip').hide('slow');
  });
}

function reloadShippingSelectorsOff(ts_switch) {
  jQuery(document).ready(function() { 
    jQuery.ajax({
      url: 'index.php',
      data: 'reloadTotalCoupons=yes',
      dataType: 'json',
      success: function (data) {
        jQuery('#couponimage').html('');
        jQuery('#couponprice').html('0.00');
        jQuery('#basket-total-t-coupon').hide();
        jQuery('#price-t-total').html(data['total']);
        jQuery('#t-total').val(data['rawtotal']);
        jQuery('#totals').html(data['buildtotals']+data['gtotals']);
      }
    });
  });
  return false;
}

function reloadShippingSelectors() {
  jQuery(document).ready(function() { 
    jQuery.ajax({
      url: 'index.php',
      data: 'clearDiscountCoupon=yes',
      dataType: 'html',
      success: function (data) {
        jQuery('#couponimage').html('');
        jQuery('#couponprice').html('0.00');
        jQuery('#ship_options').hide();
        jQuery('#loadBlock').hide();
        jQuery('#notesWrapper').hide();
        jQuery('#newsletterOptInWrapper').hide();
        jQuery('#couponWrapper').hide();
        jQuery('#areas').val('0');
        jQuery('#selectors').show();
        jQuery('#no-shipping').show();
        jQuery('#textInstructions').html(data);
      }
    });
  });
  return false;
}

function loadGrandTotal(raw,total,rawtax,tax,rawship,ship) {
  jQuery(document).ready(function() {
    jQuery('#price-t-tax').html(tax);
    jQuery('#t-tax').val(rawtax);
    jQuery('#price-t-total').html(total);
    jQuery('#t-total').val(raw);
    jQuery('#price-t-shipping').html(ship);
    jQuery('#t-shipping').val(rawship);
  });
}

function showTotals(id,cod) {
  jQuery(document).ready(function() { 
    jQuery.ajax({
      url: 'index.php',
      data: 'p=set-shipping&id='+id,
      dataType: 'json',
      success: function(data) {
        jQuery('#no-shipping').hide();
        var methods = jQuery('#mc_paymentMethods').html();
        jQuery('#totals').html(data['buildtotals']+data['gtotals']);
        var wrapper = jQuery('#totalsWrapper').html();
        jQuery('#loadBlock').html('<div class="totalsWrapper" id="totalsWrapper">'+wrapper+'</div><div class="mc_paymentMethods" id="mc_paymentMethods">'+methods+'</div>');
        // If COD isn`t available, hide it..
        // If it was hidden before, show it..
        if (cod=='no') {
          jQuery('#cashOnDelivery').hide();
        } else {
          jQuery('#cashOnDelivery').show();
        }
        jQuery('#notesWrapper').show();
        jQuery('#newsletterOptInWrapper').show();
        jQuery('#couponWrapper').show();
        jQuery('#loadBlock').show();
      }
    }); 
  }); 
}

//-----------------------------------------------------------------------------
// REMOVE INSURANCE
// Removes insurance if option available
//-----------------------------------------------------------------------------

function removeInsuranceCharge() {
  var action = jQuery('#inslink').attr('rel');
  jQuery(document).ready(function() {
    jQuery.ajax({
      url: 'index.php',
      data: 'p=insurance&action='+action,
      dataType: 'json',
      success: function (data) {
        jQuery('#price-t-total').html(data['total']);
        jQuery('#t-total').val(data['rawtotal']);
        jQuery('#totals').html(data['buildtotals']+data['gtotals']);
        // Hide shipping if 0.00..
        if (jQuery('#t-shipping').val()=='0.00') {
          jQuery('#basket-total-t-shipping').remove();
        }
        jQuery('#inslink').attr('title',data['text']);
        jQuery('#inslink').html(data['text']);
        switch (action) {
          case 'add':
          jQuery('#inslink').attr('rel','rem');
          break;
          case 'rem':
          jQuery('#inslink').attr('rel','add');
          break;
        }
      }
    });
  });
  return false;
}

//-----------------------------------------------------------------------------
// DISCOUNT COUPONS
// The following relate to the discount coupon option on the checkout page
//-----------------------------------------------------------------------------

function addDiscountCoupon(theme) {
  var coupon = jQuery('#coupon_code').val();
  if (coupon=='') {
    jQuery('#coupon_code').focus();  
    return false;
  }
  jQuery('#image').html('<img src="'+theme+'/images/adding.gif" id="gimage" alt="" title="" />');
  jQuery(document).ready(function() { 
    jQuery.ajax({ 
      url: 'index.php',
      data: 'p=add-discount-coupon&coupon='+encodeURIComponent(coupon),
      dataType: 'json',
      success: function (data) {
        // Read incoming json and update html elements..
        switch (data['action']) {
          case 'ok':
          jQuery('#coupon_code').val('');
          jQuery('#couponprice').hide();
          jQuery('#couponprice').html(data['discount']+data['remove']);
          jQuery('#couponprice').slideDown('slow');
          jQuery('#couponimage').html('<img src="'+theme+'/images/discount-ok.png" id="gimage" alt="" title="" />');
          if (data['rebuild']!='none') {
            jQuery('#basket-total-t-coupon').hide();
            jQuery('#basket-total-t-sub').after(data['rebuild']);
          }
          jQuery('#sysMsg').hide('slow');
          loadGrandTotal(
           data['rawtotal'],
           data['total'],
           data['taxrawtotal'],
           data['taxtotal'],
           data['rawship'],
           data['ship']
          );
          break;
          default:
          jQuery('#couponimage').html('<img src="'+theme+'/images/discount-error.png" id="gimage" alt="" title="" />');
          jQuery('#sysMsg').html(data['message']);
          jQuery('#sysMsg').show('slow');
          break;
        }
      }
    });  
  });
}

function deleteDiscountCoupon() {
  jQuery(document).ready(function() { 
    jQuery.ajax({
      url: 'index.php',
      data: 'p=delete-discount-coupon',
      dataType: 'json',
      success: function (data) {
        jQuery('#couponimage').html('');
        jQuery('#price-t-total').hide();
        jQuery('#basket-total-t-coupon').hide('slow');
        jQuery('#couponprice').hide();
        jQuery('#couponprice').html(data['price']);
        jQuery('#price-t-total').html(data['total']);
        jQuery('#couponprice').slideDown('slow');
        jQuery('#price-t-total').slideDown('slow');
        adjustHiddenBoxPrice('t-total',data['rawtotal']);
        loadGrandTotal(
         data['rawtotal'],
         data['total'],
         data['taxrawtotal'],
         data['taxtotal'],
         data['rawship'],
         data['ship']
        );
      }
    });
  });  
  return false;
}

function closeDiscountCouponMessage(theme) {
  jQuery(document).ready(function() {
    jQuery('#coupon_code').val('');
    jQuery('#couponimage').html('<img src="'+theme+'/images/discount-blank.gif" id="gimage" alt="" title="" />');
    jQuery('#sysMsg').hide('slow');
  });  
}

//-----------------------------------------------------------------
// CHECKOUT BASKET
// The following relates to the basket items on the checkout page
//-----------------------------------------------------------------

function adjustHiddenBoxPrice(box,value) {
  jQuery(document).ready(function() {
    jQuery(box).val(value);
  });
}

function deleteBasketItem(box,text,which,ts_switch) {
  if (which=='link') {
    jQuery.prompt(text, { 
      buttons: { OK: true, Cancel: false },
      focus: 2,
      submit: function(e,v,m,f) { 
       if (v) {
         deleteBasketItem(box,text,'link2',ts_switch); 
       } 
      },
      top: '30%'
    });
    return false;
  }
  jQuery(document).ready(function() { 
    jQuery.ajax({ 
      url: 'index.php',
      data: 'p=delete-item&id='+box,
      dataType: 'json',
      success: function (data) {
        // If the cart count is greater than 0, we remove cart item. If 0, we redirect to checkout page to clear all..
        if (data['count']>0) {
          jQuery('#bsk-'+data['box']).hide('slow');
          // Does this trigger a refresh? This only happens if mixed tangible/downloads are in basket and tangible are removed..
          // Refresh removes shipping selectors..
          if (data['trigger']=='yes') {
            window.location = data['url'];
            return false;
          }
        } else {
          window.location = data['url'];
          return false;
        }
        if (document.getElementById('topCartCount')!='undefined') {
          jQuery('#topCartCount').html(data['count']);
        }
        // Reset shipping if options were available..
        // If global switch is off, shipping/tax rules are disabled..
        switch (ts_switch) {
          case 'on':
          if (data['clearship']=='yes') {
            reloadShippingSelectors();
          } else {
            reloadShippingSelectors();
          }
          break;
          case 'off':
          reloadShippingSelectorsOff();
          break;
        }
      }
    }); 
  }); 
}

function updateBasketQty(box,qty,ts_switch) {
  jQuery(document).ready(function() { 
    jQuery.ajax({
      url: 'index.php',
      data: 'p=update-basket&id='+box+'&qty='+qty,
      dataType: 'json',
      success: function (data) {
        // If refresh has occured, refresh..
        // This will occur if min checkout amount is set and quantities are lower..
        if (data['refresh']=='yes') {
          window.location = data['ref-page'];
        }
        // Did anything exceed stock levels..
        if (data['box']=='attr-exceed-stock') {
          mc_alertBox(data['message']);
          return false;
        }
        // Was minimum purchase quantity set..
        if (data['box']=='min-purchase-qty') {
          jQuery('#box-'+box).val(parseInt(qty+1));
          jQuery('#qtyarea-'+box).html(parseInt(qty+1));
          mc_alertBox(data['message']);
          return false;
        }
        // Was max purchase quantity set..
        if (data['box']=='max-purchase-qty') {
          jQuery('#box-'+box).val(parseInt(qty-1));
          jQuery('#qtyarea-'+box).html(parseInt(qty-1));
          mc_alertBox(data['message']);
          return false;
        }
        // Read incoming json and update html elements..
        jQuery('#pb-'+data['box']).hide();
        jQuery('#pb-'+data['box']).html(data['html']);
        jQuery('#pb-'+data['box']).show();
        if (document.getElementById('topCartCount')!='undefined') {
          jQuery('#topCartCount').html(data['count']);
        }
        // Reset shipping if options were available..
        // If global switch is off, shipping/tax rules are disabled..
        // If the shipping div doesn`t exist, selector reload is off..
        if (jQuery('#ship_options').html()==undefined) {
          var ts_switch = 'off';
        } else {
		  // Check shipping selector exists..
		  // If it does, reload..
		  if (jQuery('#ship_options')) {
		    var ts_switch = 'on';
		  }
		}
		switch (ts_switch) {
          case 'on':
          if (data['clearship']=='yes') {
            reloadShippingSelectors();
          } else {
            reloadShippingSelectors();
          }
          break;
          case 'off':
          reloadShippingSelectorsOff();
          break;
        }
      }
    }); 
  });
}

function updateQTY(type,action,max,text,text2,ts_switch) {
  jQuery(document).ready(function() {
    var qty = parseInt(jQuery('#box-'+type).val());
    switch (action) {
      case 'add':
      var qty = parseInt(qty+1);
      if (qty<=max) {
        updateBasketQty(type,qty,ts_switch);
        jQuery('#box-'+type).val(qty);
        jQuery('#qtyarea-'+type).html(qty);
      } else {
        mc_alertBox(text2);
        return false;
      }
      break;
      case 'reduce':
      var qty = parseInt(qty-1);
      if (qty>=1) {
        updateBasketQty(type,qty,ts_switch);
        jQuery('#box-'+type).val(qty);
        jQuery('#qtyarea-'+type).html(qty);
      }
      if (qty==0) {
        jQuery('#box-'+type).val(qty);
        jQuery('#qtyarea-'+type).html(qty);
        jQuery.prompt(text, { 
          buttons: { OK: true, Cancel: false },
          focus: 2,
          submit: function(e,v,m,f) { 
            if (v) { 
              deleteBasketItem(type,text,'zero',ts_switch);
            } else {
              jQuery('#box-'+type).val('1');
              jQuery('#qtyarea-'+type).html('1');
            }
          },
          top: '30%'
        });
      }
      break;
    }
  });  
}

function refreshPersonalisation(div,price,ts_switch,theme) {
  jQuery('#'+div).css('background','url('+theme+'/images/pers_spinner.gif) no-repeat 50% 50%');
  jQuery(document).ready(function() { 
    jQuery.ajax({
      url: 'index.php',
      data: 'ppRebuild='+div,
      dataType: 'json',
      success: function (data) {
        // Incoming is array, update based on slot..
        jQuery.each(data, function (i, msg) {
          switch (i) {
            // Div refresh..
            case 0:
            if (msg=='reload') {
              window.location = '?p=checkout';
              return false;
            }
            jQuery('#'+div).html(msg).slideDown('slow');
            jQuery('#'+div).css('background-image','none');
            break;
            // Price reload..
            case 1:
            jQuery('#'+price).html(msg).slideDown('slow');
            jQuery('#'+div).css('background-image','none');
            break;
          }
        });
        switch (ts_switch) {
          case 'on':
          reloadShippingSelectors();
          break;
          case 'off':
          reloadShippingSelectorsOff();
          break;
        }        
      }
    });
  });
  return false;
}

function updateProductPersonalisation(code,theme) {
  // Transmit data to server using jquery/ajax..
  jQuery('#update_spinner').css('background','url('+theme+'/images/pers_spinner.gif) no-repeat 2% 50%');
  jQuery(document).ready(function() { 
    jQuery.ajax({
      type: 'POST',
      url: 'index.php?ppCE='+code,
      data: jQuery("#personalisationWindow > form").serialize(),
      cache: false,
      dataType: 'html',
      success: function (data) {
        if (data=='') {
          // Reset personalisation fields back to their original colour..
          resPBoxValues();
          jQuery('#update_spinner').css('background-image','none');
          jQuery('#message').slideDown('slow');
        } else {
          var string = data.split('#######');
          jQuery('#update_spinner').css('background-image','none');
          jQuery('#'+string[1]).addClass('error_highlight');
          jQuery('#'+string[1]).focus();
          mc_alertBox(string[0]);
        }
      }
    }); 
  });
  return false; 
}

//--------------------------------------------
// GIFT CERTS - EDIT
//--------------------------------------------

function mc_editBasketGiftCert(type,slot,text) {
  // Transmit data to server using jquery/ajax..
  jQuery(document).ready(function() { 
    jQuery.ajax({
      url: 'index.php',
      data: 'p=checkout&editGiftCert='+type+'&slot='+slot,
      dataType: 'json',
      success: function (data) {
	    if (data['name']) {
          var html = '<input type="text" class="box" name="gcnme_'+slot+'" value="'+data['name']+'" /><br />';
		  html += '<input style="margin-top:2px" type="text" class="box" name="gcem_'+slot+'" value="'+data['email']+'" />';
		  // Include message box for recipient (to)..
		  if (type=='to') {
		  html += '<br /><textarea style="margin-top:2px" rows="3" cols="5" name="gcmsg_'+slot+'">'+data['message']+'</textarea>';
		  }
		  html += '&nbsp;&nbsp;<a style="text-transform:none" href="#" onclick="mc_updateGiftCert(\''+type+'\',\''+slot+'\');return false" class="closeandsave">'+text+'</a>';
		  jQuery('#giftbox-'+type+'-'+slot).html(html);
        }
	  }
    });  
  });
}

function mc_updateGiftCert(type,slot) {
  // Transmit data to server using jquery/ajax..
  jQuery(document).ready(function() {
   jQuery.post('index.php?p=checkout&updateGiftCert='+type+'&slot='+slot, { 
    name: jQuery('input[name="gcnme_'+slot+'"]').val(),
	email: jQuery('input[name="gcem_'+slot+'"]').val(),
	msg: jQuery('textarea[name="gcmsg_'+slot+'"]').val()
   }, 
   function(data) {
    if (data['html']) {
      jQuery('#giftbox-'+type+'-'+slot).html(data['html']);
    }
   },'json'); 
  });
  return false;
}

//--------------------------------------------
// MENU BASKET
// The following relate to the menu basket
//--------------------------------------------

function removeBasketItem(product,theme) {
  // Transmit data to server using jquery/ajax..
  jQuery(document).ready(function() { 
    jQuery.ajax({
      url: 'index.php',
      data: 'p=delete-menuitem&id='+product,
      dataType: 'json',
      success: function (data) {
        // Read incoming json and update html elements..
        switch (data['loadtype']) {
          case 'empty':
          jQuery('#shoppingBasket').hide();
          jQuery('#shoppingBasket').html(data['html']);
          jQuery('#shoppingBasket').slideDown('slow');
          jQuery('#footerBasket').hide();
          break;
          case 'items':
          jQuery('#mb-'+data['box']).hide('slow');
          jQuery('#menu-basket-total').html(data['total']);
          break;
        }
        if (data['id']>0 && document.getElementById('img'+data['id'])!='undefined' &&
            document.getElementById('img'+data['id'])!=null) {
          document.getElementById('img'+data['id']).src=theme+'/images/addtocart.gif';
        }
        if (document.getElementById('topCartCount')!='undefined') {
          jQuery('#topCartCount').html(data['count']);
        }
      }
    });  
  });
}

function addGiftToBasket(theme) {
  // Error check..
  var fields = ['from_name','from_email','to_name','to_email'];
  var er     = 0;
  for (var i=0; i<fields.length; i++) {
    if (jQuery('input[name="'+fields[i]+'"]').val()=='') {
	  jQuery('input[name="'+fields[i]+'"]').removeClass('box').addClass('box_err');
	  ++er;
	}
  }
  // Transmit data to server using jquery/ajax..
  if (er==0) {
    jQuery('#spinner').css('background','url('+theme+'/images/addtobasket.gif) no-repeat right center');
    jQuery(document).ready(function() { 
      jQuery.ajax({
        type: 'POST',
        url: 'index.php?p=gift',
        data: jQuery("#addToBasket > form").serialize(),
        cache: false,
        dataType: 'json',
        success: function (data) {
		  jQuery('#spinner').css('background-image','none');
		  switch (data['message']) {
		    case 'OK':
			if (data['previous']!='0') {
			  if (document.getElementById('topCartCount')!='undefined') {
                jQuery('#topCartCount').html(data['count']);
              }
              jQuery('#menu-basket-total').html(data['total']);
              jQuery('#'+data['previous']).after(data['append']);
              jQuery('#'+data['id']).css('display','none');
              jQuery('#'+data['id']).show('slow');
              jQuery('#spinner').css('background','url('+theme+'/images/addedtobasket.png) no-repeat right center');
			  // Remove background image..
			  setTimeout(function() {
                jQuery('#spinner').css('background-image','none');
			  }, 1500);
			  // Reset personalisation fields back to their original state..
              resPBoxes();
			} else {
			  jQuery('#shoppingBasket').hide();
              jQuery('#shoppingBasket').html(data['html']);
              if (document.getElementById('topCartCount')!='undefined') {
                jQuery('#topCartCount').html(data['count']);
              }
              jQuery('#shoppingBasket').slideDown('slow');
              jQuery('#spinner').css('background','url('+theme+'/images/addedtobasket.png) no-repeat right center');
              // Reset personalisation fields back to their original state..
              resPBoxes();
              jQuery('#footerBasket').show();
			  // Remove background images..
			  setTimeout(function() {
                jQuery('#spinner').css('background-image','none');
			  }, 1500);
			}
			// Clear "To" boxes..
			jQuery('input[name="to_name"]').val('');
			jQuery('input[name="to_email"]').val('');
			break;
			default:
			jQuery('#spinner').css('background-image','none');
            mc_alertBox(data['message']);
			break;
		  }	
        }
      }); 
    });
  }
  return false; 
}

function addToBasket(id,theme) {
  // Transmit data to server using jquery/ajax..
  jQuery('#spinner').html('<img src="'+theme+'/images/addtobasket.gif" alt="" title="" />&nbsp;&nbsp;').fadeIn(500);
  jQuery(document).ready(function() { 
    jQuery.ajax({
      type: 'POST',
      url: 'index.php?pID='+id,
      data: jQuery("#addToBasket > form").serialize(),
      cache: false,
      dataType: 'json',
      success: function (data) {
        jQuery('#spinner').html('&nbsp;');
        // Was anything selected..
        if (data['message']=='no-items-set') {
          mc_alertBox(data['msg']);
          return false;
        }
        // Do we refresh menu basket..
        if (data['refresh']=='li-refresh' || data['refresh']=='new-item') {
          if (data['previous']!='0') {
            if (document.getElementById('topCartCount')!='undefined') {
              jQuery('#topCartCount').html(data['count']);
            }
            switch (data['refresh']) {
              case 'li-refresh':
              jQuery('#'+data['id']).html(data['litag']);
              jQuery('#menu-basket-total').html(data['total']);
              jQuery('#'+data['id']).hide('slow');
              jQuery('#'+data['id']).slideDown('slow');
              jQuery('#spinner').html('<img src="'+theme+'/images/addedtobasket.png" alt="" title="" />&nbsp;&nbsp;').fadeOut(3000);
              break;
              case 'new-item':
              jQuery('#menu-basket-total').html(data['total']);
              jQuery('#'+data['previous']).after(data['append']);
              jQuery('#'+data['id']).css('display','none');
              jQuery('#'+data['id']).show('slow');
              jQuery('#spinner').html('<img src="'+theme+'/images/addedtobasket.png" alt="" title="" />&nbsp;&nbsp;').fadeOut(3000);
              break;
              default:
              // Debugging..
              //mc_alertBox(data['refresh')+'\n\n'+data['message']);
              break;
            }
            // Reset personalisation fields back to their original colour..
            resPBoxes();
          } else {
            jQuery('#shoppingBasket').hide();
            jQuery('#shoppingBasket').html(data['html']);
            if (document.getElementById('topCartCount')!='undefined') {
              jQuery('#topCartCount').html(data['count']);
            }
            jQuery('#shoppingBasket').slideDown('slow');
            jQuery('#spinner').html('<img src="'+theme+'/images/addedtobasket.png" alt="" title="" />&nbsp;&nbsp;').fadeOut(3000);
            // Reset personalisation fields back to their original state..
            resPBoxes();
            jQuery('#footerBasket').show();
          }
        } else {
          if (data['refresh']=='blank-per-field' || data['refresh']=='blank-attr-field') {
            jQuery('#'+data['field']).addClass('error_highlight');
            jQuery('#'+data['field']).focus();
          }
          if (data['refresh']=='min-purchase-qty') {
            // Custom code if required..
          }
          if (data['refresh']=='max-purchase-qty') {
            // Custom code if required..
          }
          mc_alertBox(data['message']);
        }
      }
    }); 
  });
  return false; 
}

function resPBoxValues() {
  jQuery(document).ready(function() { 
    jQuery("#personalisation textarea").each(function(){
      jQuery('#'+jQuery(this).attr('id')).removeClass('error_highlight');
    });
    jQuery("#personalisation input").each(function(){
      jQuery('#'+jQuery(this).attr('id')).removeClass('error_highlight');
    });
    jQuery("#personalisation select").each(function(){
      jQuery('#'+jQuery(this).attr('id')).removeClass('error_highlight');
    });
  });
}

function resPBoxes() {
  jQuery(document).ready(function() { 
    jQuery("#personalisation textarea").each(function(){
      jQuery('#'+jQuery(this).attr('id')).removeClass('error_highlight').val('');
    });
    jQuery("#personalisation input").each(function(){
      jQuery('#'+jQuery(this).attr('id')).removeClass('error_highlight').val('');
    });
    jQuery("#personalisation select").each(function(){
      jQuery('#'+jQuery(this).attr('id')).removeClass('error_highlight').val('no-option-selected');
    });
  });  
}