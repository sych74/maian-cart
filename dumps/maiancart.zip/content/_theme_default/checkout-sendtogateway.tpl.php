<!DOCTYPE html>
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=<?php echo $this->CHARSET; ?>" />
<title><?php echo $this->TITLE; ?></title>
<base href="<?php echo $this->BASE_PATH; ?>/" />
<link rel="stylesheet" href="<?php echo $this->BASE_PATH.'/'.$this->THEME_FOLDER; ?>/css/stylesheet.css" type="text/css" />
<link rel="SHORTCUT ICON" href="<?php echo $this->BASE_PATH; ?>/favicon.ico" />
<script type="text/javascript" src="<?php echo $this->BASE_PATH.'/'.$this->THEME_FOLDER; ?>/js/jquery.js"></script>
<?php
// Refreshes to specific payment page url without form data..
if ($this->META_REFRESH) {
?>
<meta http-equiv="refresh" content="5;url=<?php echo $this->META_REFRESH; ?>" />
<?php
} else {
?>
<script type="text/javascript">
//<![CDATA[
setTimeout(function() {
  jQuery('#gateway').submit(); 
}, 3000);
//]]>
</script>
<?php
}
?>
</head>

<body>

<div class="responseHandlers">
      
 <div class="top">
   <p><b><?php echo $this->TEXT[0]; ?></b><br /><br /><?php echo $this->TEXT[1]; ?></p>
 </div>
 
 <div class="bottom">
  <p><img src="<?php echo $this->THEME_FOLDER; ?>/images/connecting.gif" alt="" title="" /></p>
 </div>
 
</div>

<div>
<?php
// DO NOT REMOVE THIS!
echo $this->PAYMENT_FIELDS;
?>
</div>

</body>
</html>