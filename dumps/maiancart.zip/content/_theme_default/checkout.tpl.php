      <?php
      /*
        CHECKOUT ROUTINES WITH SHIPPING/ZONES/TAX
        IMPORTANT!! Treat this template file with care. Div IDs are VERY important to the Ajax cart
         routines and should not be changed or renamed in any way.
      */
      ?>
      <h1><?php echo $this->TEXT[0]; ?></h1>
      
      <?php
      // Only show message if cart count is greater than 0..
      if ($this->CART_COUNT>0) {
      ?>
      <p class="basket_msg"><?php echo $this->TEXT[1]; ?></p>
      <?php
      }
      ?>

      <form method="post" id="form" action="<?php echo $this->URL[0]; ?>" onsubmit="return mc_checkRequiredFields('<?php echo $this->ADDRESSES[12]; ?>')">
      <?php
      // BASKET ITEMS
      // html/basket-checkout/basket-wrapper.htm
      // html/basket-checkout/basket-item.htm
      // html/basket-checkout/basket-personalisation-wrapper.htm
      // html/basket-checkout/basket-personalisation-wrap-rebuild.htm
      // html/basket-checkout/basket-personalisation-option.htm
      // html/basket-checkout/basket-personalisation-add.htm
      // html/basket-checkout/basket-personalisation-add-rebuild.htm
      echo $this->BASKET_ITEMS;
      
      // Only show address options if cart count is greater than 0..
      if ($this->CART_COUNT>0 && $this->IS_MIN_CHECKOUT_SET=='no') {
      // Load default shipping country/regions..
      ?>
      <script type="text/javascript">
      //<![CDATA[
      jQuery(document).ready(function() {
        reloadRegions('<?php echo $this->DEFAULT_COUNTRY; ?>','<?php echo $this->THEME_FOLDER; ?>');
		stateLoader(0,'init');
      });
      //]]>
      </script>
      
      <div class="addresses" id="addresses">
        
        <div class="billing">
        
          <h2 class="title">
           <span><?php echo $this->ADDRESSES[1]; ?>:</span>
          </h2> 
          
          <div class="addrfields">
          
            <div class="left">
              <label><?php echo $this->ADDRESSES[2]; ?></label>
              <input type="text" name="bill_1" value="" class="box" tabindex="1" />
              <label><?php echo $this->ADDRESSES[4]; ?></label>
              <input type="text" name="bill_3" value="" class="box" tabindex="3" />
              <label><?php echo $this->ADDRESSES[6]; ?></label>
              <input type="text" name="bill_5" value="" class="box" tabindex="5" />
              <label><?php echo $this->ADDRESSES[8]; ?></label>
              <input type="text" name="bill_7" value="" class="box" tabindex="7" />
              <label><?php echo $this->ADDRESSES[10]; ?></label>
              <select name="bill_9" tabindex="9" onchange="jQuery('#countries').val(this.value);reloadRegions('0','<?php echo $this->THEME_FOLDER; ?>');stateLoader(this.value,'bill')">
               <option value="0">- - - - - -</option>
               <?php
               echo $this->COUNTRIES;
               ?>
              </select>
            </div>
            
            <div class="right">
              <label><?php echo $this->ADDRESSES[3]; ?></label>
              <input type="text" name="bill_2" value="" class="box" tabindex="2" />
              <label><?php echo $this->ADDRESSES[5]; ?></label>
              <input type="text" name="bill_4" value="" class="box" tabindex="4" />
              <label><?php echo $this->ADDRESSES[7]; ?></label>
			  <?php
			  // State dropdown appears if United States/Canada is selected, otherwise defaults to standard text box..
			  ?>
              <input type="text" name="bill_6" value="" class="box" tabindex="6" />
			  <select name="bill_6" id="bill_usstates" tabindex="6">
			  <?php
			  // control/states.php
              echo $this->US_STATES;
              ?>
			  </select>
			  <select name="bill_6" id="bill_canstates" tabindex="6">
			  <?php
			  // control/states.php
              echo $this->CAN_STATES;
              ?>
			  </select>
			  <label><?php echo $this->ADDRESSES[9]; ?></label>
              <input type="text" name="bill_8" value="" class="box" tabindex="8" />
            </div>
            
            <br class="clear" />
          
          </div>
        
        </div>
        
        <div class="shipping">
           
          <h2 class="title">
           <span class="span"><span><a href="#" onclick="copyFromBilling('<?php echo $this->THEME_FOLDER; ?>','yes');return false" title="<?php echo $this->ADDRESSES[11]; ?>"><?php echo $this->ADDRESSES[11]; ?></a></span><?php echo $this->ADDRESSES[0]; ?>:</span>
          </h2> 
          
          <div class="addrfields">
            
            <div class="left">
              <label><?php echo $this->ADDRESSES[2]; ?></label>
              <input type="text" name="ship_1" value="" class="box" tabindex="11" />
              <label><?php echo $this->ADDRESSES[4]; ?></label>
              <input type="text" name="ship_3" value="" class="box" tabindex="13" />
              <label><?php echo $this->ADDRESSES[6]; ?></label>
              <input type="text" name="ship_5" value="" class="box" tabindex="15" />
              <label><?php echo $this->ADDRESSES[8]; ?></label>
              <input type="text" name="ship_7" value="" class="box" tabindex="17" />
              <label><?php echo $this->ADDRESSES[10]; ?></label>
              <select name="ship_9" id="countries" onchange="reloadRegions('0','<?php echo $this->THEME_FOLDER; ?>');stateLoader(this.value,'ship')" tabindex="19">
               <option value="0">- - - - - -</option>
               <?php
               echo $this->COUNTRIES;
               ?>
              </select>
            </div>
            
            <div class="right">
              <label><?php echo $this->ADDRESSES[3]; ?></label>
              <input type="text" name="ship_2" value="" class="box" tabindex="12" />
              <label><?php echo $this->ADDRESSES[5]; ?></label>
              <input type="text" name="ship_4" value="" class="box" tabindex="14" />
              <label><?php echo $this->ADDRESSES[7]; ?></label>
			  <?php
			  // State dropdown appears if United States/Canada is selected, otherwise defaults to standard text box..
			  ?>
			  <input type="text" name="ship_6" value="" class="box" tabindex="16" />
			  <select name="ship_6" id="ship_usstates" tabindex="16">
			  <?php
			  // control/states.php
              echo $this->US_STATES;
              ?>
			  </select>
			  <select name="ship_6" id="ship_canstates" tabindex="16">
			  <?php
			  // control/states.php
              echo $this->CAN_STATES;
              ?>
			  </select>
			  <label><?php echo $this->ADDRESSES[9]; ?></label>
              <input type="text" name="ship_8" value="" class="box" tabindex="18" />
            </div>
            
            <br class="clear" />
            
          </div> 
           
        </div>
        
        <br class="clear" />
        
      </div>
      
      <?php
      }
      
      // If min checkout amount not enforced, so options..
      if ($this->IS_MIN_CHECKOUT_SET=='no') {
        
        // SHIPPING OPTIONS
        // html/basket-checkout/basket-shipping.htm
        // html/basket-checkout/basket-shipping-flat.htm
        // html/basket-checkout/basket-shipping-percent.htm
        // html/basket-checkout/basket-shipping-wrapper.htm
        echo $this->SHIPPING_OPTIONS;
      
        // DISCOUNT COUPON
        // html/basket-checkout/basket-discount-coupon.htm
        echo $this->DISCOUNT_COUPON;
      
      }
      // Only show buttons/payment methods and notes box if cart count is greater than 0..
      if ($this->CART_COUNT>0) {
      ?>
      <div class="notesWrapper" id="notesWrapper">
        
        <h2 class="title">
          <span><?php echo $this->TEXT[6]; ?>:</span>
        </h2>  
        
        <div class="notes">
         <p><textarea name="notes" id="notes" rows="4" cols="20"></textarea></p>
        </div>
        
        <p class="bottom"></p>
      </div>
      
      <?php
      // NEWSLETTER OPT IN
      // html/basket-checkout/basket-newsletter-opt-in.htm
      echo $this->NEWSLETTER_OPT_IN;
      
      // This div displays initially, but auto disappears if shipping is selected..
      ?>
      <div id="loadBlock">
      
      <?php
      // TOTALS..
      ?>
      <div class="totalsWrapper" id="totalsWrapper">
        
        <h2 class="title">
          <span><?php echo $this->TEXT[7]; ?>:</span>
        </h2>  
        
        <div id="totals">
         <?php
         // BASKET TOTALS
         // html/basket-checkout/basket-total.htm
         echo $this->TOTALS;
         ?>
         <div class="payment_grand" id="basket-total-t-total">
          <span class="payment_amount_grand" id="price-t-total"><?php echo $this->BASKET_TOTAL; ?></span>
          <span class="text_grand"><?php echo $this->TEXT[9]; ?>:</span>
          <input type="hidden" name="t-total" id="t-total" value="<?php echo $this->BASKET_TOTAL_NO_SYMBOL; ?>" />
          
          <br class="clear" />
         </div>
        </div>
         
        <p class="bottom"></p>
      </div> 
         
      <?php
      // PAYMENT METHODS..
      ?>
      <div class="mc_paymentMethods" id="mc_paymentMethods">
        
        <h2 class="title">
          <span><?php echo $this->TEXT[10]; ?>:</span>
        </h2>
           
        <div class="methods">
        <div<?php echo $this->HIDE_TAG; ?>>
          <?php
          // PAYMENT METHODS SELECTIONS
          // html/basket-checkout/basket-payment-methods.htm
          echo $this->PAYMENT_OPTIONS;
          ?>
        </div>
        <p class="inputbutton">
          <input type="hidden" name="process" value="1" />
          <input type="submit" class="button" value="<?php echo $this->TEXT[28]; ?>" title="<?php echo $this->TEXT[28]; ?>" />
        </p>
        </div>
           
        <p class="bottom"></p>
      </div>
      
      </div>
      
      <?php
      // The 'totals' div is not shown by default until shipping has been selected..
      // Adjust if min checkout amount isn`t reached..
      ?>
      <div class="totals" id="no-shipping">
        <p id="textInstructions"><?php echo ($this->IS_MIN_CHECKOUT_SET=='yes' ? $this->TEXT[30] : $this->TEXT[8]); ?></p>
      </div>
      <?php
      
      // ..else show message about empty basket..
      } else {
      ?>
      <p class="empty_basket_img"><img src="<?php echo $this->THEME_FOLDER; ?>/images/empty-basket.png" alt="" title="" /></p>
      <p class="empty_basket"><?php echo $this->TEXT[5]; ?></p>
      <?php
      }
      ?>
      </form>
