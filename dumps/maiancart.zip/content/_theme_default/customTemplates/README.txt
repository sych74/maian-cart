This directory is for the 'System > Manage New Pages' and 'Left Menu Box Controller' via 'System > General Settings' in admin.

Create files here with a '.tpl.php' extension.

-------------
NEW PAGES
-------------

- Specify file as the load file when adding/editing a new page. This will override the system default file and enable you to add in your own PHP for different pages.

- If you want to parse BBCode on a custom template page you can use the following function:

  mc_txtParsingEngine(var);

- For loading of category, see notes in 'example.tpl.php' file

-------------
MENU BOXES
-------------

- See information in docs about the left menu box controller.

  docs/system-1.html
  
- For loading of menu box, see notes in 'box-example.tpl.php' file  
