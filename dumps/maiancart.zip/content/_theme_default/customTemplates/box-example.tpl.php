    <div class="menuBox">
      
      <span class="head"><span>&#043; Menu Box Example</span></span>
      
      <div class="middle">
	   <p style="padding:10px 10px 0 10px">
       <?php
	   echo 'Today is: '.date('l');
	   ?><br /><br />
	   Example menu box.
	   </p>
      </div>
      
      <p class="bottom"></p>
    </div>