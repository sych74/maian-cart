      <h1><?php echo $this->TEXT; ?></h1>
      
      <?php 
      // Editable text in admin area..
      echo $this->BODY_TEXT; 
      ?>
