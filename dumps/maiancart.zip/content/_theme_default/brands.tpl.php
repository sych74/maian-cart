     <?php
      // BRANDS TEMPLATE FILE
      // If required you can recall any value from the brands table via the $this->BDATA array..
      // This is for advanced users only..to see the contents of the array use print_r.
      // print_r($this->BDATA)
      ?>
      <h1><?php echo $this->BRANDNAME; ?></h1>
     
     <div class="catComments">
       <?php echo $this->MESSAGE; ?>
     </div>  
     
     <p class="productFilter">
       <?php 
       // Are the RSS feeds enabled?
       if ($this->SETTINGS->en_rss=='yes') {
       ?>
       <span class="catRss"><a href="<?php echo $this->FEED_URL; ?>" title="<?php echo $this->TEXT[1]; ?>" onclick="window.open(this);return false"><img src="<?php echo $this->THEME_FOLDER; ?>/images/rss.png" alt="<?php echo $this->TEXT[1]; ?>" title="<?php echo $this->TEXT[1]; ?>" /></a></span>
       <?php
       }
       // Show brands filter option if applicable..
       // Also appears in left hand menu..
       ?> 
       <select name="brands" onchange="location=this.options[this.selectedIndex].value" style="margin-right:30px">
         <option value="<?php echo $this->PAGE_URL; ?>"><?php echo $this->TEXT[2]; ?></option>
         <?php
         // CATEGORIES
         // html/html-option-tags.htm
         echo $this->CATEGORIES;
         ?>
       </select>
       <select name="cat" onchange="location=this.options[this.selectedIndex].value">
         <?php
         // BRAND FILTER OPTIONS
         // html/html-option-tags.htm
         echo $this->FILTER_OPTIONS;
         ?>
       </select>
     </p>
     
     <div class="categoryProducts">
      <ul>
      <?php
      // BRAND PRODUCTS
      // html/categories/category-product.htm
      echo $this->PRODUCTS;
      ?>
      </ul>
      <br class="clear" />
     </div>
     
     <?php
     /// Only show page numbers if products exist for brand..
     if ($this->PAGINATION) {
       echo $this->PAGINATION;
     }
     ?>
