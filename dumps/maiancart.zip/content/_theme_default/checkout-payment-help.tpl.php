<!DOCTYPE html>
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=<?php echo $this->CHARSET; ?>" />
<title></title>
<base href="<?php echo $this->BASE_PATH; ?>/" />
<link rel="stylesheet" href="<?php echo $this->BASE_PATH; ?>/<?php echo $this->THEME_FOLDER; ?>/css/stylesheet.css" type="text/css" />
</head>

<body class="windowBody">      

  <div class="windowArea">

  <h1 class="prodDesc"><?php echo $this->TEXT[0]; ?></h1>
      
  <div class="paymentMethodMessage">
  <?php 
  echo $this->TEXT[1]; 
  ?>
  </div>

</div>

</body>
</html>
