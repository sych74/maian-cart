Files in the 'html' folder contain html (HyperText Markup Language) relevant to the parsing of system data.

You can change anything you want here, but be careful NOT to remove system variables enclosed in braces.

Example: {variable}

Always make a copy of the default template folder and refer to this for reference.

------------------
TEXT EDITORS
------------------

There are some excellent free text editors around for editing html. If you don`t have Notepad, a few recommendations are as follows:

- PSPad
  http://www.pspad.com/

- Notepad++
  http://notepad-plus-plus.org 

- Crimson Editor
  http://www.crimsoneditor.com/
  
- EditPad Lite
  http://www.editpadlite.com/
  
- Context
  http://www.contexteditor.org/

- RJ TextEd
  http://www.rj-texted.se/   

----------------
SEARCHING
----------------

If you can`t find a particular variable, use a good search utility to find the language you are looking for and search the 'admin/templates/language/english/' directory. 
Note that the same text may appear in several files.

Recommended free search utilities are:

- Super Finder
  http://fsl.sytes.net

- Copernic
  http://www.copernic.com/en/products/desktop-search/index.html  

- File Seek
  http://www.fileseek.ca
  
- File Locator
  http://www.mythicsoft.com  
  
  
=============================================================================================
NOTE THAT I AM NOT AFFILIATED WITH THE ABOVE PRODUCTS AND THEY ARE USED AT YOUR OWN RISK
=============================================================================================