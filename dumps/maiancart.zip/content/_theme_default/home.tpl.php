      <?php
      // DISPLAY PARENT CATEGORIES ON HOMEPAGE
      // html/categories/home-categories.htm
      // html/categories/home-categories-link.htm
      echo $this->CATEGORIES;
      ?>
      
      <div id="homepageProductsHeader">
        <p><?php echo $this->TXT[0]; ?></p>
      </div>
      
      <div class="categoryProducts">
      
      <ul>
       <?php
       // FEATURED PRODUCTS
       // html/categories/category-product.htm
       echo $this->PRODUCTS;
       ?>
      </ul>
      
      <br class="clear" />
     
     </div>
