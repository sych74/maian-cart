<!DOCTYPE html>
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=<?php echo $this->CHARSET; ?>" />
<title></title>
<base href="<?php echo $this->BASE_PATH; ?>/" />
<link rel="stylesheet" href="<?php echo $this->BASE_PATH; ?>/<?php echo $this->THEME_FOLDER; ?>/css/stylesheet.css" type="text/css" />
<script type="text/javascript" src="<?php echo $this->BASE_PATH; ?>/<?php echo $this->THEME_FOLDER; ?>/js/jquery.js"></script>
<script type="text/javascript" src="<?php echo $this->BASE_PATH; ?>/<?php echo $this->THEME_FOLDER; ?>/js/plugins/jquery.counter.js"></script>
<script type="text/javascript" src="<?php echo $this->BASE_PATH; ?>/<?php echo $this->THEME_FOLDER; ?>/js/cart.js"></script>
</head>

<body class="windowBody">      

  <div class="windowArea">      

  <h1 class="prodDesc"><span class="pers">&nbsp;</span><?php echo $this->TEXT[0]; ?></h1>
      
  <div id="personalisationWindow">

  <form id="form" method="post" onsubmit="return updateProductPersonalisation('<?php echo $_GET['ppCE']; ?>','<?php echo $this->THEME_FOLDER; ?>')" action="<?php echo $this->URL; ?>">      
  <?php 
  // PERSONALISATION OPTIONS
  // html/products/product-personalisation-input.htm
  // html/products/product-personalisation-script.htm
  // html/products/product-personalisation-select.htm
  // html/products/product-personalisation-select-option.htm
  // html/products/product-personalisation-textarea.htm
  // html/products/product-personalisation-wrapper.htm
  echo $this->OPTIONS;
  ?>

  <div class="baseWrapper">
    <p class="message" id="message"><?php echo $this->TEXT[2]; ?></p>
    <p class="update" id="update_spinner"><input type="hidden" name="psUpdate" value="yes" /><input class="button" type="submit" title="<?php echo $this->TEXT[1]; ?>" value="<?php echo $this->TEXT[1]; ?>" /></p>
  </div>

  </form>

  </div>

</div>

</body>
</html>
