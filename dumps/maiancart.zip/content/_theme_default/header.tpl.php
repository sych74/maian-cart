<!DOCTYPE html>
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=<?php echo $this->CHARSET; ?>" />
<title><?php echo $this->TITLE; ?></title>
<meta name="keywords" content="<?php echo $this->META_KEYS; ?>" /> 
<meta name="description" content="<?php echo $this->META_DESC; ?>" />
<?php
// FACEBOOK OPEN GRAPH IMAGE META TAG..
if ($this->FB_OG_META) {
?>
<meta property="og:image" content="<?php echo $this->FB_OG_META; ?>" />
<?php
}
?>
<base href="<?php echo $this->BASE_PATH; ?>/" />
<?php
// RSS LINK
echo $this->RSS_HEAD_LINK; 
// JAVASCRIPT MODULES
// Do NOT remove this. Also, the jQuery library is enabled by default, do NOT include it again in your code!!
echo $this->JAVASCRIPT; 
?>
<link rel="stylesheet" href="<?php echo $this->BASE_PATH.'/'.$this->THEME_FOLDER; ?>/css/stylesheet.css" type="text/css" />
<link rel="SHORTCUT ICON" href="<?php echo $this->BASE_PATH; ?>/favicon.ico" />
<?php
// BANNER SLIDER
if ($this->BANNERS && $this->BANNER_LOADER=='yes') {
?>
<script type="text/javascript">
//<![CDATA[
jQuery(document).ready(function($) {
  jQuery('#slider').bjqs();
});
//]]>
</script>
<?php
}
?>
</head>

<body>
<?php
// overDiv is required for personalisation hover text in basket menu..
?>
<div id="overDiv" style="position:absolute; visibility:hidden; z-index:1000;"></div>

<div id="topBar">

  <div class="inner">
   <p>
   <span class="links">
    <a href="<?php echo $this->BASE_PATH; ?>" class="store" title="<?php echo $this->TEXT[7]; ?>"><?php echo $this->TEXT[7]; ?></a>
    <a href="<?php echo $this->SPECIALS_URL; ?>" class="specials" title="<?php echo $this->TEXT[8]; ?>"><?php echo $this->TEXT[8]; ?></a>
    <a href="<?php echo $this->LATEST_URL; ?>" class="latest" title="<?php echo $this->TEXT[6]; ?>"><?php echo $this->TEXT[6]; ?></a>
    <?php
    // Are RSS feeds enabled?
    if ($this->ENABLE_RSS=='yes') {
    ?>
    <a onclick="window.open(this);return false" href="<?php echo $this->FEED_URL; ?>" class="rsstop" title="<?php echo $this->TEXT[2]; ?>"><?php echo $this->TEXT[2]; ?></a>
    <?php
    }
    // Is sitemap enabled?
    if ($this->ENABLE_SITEMAP=='yes') {
    ?>
    <a href="<?php echo $this->SITEMAP_URL; ?>" class="sitemap" title="<?php echo $this->TEXT[9]; ?>"><?php echo $this->TEXT[9]; ?></a> 
    <?php
    }
    // Is checkout enabled?
    if ($this->ENABLE_CHECKOUT=='yes') {
    ?>
    <a href="<?php echo $this->CHECKOUT_URL; ?>" class="basket" title="<?php echo $this->TEXT[1]; ?>"><?php echo $this->TEXT[1]; ?></a> (<span id="topCartCount"><?php echo $this->CART_COUNT; ?></span>)
    <?php
    }
    ?>
   </span>
   
   <a class="adv_search" href="<?php echo $this->ADVANCED_SEARCH_URL; ?>" title="<?php echo $this->TEXT[5]; ?>"><?php echo $this->TEXT[3]; ?></a>: <input type="text" id="store_search_box" class="box" value="<?php echo $this->TEXT[4]; ?>" name="keys" onclick="if(this.value=='<?php echo $this->TEXT[4]; ?>'){this.value=''}" onblur="if(this.value==''){this.value='<?php echo $this->TEXT[4]; ?>'}" onkeypress="if(mcKeyCodeEvent(event)==13){searchStore('<?php echo $this->BASE_PATH; ?>','<?php echo $this->TEXT[4]; ?>')}" /> <input type="button" value="&gt;" title="<?php echo $this->TEXT[3]; ?>" class="searchbutton" onclick="searchStore('<?php echo $this->BASE_PATH; ?>','<?php echo $this->TEXT[4]; ?>')" />
   
   </p>
  </div>
  
</div>

<div id="logo">
 
  <div id="logoInner">
  
   <div class="left">
 
    <p><a href="<?php echo $this->URL_I; ?>"><img src="<?php echo ($this->STORE_LOGO ? 'content/products/'.$this->STORE_LOGO : $this->THEME_FOLDER.'/images/logo.png'); ?>" alt="<?php echo $this->MY_STORE; ?>" title="<?php echo $this->MY_STORE; ?>" /></a></p>
 
   </div>
  
   <div class="right" id="slider">
    
    <?php
    // HEADER BANNER SLIDER/ROTATOR
    // html/header-slider.htm
    // html/header-slider-img.htm
	// If you don`t want any banners at all, remove the variable or add alternative comment to this div
    echo $this->BANNERS;
    ?>
   
   </div>
  
   <br class="clear" />
   
  </div>  

</div> 

<div id="wrapper">

 <?php
 // Only show breadcrumb links if NOT on checkout page..
 if ($this->ON_CHECKOUT_PAGE=='no') {
 ?>
 <div id="menu">
  <p<?php echo (!$this->CURRENCIES ? ' class="nocur"' : ''); ?>>
  <span class="breadcrumbs"><?php echo $this->BREADCRUMBS; ?></span>
  <span class="currencies">
  <?php
  // If no currencies are enabled for currency converter, show nothing..
  echo ($this->CURRENCIES ? $this->CURRENCIES : '&nbsp;'); 
  ?>
  </span>
  </p>
 </div>
 <?php
 }
 
 // NEWS TICKER..
 // html/ticker-wrapper.htm
 // html/ticker-news-item.htm
 echo $this->NEWS_TICKER;
 ?>
 
 <div id="innerWrapper">
  <?php
  // Are we showing left nav column?
  // Hidden on some new pages and checkout page..
  if ($this->SHOW_LEFT_COLUMN=='yes') {
  ?>
  <div class="leftMenu">
   
    <?php
    // MENU BASKET..
    // Visible on all pages EXCEPT pages in array..
    // Should NOT be visible when on checkout page..
    // Also disable if checkout isn`t enabled..
    if ($this->ENABLE_CHECKOUT=='yes') {
      if (!isset($_GET['p']) || (isset($_GET['p']) && !in_array($_GET['p'],array('checkout','no-gateway')))) {
      ?>
      <div id="shoppingBasket">
      
       <div class="basketItems">
        <p class="top"><span><?php echo $this->SHOPPING_BASKET; ?></span></p>
        <?php
        // BASKET ITEMS
        // html/basket-menu/menu-basket-empty.htm
        // html/basket-menu/menu-basket-item.htm
        // html/basket-menu/menu-basket-item-rebuild.htm
        // html/basket-menu/menu-basket-item-personalisation.htm 
        // html/basket-menu/menu-basket-item-personalisation-hover.htm 
        // html/basket-menu/menu-basket-item-personalisation-hover-item.htm       
        // html/basket-menu/menu-basket-refresh.htm
        // html/basket-menu/menu-basket-wrapper.htm
        echo $this->BASKET_ITEMS;
        ?>
        <p class="bottom"></p>
       </div>
    
      </div>
      <?php 
      }
    }
    
    // LEFT BOXES..
    // Ordered in admin settings..
    
    // CATEGORIES
    // html/left-menu/category-wrapper.htm
    // html/left-menu/category-link.htm
    // html/left-menu/category-sub-click.htm
    // html/left-menu/sub-category-wrapper.htm
    // html/left-menu/sub-category-link.htm
    
    // PRICE POINTS
    // html/left-menu/price-points-wrapper.htm
    // html/left-menu/price-points-link.htm
    
    // BRANDS
    // html/left-menu/brands-wrapper.htm
    // html/left-menu/brands-link.htm
    
    // MOST POPULAR PRODUCTS
    // html/left-menu/most-popular-wrapper.htm
    // html/left-menu/most-popular-links.htm
    
    // RECENTLY VIEWED ITEMS
    // html/left-menu/most-recent-wrapper.htm
    // html/left-menu/most-recent-links.htm
    
    // NEW PAGES / OTHER LINKS..
    // html/left-menu/new-pages-wrapper.htm
    // html/left-menu/new-page-links.htm
    
    // LATEST TWEETS..
    // html/left-menu/latest-tweets.htm
    
    // RSS SCROLLER..
    // html/left-menu/rss-scroller.htm
	
	// CUSTOM BOXES..
	// customTemplates/box**.tpl.php
    
    echo $this->DISPLAY_LEFT_BOXES; 
    ?>
  </div>
  
  <div class="mainContent">
  
    <div class="contentBody">
    
  <?php
  } else {
  // If left column is disabled, wrap in content body div to keep formatting..
  ?>
  <div class="contentBody">  
  <?php
  }
  ?>