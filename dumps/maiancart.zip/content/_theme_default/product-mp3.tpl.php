<?php
// PRODUCT MP3 TEMPLATE FILE
// If required you can recall any value from the product table via the $this->PDATA array..
// This is for advanced users only..to see the contents of the array use print_r.
// print_r($this->PDATA)
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=<?php echo $this->CHARSET; ?>" />
<title><?php echo mc_cleanDataEnt($this->PDATA['pName']); ?></title>
<base href="<?php echo $this->BASE_PATH; ?>/" />
<link rel="stylesheet" href="<?php echo $this->BASE_PATH; ?>/<?php echo $this->THEME_FOLDER; ?>/css/stylesheet.css" type="text/css" />
<script type="text/javascript" src="<?php echo $this->BASE_PATH; ?>/<?php echo $this->THEME_FOLDER; ?>/js/swfobject.js"></script>
<script type="text/javascript" src="<?php echo $this->BASE_PATH; ?>/<?php echo $this->THEME_FOLDER; ?>/js/global.js"></script>
</head>

<body class="windowBody">      

 <div class="windowArea">

  <h1 class="prodDesc"><span class="mp3">&nbsp;</span><?php echo $this->TEXT[0]; ?></h1>
      
  <div id="mp3Wrapper">

  <?php
  // MP3 PREVIEWS..
  // html/products/product-mp3.htm
  // js/global.js (Configuration)
  echo $this->MP3_PREVIEWS;

  ?>

  </div>

</div>

</body>
</html>