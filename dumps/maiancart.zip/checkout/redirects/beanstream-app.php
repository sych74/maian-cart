<?php

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  This File: beanstream-app.php
  Description: Callback redirect file
  
  We use this because beanstream appends ? to the return urls and the default won`t redirect
  correctly. This file must NOT be changed.

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

$basePath = pathinfo(dirname(__FILE__));
define('PATH', substr($basePath['dirname'],0,-9).'/');

// ERROR REPORTING..
include(PATH.'control/error-reporting.php');

// SET PATH TO CART FOLDER..
define('PARENT', 1);

// DATABASE CONNECTION..
include(PATH.'control/connect.inc.php');
include(PATH.'control/functions.php');

// INIT..
include(PATH.'control/system/core/init.php');
  
// CHECK PAYMENT METHOD IS ENABLED..
if (!isset($mcSystemPaymentMethods['beanstream']['ID'])) {
  include(PATH.'control/system/headers/200.php');
  exit;
}

// DETECT SSL..
$ssl = mc_detectSSLConnection();
$url =  ($ssl=='yes' ? str_replace('http://','https://',$SETTINGS->ifolder).'/' : $SETTINGS->ifolder.'/');

if (isset($_GET['ref1'])) {
  $chop = explode('-',$_GET['ref1']);
  header("Location: ".$url."index.php?gw=".$chop[1]."-".$chop[0]);
} else {
  header("Location: ".$url);
}

?>