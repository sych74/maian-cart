<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } 
$payStatuses  = mc_loadDefaultStatuses();
define('CALBOX', 'from|to');
include(PATH.'templates/date-picker.php');
?>
<div id="content">

<?php
echo $msg_salessearch; 
?>
<br /><br />

<div class="fieldHeadWrapper">
  <p><?php echo $msg_salessearch2; ?>:</p>
</div>

<form method="get" action="index.php">
<div class="formFieldWrapper">
  <div class="formLeft" style="width:15%">
    <label><?php echo $msg_salessearch3; ?>: <?php echo mc_displayHelpTip($msg_javascript326,'RIGHT'); ?></label>
    <input type="text" name="invoice" value="<?php echo (isset($_GET['invoice']) ? mc_cleanDataEnt($_GET['invoice']) : ''); ?>" class="box" style="width:70%" /> 
  </div>
  <div class="formLeft" style="width:17%">
    <label><?php echo $msg_salessearch8; ?>: <?php echo mc_displayHelpTip($msg_javascript553,'RIGHT'); ?></label>
    <input type="text" name="code" value="<?php echo (isset($_GET['code']) ? mc_cleanDataEnt($_GET['code']) : ''); ?>" class="box" style="width:70%" /> 
  </div>
  <div class="formLeft" style="width:28%">  
    <label><?php echo $msg_salessearch4; ?>:</label>
    <input id="from" type="text" name="from" value="<?php echo (isset($_GET['from']) ? mc_cleanDataEnt($_GET['from']) : ''); ?>" class="box" style="width:35%" /> <?php echo mc_defineNewline().$msg_salessearch5.mc_defineNewline(); ?> <input id="to" type="text" name="to" value="<?php echo (isset($_GET['to']) ? mc_cleanDataEnt($_GET['to']) : ''); ?>" class="box" style="width:35%" />
  </div>
  <div class="formLeft" style="width:18%">
    <label><?php echo $msg_salessearch6; ?>:</label>
    <input type="text" name="name" value="<?php echo (isset($_GET['name']) ? mc_cleanDataEnt($_GET['name']) : ''); ?>" class="box" /> 
  </div>
  <div class="formRight" style="width:18%">  
    <label><?php echo $msg_salessearch7; ?>:</label>
    <input type="text" name="email" value="<?php echo (isset($_GET['email']) ? mc_cleanDataEnt($_GET['email']) : ''); ?>" class="box" />
  </div>
  <br class="clear" />
</div>

<p style="text-align:center;padding-top:20px">
 <input type="hidden" name="p" value="sales-search" />
 <input type="hidden" name="process" value="yes" />
 <input class="formbutton" type="submit" value="<?php echo mc_cleanDataEnt($msg_salessearch2); ?>" title="<?php echo mc_cleanDataEnt($msg_salessearch2); ?>" />
</p>
</form>

<?php
if (isset($SEARCH)) {
$q_cnts  = mysql_query("SELECT count(*) AS scount,SUM(grandTotal) AS ptotal
           FROM ".DB_PREFIX."sales
           WHERE saleConfirmation = 'yes'
           $searchFilter
           ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
$SUMS    = mysql_fetch_object($q_cnts);
?>
<div class="fieldHeadWrapper" style="margin-top:15px">
  <p><span class="float"><?php echo $msg_productmanage2; ?>: <b><?php echo number_format($SUMS->scount); ?></b></span><?php echo $msg_sales3; ?>:</p>
</div>
<?php
$query = mysql_query("SELECT *,DATE_FORMAT(purchaseDate,'".$SETTINGS->mysqlDateFormat."') AS sdate 
         FROM ".DB_PREFIX."sales
         WHERE saleConfirmation = 'yes'
         $searchFilter
         ORDER BY id
         LIMIT $limit,".PRODUCTS_PER_PAGE."
         ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
if (mysql_num_rows($query)>0) {         
while ($SALES = mysql_fetch_object($query)) {
?>         
<div class="productWrapper">
  <div class="productWrapper_inner">
   <div class="td1"><?php echo mc_saleInvoiceNumber($SALES->invoiceNo); ?></div>
   <div class="td2"><?php echo ($SALES->bill_1 ? mc_cleanData($SALES->bill_1) : '&nbsp;'); ?></div>
   <div class="td3"><?php echo $SALES->sdate; ?></div>
   <div class="td4"><?php echo mc_paymentMethodName($SALES->paymentMethod); ?></div>
   <div class="td5"><?php echo str_replace(array('{id}','{count}'),array($SALES->id,mc_sumCount('purchases WHERE saleID = \''.$SALES->id.'\' AND saleConfirmation = \'yes\'','productQty',true)),$msg_sales31); ?></div>
   <div class="td6"><?php echo mc_currencyFormat(mc_formatPrice($SALES->grandTotal,true)); ?></div>
   <br class="clear" />
   <p class="status"><?php echo statusText($SALES->paymentStatus); ?></p>
  </div>
  <p class="panel">
    <?php
    if ($uDel=='yes') {
    ?>
    <a class="delete" href="?p=sales&amp;delete=<?php echo $SALES->id; ?>" onclick="return confirmMessage('<?php echo mc_cleanDataEnt($msg_javascript45); ?>')" title="<?php echo mc_cleanDataEnt($msg_script10); ?>"><?php echo $msg_script10; ?></a>
    <?php
    }
    ?>
    <a class="edit" href="?p=sales-view&amp;sale=<?php echo $SALES->id; ?>" title="<?php echo mc_cleanDataEnt($msg_sales13); ?>"><?php echo $msg_sales13; ?></a>
    <a class="exp" href="?p=sales&amp;export=<?php echo $SALES->id; ?>" title="<?php echo mc_cleanDataEnt($msg_sales4); ?>"><?php echo $msg_sales4; ?></a>
    <a class="invoice" href="?p=invoice&amp;sale=<?php echo $SALES->id; ?>" onclick="window.open(this);return false" title="<?php echo mc_cleanDataEnt($msg_sales5); ?>"><?php echo $msg_sales5; ?></a>
    <?php
    // Show packing slip link if there are physical products..
    if (mc_rowCount('purchases WHERE saleID = \''.$SALES->id.'\' AND saleConfirmation = \'yes\' AND productType = \'physical\'')>0) {
    ?>
    <a class="packing" href="?p=packing-slip&amp;sale=<?php echo $SALES->id; ?>" onclick="window.open(this);return false" title="<?php echo mc_cleanDataEnt($msg_sales6); ?>"><?php echo $msg_sales6; ?></a>
    <?php
    }
    if (mc_rowCount('purch_pers WHERE saleID = \''.mc_digitSan($SALES->id).'\'')>0) {
    ?>
    <a class="pers" href="?p=sales-view&amp;view-personalisation=<?php echo $SALES->id; ?>" title="<?php echo mc_cleanDataEnt($msg_sales37); ?>" onclick="mc_Window(this.href,'<?php echo GREYBOX_PERS_HEIGHT; ?>','<?php echo GREYBOX_PERS_WIDTH; ?>',this.title);return false;"><?php echo $msg_sales37; ?></a>
    <?php
    }
    if (mc_rowCount('purchases WHERE saleID = \''.$SALES->id.'\' AND saleConfirmation = \'yes\' AND productType = \'download\'')>0) {
    ?>
    <a class="downloads" href="?p=downloads&amp;sale=<?php echo $SALES->id; ?>" title="<?php echo mc_cleanDataEnt($msg_sales38); ?>" onclick="mc_Window(this.href,'<?php echo GREYBOX_DOWNLOADS_HEIGHT; ?>','<?php echo GREYBOX_DOWNLOADS_WIDTH; ?>',this.title);return false;"><?php echo $msg_sales38; ?></a>
    <?php
    }
    ?>
    <a class="update" href="?p=sales-update&amp;sale=<?php echo $SALES->id; ?>" title="<?php echo mc_cleanDataEnt($msg_sales2); ?>"><?php echo $msg_sales2; ?></a>
    <br class="clear" />
  </p>
</div>
<?php
}
define('PER_PAGE',PRODUCTS_PER_PAGE);
if ($SUMS->scount>0 && $SUMS->scount>PER_PAGE) {
  $PTION = new pagination($SUMS->scount,'?p='.$cmd.'&amp;next=');
  echo $PTION->display();
}
} else {
?>
<p class="noData"><?php echo $msg_sales26; ?></p>
<?php
}
} else {
?>
<p style="padding:0 0 100px 0">&nbsp;</p>
<?php
}
?>

</div>
