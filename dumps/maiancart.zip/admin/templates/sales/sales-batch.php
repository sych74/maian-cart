<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } ?>
<div id="content">
<script type="text/javascript">
//<![CDATA[
function checkform() {
  var message = '';
  if (jQuery('#text').val()=='' || jQuery('#title').val()=='') {
    message = '- <?php echo mc_cleanDataEnt($msg_javascript156); ?>';
  }
  if (message) {
    alert(message);
    if (jQuery('#title').val()=='') {
      jQuery('#title').focus();
    } else {
      jQuery('#text').focus();
    }
    return false;
  } else {
    return confirmMessage('<?php echo mc_cleanDataEnt($msg_javascript45); ?>');
  }
}
//]]>
</script>

<?php
if (isset($OK)) {
  echo actionCompleted(str_replace('{count}',count($_POST['batch']),$msg_salesbatch10));
}
echo $msg_salesbatch; 
$payStatuses = mc_loadDefaultStatuses();
$find        = array('{WEBSITE_NAME}','{WEBSITE_URL}');
$replace     = array(mc_cleanData($SETTINGS->website),$SETTINGS->ifolder);
?>
<br /><br />

<div id="form_field">
<form method="post" id="form" action="?p=sales-batch" onsubmit="return checkform()">
<div class="fieldHeadWrapper">
  <p><?php echo $msg_salesbatch2; ?> (<?php echo count($_POST['batch']); ?>)</p>
</div>

<div class="formFieldWrapper">
  <input class="box" type="text" id="title" name="title" tabindex="<?php echo (++$tabIndex); ?>" value="<?php echo str_replace(array('{website}'),array(mc_cleanData($SETTINGS->website)),mc_cleanDataEnt($msg_salesbatch3)); ?>" style="width:95%" />
  <br class="clear" />
</div>

<div class="formFieldWrapper">
  <p class="save" id="save">
   <a href="#" onclick="if (jQuery('#text').val()!=''){addNewStatus('<?php echo str_replace(array('\'','&#039;'),array(),$msg_javascript318); ?>');return false}else{alert('<?php echo str_replace(array('\'','&#039;'),array(),$msg_javascript324); ?>');jQuery('#text').focus();return false}"><img src="templates/images/save_status.png" alt="<?php echo mc_cleanDataEnt($msg_salesbatch4); ?>" title="<?php echo mc_cleanDataEnt($msg_salesbatch4); ?>" /></a>&nbsp;&nbsp;&nbsp;
   <a href="#" onclick="<?php echo (mc_rowCount('status_text')>0 ? 'jQuery(\'#statusesShow\').toggle(\'slow\');' : 'alert(\''.mc_cleanDataEnt($msg_javascript323).'\');'); ?>return false"><img src="templates/images/load_status.png" alt="<?php echo mc_cleanDataEnt($msg_salesbatch5); ?>" title="<?php echo mc_cleanDataEnt($msg_salesbatch5); ?>" /></a>&nbsp;&nbsp;&nbsp;
   <a href="?p=sales-statuses" title="<?php echo mc_cleanDataEnt($msg_salesbatch6); ?>" onclick="mc_Window(this.href,'<?php echo GREYBOX_STATUS_HEIGHT; ?>','<?php echo GREYBOX_STATUS_WIDTH; ?>',this.title);return false;"><img src="templates/images/manage_status.png" alt="<?php echo mc_cleanDataEnt($msg_salesbatch6); ?>" title="<?php echo mc_cleanDataEnt($msg_salesbatch6); ?>" /></a>
  </p>
  <p class="loadStatuses" id="statusesShow" style="display:none">
  <span class="float">
   <a href="#" onclick="jQuery('#statusesShow').hide('slow');return false" title="<?php echo mc_cleanDataEnt($msg_script8); ?>"><img src="templates/images/close.png" alt="<?php echo mc_cleanDataEnt($msg_script8); ?>" title="<?php echo mc_cleanDataEnt($msg_script8); ?>" /></a>
  </span>
  <select onchange="if(this.value>0){loadStatusText(this.value)}">
  <option value="0">- - - - - -</option>
  <?php
  $query = mysql_query("SELECT * FROM ".DB_PREFIX."status_text ORDER BY statTitle")
           or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  while ($STATUS = mysql_fetch_object($query)) {
  ?>
  <option value="<?php echo $STATUS->id; ?>"><?php echo mc_cleanDataEnt($STATUS->statTitle); ?></option>
  <?php
  }
  ?>
  </select>
  </p>  
  <textarea rows="5" tabindex="<?php echo (++$tabIndex); ?>" cols="30" id="text" name="text" class="updatetextarea"><?php echo mc_cleanDataEnt(str_replace($find,$replace,file_get_contents(MCLANG.'email-templates/order-updated-batch.txt'))); ?></textarea>
  <p class="variables"><?php echo $msg_salesbatch7; ?></p>
</div>

<div class="formFieldWrapper">
  <div class="formRight" style="width:33%">
    <label><?php echo $msg_salesbatch11; ?>: <?php echo mc_displayHelpTip($msg_javascript538,'RIGHT'); ?></label>
    <select name="status" id="status" tabindex="<?php echo (++$tabIndex); ?>">
    <?php
    foreach ($payStatuses AS $key => $value) {
    ?>
    <option value="<?php echo $key; ?>"><?php echo $value; ?></option>
    <?php
    }
    // Get additional payment statuses..
    $q_add_stats = mysql_query("SELECT * FROM `".DB_PREFIX."paystatuses` 
                   WHERE `pMethod` IN('all')
                   ORDER BY `pMethod`,`statname`
                   ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    if (mysql_num_rows($q_add_stats)>0) {
    ?>
    <option value="0" disabled="disabled">- - - - - - - - -</option>
    <?php
    }
    while ($ST = mysql_fetch_object($q_add_stats)) {
    ?>
    <option value="<?php echo $ST->id; ?>"><?php echo mc_cleanData($ST->statname); ?></option>
    <?php
    }
    ?>
    </select>
  </div>
  <div class="formLeft" style="width:28%;padding-top:15px">
   <input tabindex="<?php echo (++$tabIndex); ?>" type="checkbox" name="email" value="yes" checked="checked" /> <?php echo $msg_salesbatch8; ?>
  </div>
  <div class="formRight" style="width:38%;padding-top:10px;text-align:right">
   <?php echo $msg_salesbatch9; ?> <input type="text" tabindex="<?php echo (++$tabIndex); ?>" class="box" name="copy_email" value="<?php echo ($SETTINGS->batchMail ? mc_cleanDataEnt($SETTINGS->batchMail) : ''); ?>" style="width:60%" /> <?php echo mc_displayHelpTip($msg_javascript249,'LEFT'); ?>
  </div>
  <br class="clear" />
</div> 

<div class="fieldHeadWrapper" style="margin-top:15px">
  <p><?php echo $msg_salesbatch12; ?> (<?php echo count($_POST['batch']); ?>)</p>
</div>

<?php
for ($i=0; $i<count($_POST['batch']); $i++) {
$ORDER  = mc_getTableData('sales','id',mc_digitSan($_POST['batch'][$i]));
?>
<div class="batchSales" id="batch_sale_<?php echo $ORDER->id; ?>">
  <input type="hidden" name="batch[]" value="<?php echo $ORDER->id; ?>" />
  <div class="batchLeft">
    <p>#<?php echo mc_saleInvoiceNumber($ORDER->invoiceNo); ?> (<?php echo mc_cleanDataEnt($ORDER->bill_1); ?>, <?php echo date($SETTINGS->systemDateFormat,strtotime($ORDER->purchaseDate)); ?>)</p>
  </div>
  <div class="batchCenter">
    <p>[ <a href="#" onclick="jQuery('#batch_sale_<?php echo $ORDER->id; ?>').remove();return false" title="<?php echo mc_cleanDataEnt($msg_salesbatch13); ?>"><?php echo mc_cleanDataEnt($msg_salesbatch13); ?></a> ]</p>
  </div>
  <div class="batchRight">
    <p><a href="?p=sales&amp;ordered=<?php echo $ORDER->id; ?>" title="<?php echo mc_cleanDataEnt($msg_salesbatch14); ?>" onclick="mc_Window(this.href,'<?php echo GREYBOX_PRODUCTS_HEIGHT; ?>','<?php echo GREYBOX_PRODUCTS_WIDTH; ?>',this.title);return false;"><img src="templates/images/big-view.png" alt="<?php echo mc_cleanDataEnt($msg_salesbatch14); ?>" title="<?php echo mc_cleanDataEnt($msg_salesbatch14); ?>" /></a></p>
  </div>
  <br class="clear" />
</div>
<?php
}
?>

<p style="text-align:center;padding:20px 0 20px 0">
 <input type="hidden" name="process" value="yes" />
 <input class="formbutton" type="submit" value="<?php echo mc_cleanDataEnt($msg_salesbatch2); ?>" title="<?php echo mc_cleanDataEnt($msg_salesbatch2); ?>" />
 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input class="formbutton2" type="button" onclick="window.location='?p=sales'" value="<?php echo mc_cleanDataEnt($msg_script11); ?>" title="<?php echo mc_cleanDataEnt($msg_script11); ?>" />
</p>

</form>
</div>
<p>&nbsp;</p>
</div>
