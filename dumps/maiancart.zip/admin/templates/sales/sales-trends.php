<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } 
$range = (isset($_GET['range']) && in_array($_GET['range'],array(3,6,12,24,'year')) ? $_GET['range'] : 
         (DEFAULT_SALES_TREND && in_array(strtolower(DEFAULT_SALES_TREND),array(3,6,12,24,'year')) ? 
         strtolower(DEFAULT_SALES_TREND) : 
         'year')
);
$cat   = (isset($_GET['cat']) && is_numeric($_GET['cat']) ? $_GET['cat'] : '0');
?>
<div id="content">

<?php
echo $msg_stats22
?>
<br /><br />

<div class="statsTop">
  <div class="left">
    <select onchange="if(this.value!= 0){location=this.options[this.selectedIndex].value}">
    <option value="?p=stats"><?php echo $msg_stats6; ?></option>
    <?php
    $q_cats = mysql_query("SELECT * FROM `".DB_PREFIX."categories` 
              WHERE `catLevel` = '1'
              AND `childOf`    = '0'
              AND `enCat`      = 'yes'
              ORDER BY `catname`
			  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($CATS = mysql_fetch_object($q_cats)) {
    ?>
    <option value="?p=sales-trends&amp;cat=<?php echo $CATS->id.'&amp;range='.$range; ?>"<?php echo (isset($_GET['cat']) && $_GET['cat']==$CATS->id ? ' selected="selected"' : ''); ?>><?php echo mc_cleanDataEnt($CATS->catname); ?></option>
    <?php
    $q_children = mysql_query("SELECT * FROM `".DB_PREFIX."categories` 
                  WHERE `catLevel` = '2'
                  AND `enCat`      = 'yes'
                  AND `childOf`    = '".$CATS->id."'
                  ORDER BY `catname`
				  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($CHILDREN = mysql_fetch_object($q_children)) {
    ?>
    <option value="?p=sales-trends&amp;cat=<?php echo $CHILDREN->id.'&amp;range='.$range; ?>"<?php echo (isset($_GET['cat']) && $_GET['cat']==$CHILDREN->id ? ' selected="selected"' : ''); ?>>- <?php echo mc_cleanDataEnt($CHILDREN->catname); ?></option>
    <?php
    $q_infants = mysql_query("SELECT * FROM `".DB_PREFIX."categories` 
                 WHERE `catLevel` = '3'
                 AND `childOf`    = '{$CHILDREN->id}'
                 AND `enCat`      = 'yes'
                 ORDER BY `catname`
                 ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($INFANTS = mysql_fetch_object($q_infants)) {
    ?>
    <option value="?p=sales-trends&amp;cat=<?php echo $INFANTS->id.'&amp;range='.$range; ?>"<?php echo (isset($_GET['cat']) && $_GET['cat']==$INFANTS->id ? ' selected="selected"' : ''); ?>>&nbsp;&nbsp;- <?php echo mc_cleanDataEnt($INFANTS->catname); ?></option>
    <?php
    }
    }
    }
    ?>
    </select>
  </div>
  <div class="right">
    <p>
    <select onchange="if(this.value!= 0){location=this.options[this.selectedIndex].value}">
    <option value="?p=sales-trends&amp;cat=<?php echo $cat; ?>&amp;range=year"<?php echo ($range=='year' ? ' selected="selected"' : ''); ?>><?php echo $msg_stats24; ?></option>
    <option value="?p=sales-trends&amp;cat=<?php echo $cat; ?>&amp;range=3"<?php echo ($range==3 ? ' selected="selected"' : ''); ?>><?php echo str_replace('{duration}',3,$msg_stats20); ?></option>
    <option value="?p=sales-trends&amp;cat=<?php echo $cat; ?>&amp;range=6"<?php echo ($range==6 ? ' selected="selected"' : ''); ?>><?php echo str_replace('{duration}',6,$msg_stats20); ?></option>
    <option value="?p=sales-trends&amp;cat=<?php echo $cat; ?>&amp;range=12"<?php echo ($range==12 ? ' selected="selected"' : ''); ?>><?php echo str_replace('{duration}',12,$msg_stats20); ?></option>
    <option value="?p=sales-trends&amp;cat=<?php echo $cat; ?>&amp;range=24"<?php echo ($range==24 ? ' selected="selected"' : ''); ?>><?php echo str_replace('{duration}',24,$msg_stats20); ?></option>
    </select>
    </p>
  </div>
  <br class="clear" />
</div>

<div class="fieldHeadWrapper">
  <p><?php echo $msg_stats25; ?>:</p>
</div>

<?php
if (mc_rowCount('purchases WHERE `saleConfirmation` = \'yes\'')>0) {
?>
<div class="graphStats">
  <div class="salesTrends" style="padding:5px">
    <div id="chartdiv_trends"></div>
    <script type="text/javascript">
     //<![CDATA[
     jQuery(document).ready(function() {  
     <?php
     $months = array();
     $line1  = array();
     $line2  = array();
	 $line3  = array();
     $ts     = strtotime(date("Y-m-d"));
     switch ($range) {
       case 'year':
       for ($i=1; $i<13; $i++) {
         $y                     = date('y',$ts);
         $year                  = date('Y',$ts);
         $nm                    = ($i<10 ? '0'.$i : $i);
         $m                     = $msg_script41[$i-1];
         $m                     = str_replace("'","\'",$m);
         $months[]              = "'$m $y'";
         $line1[$nm.'-'.$year]  = 0;
         $line2[$nm.'-'.$year]  = 0; 
		 $line3[$nm.'-'.$year]  = 0; 
       }
       $SQL  = "AND `purchaseDate` BETWEEN '".date("Y",$ts)."-01-01' AND '".date("Y",$ts)."-12-31'";
       break;
       default:
       for ($i=($range-1); $i>-1; $i--) {
         $y                     = date('y',strtotime('-'.$i.' months',$ts));
         $year                  = date('Y',strtotime('-'.$i.' months',$ts));
         $nm                    = date('m',strtotime('-'.$i.' months',$ts));
         $m                     = $msg_script41[date('n',strtotime('-'.$i.' months',$ts))-1];
         $m                     = str_replace("'","\'",$m);
         $months[]              = "'$m $y'";
         $line1[$nm.'-'.$year]  = 0;
         $line2[$nm.'-'.$year]  = 0; 
		 $line3[$nm.'-'.$year]  = 0; 
       }
       $SQL  = "AND `purchaseDate` > DATE_SUB(CURDATE(),INTERVAL ".($range-1)." MONTH)".mc_defineNewline();
       break;
     }  
     $qs  = mysql_query("SELECT MONTH(`purchaseDate`) as `m`,
            YEAR(`purchaseDate`) AS `y`,
            SUM(`productQty`) AS `qty`,
            `productType`
            FROM `".DB_PREFIX."purchases` 
            WHERE `saleConfirmation` = 'yes'
            $SQL
            ".($cat>0 ? 'AND `categoryID` = \''.$cat.'\'' : '')."
            GROUP BY 2,1
            ORDER BY YEAR(`purchaseDate`),MONTH(`purchaseDate`)
            ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
     while ($P_P = mysql_fetch_object($qs)) {
       $P_P->m = ($P_P->m<10 ? '0'.$P_P->m : $P_P->m);
       switch ($P_P->productType) {
	     case 'physical':
         $line1[$P_P->m.'-'.$P_P->y] = ($line1[$P_P->m.'-'.$P_P->y]+$P_P->qty);
		 break;
         case 'download':
		 $line2[$P_P->m.'-'.$P_P->y] = ($line2[$P_P->m.'-'.$P_P->y]+$P_P->qty);
		 break;
		 case 'virtual':
		 $line3[$P_P->m.'-'.$P_P->y] = ($line3[$P_P->m.'-'.$P_P->y]+$P_P->qty);
		 break;
       }
     }
     ?>
     line1 = [<?php echo implode(',',$line1); ?>];
     line2 = [<?php echo implode(',',$line2); ?>];
	 line3 = [<?php echo implode(',',$line3); ?>];
     ticks = [<?php echo implode(',',$months); ?>];
     plot1 = jQuery.jqplot('chartdiv_trends', [line1,line2,line3], {
                       grid: {
                         borderWidth: 0,
                         shadow: false
                       },
                       axes: {
                         yaxis: {
                           min: 0,
                           tickOptions: {
                             formatString: '%d'
                           }
                         },
                         xaxis: { 
                           rendererOptions:{
                             tickRenderer: jQuery.jqplot.CanvasAxisTickRenderer
                           },
                           ticks:ticks,
                           <?php
                           if ($range=='24') {
                           ?>
                           tickOptions: {
                             fontSize: '9px',
                             fontFamily: 'Arial',
                             angle:-40
                           },
                           <?php
                           }
                           ?>
                           renderer: jQuery.jqplot.CategoryAxisRenderer
                         }
                       },
                       series: [{
                          lineWidth: 1, 
                          label: '<?php echo str_replace("'","\'",$msg_stats12); ?>'
                       },{
                          lineWidth: 1, 
                          label: '<?php echo str_replace("'","\'",$msg_stats13); ?>'
                       },{
                          lineWidth: 1, 
                          label: '<?php echo str_replace("'","\'",$msg_stats28); ?>'
                       }],
                       legend: {
                         show: true
                       }
     });
     });
     //]]>
    </script>
  </div>
</div>

<div class="fieldHeadWrapper" style="margin-top:10px">
  <p><?php echo $msg_stats23; ?>:</p>
</div>

<div class="graphStats" style="margin-top:10px">
  <div class="salesTrends" style="padding:5px">
    <div id="chartdiv_trends2"></div>
    <script type="text/javascript">
     //<![CDATA[
     jQuery(document).ready(function() {  
     <?php
     $months = array();
     $line1  = array();
     $line2  = array();
	 $line3  = array();
     $ts     = strtotime(date("Y-m-d"));
     switch ($range) {
       case 'year':
       for ($i=1; $i<13; $i++) {
         $y                     = date('y',$ts);
         $year                  = date('Y',$ts);
         $nm                    = ($i<10 ? '0'.$i : $i);
         $m                     = $msg_script41[$i-1];
         $m                     = str_replace("'","\'",$m);
         $months[]              = "'$m $y'";
         $line1[$nm.'-'.$year]  = 0;
         $line2[$nm.'-'.$year]  = 0; 
		 $line3[$nm.'-'.$year]  = 0; 
       }
       $SQL  = "AND purchaseDate BETWEEN '".date("Y",$ts)."-01-01' AND '".date("Y",$ts)."-12-31'";
       break;
       default:
       for ($i=($range-1); $i>-1; $i--) {
         $y                     = date('y',strtotime('-'.$i.' months',$ts));
         $year                  = date('Y',strtotime('-'.$i.' months',$ts));
         $nm                    = date('m',strtotime('-'.$i.' months',$ts));
         $m                     = $msg_script41[date('n',strtotime('-'.$i.' months',$ts))-1];
         $m                     = str_replace("'","\'",$m);
         $months[]              = "'$m $y'";
         $line1[$nm.'-'.$year]  = 0;
         $line2[$nm.'-'.$year]  = 0; 
		 $line3[$nm.'-'.$year]  = 0; 
       }
       $SQL  = "AND `purchaseDate` > DATE_SUB(CURDATE(),INTERVAL ".($range-1)." MONTH)".mc_defineNewline();
       break;
     }
     $qs  = mysql_query("SELECT MONTH(`purchaseDate`) AS `m`,
            YEAR(`purchaseDate`) AS `y`,
            SUM((`salePrice`+`persPrice`+`attrPrice`)*`productQty`) AS `g`,
            `productType`
            FROM `".DB_PREFIX."purchases` 
            WHERE `saleConfirmation` = 'yes'
            $SQL
            ".($cat>0 ? 'AND `categoryID` = \''.$cat.'\'' : '')."
            GROUP BY 1,2,4
            ORDER BY YEAR(`purchaseDate`),MONTH(`purchaseDate`)
            ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
     while ($P_P = mysql_fetch_object($qs)) {
       $P_P->m = ($P_P->m<10 ? '0'.$P_P->m : $P_P->m);
       switch ($P_P->productType) {
	     case 'physical':
         $line1[$P_P->m.'-'.$P_P->y] += mc_formatPrice($P_P->g);
		 break;
         case 'download':
		 $line2[$P_P->m.'-'.$P_P->y] += mc_formatPrice($P_P->g);
		 break;
		 case 'virtual':
		 $line3[$P_P->m.'-'.$P_P->y] += mc_formatPrice($P_P->g);
		 break;
       }
     }
     ?>
     line1 = [<?php echo implode(',',$line1); ?>];
     line2 = [<?php echo implode(',',$line2); ?>];
	 line3 = [<?php echo implode(',',$line3); ?>];
     ticks = [<?php echo implode(',',$months); ?>];
     plot1 = jQuery.jqplot('chartdiv_trends2', [line1,line2,line3], {
                       grid: {
                         borderWidth: 0,
                         shadow: false
                       },
                       axes: {
                         yaxis: {
                           tickOptions: {
                             formatString: '%.2f'
                           },
                           min: 0
                         },
                         xaxis: { 
                           rendererOptions:{
                             tickRenderer: jQuery.jqplot.CanvasAxisTickRenderer
                           },
                           ticks:ticks, 
                           <?php
                           if ($range=='24') {
                           ?>
                           tickOptions: {
                             fontSize: '9px',
                             fontFamily: 'Arial',
                             angle:-40
                           },
                           <?php
                           }
                           ?>
                           renderer: jQuery.jqplot.CategoryAxisRenderer
                         }
                       },
                       series: [{
                          lineWidth: 1, 
                          label: '<?php echo str_replace("'","\'",$msg_stats12); ?>'
                       },{
                          lineWidth: 1, 
                          label: '<?php echo str_replace("'","\'",$msg_stats13); ?>'
                       },{
                          lineWidth: 1, 
                          label: '<?php echo str_replace("'","\'",$msg_stats28); ?>'
                       }],
                       legend: {
                         show: true
                       }
     });
     });
     //]]>
    </script>
  </div>
  <p class="rendering" style="text-align:right;padding:15px"><?php echo $msg_script51; ?>: <a href="http://www.jqPlot.com" onclick="window.open(this);return false" title="jqPlot">jqPlot</a> &copy; Chris Leonello</p>
</div>
<?php
} else {
?>
<div class="graphStats">
  <p class="noData"><?php echo $msg_sales17; ?></p>
</div>
<?php
}
?>

</div>
