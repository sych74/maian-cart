<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } 
$payStatuses  = mc_loadDefaultStatuses();
// Set filter here..
$sqlFilter  = (isset($_GET['filter']) && (array_key_exists($_GET['filter'],$payStatuses) || is_numeric($_GET['filter'])) ? 'AND `paymentStatus` = \''.$_GET['filter'].'\'' : '');
$sqlFilter .= ($sqlFilter ? mc_defineNewline() : '').(isset($_GET['country']) ? 'AND `shipSetCountry` = \''.mc_digitSan($_GET['country']).'\'' : '');
$sqlFilter .= ($sqlFilter ? mc_defineNewline() : '').(isset($_GET['pm']) && in_array($_GET['pm'],array_keys($mcSystemPaymentMethods)) ? 'AND `paymentMethod` = \''.$_GET['pm'].'\'' : '');
$sqlOrder   = 'id DESC';
if (isset($_GET['orderby'])) {
  switch ($_GET['orderby']) {
    case 'date_asc':   $sqlOrder   = 'purchaseDate';         break;
    case 'date_desc':  $sqlOrder   = 'purchaseDate DESC';    break;
    case 'price_asc':  $sqlOrder   = 'grandTotal*1000';      break;
    case 'price_desc': $sqlOrder   = 'grandTotal*1000 DESC'; break;
    case 'name_asc':   $sqlOrder   = 'bill_1';               break;
    case 'name_desc':  $sqlOrder   = 'bill_1 DESC';          break;
  }
}
if (isset($_GET['country'])) {
  $_GET['country'] = mc_digitSan($_GET['country']);
}
// Get counts..
$q_cnts  = mysql_query("SELECT count(*) AS `scount`,SUM(grandTotal) AS `ptotal`
           FROM `".DB_PREFIX."sales`
           WHERE `saleConfirmation` = 'yes'
           $sqlFilter
           ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
$SUMS    = mysql_fetch_object($q_cnts);
?>
<div id="content">

<?php
if (isset($OK) && $cnt>0) {
  echo actionCompleted($msg_sales40);
}
echo $msg_sales; 
?>
<br /><br />

<div class="salesTop">
  <p><span class="float"><?php echo str_replace('{total}',mc_currencyFormat(mc_formatPrice($SUMS->ptotal,true)),$msg_sales14); ?></span>
  <b><?php echo $msg_sales10; ?></b>: 
  <select onchange="if(this.value!= 0){location=this.options[this.selectedIndex].value}">
  <option value="?p=sales&amp;next=<?php echo $page.(isset($_GET['country']) ? '&amp;country='.$_GET['country'] : '').(isset($_GET['orderby']) ? '&amp;orderby='.$_GET['orderby'] : '').(isset($_GET['pm']) ? '&amp;pm='.$_GET['pm'] : ''); ?>"><?php echo $msg_sales11; ?></option>
  <?php
  foreach ($payStatuses AS $key => $value) {
  ?>
  <option value="?p=sales&amp;next=<?php echo $page; ?>&amp;filter=<?php echo $key.(isset($_GET['country']) ? '&amp;country='.$_GET['country'] : '').(isset($_GET['orderby']) ? '&amp;orderby='.$_GET['orderby'] : '').(isset($_GET['pm']) ? '&amp;pm='.$_GET['pm'] : ''); ?>"<?php echo (isset($_GET['filter']) && $_GET['filter']==$key ? ' selected="selected"' : ''); ?>><?php echo $value; ?></option>
  <?php
  }
  // Get additional payment statuses..
  $q_add_stats = mysql_query("SELECT * FROM ".DB_PREFIX."paystatuses 
                 ORDER BY `pMethod`,`statname`
                 ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  if (mysql_num_rows($q_add_stats)>0) {
  ?>
  <option value="0" disabled="disabled">- - - - - - - - -</option>
  <?php
  }
  while ($ST = mysql_fetch_object($q_add_stats)) {
  ?>
  <option value="?p=sales&amp;next=<?php echo $page; ?>&amp;filter=<?php echo $ST->id.(isset($_GET['country']) ? '&amp;country='.$_GET['country'] : '').(isset($_GET['orderby']) ? '&amp;orderby='.$_GET['orderby'] : '').(isset($_GET['pm']) ? '&amp;pm='.$_GET['pm'] : ''); ?>"<?php echo (isset($_GET['filter']) && $_GET['filter']==$ST->id ? ' selected="selected"' : ''); ?>><?php echo mc_cleanData($ST->statname); ?></option>
  <?php
  }
  ?>
  </select>
  </p>
</div>

<div class="salesTopFilter">
  <p>
    <span class="left">
    <?php echo $msg_sales19; ?>: <select onchange="if(this.value!= 0){location=this.options[this.selectedIndex].value}">
    <option value="?p=sales&amp;orderby=date_desc<?php echo (isset($_GET['country']) ? '&amp;country='.$_GET['country'] : '').(isset($_GET['filter']) ? '&amp;filter='.$_GET['filter'] : '').(isset($_GET['pm']) ? '&amp;pm='.$_GET['pm'] : ''); ?>"<?php echo (isset($_GET['orderby']) && $_GET['orderby']=='date_desc' ? ' selected="selected"' : ''); ?>><?php echo $msg_sales20; ?></option>
    <option value="?p=sales&amp;orderby=date_asc<?php echo (isset($_GET['country']) ? '&amp;country='.$_GET['country'] : '').(isset($_GET['filter']) ? '&amp;filter='.$_GET['filter'] : '').(isset($_GET['pm']) ? '&amp;pm='.$_GET['pm'] : ''); ?>"<?php echo (isset($_GET['orderby']) && $_GET['orderby']=='date_asc' ? ' selected="selected"' : ''); ?>><?php echo $msg_sales21; ?></option>
    <option value="?p=sales&amp;orderby=price_desc<?php echo (isset($_GET['country']) ? '&amp;country='.$_GET['country'] : '').(isset($_GET['filter']) ? '&amp;filter='.$_GET['filter'] : '').(isset($_GET['pm']) ? '&amp;pm='.$_GET['pm'] : ''); ?>"<?php echo (isset($_GET['orderby']) && $_GET['orderby']=='price_desc' ? ' selected="selected"' : ''); ?>><?php echo $msg_sales22; ?></option>
    <option value="?p=sales&amp;orderby=price_asc<?php echo (isset($_GET['country']) ? '&amp;country='.$_GET['country'] : '').(isset($_GET['filter']) ? '&amp;filter='.$_GET['filter'] : '').(isset($_GET['pm']) ? '&amp;pm='.$_GET['pm'] : ''); ?>"<?php echo (isset($_GET['orderby']) && $_GET['orderby']=='price_asc' ? ' selected="selected"' : ''); ?>><?php echo $msg_sales23; ?></option>
    <option value="?p=sales&amp;orderby=name_asc<?php echo (isset($_GET['country']) ? '&amp;country='.$_GET['country'] : '').(isset($_GET['filter']) ? '&amp;filter='.$_GET['filter'] : '').(isset($_GET['pm']) ? '&amp;pm='.$_GET['pm'] : ''); ?>"<?php echo (isset($_GET['orderby']) && $_GET['orderby']=='name_asc' ? ' selected="selected"' : ''); ?>><?php echo $msg_sales24; ?></option>
    <option value="?p=sales&amp;orderby=name_desc<?php echo (isset($_GET['country']) ? '&amp;country='.$_GET['country'] : '').(isset($_GET['filter']) ? '&amp;filter='.$_GET['filter'] : '').(isset($_GET['pm']) ? '&amp;pm='.$_GET['pm'] : ''); ?>"<?php echo (isset($_GET['orderby']) && $_GET['orderby']=='name_desc' ? ' selected="selected"' : ''); ?>><?php echo $msg_sales25; ?></option>
    </select>
    </span>
    <span class="middle">
    <?php echo $msg_sales18; ?>:
    <select onchange="if(this.value!= 0){location=this.options[this.selectedIndex].value}">
    <option value="?p=sales<?php echo (isset($_GET['orderby']) ? '&amp;orderby='.$_GET['orderby'] : '').(isset($_GET['filter']) ? '&amp;filter='.$_GET['filter'] : '').(isset($_GET['pm']) ? '&amp;pm='.$_GET['pm'] : ''); ?>"><?php echo $msg_sales29; ?></option>
    <?php
    $q_c = mysql_query("SELECT * FROM ".DB_PREFIX."countries 
           WHERE `enCountry` = 'yes' 
           ORDER BY `cName`
           ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($C = mysql_fetch_object($q_c)) {
    ?>
    <option value="?p=sales&amp;country=<?php echo $C->id; ?><?php echo (isset($_GET['orderby']) ? '&amp;orderby='.$_GET['orderby'] : '').(isset($_GET['filter']) ? '&amp;filter='.$_GET['filter'] : '').(isset($_GET['pm']) ? '&amp;pm='.$_GET['pm'] : ''); ?>"<?php echo (isset($_GET['country']) && $_GET['country']==$C->id ? ' selected="selected"' : ''); ?>><?php echo mc_cleanData($C->cName); ?></option>
    <?php
    }
    ?>
    </select>
    </span>
    <span class="right">
    <?php echo $msg_sales27; ?>:
    <select onchange="if(this.value!= 0){location=this.options[this.selectedIndex].value}">
    <option value="?p=sales<?php echo (isset($_GET['orderby']) ? '&amp;orderby='.$_GET['orderby'] : '').(isset($_GET['filter']) ? '&amp;filter='.$_GET['filter'] : '').(isset($_GET['country']) ? '&amp;country='.$_GET['country'] : ''); ?>"><?php echo $msg_sales28; ?></option>
    <?php
    if (!empty($mcSystemPaymentMethods)) {
    foreach ($mcSystemPaymentMethods AS $key => $value) {
	if ($value['enable']=='yes') {
    ?>
    <option value="?p=sales&amp;pm=<?php echo $key; ?><?php echo (isset($_GET['orderby']) ? '&amp;orderby='.$_GET['orderby'] : '').(isset($_GET['filter']) ? '&amp;filter='.$_GET['filter'] : '').(isset($_GET['country']) ? '&amp;country='.$_GET['country'] : ''); ?>"<?php echo (isset($_GET['pm']) && $_GET['pm']==$key ? ' selected="selected"' : ''); ?>><?php echo $value['lang']; ?></option>
    <?php
	}
    }
    }
    ?>
    </select>
    </span>
    <br class="clear" />
  </p>
</div>

<div id="formField">
<form method="post" action="?p=sales-batch">

<div class="fieldHeadWrapper">
  <p><span class="float"><?php echo $msg_productmanage2; ?>: <b><?php echo number_format($SUMS->scount); ?></b></span><?php echo $msg_sales3; ?></p>
</div>

<?php
$query = mysql_query("SELECT *,DATE_FORMAT(`purchaseDate`,'".$SETTINGS->mysqlDateFormat."') AS `sdate`
         FROM `".DB_PREFIX."sales`
         WHERE `saleConfirmation` = 'yes'
         $sqlFilter
         ORDER BY $sqlOrder
         LIMIT $limit,".PRODUCTS_PER_PAGE."
         ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
if (mysql_num_rows($query)>0) {         
while ($SALES = mysql_fetch_object($query)) {
?>         
<div class="productWrapper">
  <div class="productWrapper_inner">
   <div class="td1"><?php echo mc_saleInvoiceNumber($SALES->invoiceNo); ?></div>
   <div class="td2"><?php echo ($SALES->bill_1 ? mc_cleanData($SALES->bill_1) : '&nbsp;'); ?></div>
   <div class="td3"><?php echo $SALES->sdate; ?></div>
   <div class="td4"><?php echo mc_paymentMethodName($SALES->paymentMethod); ?></div>
   <div class="td5"><?php echo str_replace(array('{id}','{count}'),array($SALES->id,mc_sumCount('purchases WHERE `saleID` = \''.$SALES->id.'\' AND `saleConfirmation` = \'yes\'','productQty',true)),$msg_sales31); ?></div>
   <div class="td6"><?php echo mc_currencyFormat(mc_formatPrice($SALES->grandTotal,true)); ?></div>
   <br class="clear" />
   <p class="status"><?php echo statusText($SALES->paymentStatus); ?></p>
  </div>
  <p class="panel">
    <span style="float:left;padding-left:10px">
	 <input type="checkbox" name="batch[]" value="<?php echo $SALES->id; ?>" />
	</span> 
    <?php
    if ($uDel=='yes') {
    ?>
    <a class="delete" href="?p=sales&amp;delete=<?php echo $SALES->id; ?>" onclick="return confirmMessage('<?php echo mc_cleanDataEnt($msg_javascript45); ?>')" title="<?php echo mc_cleanDataEnt($msg_script10); ?>"><?php echo $msg_script10; ?></a>
    <?php
    }
    ?>
    <a class="edit" href="?p=sales-view&amp;sale=<?php echo $SALES->id; ?>" title="<?php echo mc_cleanDataEnt($msg_sales13); ?>"><?php echo $msg_sales13; ?></a>
    <a class="exp" href="?p=sales&amp;export=<?php echo $SALES->id; ?>" title="<?php echo mc_cleanDataEnt($msg_sales4); ?>"><?php echo $msg_sales4; ?></a>
    <a class="invoice" href="?p=invoice&amp;sale=<?php echo $SALES->id; ?>" onclick="window.open(this);return false" title="<?php echo mc_cleanDataEnt($msg_sales5); ?>"><?php echo $msg_sales5; ?></a>
    <?php
    // Show packing slip link if there are physical products..
    if (mc_rowCount('purchases WHERE `saleID` = \''.$SALES->id.'\' AND `saleConfirmation` = \'yes\' AND `productType` = \'physical\'')>0) {
    ?>
    <a class="packing" href="?p=packing-slip&amp;sale=<?php echo $SALES->id; ?>" onclick="window.open(this);return false" title="<?php echo mc_cleanDataEnt($msg_sales6); ?>"><?php echo $msg_sales6; ?></a>
    <?php
    }
    // Show personalisation link if there are personalised products..
    if (mc_rowCount('purch_pers WHERE `saleID` = \''.mc_digitSan($SALES->id).'\'')>0) {
    ?>
    <a class="pers" href="?p=sales-view&amp;view-personalisation=<?php echo $SALES->id; ?>" title="<?php echo mc_cleanDataEnt($msg_sales37); ?>" onclick="mc_Window(this.href,'<?php echo GREYBOX_PERS_HEIGHT; ?>','<?php echo GREYBOX_PERS_WIDTH; ?>',this.title);return false;"><?php echo $msg_sales37; ?></a>
    <?php
    }
    // Show downloads link if there are downloadable products..
    if (mc_rowCount('purchases WHERE `saleID` = \''.$SALES->id.'\' AND `saleConfirmation` = \'yes\' AND `productType` = \'download\'')>0) {
    ?>
    <a class="downloads" href="?p=downloads&amp;sale=<?php echo $SALES->id; ?>" title="<?php echo mc_cleanDataEnt($msg_sales38); ?>" onclick="mc_Window(this.href,'<?php echo GREYBOX_DOWNLOADS_HEIGHT; ?>','<?php echo GREYBOX_DOWNLOADS_WIDTH; ?>',this.title);return false;"><?php echo $msg_sales38; ?></a>
    <?php
    }
    ?>
    <a class="update" href="?p=sales-update&amp;sale=<?php echo $SALES->id; ?>" title="<?php echo mc_cleanDataEnt($msg_sales2); ?>"><?php echo $msg_sales2; ?></a>
    <br class="clear" />
  </p>
</div>
<?php
}
?>

<p style="padding:10px 0 10px 10px">
<input type="checkbox" name="all" value="all" onclick="toggleCheckBoxesID(this.checked,'formField')" />&nbsp;&nbsp;&nbsp;
<input type="submit" value="<?php echo mc_cleanDataEnt($msg_sales44); ?>" title="<?php echo mc_cleanDataEnt($msg_sales44); ?>" class="formbutton" />
</p>

</form>
</div>
<?php
define('PER_PAGE',PRODUCTS_PER_PAGE);
if ($SUMS->scount>0 && $SUMS->scount>PER_PAGE) {
  $PTION = new pagination($SUMS->scount,'?p='.$cmd.'&amp;next=');
  echo $PTION->display();
}
} else {
?>
<p class="noData"><?php echo $msg_sales17; ?></p>
</form>
</div>
<?php
}
?>

</div>
