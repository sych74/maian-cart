<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } 
define('CALBOX', 'from|to');
include(PATH.'templates/date-picker.php');
?>
<div id="content">

<?php
echo $msg_salesexport; 
?>
<br /><br />

<div class="fieldHeadWrapper">
  <p><?php echo $msg_salesexport2; ?>:</p>
</div>

<?php
if (isset($return) && $return=='none') {
?>
<p class="noData" style="margin-bottom:5px"><?php echo $msg_salesexport15; ?></p>
<?php
}
$payStatuses = mc_loadDefaultStatuses();
?>

<form method="post" id="form" action="?p=sales-export">
<div class="formFieldWrapper">
  <div class="formLeft" style="width:43%">
    <label><?php echo $msg_salesexport10; ?>: <?php echo mc_displayHelpTip($msg_javascript135,'RIGHT'); ?></label>
    <select name="range" tabindex="1">
    <option value="0">- - - - - -</option>
    <?php
    foreach ($payStatuses AS $key => $value) {
    ?>
    <option value="<?php echo $key; ?>"<?php echo (isset($_POST['range']) && $_POST['range']==$key ? ' selected="selected"' : ''); ?>><?php echo $value; ?></option>
    <?php
    }
    // Get additional payment statuses..
    $q_add_stats = mysql_query("SELECT * FROM ".DB_PREFIX."paystatuses 
                   ORDER BY `pMethod`,`statname`
                   ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    if (mysql_num_rows($q_add_stats)>0) {
    ?>
    <option value="0" disabled="disabled">- - - - - - - - -</option>
    <?php
    }
    while ($ST = mysql_fetch_object($q_add_stats)) {
    ?>
    <option value="<?php echo $ST->id; ?>"<?php echo (isset($_POST['range']) && $_POST['range']==$ST->id ? ' selected="selected"' : ''); ?>><?php echo mc_cleanData($ST->statname); ?></option>
    <?php
    }
    ?>
    </select>
  </div>
  <div class="formRight" style="width:33%">  
    <label><?php echo $msg_salessearch4; ?>: <?php echo mc_displayHelpTip($msg_javascript136); ?></label>
    <input type="text" tabindex="2" name="from" value="<?php echo (isset($_POST['from']) ? mc_cleanDataEnt($_POST['from']) : ''); ?>" class="box" style="width:35%" id="from" /> <?php echo $msg_salessearch5; ?>
    <input type="text" tabindex="3" name="to" value="<?php echo (isset($_POST['to']) ? mc_cleanDataEnt($_POST['to']) : ''); ?>" class="box" style="width:35%" id="to" />
  </div>
  <div class="formLeft" style="width:23%">
    <label><?php echo $msg_salesexport7; ?>: <?php echo mc_displayHelpTip($msg_javascript137,'LEFT'); ?></label>
    <input type="text" tabindex="4" name="sep" value="<?php echo (isset($_POST['sep']) ? mc_cleanDataEnt($_POST['sep']) : ','); ?>" class="box" style="width:10%" /> 
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper">
  <div class="formLeft" style="width:43%">
    <label><?php echo $msg_salesexport6; ?>: <?php echo mc_displayHelpTip($msg_javascript148,'RIGHT'); ?></label>
    <select name="method" tabindex="5">
    <option value="0">- - - - - -</option>
    <?php
    foreach ($mcSystemPaymentMethods AS $key => $value) {
	if ($value['enable']=='yes') {
    ?>
    <option value="<?php echo $key; ?>"<?php echo (isset($_POST['method']) && $_POST['method']==$key ? ' selected="selected"' : ''); ?>><?php echo $value['lang']; ?></option>
    <?php
	}
    }
    ?>
    </select>
  </div>
  <div class="formRight" style="width:33%">  
    <label><?php echo $msg_sales18; ?>: <?php echo mc_displayHelpTip($msg_javascript149); ?></label>
    <select name="country" tabindex="6">
    <option value="0">- - - - - -</option>
    <?php
    $q_c = mysql_query("SELECT * FROM ".DB_PREFIX."countries 
           WHERE enCountry = 'yes' 
           ORDER BY cName
           ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($C = mysql_fetch_object($q_c)) {
    ?>
    <option value="<?php echo $C->id; ?>"<?php echo (isset($_POST['country']) && $_POST['country']==$C->id ? ' selected="selected"' : ''); ?>><?php echo mc_cleanData($C->cName); ?></option>
    <?php
    }
    ?>
    </select>
  </div>
  <div class="formLeft" style="width:23%">
    <label><?php echo $msg_salesexport17; ?>: <?php echo mc_displayHelpTip($msg_javascript150,'LEFT'); ?></label>
    <?php echo $msg_script5; ?> <input tabindex="7" type="radio" name="header" value="yes"<?php echo (isset($_POST['header']) && $_POST['header']=='yes' ? ' checked="checked"' : (!isset($_POST['header']) ? ' checked="checked"' : '')); ?> /> <?php echo $msg_script6; ?> <input tabindex="7" type="radio" name="header" value="no"<?php echo (isset($_POST['header']) && $_POST['header']=='no' ? ' checked="checked"' : ''); ?> /> 
  </div>
  <br class="clear" />
</div>

<p style="text-align:center;padding:20px 0 30px 0">
 <input type="hidden" name="process" value="yes" />
 <input class="formbutton" type="submit" value="<?php echo mc_cleanDataEnt($msg_salesexport2); ?>" title="<?php echo mc_cleanDataEnt($msg_salesexport2); ?>" />
 <?php echo (isset($return) && $return=='none' ? '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input class="formbutton2" type="button" onclick="window.location=\'?p=sales-export\'" value="'.mc_cleanDataEnt($msg_script11).'" title="'.mc_cleanDataEnt($msg_script11).'" />' : ''); ?>
</p>
</form>

</div>
