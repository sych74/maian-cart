<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } 
define('CALBOX', 'from|to');
include(PATH.'templates/date-picker.php');
?>
<div id="content">

<?php
echo $msg_salesexport8; 
?>
<br /><br />

<div class="fieldHeadWrapper">
  <p><?php echo $msg_salesexport9; ?>:</p>
</div>

<?php
if (isset($return) && $return=='none') {
?>
<p class="noData" style="margin-bottom:5px"><?php echo $msg_salesexport13; ?></p>
<?php
}
?>

<form method="post" id="form" action="?p=sales-export-buyers">
<div class="formFieldWrapper">
  <div class="formLeft" style="width:43%">
    <label><?php echo $msg_salesexport5; ?>: <?php echo mc_displayHelpTip($msg_javascript138,'RIGHT'); ?></label>
    <div class="categoryBoxes">
    <input type="checkbox" tabindex="1" name="log" value="all" onclick="selectAll()" /> <b><?php echo $msg_productadd35; ?></b><br />
    <?php
    $q_cats = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
              WHERE catLevel = '1'
              AND childOf    = '0'
              AND enCat      = 'yes'
              ORDER BY catname") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($CATS = mysql_fetch_object($q_cats)) {
    ?>
    <p id="cat_<?php echo $CATS->id; ?>"><input onclick="if(this.checked){selectChildren('cat_<?php echo $CATS->id; ?>','on')}else{selectChildren('cat_<?php echo $CATS->id; ?>','off')}" tabindex="1" type="checkbox" name="range[]" value="<?php echo $CATS->id; ?>"<?php echo (isset($_POST['range']) && in_array($CATS->id,$_POST['range']) ? ' checked="checked"' : ''); ?> /> <?php echo mc_cleanDataEnt($CATS->catname); ?><br />
    <?php
    $q_children = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
                  WHERE catLevel = '2'
                  AND enCat      = 'yes'
                  AND childOf    = '".$CATS->id."'
                  ORDER BY catname") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($CHILDREN = mysql_fetch_object($q_children)) {
    ?>
    <span id="child_<?php echo $CHILDREN->id; ?>">
    &nbsp;&nbsp;<input onclick="if(this.checked){selectChildren('child_<?php echo $CHILDREN->id; ?>','on')}else{selectChildren('child_<?php echo $CHILDREN->id; ?>','off')}" tabindex="1" type="checkbox" name="range[]" value="<?php echo $CHILDREN->id; ?>"<?php echo (isset($_POST['range']) && in_array($CHILDREN->id,$_POST['range']) ? ' checked="checked"' : ''); ?> /> <?php echo mc_cleanDataEnt($CHILDREN->catname); ?><br />
    <?php
    $q_infants = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
                 WHERE catLevel = '3'
                 AND childOf    = '{$CHILDREN->id}'
                 AND enCat      = 'yes'
                 ORDER BY catname
                 ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($INFANTS = mysql_fetch_object($q_infants)) {
    ?>
    &nbsp;&nbsp;&nbsp;&nbsp;<input tabindex="1" type="checkbox" name="range[]" value="<?php echo $INFANTS->id; ?>"<?php echo (isset($_POST['range']) && in_array($INFANTS->id,$_POST['range']) ? ' checked="checked"' : ''); ?> /> <?php echo mc_cleanDataEnt($INFANTS->catname); ?><br />
    <?php
    }
    ?>
    </span>
    <?php
    }
    ?>
    </p>
    <?php
    }
    ?>
    </div>
  </div>
  <div class="formRight" style="width:33%">  
    <label><?php echo $msg_salessearch4; ?>: <?php echo mc_displayHelpTip($msg_javascript136); ?></label>
    <input tabindex="2" type="text" name="from" value="<?php echo (isset($_POST['from']) ? mc_cleanDataEnt($_POST['from']) : ''); ?>" class="box" style="width:35%" id="from" /> <?php echo $msg_salessearch5; ?>
    <input tabindex="3" type="text" name="to" value="<?php echo (isset($_POST['to']) ? mc_cleanDataEnt($_POST['to']) : ''); ?>" class="box" style="width:35%" id="to" />
    
    <label style="margin-top:15px"><?php echo $msg_sales18; ?>: <?php echo mc_displayHelpTip($msg_javascript146); ?></label>
    <select name="country" tabindex="4">
    <option value="0">- - - - - -</option>
    <?php
    $q_c = mysql_query("SELECT * FROM ".DB_PREFIX."countries 
           WHERE enCountry = 'yes' 
           ORDER BY cName
           ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($C = mysql_fetch_object($q_c)) {
    ?>
    <option value="<?php echo $C->id; ?>"<?php echo (isset($_POST['country']) && $_POST['country']==$C->id ? ' selected="selected"' : ''); ?>><?php echo mc_cleanData($C->cName); ?></option>
    <?php
    }
    ?>
    </select>
  </div>
  <div class="formLeft" style="width:23%">
    <label><?php echo $msg_salesexport12; ?>: <?php echo mc_displayHelpTip($msg_javascript139,'LEFT'); ?></label>
    <input type="text" tabindex="5" name="format" value="<?php echo (isset($_POST['format']) ? mc_cleanDataEnt($_POST['format']) : '%name%,%email%'); ?>" class="box" />
    
    <label style="margin-top:15px"><?php echo $msg_salesexport14; ?>: <?php echo mc_displayHelpTip($msg_javascript147,'LEFT'); ?></label>
    <?php echo $msg_script5; ?> <input tabindex="6" type="radio" name="refunded" value="yes"<?php echo (isset($_POST['refunded']) && $_POST['refunded']=='yes' ? ' checked="checked"' : ''); ?> /> <?php echo $msg_script6; ?> <input tabindex="6" type="radio" name="refunded" value="no"<?php echo (isset($_POST['refunded']) && $_POST['refunded']=='no' ? ' checked="checked"' : (!isset($_POST['refunded']) ? ' checked="checked"' : '')); ?> /> 
  </div>
  <br class="clear" />
</div>

<p style="text-align:center;padding:20px 0 30px 0">
 <input type="hidden" name="process" value="yes" />
 <input class="formbutton" type="submit" value="<?php echo mc_cleanDataEnt($msg_salesexport9); ?>" title="<?php echo mc_cleanDataEnt($msg_salesexport9); ?>" />
</p>
</form>

</div>
