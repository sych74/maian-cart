<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } ?>
<div id="content">

<?php
if (isset($OK) && $cnt>0) {
  echo actionCompleted($msg_giftoverview3);
}
echo $msg_giftoverview;
?>
<br /><br />

<div class="statsTop">
  <div class="topLeft"><select onchange="if(this.value!= 0){location=this.options[this.selectedIndex].value}">
  <option value="?p=gift-overview<?php echo (isset($_GET['keys']) ? '&amp;keys='.mc_cleanDataEnt($_GET['keys']) : ''); ?>"><?php echo $msg_giftoverview8; ?></option>
  <option value="?p=gift-overview&amp;filter=redeemed<?php echo (isset($_GET['keys']) ? '&amp;keys='.mc_cleanDataEnt($_GET['keys']) : ''); ?>"<?php echo (isset($_GET['filter']) && $_GET['filter']=='redeemed' ? ' selected="selected"' : ''); ?>><?php echo $msg_giftoverview9; ?></option>
  <option value="?p=gift-overview&amp;filter=disabled<?php echo (isset($_GET['keys']) ? '&amp;keys='.mc_cleanDataEnt($_GET['keys']) : ''); ?>"<?php echo (isset($_GET['filter']) && $_GET['filter']=='disabled' ? ' selected="selected"' : ''); ?>><?php echo $msg_giftoverview6; ?></option>
  </select></div>
  <div class="topRight">
  <form method="get" action="index.php">
   <p><input type="hidden" name="p" value="gift-overview" /><?php echo (isset($_GET['filter']) ? '<input type="hidden" name="filter" value="'.mc_digitSan($_GET['filter']).'" />' : ''); ?><?php echo $msg_giftoverview10; ?>: <input type="text" name="keys" value="<?php echo (isset($_GET['keys']) ? mc_cleanDataEnt($_GET['keys']) : ''); ?>" class="box" style="width:40%" /> <input type="submit" class="formbutton" value="<?php echo mc_cleanDataEnt($msg_giftoverview7); ?>" title="<?php echo mc_cleanDataEnt($msg_giftoverview7); ?>" /></p>
  </form>
  </div>
  <br class="clear" />
</div>

<?php
$SQL = 'WHERE `active` = \'yes\'';
if (isset($_GET['filter'])) {
  switch ($_GET['filter']) {
    case 'redeemed':
	$SQL = "WHERE `value` != `redeemed` AND `active` = 'yes'";
	break;
	case 'disabled':
	$SQL = "WHERE `enabled` = 'no' AND `active` = 'yes'";
	break;
  }
}
if (isset($_GET['keys'])) {
  $sKeys  = '%'.mc_safeImportString($_GET['keys']).'%';
  $sKeysD = mc_safeImportString($_GET['keys']);
  $SQL   .= ($SQL ? 'AND ' : 'WHERE ')."(`from_name` LIKE '{$sKeys}' OR `to_name` LIKE '{$sKeys}' OR `from_email` LIKE '{$sKeys}' OR `to_email` LIKE '{$sKeys}' OR `code` LIKE '{$sKeys}' OR `notes` LIKE '{$sKeys}' OR `dateAdded` = '{$sKeysD}')";
}
$q_p = mysql_query("SELECT SQL_CALC_FOUND_ROWS * FROM `".DB_PREFIX."giftcodes` $SQL ORDER BY `id` DESC LIMIT $limit,".PRODUCTS_PER_PAGE)
       or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
$c            = mysql_fetch_object(mysql_query("SELECT FOUND_ROWS() AS `rows`"));
$countedRows  =  (isset($c->rows) ? $c->rows : '0');
if (mysql_num_rows($q_p)>0) {
?>
<div class="fieldHeadWrapper">
  <p><?php echo (mysql_num_rows($q_p)>0 ? '<span class="float"><a class="export_product_overview" href="?p=gift-overview&amp;export='.(isset($_GET['filter']) ? $_GET['filter'] : 'all').(isset($_GET['keys']) ? '&amp;keys='.mc_cleanDataEnt($_GET['keys']) : '').'" title="'.mc_cleanDataEnt($msg_giftoverview11).'">'.$msg_giftoverview11.'</a></span>' : ''); ?><?php echo mc_cleanDataEnt($msg_giftoverview2); ?>:</p>
</div>
<?php
while ($GIFT = mysql_fetch_object($q_p)) {
$finrep        = array(
  '{date}'     => date($SETTINGS->systemDateFormat,strtotime($GIFT->dateAdded)),
  '{value}'    => mc_currencyFormat($GIFT->value),
  '{redeemed}' => mc_currencyFormat($GIFT->redeemed),
  '{enabled}'  => ($GIFT->enabled=='yes' ? $msg_script5 : $msg_script6)
);
?>
<div class="catWrapper">
  <div class="catLeft" style="width:89%"><span style="float:right;font-size:11px"><?php echo strtr($msg_giftoverview4,$finrep); ?></span><?php echo mc_cleanDataEnt($GIFT->from_name); ?><br />&nbsp; &nbsp;&gt; <?php echo mc_cleanDataEnt($GIFT->to_name); ?></div> 
  <div class="catRight" style="width:8%;text-align:center;padding:5px 0 3px 0;background:#fff;float:right">
   <a href="?p=gift&amp;viewGift=<?php echo $GIFT->code; ?>" onclick="mc_Window(this.href,'<?php echo GREYBOX_PERS_HEIGHT; ?>','<?php echo GREYBOX_PERS_WIDTH; ?>',this.title);return false;"><img src="templates/images/edit.png" alt="<?php echo mc_cleanDataEnt($msg_script9); ?>" title="<?php echo mc_cleanDataEnt($msg_script9); ?>" /></a>&nbsp;&nbsp;
   <?php
   if ($uDel=='yes') {
   ?>
   <a href="?p=gift-overview&amp;del=<?php echo $GIFT->id; ?>" onclick="return confirmMessage('<?php echo mc_cleanDataEnt($msg_javascript45); ?>')"><img src="templates/images/delete.png" alt="<?php echo mc_cleanDataEnt($msg_script10); ?>" title="<?php echo mc_cleanDataEnt($msg_script10); ?>" /></a>
   <?php
   }
   ?>
  </div>
  <br class="clear" />
</div>
<?php
}
define('PER_PAGE',PRODUCTS_PER_PAGE);
if ($countedRows>0 && $countedRows>PER_PAGE) {
  $PTION = new pagination($countedRows,'?p='.$cmd.'&amp;next=');
  echo $PTION->display();
}
} else {
?>
<span class="noData"><?php echo $msg_giftoverview5; ?></span>
<?php
}
?>
</div>
