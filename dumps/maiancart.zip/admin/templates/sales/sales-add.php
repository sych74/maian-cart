<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } 
// Arrays..
if (!isset($_SESSION['add-phys-'.mc_encrypt(SECRET_KEY)])) {
  $_SESSION['add-phys-'.mc_encrypt(SECRET_KEY)] = array();
}
if (!isset($_SESSION['add-down-'.mc_encrypt(SECRET_KEY)])) {
  $_SESSION['add-down-'.mc_encrypt(SECRET_KEY)] = array();
}      
?>
<div id="content">
<script type="text/javascript">
//<![CDATA[
jQuery(document).ready(function() {
  mc_nextInvoice();
});
//]]>
</script>
<?php
echo $msg_addsale;
?>
<br /><br />

<div class="salesViewTop">
  <p><?php echo (!empty($_SESSION['add-phys-'.mc_encrypt(SECRET_KEY)]) || !empty($_SESSION['add-down-'.mc_encrypt(SECRET_KEY)]) ? '<span class="float"><a class="clear" href="?p=sales-add&amp;clear=yes" title="'.mc_cleanDataEnt($msg_addsale10).'" onclick="return confirmMessage(\''.mc_cleanDataEnt($msg_javascript45).'\')">'.mc_cleanDataEnt($msg_addsale10).'</a></span>' : ''); ?><b><?php echo $msg_addsale2; ?></b></p>
</div>

<div id="form_field">
<form method="post" id="form" action="?p=sales-add" onsubmit="return confirmMessage('<?php echo mc_cleanDataEnt($msg_javascript45); ?>')">

<div class="fieldHeadWrapper">
  <p><span class="float"><a class="add" onclick="mc_Window(this.href,'<?php echo GREYBOX_HEIGHT-100; ?>','<?php echo GREYBOX_WIDTH; ?>',this.title);return false;" href="?p=add-manual&amp;type=physical" title="<?php echo mc_cleanDataEnt($msg_viewsale4); ?>"><?php echo $msg_viewsale4; ?></a></span><?php echo $msg_viewsale2; ?>:</p>
</div>

<?php
if (!empty($_SESSION['add-phys-'.mc_encrypt(SECRET_KEY)])) {
foreach ($_SESSION['add-phys-'.mc_encrypt(SECRET_KEY)] AS $p) {
$split    = explode('-',$p);
$q_phys   = mysql_query("SELECT * FROM `".DB_PREFIX."products` 
            WHERE `id` = '".$split[0]."' 
            LIMIT 1
            ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
$PHYS     = mysql_fetch_object($q_phys);
$details  = '';
$code     = $PHYS->pCode;
$weight   = $PHYS->pWeight;
$price    = $PHYS->pPrice;
$offer    = $PHYS->pOffer;
$hidden   = '<input type="hidden" name="pd[]" value="'.$split[0].'-0-'.$split[2].'" /><input type="hidden" name="prod_id[]" value="'.$PHYS->id.'" />'.mc_defineNewline();
$img      = storeProductImg($PHYS->id,$PHYS);
$hasAttribs   = mc_rowCount('attributes WHERE `productID` = \''.$PHYS->id.'\'');
?>
<div class="salePurchase" id="purchase_<?php echo $PHYS->id.'-'.$split[1].'-'.$split[2]; ?>">
  <?php
  echo $hidden;
  ?>
  <div class="left"> 
    <p><?php echo $img; ?></p>
  </div>
  <div class="middle">  
    <p><?php echo mc_cleanDataEnt($PHYS->pName).($details ? ' <span class="highlight">('.$details.')</span>' : ''); ?></p>
    <?php
	if ($hasAttribs>0) {
	?>
	<div class="attrSaleBoxes" id="prodAttrArea_<?php echo $PHYS->id.'-'.$split[1].'-'.$split[2]; ?>">
	<span style="float:right"><img src="templates/images/calculator.png" alt="<?php echo mc_cleanDataEnt($msg_viewsale113); ?>" title="<?php echo mc_cleanDataEnt($msg_viewsale113); ?>" style="cursor:pointer" onclick="calcAttr('<?php echo $PHYS->id; ?>','<?php echo $PHYS->id.'-'.$split[1].'-'.$split[2]; ?>')" /></span>
	<?php
    // Attributes
	?>
	<div class="add" id="attsel_<?php echo $PHYS->id.'-'.$split[1].'-'.$split[2]; ?>" style="display:none">
	<?php
	$q_attc = mysql_query("SELECT *,`".DB_PREFIX."attributes`.`id` AS `attrID` FROM `".DB_PREFIX."attributes`
	          LEFT JOIN `".DB_PREFIX."attr_groups`
			  ON `".DB_PREFIX."attributes`.`attrGroup`    = `".DB_PREFIX."attr_groups`.`id`
              WHERE `".DB_PREFIX."attributes`.`productID` = '{$PHYS->id}'
			  ORDER BY `".DB_PREFIX."attr_groups`.`groupName`
              ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    if (mysql_num_rows($q_attc)>0) { 
	?>
	<select name="attsel" id="s_<?php echo $PHYS->id.'-'.$split[1].'-'.$split[2]; ?>" onchange="if(this.value!='0'){addAttributeToSale(this.value,'<?php echo $PHYS->id.'-'.$split[1].'-'.$split[2]; ?>','<?php echo $PHYS->id; ?>')}">
	<option value="0"><?php echo $msg_viewsale112; ?></option>
	<?php
	while ($ATTSEL = mysql_fetch_object($q_attc)) {
	?>
	<option value="<?php echo $ATTSEL->attrID; ?>" id="sel_<?php echo $PHYS->id.'-'.$split[1].'-'.$split[2]; ?>_<?php echo $ATTSEL->attrID; ?>"><?php echo mc_cleanData($ATTSEL->groupName.' - '.$ATTSEL->attrName); ?></option>
	<?php
	}
	?>
	</select> <a href="#" onclick="remAttrDropDown('<?php echo $PHYS->id.'-'.$split[1].'-'.$split[2]; ?>');return false">X</a>
	<?php
	}
	?>
	</div>
	<div class="links" id="alinks_<?php echo $PHYS->id.'-'.$split[1].'-'.$split[2]; ?>"><a href="#" onclick="hideAttr('<?php echo $PHYS->id.'-'.$split[1].'-'.$split[2]; ?>');return false" title="<?php echo mc_cleanDataEnt($msg_viewsale110); ?>"><?php echo mc_cleanDataEnt($msg_viewsale110); ?></a> <a class="edit" href="?p=product-attributes&amp;product=<?php echo $PHYS->id; ?>" onclick="window.open(this);return false" title="<?php echo mc_cleanDataEnt($msg_viewsale111); ?>"><?php echo mc_cleanDataEnt($msg_viewsale111); ?></a></div>
	</div>
	<?php
	}
    
    $iBoxes = 0;
    // Personalisation
    $q_ps1 = mysql_query("SELECT * FROM `".DB_PREFIX."personalisation`
             WHERE `productID` = '{$PHYS->id}'
             AND `enabled`     = 'yes'
             ORDER BY `id`
             ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    if (mysql_num_rows($q_ps1)>0) {     
    ?>
    <div class="personalisation" id="pWrapper_<?php echo $PHYS->id.'-'.$split[1].'-'.$split[2]; ?>">
    <span style="float:right"><img src="templates/images/calculator.png" alt="<?php echo mc_cleanDataEnt($msg_viewsale114); ?>" title="<?php echo mc_cleanDataEnt($msg_viewsale114); ?>" style="cursor:pointer" onclick="calcPers('<?php echo $PHYS->id; ?>','<?php echo $PHYS->id.'-'.$split[1].'-'.$split[2]; ?>')" /></span>
	<?php
    while ($PS = mysql_fetch_object($q_ps1)) {
    ++$iBoxes;
    $cost         = $PS->persAddCost;
    $PS->boxType  = ($PS->persOptions ? 'select' : $PS->boxType);
    $inputBoxes   = '<input type="hidden" name="product[\''.$p.'\'][]" value="'.$PHYS->id.'" />
                     <input type="hidden" name="cost[\''.$p.'\'][]" value="'.$PS->persAddCost.'" />';
    switch ($PS->boxType) {
     case 'input':
     ?>
     <span class="personalisation_item"><?php echo mc_persTextDisplay(mc_cleanDataEnt($PS->persInstructions),true); ?> <span class="personalisation_item_price">(<?php echo str_replace('{extra_cost}',mc_currencyFormat($cost),($cost>0 ? $msg_viewsale54 : $msg_viewsale55)); ?>)</span></span>
     <span class="personalisation_item_data"><?php echo $inputBoxes; ?><input type="hidden" name="persnew['<?php echo $p; ?>'][]" value="<?php echo $PS->id; ?>" /><input id="ibox_<?php echo $PHYS->id.'-'.$split[1].'-'.$split[2]; ?>_<?php echo $iBoxes; ?>" class="box" type="text" name="pnvalue['<?php echo $p; ?>'][]" value="" /></span>
     <?php
     break;
     case 'textarea':
     ?>
     <span class="personalisation_item"><?php echo mc_persTextDisplay(mc_cleanDataEnt($PS->persInstructions),true); ?> <span class="personalisation_item_price">(<?php echo str_replace('{extra_cost}',mc_currencyFormat($cost),($cost>0 ? $msg_viewsale54 : $msg_viewsale55)); ?>)</span></span>
     <span class="personalisation_item_data"><?php echo $inputBoxes; ?><input type="hidden" name="persnew['<?php echo $p; ?>'][]" value="<?php echo $PS->id; ?>" /><textarea id="ibox_<?php echo $PHYS->id.'-'.$split[1].'-'.$split[2]; ?>_<?php echo $iBoxes; ?>" name="pnvalue['<?php echo $p; ?>'][]" rows="5" cols="20"></textarea></span>
     <?php
     break;
     case 'select':
     ?>
     <span class="personalisation_item"><?php echo mc_persTextDisplay(mc_cleanDataEnt($PS->persInstructions),true); ?> <span class="personalisation_item_price">(<?php echo str_replace('{extra_cost}',mc_currencyFormat($cost),($cost>0 ? $msg_viewsale54 : $msg_viewsale55)); ?>)</span></span>
     <span class="personalisation_item_data"><?php echo $inputBoxes; ?><input type="hidden" name="persnew['<?php echo $p; ?>'][]" value="<?php echo $PS->id; ?>" /><select id="ibox_<?php echo $PHYS->id.'-'.$split[1].'-'.$split[2]; ?>_<?php echo $iBoxes; ?>" name="pnvalue['<?php echo $p; ?>'][]">
     <option value="no-option-selected">- - - - -</option>
     <?php 
     $OPT = explode('||',$PS->persOptions);
     foreach ($OPT AS $o) {
     ?>
     <option value="<?php echo $o; ?>"><?php echo mc_cleanData($o); ?></option>
     <?php
     }
     ?>
     </select>
     </span>
     <?php
     break;
    }
    }
    ?>
    </div>
    <?php
    }
    ?>
  </div>
  <div class="right">
    <p>
    <?php echo $msg_viewsale32; ?>:
    <select name="qty[]" id="qty_<?php echo $PHYS->id.'-'.$split[1].'-'.$split[2]; ?>" onchange="if(jQuery('#qty_<?php echo $PHYS->id.'-'.$split[1].'-'.$split[2]; ?>').val()=='0') {alert('<?php echo mc_cleanDataEnt($msg_javascript220); ?>');mc_MarkForDeletion('<?php echo $PHYS->id.'-'.$split[1].'-'.$split[2]; ?>');}else{displayPurchaseProductPrices('<?php echo $PHYS->id.'-'.$split[1].'-'.$split[2]; ?>','sales-view');}">
    <?php
    foreach (range(0,SALE_QTY_LIMIT) AS $qty) {
    ?>
    <option value="<?php echo $qty; ?>"<?php echo ($qty=='1' ? ' selected="selected"' : ''); ?>><?php echo $qty; ?></option>
    <?php
    }
    ?>
    </select>
    @ <input class="price" id="price_<?php echo $PHYS->id.'-'.$split[1].'-'.$split[2]; ?>" onblur="displayPurchaseProductPrices('<?php echo $PHYS->id.'-'.$split[1].'-'.$split[2]; ?>','sales-add')" type="text" name="price[]" value="<?php echo ($offer>0 ? mc_formatPrice($offer) : mc_formatPrice($price)); ?>" />
    </p> 
    <?php
    if ($hasAttribs>0) {
    ?>
    <span class="priceBox"><?php echo $msg_viewsale88; ?>: <input class="price" id="attr_<?php echo $PHYS->id.'-'.$split[1].'-'.$split[2]; ?>" type="text" onblur="displayPurchaseProductPrices('<?php echo $PHYS->id.'-'.$split[1].'-'.$split[2]; ?>','sales-add')" name="attrPrice[]" value="0.00" /></span>
    <?php
    } else {
    ?>
    <input type="hidden" name="attrPrice['<?php echo $PHYS->id.'-'.$split[1].'-'.$split[2]; ?>']" value="0.00" />
    <?php
    }
    if (mysql_num_rows($q_ps1)>0) { 
    ?>
    <span class="priceBox"><?php echo $msg_viewsale87; ?>: <input class="price" id="pers_<?php echo $PHYS->id.'-'.$split[1].'-'.$split[2]; ?>" type="text" onblur="displayPurchaseProductPrices('<?php echo $PHYS->id.'-'.$split[1].'-'.$split[2]; ?>','sales-add')" name="persPrice[]" value="0.00" /></span>
    <?php
    } else {
    ?>
    <input type="hidden" name="persPrice['<?php echo $PHYS->id.'-'.$split[1].'-'.$split[2]; ?>']" value="0.00" />
    <?php
    }
    ?>
    <span class="priceBox"><?php echo $msg_viewsale94; ?>: <input class="price" id="qtyadj_<?php echo $PHYS->id; ?>" type="text" name="qtyAdjustment[]" value="<?php echo $PHYS->pStock; ?>" /></span>
  </div>
  <br class="clear" /> 
  <p class="priceBar">
    <span class="options">
	  <?php echo str_replace(array('{code}','{url}'),array($code,'../?pID='.$PHYS->id),$msg_viewsale16); ?>
      <?php echo str_replace(array('{code}','{url}'),array($code,'?p=add-product&amp;edit='.$PHYS->id),$msg_viewsale93); ?>
	</span>
    <span class="highlight" id="highlight_<?php echo $PHYS->id.'-'.$split[1].'-'.$split[2]; ?>"><?php echo mc_currencyFormat(($offer>0 ? mc_formatPrice($offer) : mc_formatPrice($price))); ?></span>
    <input type="hidden" id="total_price_<?php echo $PHYS->id.'-'.$split[1].'-'.$split[2]; ?>" name="t_price[]" value="<?php echo ($offer>0 ? mc_formatPrice($offer) : mc_formatPrice($price)); ?>" />
  </p> 
</div>
<?php
}
} else {
?>
<p class="noData" style="margin-bottom:5px"><?php echo $msg_addsale3; ?></p>
<?php
}

?>

<div class="fieldHeadWrapper">
  <p><span class="float"><a class="add" onclick="mc_Window(this.href,'<?php echo GREYBOX_HEIGHT-100; ?>','<?php echo GREYBOX_WIDTH; ?>',this.title);return false;" href="?p=add-manual&amp;type=download" title="<?php echo mc_cleanDataEnt($msg_viewsale4); ?>"><?php echo $msg_viewsale4; ?></a></span><?php echo $msg_viewsale3; ?>:</p>
</div>

<?php
if (!empty($_SESSION['add-down-'.mc_encrypt(SECRET_KEY)])) {
foreach ($_SESSION['add-down-'.mc_encrypt(SECRET_KEY)] AS $d) {
$split    = explode('-',$d);
$q_down   = mysql_query("SELECT * FROM `".DB_PREFIX."products` 
            WHERE `id` = '".$split[0]."' 
            LIMIT 1
            ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
$DOWN     = mysql_fetch_object($q_down);
$details  = '';
$code     = $DOWN->pCode;
$weight   = $DOWN->pWeight;
$price    = $DOWN->pPrice;
$offer    = $DOWN->pOffer;
$hidden   = '<input type="hidden" name="pd[]" value="'.$split[0].'-0-'.$split[2].'" />'.mc_defineNewline(); 
$img      = storeProductImg($DOWN->id,$DOWN);
?>
<div class="salePurchase" id="purchase_<?php echo $DOWN->id; ?>_<?php echo $split[2]; ?>">
  <?php
  echo $hidden;
  ?>
  <div class="left"> 
    <p><?php echo $img; ?></p>
  </div>
  <div class="middle">  
    <p><?php echo mc_cleanDataEnt($DOWN->pName).($details ? ' <span class="highlight">('.$details.')</span>' : ''); ?></p>
  </div>
  <div class="right"> 
    <p>
    <?php echo $msg_viewsale32; ?>:
    <select name="qty[]" id="qty_<?php echo $DOWN->id; ?>_<?php echo $split[2]; ?>" onchange="if(jQuery('#qty_<?php echo $DOWN->id; ?>_<?php echo $split[2]; ?>').val()=='0') {alert('<?php echo mc_cleanDataEnt($msg_javascript220); ?>');jQuery('#price_<?php echo $DOWN->id; ?>_<?php echo $split[2]; ?>').val('0.00');jQuery('#highlight_<?php echo $DOWN->id; ?>_<?php echo $split[2]; ?>').html('<?php echo mc_currencyFormat('0.00'); ?>');jQuery('#purchase_<?php echo $DOWN->id; ?>_<?php echo $split[2]; ?>').css('border','1px solid #800000');}else{jQuery('#purchase_<?php echo $DOWN->id; ?>_<?php echo $split[2]; ?>').css('border','1px solid #e5e5e5');displayPurchaseProductPrices('<?php echo $DOWN->id; ?>_<?php echo $split[2]; ?>','sales-add','no');}">
    <?php
    foreach (range(0,SALE_QTY_LIMIT) AS $qty) {
    ?>
    <option value="<?php echo $qty; ?>"<?php echo ($qty=='1' ? ' selected="selected"' : ''); ?>><?php echo $qty; ?></option>
    <?php
    }
    ?>
    </select>
    @ <input class="price" id="price_<?php echo $DOWN->id; ?>_<?php echo $split[2]; ?>" type="text" name="price[]" value="<?php echo ($offer>0 ? mc_formatPrice($offer) : mc_formatPrice($price)); ?>" />
    </p>
  </div> 
  <br class="clear" />  
  <p class="priceBar">
    <span class="options">
	 <?php echo str_replace(array('{code}','{url}'),array($code,'../?pID='.$DOWN->id),$msg_viewsale16); ?>
     <?php echo str_replace(array('{code}','{url}'),array($code,'?p=add-product&amp;edit='.$DOWN->id),$msg_viewsale93); ?>
    </span>
    <span class="highlight" id="highlight_<?php echo $DOWN->id; ?>_<?php echo $split[2]; ?>"><?php echo mc_currencyFormat(($offer>0 ? mc_formatPrice($offer) : mc_formatPrice($price))); ?></span>
    <input type="hidden" id="total_price_<?php echo $DOWN->id.'-'.$split[1].'-'.$split[2]; ?>" name="t_price[]" value="<?php echo ($offer>0 ? mc_formatPrice($offer) : mc_formatPrice($price)); ?>" />
  </p>
</div>
<?php
}
} else {
?>
<p class="noData" style="margin-bottom:5px"><?php echo $msg_addsale3; ?></p>
<?php
}

if (!empty($_SESSION['add-phys-'.mc_encrypt(SECRET_KEY)]) || !empty($_SESSION['add-down-'.mc_encrypt(SECRET_KEY)])) {
?>

<div class="fieldHeadWrapper">
  <p><?php echo (!empty($_SESSION['add-phys-'.mc_encrypt(SECRET_KEY)]) || !empty($_SESSION['add-down-'.mc_encrypt(SECRET_KEY)]) ? '<span class="float"><a class="recalculate" href="#" onclick="recalculateManualTotals();return false" title="'.mc_cleanDataEnt($msg_viewsale48).'">'.$msg_viewsale48.'</a></span>' : ''); ?><?php echo $msg_viewsale24; ?>:</p>
</div>

<div id="paymentOverview">

  <div class="left">
    
    <?php
    $howManyZones = mc_rowCount('zones');
    if ($howManyZones>0) {
    ?>
    <p><span><?php echo $msg_viewsale26; ?>:</span>
    <select name="shipSetCountry" id="shipSetCountry" onchange="reloadCountry()">
    <?php
    $firstCountry = array();
    $q_ctry   = mysql_query("SELECT *,`".DB_PREFIX."countries`.`id` AS `cnt_id` FROM `".DB_PREFIX."countries` 
                LEFT JOIN `".DB_PREFIX."zones`
                ON `".DB_PREFIX."countries`.`id` = `".DB_PREFIX."zones`.`zCountry`
                WHERE `enCountry`  = 'yes'
                AND `zName`       != ''
                GROUP BY `".DB_PREFIX."countries`.`id`
                ORDER BY `cName`
                ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($CTY = mysql_fetch_object($q_ctry)) {
    $firstCountry[] = $CTY->cnt_id;
    ?>
    <option value="<?php echo $CTY->cnt_id; ?>"<?php echo ($SETTINGS->shipCountry>0 && $SETTINGS->shipCountry==$CTY->cnt_id ? ' selected="selected"' : ''); ?>><?php echo mc_cleanDataEnt($CTY->cName); ?></option>
    <?php
    }
    ?>
    </select>
    </p>
    <p><span><?php echo $msg_viewsale27; ?>:</span>
    <select name="shipSetArea" id="shipSetArea" onchange="setZoneTax()">
    <?php
    $shipWithTax = 'no';
    $q_zone = mysql_query("SELECT * FROM `".DB_PREFIX."zones`
              WHERE `zCountry` = '".($SETTINGS->shipCountry>0 ? $SETTINGS->shipCountry : (isset($firstCountry[0]) ? $firstCountry[0] : '0'))."' 
              ORDER BY `zName`
              ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($Z = mysql_fetch_object($q_zone)) {
    $q_zarea   = mysql_query("SELECT `id`,`areaName` FROM `".DB_PREFIX."zone_areas`
                 WHERE `inZone` = '{$Z->id}'
                 ORDER BY `areaName`
                 ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    if (mysql_num_rows($q_zone)>0) {
    ?>
    <optgroup label="<?php echo mc_cleanDataEnt($Z->zName); ?>">
    <?php
    }
    while ($ZAREA = mysql_fetch_object($q_zarea)) {
    ?>
    <option value="<?php echo $ZAREA->id; ?>"><?php echo mc_cleanDataEnt($ZAREA->areaName); ?></option>
    <?php
    }
    if (mysql_num_rows($q_zone)>0) {
    ?>
    </optgroup>
    <?php
    }
    }
    ?>
    </select> <span id="loader" style="display:inline"></span>
    </p>
    <p><span><?php echo $msg_viewsale28; ?>:</span>
    <select name="setShipRateID" id="setShipRateID" onchange="loadShippingPrice(jQuery('#subTotal').val())">
    <optgroup label="<?php echo mc_cleanDataEnt($msg_viewsale50); ?>">
      <option value="na"><?php echo $msg_viewsale50; ?></option>
    </optgroup>
    <?php
    if ($SETTINGS->enablePickUp=='yes') {
    ?>
    <optgroup label="<?php echo mc_cleanDataEnt($msg_javascript214); ?>">
     <option value="pickup"><?php echo $msg_javascript215; ?></option>
    </optgroup>
    <?php
    }
    $q_zone = mysql_query("SELECT `id`,`zName` FROM `".DB_PREFIX."zones` 
              WHERE `zCountry` = '".($SETTINGS->shipCountry>0 ? $SETTINGS->shipCountry : (isset($firstCountry[0]) ? $firstCountry[0] : '0'))."' 
              ORDER BY `zName`
              ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($Z = mysql_fetch_object($q_zone)) {
    //---------------------------------------------------------------------
    $q_service = mysql_query("SELECT `id`,`sName` FROM `".DB_PREFIX."services`
                 WHERE `inZone` = '{$Z->id}'
                 ORDER BY `sName`
                 ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    //---------------------------------------------------------------------
    $q_flat = mysql_query("SELECT `id`,`rate` FROM ".DB_PREFIX."flat
              WHERE `inZone` = '{$Z->id}'
              LIMIT 1
              ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    $FLAT = mysql_fetch_object($q_flat);     
	//---------------------------------------------------------------------
	$q_prte = mysql_query("SELECT `id`,`rate`,`item` FROM `".DB_PREFIX."per`
              WHERE `inZone` = '{$Z->id}'
              LIMIT 1
              ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    $PER_ITEM = mysql_fetch_object($q_prte);  
    //---------------------------------------------------------------------
    $q_percent = mysql_query("SELECT * FROM `".DB_PREFIX."percent`
                 WHERE `inZone` = '{$Z->id}'
                 ORDER BY `priceFrom`*100,`priceTo`*100
                 ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    //---------------------------------------------------------------------
    if (mysql_num_rows($q_service)>0 || mysql_num_rows($q_percent)>0 || isset($FLAT->id) || isset($PER_ITEM->id)) {
    ?>
    <optgroup label="<?php echo mc_cleanDataEnt($Z->zName); ?>">
    <?php
    }
    //---------------------------------------------------------------------
    // Flat
    //---------------------------------------------------------------------
    if (isset($FLAT->id)) {
    ?>
    <option value="0" disabled="disabled">(&#043;) <?php echo $msg_viewsale95; ?></option>
    <option value="flat<?php echo $FLAT->id; ?>"><?php echo $msg_viewsale95.' - '.mc_currencyFormat(mc_formatPrice($FLAT->rate)); ?></option>
    <?php
    }
	//---------------------------------------------------------------------
    // PerItem Rate
    //---------------------------------------------------------------------
    if (isset($PER_ITEM->id)) {
    ?>
    <option value="0" disabled="disabled">(&#043;) <?php echo $msg_viewsale124; ?></option>
    <option value="pert<?php echo $PER_ITEM->id; ?>"><?php echo str_replace(array('{first}','{item}'),array(mc_currencyFormat(mc_formatPrice($PER_ITEM->rate)),mc_currencyFormat(mc_formatPrice($PER_ITEM->item))),$msg_viewsale125); ?></option>
    <?php
    }
    //---------------------------------------------------------------------
    // Percentage based..
    //---------------------------------------------------------------------
    if (mysql_num_rows($q_percent)>0) {
    ?>
    <option value="0" disabled="disabled">(&#043;) <?php echo $msg_viewsale96; ?></option>
    <?php
    while ($PR = mysql_fetch_object($q_percent)) {
    ?>
    <option value="perc<?php echo $PR->id; ?>">&nbsp;<?php echo mc_currencyFormat(mc_formatPrice($PR->priceFrom)).' - '.mc_currencyFormat(mc_formatPrice($PR->priceTo)).' ('.$PR->percentage.'%)'; ?></option>
    <?php
    }
    }
    //---------------------------------------------------------------------
    // Services/rates = weight based
    //---------------------------------------------------------------------
    if (mysql_num_rows($q_service)>0) {
    while ($S = mysql_fetch_object($q_service)) {
    ?>
    <option value="0" disabled="disabled">&gt; <?php echo mc_cleanDataEnt($S->sName); ?></option>
    <?php
    $q_rates = mysql_query("SELECT * FROM `".DB_PREFIX."rates`
               WHERE `rService` = '{$S->id}'
               ORDER BY `id`
               ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($R = mysql_fetch_object($q_rates)) { 
    // Tare weight..
    $tareCost = '';
    $tare     = getTareWeight(0,$R->rService,array($R->rWeightFrom,$R->rWeightTo));
    if (isset($tare[0]) && $tare[0]=='yes') {
      switch (substr($tare[1],-1)) {
        case '%':
        $calc     = substr($tare[1],0,-1).'%';
        $tareCost = str_replace('{amount}',$calc,$msg_viewsale106);
        break;
        default:
        $tareCost = str_replace('{amount}',mc_currencyFormat(mc_formatPrice($tare[1])),$msg_viewsale106);
        break;
      }
    }              
    ?>
    <option value="<?php echo $R->id; ?>">&nbsp;<?php echo $R->rWeightFrom.' - '.$R->rWeightTo.' ('.mc_currencyFormat(mc_formatPrice($R->rCost)).$tareCost; ?>)</option>
    <?php
    }
    }
    }
    if (mysql_num_rows($q_service)>0 || mysql_num_rows($q_percent)>0 || isset($FLAT->id) || isset($PER_ITEM->id)) {
    ?>
    </optgroup>
    <?php
    }
    }
    ?>
    </select> <span id="loader2" style="display:inline"></span>
    </p>
    <?php
    } else {
    ?>
    <p><span><?php echo $msg_viewsale26; ?>:</span><?php echo $msg_viewsale86; ?></p>
    <?php
    }
    ?>
    
    <p><span><?php echo $msg_viewsale29; ?>:</span><input type="text" class="box" name="cartWeight" id="cartWeight" value="0" /></p>
    
  </div>
  
  <div class="right">
  
    <p><span><?php echo $msg_sales45; ?>:</span><input type="text" class="box" name="subTotal" id="subTotal" value="0.00" /></p>
    <p><span><?php echo $msg_addsale9; ?>:</span>- <input type="text" class="box" name="globalTotal" id="globalTotal" value="0.00" /></p>
    <p><span><?php echo $msg_viewsale30; ?>:</span><input type="text" class="box" name="shipTotal" id="shipTotal" value="0.00" /></p>
    <p><span><?php echo str_replace('{percentage}',0,$msg_viewsale23); ?>:</span><input type="hidden" name="taxRate" id="taxRate" value="0" /><input type="text" class="box" name="taxPaid" id="taxPaid" value="0.00" /></p>
    <p><span><?php echo $msg_viewsale97; ?>:</span><input type="text" class="box" name="insuranceTotal" id="insuranceTotal" value="0.00" /></p>
    <p><span><?php echo $msg_viewsale33; ?>:</span><input type="text" class="box" name="grandTotal" id="grandTotal" value="0.00" /></p>
    <p><span style="display:block;margin:0 0 5px 0"><b><?php echo $msg_viewsale19; ?></b>:</span>
    <select name="paymentMethod">
    <?php
    foreach ($mcSystemPaymentMethods AS $key => $value) {
	if ($value['enable']=='yes') {
    ?>
    <option value="<?php echo $key; ?>"><?php echo $value['lang']; ?></option>
    <?php
	}
    }
    ?>
    </select>
    </p>
  
  </div>
  
  <br class="clear" />
 
</div>

<div class="fieldHeadWrapper">
  <p><span class="float"><a class="copyfromshipping" href="#" onclick="copyFromShipping();return false" title="<?php echo mc_cleanDataEnt($msg_viewsale121); ?>"><?php echo $msg_viewsale121; ?></a></span><?php echo $msg_viewsale98; ?>:</p>
</div>

<div class="buyerAddresses" style="padding-bottom:10px">

  <div class="left">
  
    <div>
     <div style="float:left;width:49%">
      <p><span><?php echo $msg_viewsale37; ?>:</span><input type="text" class="box" name="ship_1" value="" /></p>
     </div>
     <div style="float:right;width:49%">
      <p><span><?php echo $msg_viewsale99; ?>:</span><input type="text" class="box" name="ship_3" value="" /></p>
     </div>
     <br class="clear" />
    </div> 
    
    <div>
     <div style="float:left;width:49%">
      <p><span><?php echo $msg_viewsale100; ?>:</span><input type="text" class="box" name="ship_4" value="" /></p>
     </div>
     <div style="float:right;width:49%">
      <p><span><?php echo $msg_viewsale101; ?>:</span><input type="text" class="box" name="ship_5" value="" /></p>
     </div>
     <br class="clear" />
    </div>
    
    <div>
     <div style="float:left;width:49%">
      <p><span><?php echo $msg_viewsale102; ?>:</span><input type="text" class="box" name="ship_6" value="" /></p>
     </div>
     <div style="float:right;width:49%">
      <p><span><?php echo $msg_viewsale103; ?>:</span><input type="text" class="box" name="ship_7" value="" /></p>
     </div>
     <br class="clear" />
    </div>
    
    <div>
     <div style="float:left;width:49%">
      <p><span><?php echo $msg_viewsale39; ?>:</span><input type="text" class="box" name="ship_2" value="" /></p>
     </div>
     <div style="float:right;width:49%">
      <p><span><?php echo $msg_viewsale40; ?>:</span><input type="text" class="box" name="ship_8" value="" /></p>
     </div>
     <br class="clear" />
    </div>
    
    <?php
    // Only show shipping country in address list if not shown above..
    if ($howManyZones==0) {
    ?>
    <div>
     <div style="float:left;width:49%">
      <p><span><?php echo $msg_viewsale26; ?>:</span>
      <select name="shipSetCountry">
      <?php
      $q_ctry   = mysql_query("SELECT * FROM `".DB_PREFIX."countries` 
                  WHERE `enCountry`  = 'yes'
                  ORDER BY `cName`
                  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
      while ($CTY = mysql_fetch_object($q_ctry)) {
      ?>
      <option value="<?php echo $CTY->id; ?>"><?php echo mc_cleanDataEnt($CTY->cName); ?></option>
      <?php
      }
      ?>
      </select>
      </p>
     </div>
     <div style="float:right;width:49%">
     </div>
     <br class="clear" />
    </div>
    <?php
    }
    ?>
    
    <br class="clear" />
  </div>
  
  <div class="right">
  
    <div>
     <div style="float:left;width:49%">
      <p><span><?php echo $msg_viewsale37; ?>:</span><input type="text" class="box" name="bill_1" value="" /></p>
     </div>
     <div style="float:right;width:49%">
      <p><span><?php echo $msg_viewsale99; ?>:</span><input type="text" class="box" name="bill_3" value="" /></p>
     </div>
     <br class="clear" />
    </div> 
    
    <div>
     <div style="float:left;width:49%">
      <p><span><?php echo $msg_viewsale100; ?>:</span><input type="text" class="box" name="bill_4" value="" /></p>
     </div>
     <div style="float:right;width:49%">
      <p><span><?php echo $msg_viewsale101; ?>:</span><input type="text" class="box" name="bill_5" value="" /></p>
     </div>
     <br class="clear" />
    </div> 
  
    <div>
     <div style="float:left;width:49%">
      <p><span><?php echo $msg_viewsale102; ?>:</span><input type="text" class="box" name="bill_6" value="" /></p>
     </div>
     <div style="float:right;width:49%">
      <p><span><?php echo $msg_viewsale103; ?>:</span><input type="text" class="box" name="bill_7" value="" /></p>
     </div>
     <br class="clear" />
    </div> 
    
    <div>
     <div style="float:left;width:49%">
      <p><span><?php echo $msg_viewsale39; ?>:</span><input type="text" class="box" name="bill_2" value="" /></p>
     </div>
     <div style="float:right;width:49%">
      <p><span><?php echo $msg_viewsale40; ?>:</span><input type="text" class="box" name="bill_8" value="" /></p>
     </div>
     <br class="clear" />
    </div> 
    
    <div>
     <div style="float:left;width:49%">
      <p><span><?php echo $msg_viewsale104; ?>:</span>
      <select name="bill_9">
      <?php
      $q_ctry   = mysql_query("SELECT * FROM `".DB_PREFIX."countries` 
                  WHERE `enCountry`  = 'yes'
                  ORDER BY `cName`
                  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
      while ($CTY = mysql_fetch_object($q_ctry)) {
      ?>
      <option value="<?php echo $CTY->id; ?>"><?php echo mc_cleanDataEnt($CTY->cName); ?></option>
      <?php
      }
      ?>
      </select>
      </p>
     </div>
     <div style="float:right;width:49%">
     </div>
     <br class="clear" />
    </div> 
    
    <br class="clear" />  
  </div>
  
  <br class="clear" />

</div>

<div class="fieldHeadWrapper">
  <p><?php echo $msg_viewsale7; ?>:</p>
</div>

<div class="buyerDetails" style="padding-bottom:10px">

  <div class="right">
  
    <p><span><?php echo $msg_viewsale41; ?>:</span><textarea rows="5" cols="20" name="saleNotes"></textarea></p>
    <p><span><?php echo $msg_viewsale42; ?>:</span><input type="text" class="box" name="ipAddress" value="" /></p>
    <div class="saleDates">
      <div class="dateLeft">
       <p><span><?php echo $msg_viewsale43; ?>:</span>
       <?php
       $d = explode('-',date('Y-m-d'));
       ?>
       <select name="days">
       <?php
       foreach (range(1,31) AS $days) {
       $days = ($days<10 ? '0'.$days : $days);
       ?>
       <option value="<?php echo $days; ?>"<?php echo ($d[2]==$days ? ' selected="selected"' : ''); ?>><?php echo $days; ?></option>
       <?php
       }
       ?>
       </select> : 
       <select name="months">
       <?php
       foreach (range(1,12) AS $months) {
       $slot    = ($months-1);
       $months  = ($months<10 ? '0'.$months : $months);
       ?>
       <option value="<?php echo $months; ?>"<?php echo ($d[1]==$months ? ' selected="selected"' : ''); ?>><?php echo $msg_script41[$slot]; ?></option>
       <?php
       }
       ?>
       </select> : 
       <select name="years">
       <?php
       foreach (range(2010,date('Y')+1) AS $years) {
       ?>
       <option value="<?php echo $years; ?>"<?php echo ($d[0]==$years ? ' selected="selected"' : ''); ?>><?php echo $years; ?></option>
       <?php
       }
       ?>
       </select>
       </p>
       
       <p><span class="nextInv"><a href="#" onclick="mc_nextInvoice();return false"><?php echo $msg_sales43; ?></a></span><span><?php echo $msg_viewsale65; ?>:</span>
       <input type="text" class="box" name="invoiceNo" id="invoiceNo" value="" />
       </p>
       
       <br class="clear" />
      </div>
      
      <div class="dateRight"> 
       <p><span><?php echo $msg_viewsale51; ?>:</span>
       <input type="text" class="box" name="gatewayID" value="" />
       </p>
       <br class="clear" />
      </div>  
    </div>
  </div>
  
  <br class="clear" />

</div>

<div class="fieldHeadWrapper">
  <p><?php echo $msg_addsale8; ?>:</p>
</div>

<div class="buyerDetails" style="padding-bottom:10px">

  <div class="left">
    <p><span><?php echo $msg_addsale4; ?>:</span>&nbsp;<select name="editStatus">
    <?php
    $payStatuses = mc_loadDefaultStatuses();
    // Get last status..
    foreach ($payStatuses AS $key => $value) {
    ?>
    <option value="<?php echo $key; ?>"><?php echo $value; ?></option>
    <?php
    }
    // Get additional payment statuses..
    $q_add_stats = mysql_query("SELECT * FROM `".DB_PREFIX."paystatuses` 
                   ORDER BY `pMethod`,`statname`
                   ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    if (mysql_num_rows($q_add_stats)>0) {
    ?>
    <option value="0" disabled="disabled">- - - - - - - - -</option>
    <?php
    }
    while ($ST = mysql_fetch_object($q_add_stats)) {
    ?>
    <option value="<?php echo $ST->id; ?>"><?php echo mc_cleanData($ST->statname); ?></option>
    <?php
    }
    ?>
    </select>
    </p>
  </div>
  
  <div class="right">
    <p><span><?php echo $msg_addsale5; ?>:</span><textarea rows="5" cols="20" name="editNotes" id="editNotes"><?php echo mc_cleanDataEnt($msg_addsale6); ?></textarea></p>
  </div>
  
  <br class="clear" />

</div>  

<p style="text-align:center;margin:20px 0 50px 0">
  <input type="hidden" name="process_add_sale" id="process_add_sale" value="yes" />
  <input class="formbutton" type="submit" value="<?php echo mc_cleanDataEnt($msg_addsale7); ?>" title="<?php echo mc_cleanDataEnt($msg_addsale7); ?>" />
</p>
<?php
}
?>

</form>
</div>

</div>
