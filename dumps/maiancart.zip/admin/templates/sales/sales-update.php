<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } 
$ORDER     = mc_getTableData('sales','id',mc_digitSan($_GET['sale']));
$ip        = explode(',',$ORDER->ipAddress);
$ipString  = array();
foreach ($ip AS $i) {
  $ipString[] = '<a href="http://www.ipchecking.com/?ip='.$i.'" title="'.$i.'" onclick="window.open(this);return false">'.$i.'</a>';
}
?>
<div id="content">
<script type="text/javascript">
//<![CDATA[
function checkform() {
  var message = '';
  if (jQuery('#text').val()=='' || jQuery('#title').val()=='') {
    message = '- <?php echo mc_cleanDataEnt($msg_javascript156); ?>';
  }
  if (message) {
    alert(message);
    if (jQuery('#title').val()=='') {
      jQuery('#title').focus();
    } else {
      jQuery('#text').focus();
    }
    return false;
  } else {
    return confirmMessage('<?php echo mc_cleanDataEnt($msg_javascript45); ?>');
  }
}
//]]>
</script>

<?php
if (isset($OK)) {
  echo actionCompleted($msg_salesupdate17);
}
if (isset($DEL) && $cnt>0) {
  echo actionCompleted($msg_salesupdate18);
}
echo $msg_salesupdate; 
$payStatuses = mc_loadDefaultStatuses();
$find        = array('{NAME}','{ORDER}','{WEBSITE_NAME}','{WEBSITE_URL}');
$replace     = array(mc_cleanData($ORDER->bill_1),
                     mc_saleInvoiceNumber(mc_digitSan($ORDER->invoiceNo)),
                     mc_cleanData($SETTINGS->website),
                     $SETTINGS->ifolder
               );
?>
<br /><br />

<div class="salesViewTop">
  <p><span class="float">
  <a class="edit" href="?p=sales-view&amp;sale=<?php echo mc_digitSan($_GET['sale']); ?>" title="<?php echo mc_cleanDataEnt($msg_salesupdate8); ?>"><?php echo $msg_salesupdate8; ?></a>
  <?php
  if ($ORDER->saleConfirmation=='yes') {
  if (mc_rowCount('purchases WHERE `saleID` = \''.mc_digitSan($_GET['sale']).'\' AND `saleConfirmation` = \'yes\' AND `productType` = \'physical\'')>0) {
  ?>
  <a class="packing" href="?p=packing-slip&amp;sale=<?php echo mc_digitSan($_GET['sale']); ?>" onclick="window.open(this);return false" title="<?php echo mc_cleanDataEnt($msg_sales6); ?>"><?php echo $msg_sales6; ?></a>
  <?php
  }
  ?>
  <a class="invoice" href="?p=invoice&amp;sale=<?php echo mc_digitSan($_GET['sale']); ?>" onclick="window.open(this);return false" title="<?php echo mc_cleanDataEnt($msg_sales5); ?>"><?php echo $msg_sales5; ?></a>
  <a class="export" href="?p=sales&amp;export=<?php echo mc_digitSan($_GET['sale']); ?>" title="<?php echo mc_cleanDataEnt($msg_sales4); ?>"><?php echo $msg_sales4; ?></a>
  <?php
  }
  ?>
  </span>
  <b><?php echo $msg_salesupdate2.' (#<a href="?p=sales&amp;ordered='.mc_digitSan($_GET['sale']).'" title="Products Ordered" onclick="mc_Window(this.href,\''.GREYBOX_PRODUCTS_HEIGHT.'\',\''.GREYBOX_PRODUCTS_WIDTH.'\',this.title);return false;">'.mc_saleInvoiceNumber(mc_digitSan($ORDER->invoiceNo)).'</a>)'; ?></b>
  </p>
</div>

<div id="form_field">
<form method="post" id="form" action="?p=sales-update&amp;sale=<?php echo mc_digitSan($_GET['sale']); ?>" enctype="multipart/form-data" onsubmit="return checkform()">
<div class="fieldHeadWrapper">
  <p><span class="float"><?php echo $msg_salesupdate39.implode(', ',$ipString);; ?></span><?php echo mc_cleanDataEnt($ORDER->bill_1); ?> <span title="<?php echo $ORDER->bill_2; ?>" onclick="location.href='mailto:<?php echo $ORDER->bill_2; ?>?subject=<?php echo str_replace(array("'",' ','{order}'),array("\'",'%20',mc_saleInvoiceNumber(mc_digitSan($ORDER->invoiceNo))),$msg_salesupdate36); ?>'" style="text-transform:none;font-weight:normal;cursor:pointer"><?php echo ($ORDER->bill_2 ? '&lt;'.$ORDER->bill_2.'&gt;' : '&nbsp;'); ?></span></p>
</div>

<div class="formFieldWrapper">
  <input class="box" type="text" id="title" name="title" tabindex="<?php echo (++$tabIndex); ?>" value="<?php echo str_replace(array('{website}','{order}'),array(mc_cleanData($SETTINGS->website),mc_saleInvoiceNumber(mc_digitSan($ORDER->invoiceNo))),mc_cleanDataEnt($msg_salesupdate19)); ?>" style="width:95%" />
  <br class="clear" />
</div>

<div class="formFieldWrapper">
  <p class="save" id="save">
   <a href="#" onclick="if (jQuery('#text').val()!=''){addNewStatus('<?php echo str_replace(array('\'','&#039;'),array(),$msg_javascript318); ?>');return false}else{alert('<?php echo str_replace(array('\'','&#039;'),array(),$msg_javascript324); ?>');jQuery('#text').focus();return false}"><img src="templates/images/save_status.png" alt="<?php echo mc_cleanDataEnt($msg_salesupdate23); ?>" title="<?php echo mc_cleanDataEnt($msg_salesupdate23); ?>" /></a>&nbsp;&nbsp;&nbsp;
   <a href="#" onclick="<?php echo (mc_rowCount('status_text')>0 ? 'jQuery(\'#statusesShow\').toggle(\'slow\');' : 'alert(\''.mc_cleanDataEnt($msg_javascript323).'\');'); ?>return false"><img src="templates/images/load_status.png" alt="<?php echo mc_cleanDataEnt($msg_salesupdate24); ?>" title="<?php echo mc_cleanDataEnt($msg_salesupdate24); ?>" /></a>&nbsp;&nbsp;&nbsp;
   <a href="?p=sales-statuses" title="<?php echo mc_cleanDataEnt($msg_salesupdate25); ?>" onclick="mc_Window(this.href,'<?php echo GREYBOX_STATUS_HEIGHT; ?>','<?php echo GREYBOX_STATUS_WIDTH; ?>',this.title);return false;"><img src="templates/images/manage_status.png" alt="<?php echo mc_cleanDataEnt($msg_salesupdate25); ?>" title="<?php echo mc_cleanDataEnt($msg_salesupdate25); ?>" /></a>
  </p>
  <p class="loadStatuses" id="statusesShow" style="display:none">
  <span class="float">
   <a href="#" onclick="jQuery('#statusesShow').hide('slow');return false" title="<?php echo mc_cleanDataEnt($msg_script8); ?>"><img src="templates/images/close.png" alt="<?php echo mc_cleanDataEnt($msg_script8); ?>" title="<?php echo mc_cleanDataEnt($msg_script8); ?>" /></a>
  </span>
  <select onchange="if(this.value>0){loadStatusText(this.value)}">
  <option value="0">- - - - - -</option>
  <?php
  $query = mysql_query("SELECT * FROM ".DB_PREFIX."status_text ORDER BY statTitle")
           or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  while ($STATUS = mysql_fetch_object($query)) {
  ?>
  <option value="<?php echo $STATUS->id; ?>"><?php echo mc_cleanDataEnt($STATUS->statTitle); ?></option>
  <?php
  }
  ?>
  </select>
  </p>  
  <textarea rows="5" tabindex="<?php echo (++$tabIndex); ?>" cols="30" id="text" name="text" class="updatetextarea"><?php echo mc_cleanDataEnt(str_replace($find,$replace,file_get_contents(MCLANG.'email-templates/order-updated.txt'))); ?></textarea>
  <p class="variables"><?php echo $msg_salesupdate42; ?>: {ORDER} <?php echo mc_cleanDataEnt($msg_salesupdate41); ?>, {DOWNLOADS} <?php echo mc_cleanDataEnt($msg_salesupdate40); ?></p>
  <p style="margin-top:5px;padding:10px 0 0 0"><input tabindex="<?php echo (++$tabIndex); ?>" type="checkbox" name="email" value="yes" checked="checked" /> <?php echo str_replace('{buyer}',mc_cleanData($ORDER->bill_1),$msg_salesupdate11); ?> <span style="display:block;width:700px;float:right;text-align:right"><?php echo $msg_salesupdate12; ?> <input type="text" tabindex="<?php echo (++$tabIndex); ?>" class="box" name="copy_email" value="<?php echo mc_cleanData($ORDER->orderCopyEmails); ?>" style="width:40%" /> <?php echo mc_displayHelpTip($msg_javascript249,'LEFT'); ?></span><br class="clear" /></p>
</div>

<div class="formFieldWrapper">
  <div class="formRight" style="width:33%">
    <label><?php echo $msg_salesupdate4; ?>: <?php echo mc_displayHelpTip($msg_javascript130,'RIGHT'); ?></label>
    <?php
    if ($SETTINGS->smtp=='yes') {
    ?>
    <input tabindex="<?php echo (++$tabIndex); ?>" type="file" name="attachment[]" class="box" value="" /> 
    <?php
    } else {
    echo $msg_salesupdate20;
    }
    ?>
  </div>
  <div class="formRight" style="width:33%">
    <label><?php echo $msg_salesupdate4; ?>: <?php echo mc_displayHelpTip($msg_javascript130); ?></label>
    <?php
    if ($SETTINGS->smtp=='yes') {
    ?>
    <input tabindex="<?php echo (++$tabIndex); ?>" type="file" name="attachment[]" class="box" value="" /> 
    <?php
    } else {
    echo $msg_salesupdate20;
    }
    ?>
  </div>
  <div class="formRight" style="width:33%">
    <label><?php echo $msg_salesupdate4; ?>: <?php echo mc_displayHelpTip($msg_javascript130,'LEFT'); ?></label>
    <?php
    if ($SETTINGS->smtp=='yes') {
    ?>
    <input tabindex="<?php echo (++$tabIndex); ?>" type="file" name="attachment[]" class="box" value="" /> 
    <?php
    } else {
    echo $msg_salesupdate20;
    }
    ?>
  </div>
  <br class="clear" />
</div> 

<div class="formFieldWrapper">
  <div class="formRight" style="width:33%">
    <label><?php echo $msg_salesupdate5; ?>: <?php echo mc_displayHelpTip($msg_javascript131,'RIGHT'); ?></label>
    <select name="status" id="status" tabindex="<?php echo (++$tabIndex); ?>">
    <?php
    if ($ORDER->saleConfirmation=='no') {
    ?>
    <option value=""<?php echo (isset($lastStatus->orderStatus) && $lastStatus->orderStatus=='' ? ' selected="selected"' : ''); ?>>N/A</option>
    <?php
    // Get last status..
    }
    $lastStatus = mc_getTableData('statuses','saleID',mc_digitSan($_GET['sale']),'ORDER BY id DESC','orderStatus');
    foreach ($payStatuses AS $key => $value) {
    ?>
    <option value="<?php echo $key; ?>"<?php echo (isset($lastStatus->orderStatus) && $lastStatus->orderStatus==$key ? ' selected="selected"' : ''); ?>><?php echo $value; ?></option>
    <?php
    }
    // Get additional payment statuses..
    $q_add_stats = mysql_query("SELECT * FROM ".DB_PREFIX."paystatuses 
                   WHERE pMethod IN('all','".$ORDER->paymentMethod."')
                   ORDER BY pMethod,statname
                   ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    if (mysql_num_rows($q_add_stats)>0) {
    ?>
    <option value="0" disabled="disabled">- - - - - - - - -</option>
    <?php
    }
    while ($ST = mysql_fetch_object($q_add_stats)) {
    ?>
    <option value="<?php echo $ST->id; ?>"><?php echo mc_cleanData($ST->statname); ?></option>
    <?php
    }
    ?>
    </select>
  </div>
  <div class="formRight" style="width:33%">
    <label><?php echo $msg_salesupdate9; ?>: <?php echo mc_displayHelpTip($msg_javascript132); ?></label>
    <?php echo $msg_script5; ?> <input tabindex="<?php echo (++$tabIndex); ?>" type="radio" name="save" value="yes"<?php echo (SAVE_ATTACHMENTS_TO_SERVER=='yes' ? ' checked="checked"' : ''); ?> /> <?php echo $msg_script6; ?> <input tabindex="<?php echo (++$tabIndex); ?>" type="radio" name="save" value="no"<?php echo (SAVE_ATTACHMENTS_TO_SERVER=='no' || !in_array(SAVE_ATTACHMENTS_TO_SERVER,array('yes','no')) ? ' checked="checked"' : ''); ?> />
  </div>
  <div class="formRight" style="width:33%">
    <label><?php echo $msg_salesupdate10; ?>: <?php echo mc_displayHelpTip($msg_javascript133,'LEFT'); ?></label>
    <select name="folder" id="folderList" tabindex="<?php echo (++$tabIndex); ?>">
      <option value="attachments"><?php echo $msg_salesupdate14; ?></option>
      <?php
      if (is_dir(PATH.ATTACH_FOLDER)) {
        $dir = opendir(PATH.ATTACH_FOLDER);
        while (false!==($read=readdir($dir))) {
          if (!in_array($read,array('.','..')) && is_dir(PATH.ATTACH_FOLDER.'/'.$read)) {
          ?>
          <option value="<?php echo $read; ?>"><?php echo ATTACH_FOLDER; ?>/<?php echo $read; ?></option>
          <?php
          }
        }
        closedir($dir);
      }
      ?>
    </select> <input type="button" onclick="createAttachmentFolder('<?php echo mc_cleanDataEnt($msg_javascript152); ?>')" class="createfolderbutton" name="<?php echo $msg_salesupdate13; ?>" value="+" />  
  </div>
  <br class="clear" />
</div> 

<p style="text-align:center;padding:20px 0 20px 0">
 <input type="hidden" name="process" value="1" />
 <input type="hidden" name="invoice" value="<?php echo mc_digitSan($_GET['sale']); ?>" />
 <input type="hidden" name="invoiceNo" value="<?php echo $ORDER->invoiceNo; ?>" />
 <input type="hidden" name="buyCode" value="<?php echo $ORDER->buyCode; ?>" />
 <input type="hidden" name="orderDownloads" value="<?php echo (mc_rowCount('purchases WHERE saleID = \''.mc_digitSan($_GET['sale']).'\' AND productType = \'download\'')>0 ? 'yes' : 'no'); ?>" />
 <input type="hidden" name="buyer" value="<?php echo mc_cleanData($ORDER->bill_1); ?>" />
 <input type="hidden" name="bill_2" value="<?php echo $ORDER->bill_2; ?>" />
 <input type="hidden" name="saleConfirm" value="<?php echo $ORDER->saleConfirmation; ?>" />
 <input class="formbutton" type="submit" value="<?php echo mc_cleanDataEnt($msg_salesupdate6); ?>" title="<?php echo mc_cleanDataEnt($msg_salesupdate6); ?>" />
</p>
</form>
</div>
<?php
$q_stat = mysql_query("SELECT *,DATE_FORMAT(dateAdded,'".$SETTINGS->mysqlDateFormat."') AS adate  
          FROM ".DB_PREFIX."statuses
          WHERE saleID = '".mc_digitSan($_GET['sale'])."'
          ORDER BY id DESC
          ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
?>          
<div class="fieldHeadWrapper">
  <p><?php echo (mysql_num_rows($q_stat)>0 ? '<span class="float"><a class="print_friendly" href="?p=sales-update&amp;print='.mc_digitSan($_GET['sale']).'" title="'.mc_cleanDataEnt($msg_salesupdate22).'" onclick="mc_Window(this.href,\''.GREYBOX_HEIGHT_PRINT.'\',\''.GREYBOX_WIDTH_PRINT.'\',this.title);return false;">'.$msg_salesupdate22.'</a></span>' : ''); ?><?php echo $msg_salesupdate3; ?>:</p>
</div>
<?php
if (mysql_num_rows($q_stat)>0) {
  while ($STATUS = mysql_fetch_object($q_stat)) {
  ?>
  <div id="stat_form_area_<?php echo $STATUS->id; ?>">
  <form method="post" id="stat_form_<?php echo $STATUS->id; ?>" action="?p=sales-update&amp;sale=<?php echo mc_digitSan($_GET['sale']); ?>&amp;status=<?php echo $STATUS->id; ?>">
  <div class="genWrapper">
   <div class="catLeft" style="width:20%">
    <span class="statusText"><?php echo statusText($STATUS->orderStatus); ?></span>
    <span class="dateAdded"><?php echo $STATUS->adate; ?> @ <?php echo $STATUS->timeAdded; ?></span>
    <span class="dateAdded"><?php echo $msg_salesupdate35.' '.mc_cleanData($STATUS->adminUser); ?></span>
   </div>
   <div class="genItem" style="font-size:11px;width:69%">
    <span id="notes_<?php echo $STATUS->id; ?>" title="<?php echo mc_cleanDataEnt($msg_salesupdate37); ?>" onclick="loadStatusEditBox('<?php echo $STATUS->id; ?>')">
     <?php echo nl2br(mc_cleanDataEnt($STATUS->statusNotes)); ?>
    </span>
    <span id="notes_edit_<?php echo $STATUS->id; ?>" style="display:none">
     <textarea onblur="updateStatusEditBox('<?php echo $STATUS->id; ?>')" class="statusArea" name="notesEdit" id="notes_text_<?php echo $STATUS->id; ?>" rows="5" cols="5"></textarea>
     <span class="closeEdit">[ <a href="#" onclick="closeStatusEdit('<?php echo $STATUS->id; ?>');return false" title="<?php echo mc_cleanDataEnt($msg_salesupdate38); ?>"><?php echo $msg_salesupdate38; ?></a> ]</span>
    </span>
    <?php
    // Attachments..
    $q_attach = mysql_query("SELECT * FROM ".DB_PREFIX."attachments
                WHERE saleID  = '".mc_digitSan($_GET['sale'])."'
                AND statusID  = '{$STATUS->id}'
                ORDER BY id
                ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    if (mysql_num_rows($q_attach)>0) {
      ?>
      <span class="attachments"><b><?php echo $msg_salesupdate16.' ('.mysql_num_rows($q_attach).')'; ?></b>:
      <?php  
      while ($ATTACHMENT = mysql_fetch_object($q_attach)) {
      ?>
      <span class="a_file"><a class="attachment_file" <?php echo ($ATTACHMENT->isSaved=='yes' ? 'href="'.$ATTACHMENT->attachFolder.'/'.$ATTACHMENT->fileName : 'href="#" onclick="javascript:mc_alertBox(\''.$msg_javascript155.'\');return false'); ?>" title="<?php echo mc_cleanDataEnt($ATTACHMENT->fileName); ?>"><?php echo ($ATTACHMENT->isSaved=='yes' ? $ATTACHMENT->attachFolder.'/'.$ATTACHMENT->fileName : $ATTACHMENT->fileName); ?></a> <?php echo ($ATTACHMENT->fileSize>0 ? '('.mc_fileSizeConversion($ATTACHMENT->fileSize).')' : ''); ?></span>
      <?php
      }
      ?>
      </span>
      <?php
    }
    ?>
   </div>
   <div class="genItem" style="width:5%;text-align:center">
   <?php
   if ($uDel=='yes') {
   ?>
   <a href="?p=sales-update&amp;sale=<?php echo mc_digitSan($_GET['sale']); ?>&amp;delete=<?php echo $STATUS->id; ?>" onclick="return confirmMessage('<?php echo mc_cleanDataEnt($msg_javascript45); ?>')"><img src="templates/images/delete.png" alt="<?php echo mc_cleanDataEnt($msg_script10); ?>" title="<?php echo mc_cleanDataEnt($msg_script10); ?>" /></a>
   <?php
   }
   ?>
   </div>
   <br class="clear" />
  </div>
  </form>
  </div>
  <?php
  }
} else {
?>
<p class="noData"><?php echo $msg_salesupdate15; ?></p>
<?php
}
?>
<p>&nbsp;</p>
</div>
