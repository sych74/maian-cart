<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } 
// Default filter..
$payStatuses     = mc_loadDefaultStatuses();
$_GET['filter']  = (isset($_GET['filter']) && (array_key_exists($_GET['filter'],$payStatuses) || is_numeric($_GET['filter'])) ? $_GET['filter'] : 'completed');
// Calculate range..
if (!isset($_GET['from']) && !isset($_GET['to'])) {
  if ($SETTINGS->jsWeekStart=='0') {
    switch (date('D')) {
      case 'Sun':
      $_GET['from']   = mc_convertBoxedDate(date("Y-m-d"));
      $_GET['fromts'] = date("Y-m-d");
      $_GET['to']     = mc_convertBoxedDate(date("Y-m-d",strtotime("+6 days",strtotime($_GET['fromts']))));
      break;
      default:
      $_GET['from']   = mc_convertBoxedDate(date("Y-m-d",strtotime('last sunday')));
      $_GET['fromts'] = date("Y-m-d",strtotime('last sunday'));
      $_GET['to']     = mc_convertBoxedDate(date("Y-m-d",strtotime("+6 days",strtotime($_GET['fromts']))));
      break;
    }
  } else {
    switch (date('D')) {
      case 'Mon':
      $_GET['from']   = mc_convertBoxedDate(date("Y-m-d"));
      $_GET['fromts'] = date("Y-m-d");
      $_GET['to']     = mc_convertBoxedDate(date("Y-m-d",strtotime("+6 days",strtotime($_GET['fromts']))));
      break;
      default:
      $_GET['from']   = mc_convertBoxedDate(date("Y-m-d",strtotime('last monday')));
      $_GET['fromts'] = date("Y-m-d",strtotime('last monday'));
      $_GET['to']     = mc_convertBoxedDate(date("Y-m-d",strtotime("+6 days",strtotime($_GET['fromts']))));
      break;
    }
  }
}
define('CALBOX', 'from|to');
include(PATH.'templates/date-picker.php');
?>
<div id="content">

<?php
echo $msg_revenue;
?>
<p style="text-align:right;margin:20px 0 20px 0" class="float"><a class="export_product_overview" href="?p=sales-revenue&amp;export=<?php echo (isset($_GET['filter']) ? $_GET['filter'] : 'all').(isset($_GET['from']) && !in_array($_GET['from'],array('','0000-00-00')) ? '&amp;from='.$_GET['from'] : '').(isset($_GET['to']) && !in_array($_GET['to'],array('','0000-00-00')) ? '&amp;to='.$_GET['to'] : ''); ?>" title="'<?php echo mc_cleanDataEnt($msg_revenue2); ?>"><?php echo $msg_revenue2; ?></a></p>

<form method="get" action="index.php">
<p><input type="hidden" name="p" value="sales-revenue" /></p>
<div class="statsTop">
  <div class="topLeft"><select name="filter">
  <option value="all"><?php echo $msg_revenue10; ?></option>
  <?php
  foreach ($payStatuses AS $key => $value) {
  ?>
  <option value="<?php echo $key; ?>"<?php echo (isset($_GET['filter']) && $_GET['filter']==$key ? ' selected="selected"' : ''); ?>><?php echo $value; ?></option>
  <?php
  }
  // Get additional payment statuses..
  $q_add_stats = mysql_query("SELECT * FROM `".DB_PREFIX."paystatuses` 
                 ORDER BY `pMethod`,`statname`
                 ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  if (mysql_num_rows($q_add_stats)>0) {
  ?>
  <option value="0" disabled="disabled">- - - - - - - - -</option>
  <?php
  }
  while ($ST = mysql_fetch_object($q_add_stats)) {
  ?>
  <option value="<?php echo $ST->id; ?>"<?php echo (isset($_GET['filter']) && $_GET['filter']==$ST->id ? ' selected="selected"' : ''); ?>><?php echo mc_cleanData($ST->statname); ?></option>
  <?php
  }
  ?>
  </select></div>
  <div class="topRight">
    <p><b><?php echo $msg_stats4; ?></b>: <input type="text" name="from" value="<?php echo (!in_array($_GET['from'],array('','0000-00-00')) ? (isset($_GET['fromts']) ? enterDatesBox($_GET['from']) : mc_cleanDataEnt($_GET['from'])) : ''); ?>" class="box" style="width:20%" id="from" /> <?php echo $msg_salessearch5; ?> <input type="text" name="to" value="<?php echo (!in_array($_GET['to'],array('','0000-00-00')) ? (isset($_GET['fromts']) ? enterDatesBox($_GET['to']) : mc_cleanDataEnt($_GET['to'])) : ''); ?>" class="box" style="width:20%" id="to" /> <input type="submit" class="formbutton" value="<?php echo mc_cleanDataEnt($msg_stats5); ?>" title="<?php echo mc_cleanDataEnt($msg_stats5); ?>" /></p>
  </div>
  <br class="clear" />
</div>
</form>
<?php
$SQL = '';
if (mc_checkValidDate($_GET['from'])!='0000-00-00' && mc_checkValidDate($_GET['to'])!='0000-00-00') {
  $SQL .= mc_defineNewline().'AND `'.DB_PREFIX.'purchases`.`purchaseDate` BETWEEN \''.mc_convertCalToSQLFormat($_GET['from']).'\' AND \''.mc_convertCalToSQLFormat($_GET['to']).'\'';
}
?>
<div class="revenueWrapper">
  <div class="revenue">
  <ul>
   <li class="date"><?php echo $msg_revenue3; ?></li>
   <li class="grand"><?php echo $msg_revenue7; ?></li>
   <li class="tax"><?php echo $msg_revenue6; ?></li>
   <li class="ship"><?php echo $msg_revenue5; ?></li>
   <li class="sub"><?php echo $msg_revenue4; ?></li>
  </ul>
  <br class="clear" />
  </div>
</div>

<?php
// Loop through date range..
if ($_GET['from']!='' && $_GET['to']!='') {
$start     = strtotime(mc_convertCalToSQLFormat($_GET['from']));
$end       = strtotime(mc_convertCalToSQLFormat($_GET['to']));
$loopDays  = round(($end-$start)/86400);
$split     = explode('-',mc_convertCalToSQLFormat($_GET['from']));
$gTot      = array('0.00','0.00','0.00','0.00');
if ($loopDays>0) {
for ($i=0; $i<($loopDays+1); $i++) {
$ts       = strtotime(date('Y-m-d',mktime(0,0,0,$split[1],$split[2],$split[0])));
$day      = date($SETTINGS->systemDateFormat,strtotime('+ '.$i.' days',$ts));
$sday     = date('Y-m-d',strtotime('+ '.$i.' days',$ts));
$qS       = mysql_query("SELECT 
            SUM(`subTotal`) AS `sub`,
            SUM(`shipTotal`) AS `ship`,
            SUM(`taxPaid`) AS `tax`,
            SUM(`grandTotal`) AS `grand` 
            FROM `".DB_PREFIX."sales`
            WHERE `saleConfirmation`  = 'yes'
            AND `purchaseDate`        = '$sday'
            AND `paymentStatus`       = '{$_GET['filter']}'
            GROUP BY `purchaseDate`
            ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
$SALE     = mysql_fetch_object($qS);
// Increment..
$gTot[0]  = mc_formatPrice($gTot[0]+(isset($SALE->sub) ? $SALE->sub : '0.00'));
$gTot[1]  = mc_formatPrice($gTot[1]+(isset($SALE->ship) ? $SALE->ship : '0.00'));
$gTot[2]  = mc_formatPrice($gTot[2]+(isset($SALE->tax) ? $SALE->tax : '0.00'));
$gTot[3]  = mc_formatPrice($gTot[3]+(isset($SALE->grand) ? $SALE->grand : '0.00'));
?>
<div class="revenueWrapperTotal">
  <div class="revenue">
  <ul>
   <li class="date"><?php echo $day; ?></li>
   <li class="grand"><?php echo mc_currencyFormat(mc_formatPrice((isset($SALE->grand) ? $SALE->grand : '0.00'),true)); ?></li>
   <li class="tax"><?php echo mc_currencyFormat(mc_formatPrice((isset($SALE->tax) ? $SALE->tax : '0.00'),true)); ?></li>
   <li class="ship"><?php echo mc_currencyFormat(mc_formatPrice((isset($SALE->ship) ? $SALE->ship : '0.00'),true)); ?></li>
   <li class="sub"><?php echo mc_currencyFormat(mc_formatPrice((isset($SALE->sub) ? $SALE->sub : '0.00'),true)); ?></li>
  </ul>
  <br class="clear" />
  </div>
</div>
<?php
}
?>

<div class="revenueWrapperGrandTotal">
  <div class="revenue">
  <ul>
   <li class="date"><?php echo $msg_revenue9; ?></li>
   <li class="grand"><?php echo mc_currencyFormat(mc_formatPrice($gTot[3],true)); ?></li>
   <li class="tax"><?php echo mc_currencyFormat(mc_formatPrice($gTot[2],true)); ?></li>
   <li class="ship"><?php echo mc_currencyFormat(mc_formatPrice($gTot[1],true)); ?></li>
   <li class="sub"><?php echo mc_currencyFormat(mc_formatPrice($gTot[0],true)); ?></li>
  </ul>
  <br class="clear" />
  </div>
</div>
<?php
} else {
?>
<span class="noData"><?php echo $msg_revenue8; ?></span>
<?php
}
} else {
?>
<span class="noData"><?php echo $msg_revenue11; ?></span>
<?php
}
?>

</div>
