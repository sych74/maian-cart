<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } 
define('CALBOX', 'from|to');
include(PATH.'templates/date-picker.php');
?>
<div id="content">

<?php
if (isset($OK)) {
  echo actionCompleted($msg_hit_overview5);
}
echo $msg_slsproductoverview;
?>
<br /><br />

<div class="statsTop">
  <div class="topLeft"><select onchange="if(this.value!= 0){location=this.options[this.selectedIndex].value}">
  <option value="?p=sales-product-overview"><?php echo $msg_productmanage5; ?></option>
  <?php
  $q_cats = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
            WHERE catLevel = '1'
            AND childOf    = '0'
            AND enCat      = 'yes'
            ORDER BY catname") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  while ($CATS = mysql_fetch_object($q_cats)) {
  ?>
  <option value="?p=sales-product-overview&amp;cat=<?php echo $CATS->id.(isset($_GET['from']) && !in_array($_GET['from'],array('','0000-00-00')) ? '&amp;from='.$_GET['from'] : '').(isset($_GET['to']) && !in_array($_GET['to'],array('','0000-00-00')) ? '&amp;to='.$_GET['to'] : ''); ?>"<?php echo (isset($_GET['cat']) && mc_digitSan($_GET['cat'])==$CATS->id ? ' selected="selected"' : ''); ?>><?php echo mc_cleanDataEnt($CATS->catname); ?></option>
  <?php
  $q_children = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
                WHERE catLevel = '2'
                AND enCat      = 'yes'
                AND childOf    = '".$CATS->id."'
                ORDER BY catname") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  while ($CHILDREN = mysql_fetch_object($q_children)) {
  ?>
  <option value="?p=sales-product-overview&amp;cat=<?php echo $CHILDREN->id.(isset($_GET['from']) && !in_array($_GET['from'],array('','0000-00-00')) ? '&amp;from='.$_GET['from'] : '').(isset($_GET['to']) && !in_array($_GET['to'],array('','0000-00-00')) ? '&amp;to='.$_GET['to'] : ''); ?>"<?php echo (isset($_GET['cat']) && mc_digitSan($_GET['cat'])==$CHILDREN->id ? ' selected="selected"' : ''); ?>>- <?php echo mc_cleanDataEnt($CHILDREN->catname); ?></option>
  <?php
  $q_infants = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
               WHERE catLevel = '3'
               AND childOf    = '{$CHILDREN->id}'
               AND enCat      = 'yes'
               ORDER BY catname
               ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  while ($INFANTS = mysql_fetch_object($q_infants)) {
  ?>
  <option value="?p=sales-product-overview&amp;cat=<?php echo $INFANTS->id.(isset($_GET['from']) && !in_array($_GET['from'],array('','0000-00-00')) ? '&amp;from='.$_GET['from'] : '').(isset($_GET['to']) && !in_array($_GET['to'],array('','0000-00-00')) ? '&amp;to='.$_GET['to'] : ''); ?>"<?php echo (isset($_GET['cat']) && mc_digitSan($_GET['cat'])==$INFANTS->id ? ' selected="selected"' : ''); ?>>&nbsp;&nbsp;- <?php echo mc_cleanDataEnt($INFANTS->catname); ?></option>
  <?php
  }
  }
  }
  ?>
  </select></div>
  <div class="topRight">
  <form method="get" action="index.php">
   <p><b><?php echo $msg_stats4; ?></b>: <input type="hidden" name="p" value="sales-product-overview" /><?php echo (isset($_GET['cat']) ? '<input type="hidden" name="cat" value="'.mc_digitSan($_GET['cat']).'" />' : ''); ?><input type="text" name="from" value="<?php echo (isset($_GET['from']) && !in_array($_GET['from'],array('','0000-00-00')) ? mc_checkValidDate($_GET['from']) : ''); ?>" class="box" style="width:20%" id="from" /> <?php echo $msg_salessearch5; ?> <input type="text" name="to" value="<?php echo (isset($_GET['to']) && !in_array($_GET['to'],array('','0000-00-00')) ? mc_checkValidDate($_GET['to']) : ''); ?>" class="box" style="width:20%" id="to" /> <input type="submit" class="formbutton" value="<?php echo mc_cleanDataEnt($msg_stats5); ?>" title="<?php echo mc_cleanDataEnt($msg_stats5); ?>" /></p>
  </form>
  </div>
  <br class="clear" />
</div>

<?php
$SQL       = '';
if (isset($_GET['cat'])) {
  $SQL = 'AND categoryID = \''.mc_digitSan($_GET['cat']).'\'';
}
if (isset($_GET['from']) && isset($_GET['to']) && mc_checkValidDate($_GET['from'])!='0000-00-00' && mc_checkValidDate($_GET['to'])!='0000-00-00') {
  $SQL .= mc_defineNewline().'AND '.DB_PREFIX.'purchases.purchaseDate BETWEEN \''.mc_convertCalToSQLFormat($_GET['from']).'\' AND \''.mc_convertCalToSQLFormat($_GET['to']).'\'';
}
$q_c = mysql_query("SELECT SUM(productQty) AS cnt 
       FROM ".DB_PREFIX."purchases
       WHERE saleConfirmation = 'yes'
       ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
$tH         = mysql_fetch_object($q_c); 
$totalHits  = (isset($tH->cnt) ? $tH->cnt : 0);   
$q_p = mysql_query("SELECT SQL_CALC_FOUND_ROWS *,SUM(productQty) AS cnt,".DB_PREFIX."purchases.id AS pid,
       ".DB_PREFIX."products.id AS pr_id
       FROM ".DB_PREFIX."purchases
       LEFT JOIN ".DB_PREFIX."products
       ON ".DB_PREFIX."purchases.productID         = ".DB_PREFIX."products.id
       LEFT JOIN ".DB_PREFIX."sales
       ON ".DB_PREFIX."purchases.saleID            = ".DB_PREFIX."sales.id
       WHERE ".DB_PREFIX."sales.saleConfirmation   = 'yes'
       AND ".DB_PREFIX."purchases.saleConfirmation = 'yes'
       AND ".DB_PREFIX."products.id                > 0
       $SQL
       GROUP BY ".DB_PREFIX."purchases.productID
       ORDER BY cnt DESC,".DB_PREFIX."products.pName
       LIMIT $limit,".PRODUCTS_PER_PAGE."
       ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
$c            = mysql_fetch_object(mysql_query("SELECT FOUND_ROWS() AS rows"));
$countedRows  =  (isset($c->rows) ? $c->rows : '0');       
?>
<div class="fieldHeadWrapper">
  <p><?php echo (mysql_num_rows($q_p)>0 ? '<span class="float"><a class="export_product_overview" href="?p=sales-product-overview&amp;export='.(isset($_GET['cat']) ? mc_digitSan($_GET['cat']) : 'all').(isset($_GET['from']) && !in_array($_GET['from'],array('','0000-00-00')) ? '&amp;from='.$_GET['from'] : '').(isset($_GET['to']) && !in_array($_GET['to'],array('','0000-00-00')) ? '&amp;to='.$_GET['to'] : '').'" title="'.mc_cleanDataEnt($msg_slsproductoverview2).'">'.$msg_slsproductoverview2.'</a></span>' : ''); ?><?php echo mc_cleanDataEnt($msg_javascript163); ?>:</p>
</div>
<?php       
if (mysql_num_rows($q_p)>0) {
while ($PURCHASE = mysql_fetch_object($q_p)) {
$perc  = 0;
// Prevent division by zero errors..
if ($PURCHASE->cnt>0) {
  $perc = number_format($PURCHASE->cnt/$totalHits*100,STATS_DECIMAL_PLACES);
}
?>
<div class="hitsOverviewWrapper">
 <div class="productName">
  <p><a href="?p=add-product&amp;edit=<?php echo $PURCHASE->pr_id; ?>" title="<?php echo mc_cleanDataEnt($msg_script9).': '.mc_cleanData($PURCHASE->pName); ?>"><?php echo mc_cleanData($PURCHASE->pName); ?></a></p>
 </div>
 <div class="totalHits">
   <p><?php echo number_format($PURCHASE->cnt); ?></p>
 </div>
 <div class="bar">
  <p title="<?php echo number_format($PURCHASE->cnt).' '.mc_cleanDataEnt($msg_slsproductoverview3).' ('.$perc.'% '.mc_cleanDataEnt($msg_slsproductoverview4).')'; ?>"><span class="progress" style="width:<?php echo $perc; ?>%"><?php echo ($PURCHASE->cnt>0 ? '&nbsp;' : ''); ?></span><?php echo ($PURCHASE->cnt==0 ? '&nbsp;' : ''); ?></p>
 </div>
 <div class="percentage">
   <p><?php echo $perc; ?>%</p>
 </div>
 <br class="clear" />
</div>
<?php
}
define('PER_PAGE',PRODUCTS_PER_PAGE);
if ($countedRows>0 && $countedRows>PER_PAGE) {
  $PTION = new pagination($countedRows,'?p='.$cmd.'&amp;next=');
  echo $PTION->display();
}
} else {
?>
<span class="noData"><?php echo ($SQL ? $msg_slsproductoverview5 : $msg_slsproductoverview6); ?></span>
<?php
}
?>
</div>
