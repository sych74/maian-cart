<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } ?>
<div id="content">

<?php
if (isset($OK)) {
  echo actionCompleted($msg_viewsale11);
}
if (isset($OK2)) {
  echo actionCompleted($msg_viewsale10);
}
if (isset($OK_ADD)) {
  echo actionCompleted($msg_viewsale77);
}
echo $msg_viewsale;
?>
<br /><br />

<div class="salesViewTop">
  <p><span class="float">
  <a class="update" href="?p=sales-update&amp;sale=<?php echo mc_digitSan($_GET['sale']); ?>" title="<?php echo mc_cleanDataEnt($msg_sales2); ?>"><?php echo $msg_sales2; ?></a>
  <?php
  if ($SALE->saleConfirmation=='yes') {
  if (mc_rowCount('purchases WHERE `saleID` = \''.mc_digitSan($_GET['sale']).'\' AND `saleConfirmation` = \'yes\' AND `productType` = \'physical\'')>0) {
  ?>
  <a class="packing" href="?p=packing-slip&amp;sale=<?php echo mc_digitSan($_GET['sale']); ?>" onclick="window.open(this);return false" title="<?php echo mc_cleanDataEnt($msg_sales6); ?>"><?php echo $msg_sales6; ?></a>
  <?php
  }
  ?>
  <a class="invoice" href="?p=invoice&amp;sale=<?php echo mc_digitSan($_GET['sale']); ?>" onclick="window.open(this);return false" title="<?php echo mc_cleanDataEnt($msg_sales5); ?>"><?php echo $msg_sales5; ?></a>
  <a class="export" href="?p=sales&amp;export=<?php echo mc_digitSan($_GET['sale']); ?>" title="<?php echo mc_cleanDataEnt($msg_sales4); ?>"><?php echo $msg_sales4; ?></a>
  <?php
  }
  ?>
  </span>
  <b><?php echo $msg_viewsale74.' (#'.mc_saleInvoiceNumber(mc_digitSan($SALE->invoiceNo)).')'; ?></b>
  </p>
</div>

<div id="form_field">
<form method="post" id="form" action="?p=sales-view&amp;sale=<?php echo mc_digitSan($_GET['sale']); ?>" onsubmit="return confirmMessage('<?php echo mc_cleanDataEnt($msg_javascript45); ?>')">
<?php
// Physical..
$q_phys = mysql_query("SELECT *,`".DB_PREFIX."products`.`id` AS `pid`,`".DB_PREFIX."purchases`.`id` AS `pcid` FROM `".DB_PREFIX."purchases`
          LEFT JOIN `".DB_PREFIX."products`
          ON `".DB_PREFIX."purchases`.`productID` = ".DB_PREFIX."products.id
          WHERE `saleID`                        = '".mc_digitSan($_GET['sale'])."' 
          AND `productType`                     = 'physical' 
          ".($SALE->saleConfirmation=='no' ? '' : 'AND `saleConfirmation` = \'yes\'')."
          ORDER BY ".DB_PREFIX."purchases.id
          ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
?>
<div class="fieldHeadWrapper">
  <p><span class="float"><?php echo (mc_rowCount('purch_pers WHERE `saleID` = \''.mc_digitSan($_GET['sale']).'\'')>0 ? '<a class="print_personalisation" onclick="mc_Window(this.href,\''.GREYBOX_PERS_HEIGHT.'\',\''.GREYBOX_PERS_WIDTH.'\',this.title);return false;" href="?p=sales-view&amp;print-personalisation='.mc_digitSan($_GET['sale']).'" title="'.mc_cleanDataEnt($msg_viewsale59).'">'.$msg_viewsale59.'</a>' : ''); ?><a class="add" onclick="mc_Window(this.href,'<?php echo GREYBOX_HEIGHT-100; ?>','<?php echo GREYBOX_WIDTH; ?>',this.title);return false;" href="?p=add&amp;sale=<?php echo mc_digitSan($_GET['sale']); ?>&amp;type=physical" title="<?php echo mc_cleanDataEnt($msg_viewsale4); ?>"><?php echo $msg_viewsale4; ?></a></span><?php echo $msg_viewsale2; ?> (<?php echo mc_sumCount('purchases WHERE `saleID` = \''.mc_digitSan($_GET['sale']).'\' AND `productType` = \'physical\'','productQty'); ?>):</p>
</div>

<?php
if (mysql_num_rows($q_phys)>0) {
while ($PHYS = mysql_fetch_object($q_phys)) {
$details      = '';
$code         = ($PHYS->pCode ? $PHYS->pCode : 'N/A');
$weight       = ($PHYS->pWeight ? $PHYS->pWeight : 'N/A');
$PHYS->pName  = ($PHYS->pName ? $PHYS->pName : $PHYS->deletedProductName);
$isDel        = ($PHYS->deletedProductName ? '<b class="deletedItem">'.$msg_script53.'</b>' : ''); 
$img          = storeProductImg($PHYS->pid,$PHYS);
$hasAttribs   = mc_rowCount('attributes WHERE `productID` = \''.$PHYS->pid.'\'');
?>
<div class="salePurchase" id="purchase_<?php echo $PHYS->pcid; ?>">
  <input type="hidden" name="pid[]" value="<?php echo $PHYS->pcid; ?>" />
  <input type="hidden" name="prod_id[]" value="<?php echo $PHYS->pid; ?>" />
  <div class="left"> 
    <p><?php echo $img; ?></p>
  </div>
  <div class="middle">  
    <p><?php echo mc_cleanDataEnt($PHYS->pName).($details ? ' <span class="highlight">('.$details.')</span>' : '').$isDel; ?></p>
    <?php
	if ($hasAttribs>0) {
	?>
	<div class="attrSaleBoxes" id="prodAttrArea_<?php echo $PHYS->pcid; ?>">
	<span style="float:right"><img src="templates/images/calculator.png" alt="<?php echo mc_cleanDataEnt($msg_viewsale113); ?>" title="<?php echo mc_cleanDataEnt($msg_viewsale113); ?>" style="cursor:pointer" onclick="calcAttr('<?php echo $PHYS->pid; ?>','<?php echo $PHYS->pcid; ?>')" /></span>
	<?php
    // Attributes
	$alreadyLoaded = array();
    $q_att = mysql_query("SELECT * FROM `".DB_PREFIX."purch_atts`
             WHERE `saleID` = '{$SALE->id}'
             ORDER BY `id`
             ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    if (mysql_num_rows($q_att)>0) { 
	while ($ATTRIBUTES = mysql_fetch_object($q_att)) {
	$alreadyLoaded[] = $ATTRIBUTES->attributeID;
	?>
	<div id="attr_<?php echo $PHYS->pcid.'_'.$ATTRIBUTES->id; ?>"><input type="text" class="box" name="attr[<?php echo $PHYS->pcid; ?>][<?php echo $ATTRIBUTES->attributeID; ?>]" value="<?php echo mc_cleanDataEnt($ATTRIBUTES->attrName); ?>" /> @ <input type="text" class="box" style="width:10%" name="attr_cost[<?php echo $PHYS->pcid; ?>][<?php echo $ATTRIBUTES->attributeID; ?>]" value="<?php echo mc_cleanDataEnt($ATTRIBUTES->addCost); ?>" /> <a href="#" onclick="hideAttrBox('<?php echo $PHYS->pcid; ?>','<?php echo $ATTRIBUTES->id; ?>');return false">X</a></div>
	<?php
	}
	}
	// Possible attributes..
	?>
	<div class="add" id="attsel_<?php echo $PHYS->pcid; ?>" style="display:none">
	<?php
	$q_attc = mysql_query("SELECT *,`".DB_PREFIX."attributes`.`id` AS `attrID` FROM `".DB_PREFIX."attributes`
	          LEFT JOIN `".DB_PREFIX."attr_groups`
			  ON `".DB_PREFIX."attributes`.`attrGroup`    = `".DB_PREFIX."attr_groups`.`id`
              WHERE `".DB_PREFIX."attributes`.`productID` = '{$PHYS->pid}'
			  ORDER BY `".DB_PREFIX."attr_groups`.`groupName`
              ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    if (mysql_num_rows($q_attc)>0) { 
	?>
	<select name="attsel" id="s_<?php echo $PHYS->pcid; ?>" onchange="if(this.value!='0'){addAttributeToSale(this.value,'<?php echo $PHYS->pcid; ?>','<?php echo $PHYS->pid; ?>')}">
	<option value="0"><?php echo $msg_viewsale112; ?></option>
	<?php
	while ($ATTSEL = mysql_fetch_object($q_attc)) {
	?>
	<option value="<?php echo $ATTSEL->attrID; ?>" id="sel_<?php echo $PHYS->pcid; ?>_<?php echo $ATTSEL->attrID; ?>"<?php echo (in_array($ATTSEL->attrID,$alreadyLoaded) ? ' style="display:none"' : ''); ?>><?php echo mc_cleanData($ATTSEL->groupName.' - '.$ATTSEL->attrName); ?></option>
	<?php
	}
	?>
	</select> <a href="#" onclick="remAttrDropDown('<?php echo $PHYS->pcid; ?>');return false">X</a>
	<?php
	}
	?>
	</div>
	<div class="links" id="alinks_<?php echo $PHYS->pcid; ?>"><a href="#" onclick="hideAttr('<?php echo $PHYS->pcid; ?>');return false" title="<?php echo mc_cleanDataEnt($msg_viewsale110); ?>"><?php echo mc_cleanDataEnt($msg_viewsale110); ?></a> <a class="edit" href="?p=product-attributes&amp;product=<?php echo $PHYS->pid; ?>" onclick="window.open(this);return false" title="<?php echo mc_cleanDataEnt($msg_viewsale111); ?>"><?php echo mc_cleanDataEnt($msg_viewsale111); ?></a></div>
	</div>
	<?php
	}
	
    // Personalisation
    $q_ps1 = mysql_query("SELECT * FROM `".DB_PREFIX."personalisation`
             WHERE `productID` = '{$PHYS->pid}'
             AND `enabled`     = 'yes'
             ORDER BY `id`
             ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    if (mysql_num_rows($q_ps1)>0) {     
    ?>
    <div class="personalisation" id="pWrapper_<?php echo $PHYS->pcid; ?>">
    <span style="float:right"><img src="templates/images/calculator.png" alt="<?php echo mc_cleanDataEnt($msg_viewsale114); ?>" title="<?php echo mc_cleanDataEnt($msg_viewsale114); ?>" style="cursor:pointer" onclick="calcPers('<?php echo $PHYS->pid; ?>','<?php echo $PHYS->pcid; ?>')" /></span>
	<?php
    $iBoxes = 0;
    while ($PS = mysql_fetch_object($q_ps1)) {
    ++$iBoxes;
    $q_ps = mysql_query("SELECT * FROM `".DB_PREFIX."purch_pers`
            WHERE `purchaseID`       = '{$PHYS->pcid}'
            AND `saleID`             = '".mc_digitSan($_GET['sale'])."'
            AND `productID`          = '{$PHYS->pid}'
            AND `personalisationID`  = '{$PS->id}'
            ORDER BY `id`
            ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    $PERS_ITEM    = mysql_fetch_object($q_ps);
    $cost         = (isset($PERS_ITEM->addCost) ? $PERS_ITEM->addCost : $PS->persAddCost);
    $PS->boxType  = ($PS->persOptions ? 'select' : $PS->boxType);
    // Input boxes for new items only..
    $inputBoxes = '<input type="hidden" name="pidnew['.$PHYS->pcid.'][]" value="'.$PHYS->pcid.'" />
    <input type="hidden" name="product['.$PHYS->pcid.'][]" value="'.$PHYS->pid.'" />
    <input type="hidden" name="cost['.$PHYS->pcid.'][]" value="'.$PS->persAddCost.'" />';
    switch ($PS->boxType) {
     case 'input':
     ?>
     <span class="personalisation_item"><?php echo mc_persTextDisplay(mc_cleanDataEnt($PS->persInstructions),true); ?> <span class="personalisation_item_price">(<?php echo str_replace('{extra_cost}',mc_currencyFormat($cost),($cost>0 ? $msg_viewsale54 : $msg_viewsale55)); ?>)</span></span>
     <span class="personalisation_item_data"><?php echo $inputBoxes; ?><input type="hidden" name="pers[<?php echo $PHYS->pcid; ?>][]" value="<?php echo (isset($PERS_ITEM->id) ? $PERS_ITEM->id : $PS->id); ?>" /><input id="ibox_<?php echo $PHYS->pcid; ?>_<?php echo $iBoxes; ?>" class="box" type="text" name="pvalue[<?php echo $PHYS->pcid; ?>][]" value="<?php echo (isset($PERS_ITEM->visitorData) ? mc_cleanDataEnt($PERS_ITEM->visitorData) : ''); ?>" /></span>
     <?php
     break;
     case 'textarea':
     ?>
     <span class="personalisation_item"><?php echo mc_persTextDisplay(mc_cleanDataEnt($PS->persInstructions),true); ?> <span class="personalisation_item_price">(<?php echo str_replace('{extra_cost}',mc_currencyFormat($cost),($cost>0 ? $msg_viewsale54 : $msg_viewsale55)); ?>)</span></span>
     <span class="personalisation_item_data"><?php echo $inputBoxes; ?><input type="hidden" name="pers[<?php echo $PHYS->pcid; ?>][]" value="<?php echo (isset($PERS_ITEM->id) ? $PERS_ITEM->id : $PS->id); ?>" /><textarea id="ibox_<?php echo $PHYS->pcid; ?>_<?php echo $iBoxes; ?>" name="pvalue[<?php echo $PHYS->pcid; ?>][]" rows="5" cols="20"><?php echo (isset($PERS_ITEM->visitorData) ? mc_cleanDataEnt($PERS_ITEM->visitorData) : ''); ?></textarea></span>
     <?php
     break;
     case 'select':
     ?>
     <span class="personalisation_item"><?php echo mc_persTextDisplay(mc_cleanDataEnt($PS->persInstructions),true); ?> <span class="personalisation_item_price">(<?php echo str_replace('{extra_cost}',mc_currencyFormat($cost),($cost>0 ? $msg_viewsale54 : $msg_viewsale55)); ?>)</span></span>
     <span class="personalisation_item_data"><?php echo $inputBoxes; ?><input type="hidden" name="pers[<?php echo $PHYS->pcid; ?>][]" value="<?php echo (isset($PERS_ITEM->id) ? $PERS_ITEM->id : $PS->id); ?>" /><select name="pvalue[<?php echo $PHYS->pcid; ?>][]" id="ibox_<?php echo $PHYS->pcid; ?>_<?php echo $iBoxes; ?>">
     <option value="no-option-selected">- - - - -</option>
     <?php 
     $OPT = explode('||',$PS->persOptions);
     foreach ($OPT AS $o) {
     ?>
     <option value="<?php echo $o; ?>"<?php echo (isset($PERS_ITEM->visitorData) && $o==$PERS_ITEM->visitorData ? ' selected="selected"' : ''); ?>><?php echo mc_cleanData($o); ?></option>
     <?php
     }
     ?>
     </select>
     </span>
     <?php
     break;
    }
    }
    ?>
    </div>
    <?php
    }
    ?>
  </div>
  <div class="right">
    <p>
    <?php echo $msg_viewsale32; ?>: 
    <select name="qty[]" id="qty_<?php echo $PHYS->pcid; ?>" onchange="if(jQuery('#qty_<?php echo $PHYS->pcid; ?>').val()=='0') {alert('<?php echo mc_cleanDataEnt($msg_javascript220); ?>');mc_MarkForDeletion('<?php echo $PHYS->pcid; ?>');}else{displayPurchaseProductPrices('<?php echo $PHYS->pcid; ?>','sales-view');}">
    <?php
    foreach (range(0,SALE_QTY_LIMIT) AS $qty) {
    ?>
    <option value="<?php echo $qty; ?>"<?php echo ($PHYS->productQty==$qty ? ' selected="selected"' : ''); ?>><?php echo $qty; ?></option>
    <?php
    }
    ?>
    </select>
    @ <input class="price" id="price_<?php echo $PHYS->pcid; ?>" type="text" onblur="displayPurchaseProductPrices('<?php echo $PHYS->pcid; ?>','sales-view')" name="price[]" value="<?php echo mc_formatPrice($PHYS->salePrice); ?>" />
    <?php
    if ($hasAttribs>0) {
    ?>
    <span class="priceBox"><?php echo $msg_viewsale88; ?>: <input class="price" id="attr_<?php echo $PHYS->pcid; ?>" type="text" onblur="displayPurchaseProductPrices('<?php echo $PHYS->pcid; ?>','sales-view')" name="attrPrice[]" value="<?php echo mc_formatPrice($PHYS->attrPrice); ?>" /></span>
    <?php
    } else {
    ?>
    <input type="hidden" name="attrPrice[]" value="0.00" />
    <?php
    }
    if (mysql_num_rows($q_ps1)>0) { 
    ?>
    <span class="priceBox"><?php echo $msg_viewsale87; ?>: <input class="price" id="pers_<?php echo $PHYS->pcid; ?>" type="text" onblur="displayPurchaseProductPrices('<?php echo $PHYS->pcid; ?>','sales-view')" name="persPrice[]" value="<?php echo mc_formatPrice($PHYS->persPrice); ?>" /></span>
    <?php
    } else {
    ?>
    <input type="hidden" name="persPrice[]" value="0.00" />
    <?php
    }
    ?>
    <span class="priceBox"><?php echo $msg_viewsale94; ?>: <input class="price" id="qtyadj_<?php echo $PHYS->pcid; ?>" type="text" name="qtyAdjustment[]" value="<?php echo $PHYS->pStock; ?>" /></span>
    </p>
  </div>
  <br class="clear" />  
  <p class="priceBar">
    <span class="options">
	<?php
    if ($isDel=='') {
     echo str_replace(array('{code}','{url}'),array($code,'../?pID='.$PHYS->pid),$msg_viewsale16);
	 echo str_replace(array('{code}','{url}'),array($code,'?p=add-product&amp;edit='.$PHYS->pid),$msg_viewsale93);
    }
    ?>
	</span>
    <span class="highlight" id="highlight_<?php echo $PHYS->pcid; ?>"><?php echo mc_currencyFormat(mc_formatPrice(($PHYS->productQty*$PHYS->salePrice)+($PHYS->persPrice+$PHYS->attrPrice),true)); ?></span>
    <input type="hidden" id="total_price_<?php echo $PHYS->pcid; ?>" name="t_price[]" value="<?php echo mc_formatPrice(($PHYS->productQty*$PHYS->salePrice)+($PHYS->persPrice+$PHYS->attrPrice)); ?>" />
  </p>
</div>
<?php
}
} else {
?>
<p class="noData" style="margin-bottom:5px"><?php echo $msg_viewsale14; ?></p>
<?php
}

// Downloadable..
$q_down = mysql_query("SELECT *,`".DB_PREFIX."products`.`id` AS `pid`,`".DB_PREFIX."purchases`.`id` AS `pcid` FROM `".DB_PREFIX."purchases`
          LEFT JOIN `".DB_PREFIX."products`
          ON `".DB_PREFIX."purchases`.`productID` = `".DB_PREFIX."products`.`id`
          WHERE `saleID`                        = '".mc_digitSan($_GET['sale'])."' 
          AND `productType`                     = 'download' 
          ".($SALE->saleConfirmation=='no' ? '' : 'AND `saleConfirmation` = \'yes\'')."
          ORDER BY `".DB_PREFIX."purchases`.`id`
          ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
?>
<div class="fieldHeadWrapper">
  <p><span class="float"><?php echo (mysql_num_rows($q_down)>0 && $SALE->saleConfirmation=='yes' ? '<a class="down" onclick="mc_Window(this.href,\''.GREYBOX_DOWNLOADS_HEIGHT.'\',\''.GREYBOX_DOWNLOADS_WIDTH.'\',this.title);return false;" href="?p=downloads&amp;sale='.mc_digitSan($_GET['sale']).'" title="'.mc_cleanDataEnt($msg_viewsale17).'">'.$msg_viewsale17.'</a>' : ''); ?><a class="add" onclick="mc_Window(this.href,'<?php echo GREYBOX_HEIGHT-100; ?>','<?php echo GREYBOX_WIDTH; ?>',this.title);return false;" href="?p=add&amp;sale=<?php echo mc_digitSan($_GET['sale']); ?>&amp;type=download" title="<?php echo mc_cleanDataEnt($msg_viewsale4); ?>"><?php echo $msg_viewsale4; ?></a></span><?php echo $msg_viewsale3; ?> (<?php echo mc_sumCount('purchases WHERE `saleID` = \''.mc_digitSan($_GET['sale']).'\' AND `productType` = \'download\'','productQty'); ?>):</p>
</div>
<?php
if (mysql_num_rows($q_down)>0) {
while ($DOWN = mysql_fetch_object($q_down)) {
$details      = '';
$code         = ($DOWN->pCode ? $DOWN->pCode : 'N/A');
$weight       = ($DOWN->pWeight ? $DOWN->pWeight : 'N/A');
$DOWN->pName  = ($DOWN->pName ? $DOWN->pName : $DOWN->deletedProductName);
$isDel2       = ($DOWN->deletedProductName ? '<b class="deletedItem">'.$msg_script53.'</b>' : '');
$img          = storeProductImg($DOWN->pid,$DOWN);
?>
<div class="salePurchase" id="purchase_<?php echo $DOWN->pcid; ?>">
  <input type="hidden" name="pid[]" value="<?php echo $DOWN->pcid; ?>" />
  <input type="hidden" name="prod_id[]" value="<?php echo $DOWN->pid; ?>" />
  <div class="left"> 
    <p><?php echo $img; ?></p>
  </div>
  <div class="middle">  
    <p><?php echo mc_cleanDataEnt($DOWN->pName).($details ? ' <span class="highlight">('.$details.')</span>' : '').$isDel2; ?></p>
  </div>
  <div class="right">
    <p>
    <?php echo $msg_viewsale32; ?>: 
    <select name="qty[]" id="qty_<?php echo $DOWN->pcid; ?>" onchange="if(jQuery('#qty_<?php echo $DOWN->pcid; ?>').val()=='0') {alert('<?php echo mc_cleanDataEnt($msg_javascript220); ?>');mc_MarkForDeletion('<?php echo $DOWN->pcid; ?>');}else{displayPurchaseProductPrices('<?php echo $DOWN->pcid; ?>','sales-view');}">
    <?php
    foreach (range(0,SALE_QTY_LIMIT) AS $qty) {
    ?>
    <option value="<?php echo $qty; ?>"<?php echo ($DOWN->productQty==$qty ? ' selected="selected"' : ''); ?>><?php echo $qty; ?></option>
    <?php
    }
    ?>
    </select>
    @ <input class="price" id="price_<?php echo $DOWN->pcid; ?>" type="text" onblur="displayPurchaseProductPrices('<?php echo $DOWN->pcid; ?>','sales-view')" name="price[]" value="<?php echo mc_formatPrice($DOWN->salePrice); ?>" />
    </p>
  </div>
  <br class="clear" />  
  <p class="priceBar">
    <span class="options">
	<?php
    if ($isDel2=='') {
      echo str_replace(array('{code}','{url}'),array($code,'../?pID='.$DOWN->pid),$msg_viewsale16);
      echo str_replace(array('{code}','{url}'),array($code,'?p=add-product&amp;edit='.$DOWN->pid),$msg_viewsale93);
    }
    ?>
	</span>
    <span class="highlight" id="highlight_<?php echo $DOWN->pcid; ?>"><?php echo mc_currencyFormat(mc_formatPrice(($DOWN->productQty*$DOWN->salePrice)+($DOWN->persPrice+$DOWN->attrPrice),true)); ?></span>
    <input type="hidden" id="total_price_<?php echo $DOWN->pcid; ?>" name="t_price[]" value="<?php echo mc_formatPrice(($DOWN->productQty*$DOWN->salePrice)+($DOWN->persPrice+$DOWN->attrPrice)); ?>" />
  </p>
</div>
<?php
}
} else {
?>
<p class="noData" style="margin-bottom:5px"><?php echo $msg_viewsale15; ?></p>
<?php
}

// Gift certs..
$q_gift = mysql_query("SELECT *,`".DB_PREFIX."giftcerts`.`id` AS `pid`,`".DB_PREFIX."purchases`.`id` AS `pcid` FROM `".DB_PREFIX."purchases`
          LEFT JOIN `".DB_PREFIX."giftcerts`
          ON `".DB_PREFIX."purchases`.`giftID` = `".DB_PREFIX."giftcerts`.`id`
          WHERE `saleID`                       = '".mc_digitSan($_GET['sale'])."' 
          AND `productType`                    = 'virtual' 
          ".($SALE->saleConfirmation=='no' ? '' : 'AND `saleConfirmation` = \'yes\'')."
          ORDER BY `".DB_PREFIX."purchases`.`id`
          ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
?>
<div class="fieldHeadWrapper">
  <p><?php echo $msg_viewsale117; ?> (<?php echo mc_sumCount('purchases WHERE `saleID` = \''.mc_digitSan($_GET['sale']).'\' AND `productType` = \'virtual\'','productQty'); ?>):</p>
</div>
<?php
if (mysql_num_rows($q_gift)>0) {
while ($GIFT = mysql_fetch_object($q_gift)) {
$details      = '';
$code         = 'N/A';
$weight       = 'N/A';
$GIFT->pName  = ($GIFT->name ? $GIFT->name : $GIFT->deletedProductName);
$isDel2       = ($GIFT->deletedProductName ? '<b class="deletedItem">'.$msg_script53.'</b>' : '');
$img          = storeProductImg($GIFT->pid,$GIFT,false,(isset($GIFT->image) ? $GIFT->image : ''));
?>
<div class="salePurchase" id="purchase_<?php echo $GIFT->pcid; ?>">
  <input type="hidden" name="pid[]" value="<?php echo $GIFT->pcid; ?>" />
  <input type="hidden" name="prod_id[]" value="<?php echo $GIFT->pid; ?>" />
  <div class="left"> 
    <p><?php echo $img; ?></p>
  </div>
  <div class="middle">  
    <p><?php echo mc_cleanDataEnt($GIFT->pName).($details ? ' <span class="highlight">('.$details.')</span>' : '').$isDel2; ?></p>
	<div class="attrSaleBoxes" id="giftArea_<?php echo mc_digitSan($_GET['sale']); ?>_<?php echo $GIFT->pcid; ?>">
	 <p>
	  <a href="?p=gift&amp;viewSaleGift=<?php echo mc_digitSan($_GET['sale']); ?>&amp;purID=<?php echo $GIFT->pcid; ?>" onclick="mc_Window(this.href,'<?php echo GREYBOX_PERS_HEIGHT; ?>','<?php echo GREYBOX_PERS_WIDTH; ?>',this.title);return false;" class="gift_view" title="<?php echo mc_cleanDataEnt($msg_viewsale119); ?>"><?php echo $msg_viewsale119; ?></a>
	  <a href="#" class="gift_resend" title="<?php echo mc_cleanDataEnt($msg_viewsale119); ?>" onclick="mc_resendGiftCert('<?php echo mc_digitSan($_GET['sale']); ?>','<?php echo $GIFT->pcid; ?>','<?php echo mc_cleanDataEnt($msg_javascript45); ?>');return false"><?php echo $msg_viewsale120; ?></a>
	 </p>
	</div>
  </div>
  <div class="right">
    <p>
    <?php echo $msg_viewsale32; ?>: 
    <b><?php echo $GIFT->productQty; ?></b>
    @ <input type="hidden" name="price[]" value="<?php echo mc_formatPrice($GIFT->salePrice); ?>" /> <?php echo mc_formatPrice($GIFT->salePrice); ?>
    </p>
  </div>
  <br class="clear" />  
  <p class="priceBar">
    <span class="options">
	<?php
    if ($isDel2=='') {
      echo str_replace(array('{code}','{url}'),array($code,'../?p=gift'),$msg_viewsale16);
      echo str_replace(array('{code}','{url}'),array($code,'?p=gift&amp;edit='.$GIFT->pid),$msg_viewsale93);
    }
    ?>
	</span>
	<input type="hidden" name="qty[]" value="<?php echo $GIFT->productQty; ?>" />
    <span class="highlight" id="highlight_<?php echo $GIFT->pcid; ?>"><?php echo mc_currencyFormat(mc_formatPrice(($GIFT->productQty*$GIFT->salePrice)+($GIFT->persPrice+$GIFT->attrPrice),true)); ?></span>
    <input type="hidden" id="total_price_<?php echo $GIFT->pcid; ?>" name="t_price[]" value="<?php echo mc_formatPrice(($GIFT->productQty*$GIFT->salePrice)+($GIFT->persPrice+$GIFT->attrPrice)); ?>" />
  </p>
</div>
<?php
}
} else {
?>
<p class="noData" style="margin-bottom:5px"><?php echo $msg_viewsale118; ?></p>
<?php
}
?>

<div class="fieldHeadWrapper">
  <p><span class="float"><a class="recalculate" href="#" onclick="recalculateTotals('<?php echo mc_digitSan($_GET['sale']); ?>');return false" title="<?php echo mc_cleanDataEnt($msg_viewsale48); ?>"><?php echo $msg_viewsale48; ?></a></span><?php echo $msg_viewsale24; ?>:</p>
</div>

<div id="paymentOverview">

  <div class="left">
    
    <?php
    $howManyZones = mc_rowCount('zones');
    if ($howManyZones>0) {
    ?>
    <p><span><?php echo $msg_viewsale26; ?>:</span>
    <select name="shipSetCountry" id="shipSetCountry" onchange="reloadCountry()">
    <?php
    $q_ctry   = mysql_query("SELECT *,`".DB_PREFIX."countries`.`id` AS `cnt_id` FROM `".DB_PREFIX."countries` 
                LEFT JOIN `".DB_PREFIX."zones`
                ON `".DB_PREFIX."countries`.`id` = `".DB_PREFIX."zones`.`zCountry`
                WHERE `enCountry`  = 'yes'
                AND `zName`       != ''
                GROUP BY `".DB_PREFIX."countries`.`id`
                ORDER BY `cName`
                ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($CTY = mysql_fetch_object($q_ctry)) {
    ?>
    <option value="<?php echo $CTY->cnt_id; ?>"<?php echo ($SALE->shipSetCountry==$CTY->cnt_id ? ' selected="selected"' : ''); ?>><?php echo mc_cleanDataEnt($CTY->cName); ?></option>
    <?php
    }
    ?>
    </select>
    </p>
    <p><span><?php echo $msg_viewsale27; ?>:</span>
    <select name="shipSetArea" id="shipSetArea" onchange="setZoneTax()">
    <?php
    $shipWithTax = 'no';
    $q_zone = mysql_query("SELECT * FROM `".DB_PREFIX."zones` 
              WHERE `zCountry` = '{$SALE->shipSetCountry}'
              ORDER BY `zName`
              ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($Z = mysql_fetch_object($q_zone)) {
    $q_zarea   = mysql_query("SELECT `id`,`areaName` FROM `".DB_PREFIX."zone_areas`
                 WHERE `inZone` = '{$Z->id}'
                 ORDER BY `areaName`
                 ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    if (mysql_num_rows($q_zone)>0) {
    ?>
    <optgroup label="<?php echo mc_cleanDataEnt($Z->zName); ?>">
    <?php
    }
    while ($ZAREA = mysql_fetch_object($q_zarea)) {
    // Shipping with tax or without for this zone..
    if ($SALE->shipSetArea==$ZAREA->id) {
      $shipWithTax = $Z->zShipping;
    }
    ?>
    <option value="<?php echo $ZAREA->id; ?>"<?php echo ($SALE->shipSetArea==$ZAREA->id ? ' selected="selected"' : ''); ?>><?php echo mc_cleanDataEnt($ZAREA->areaName); ?></option>
    <?php
    }
    if (mysql_num_rows($q_zone)>0) {
    ?>
    </optgroup>
    <?php
    }
    }
	// Add option to prevent validation error on page load..
	if (mysql_num_rows($q_zone)==0) {
	?>
	<option value="0"></option>
	<?php
	}
    ?>
    </select> <span id="loader" style="display:inline"></span>
    </p>
    <p><span><?php echo $msg_viewsale28; ?>:</span>
    <select name="setShipRateID" id="setShipRateID" onchange="loadShippingPrice(jQuery('#subTotal').val())">
    <optgroup label="<?php echo mc_cleanDataEnt($msg_viewsale50); ?>">
      <option value="na"<?php echo (mysql_num_rows($q_phys)==0 ? ' selected="selected"' : ''); ?>><?php echo $msg_viewsale50; ?></option>
    </optgroup>
    <?php
    if ($SETTINGS->enablePickUp=='yes') {
    ?>
    <optgroup label="<?php echo mc_cleanDataEnt($msg_javascript214); ?>">
     <option value="pickup"<?php echo ($SALE->setShipRateID=='pickup' ? ' selected="selected"' : ''); ?>><?php echo $msg_javascript215; ?></option>
    </optgroup>
    <?php
    }
    $q_zone = mysql_query("SELECT `id`,`zName` FROM `".DB_PREFIX."zones` 
              WHERE `zCountry` = '{$SALE->shipSetCountry}'
              ORDER BY `zName`
              ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($Z = mysql_fetch_object($q_zone)) {
    //---------------------------------------------------------------------
    $q_service = mysql_query("SELECT `id`,`sName` FROM `".DB_PREFIX."services`
                 WHERE `inZone` = '{$Z->id}'
                 ORDER BY `sName`
                 ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    //---------------------------------------------------------------------
    $q_flat = mysql_query("SELECT `id`,`rate` FROM `".DB_PREFIX."flat`
              WHERE `inZone` = '{$Z->id}'
              LIMIT 1
              ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    $FLAT = mysql_fetch_object($q_flat);  
	//---------------------------------------------------------------------
	$q_prte = mysql_query("SELECT `id`,`rate`,`item` FROM `".DB_PREFIX."per`
              WHERE `inZone` = '{$Z->id}'
              LIMIT 1
              ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    $PER_ITEM = mysql_fetch_object($q_prte);  
    //---------------------------------------------------------------------
    $q_percent = mysql_query("SELECT * FROM `".DB_PREFIX."percent`
                 WHERE `inZone` = '{$Z->id}'
                 ORDER BY `priceFrom`*100,`priceTo`*100
                 ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    //---------------------------------------------------------------------
    if (mysql_num_rows($q_service)>0 || mysql_num_rows($q_percent)>0 || isset($FLAT->id) || isset($PER_ITEM->id)) {
    ?>
    <optgroup label="<?php echo mc_cleanDataEnt($Z->zName); ?>">
    <?php
    }
    //---------------------------------------------------------------------
    // Flat
    //---------------------------------------------------------------------
    if (isset($FLAT->id)) {
    ?>
    <option value="0" disabled="disabled">(&#043;) <?php echo $msg_viewsale95; ?></option>
    <option value="flat<?php echo $FLAT->id; ?>"<?php echo ($SALE->setShipRateID==$FLAT->id && $SALE->shipType=='flat' ? ' selected="selected"' : ''); ?>><?php echo $msg_viewsale95.' - '.mc_currencyFormat(mc_formatPrice($FLAT->rate)); ?></option>
    <?php
    }
	//---------------------------------------------------------------------
    // PerItem Rate
    //---------------------------------------------------------------------
    if (isset($PER_ITEM->id)) {
    ?>
    <option value="0" disabled="disabled">(&#043;) <?php echo $msg_viewsale124; ?></option>
    <option value="pert<?php echo $PER_ITEM->id; ?>"<?php echo ($SALE->setShipRateID==$PER_ITEM->id && $SALE->shipType=='pert' ? ' selected="selected"' : ''); ?>><?php echo str_replace(array('{first}','{item}'),array(mc_currencyFormat(mc_formatPrice($PER_ITEM->rate)),mc_currencyFormat(mc_formatPrice($PER_ITEM->item))),$msg_viewsale125); ?></option>
    <?php
    }
    //---------------------------------------------------------------------
    // Percentage based..
    //---------------------------------------------------------------------
    if (mysql_num_rows($q_percent)>0) {
    ?>
    <option value="0" disabled="disabled">(&#043;) <?php echo $msg_viewsale96; ?></option>
    <?php
    while ($PR = mysql_fetch_object($q_percent)) {
    ?>
    <option value="perc<?php echo $PR->id; ?>"<?php echo ($SALE->setShipRateID==$PR->id && $SALE->shipType=='percent' ? ' selected="selected"' : ''); ?>>&nbsp;<?php echo mc_currencyFormat(mc_formatPrice($PR->priceFrom)).' - '.mc_currencyFormat(mc_formatPrice($PR->priceTo)).' ('.$PR->percentage.'%)'; ?></option>
    <?php
    }
    }
    //---------------------------------------------------------------------
    // Services/rates = weight based
    //---------------------------------------------------------------------
    if (mysql_num_rows($q_service)>0) {
    while ($S = mysql_fetch_object($q_service)) {
    ?>
    <option value="0" disabled="disabled">(&#043;) <?php echo mc_cleanDataEnt($S->sName); ?></option>
    <?php
    $q_rates = mysql_query("SELECT * FROM `".DB_PREFIX."rates`
               WHERE `rService` = '{$S->id}'
               ORDER BY `id`
               ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($R = mysql_fetch_object($q_rates)) {   
    // Tare weight..
    $tareCost = '';
    $tare     = getTareWeight(0,$R->rService,array($R->rWeightFrom,$R->rWeightTo));
    if (isset($tare[0]) && $tare[0]=='yes') {
      switch (substr($tare[1],-1)) {
        case '%':
        $calc     = substr($tare[1],0,-1).'%';
        $tareCost = str_replace('{amount}',$calc,$msg_viewsale106);
        break;
        default:
        $tareCost = str_replace('{amount}',mc_currencyFormat(mc_formatPrice($tare[1])),$msg_viewsale106);
        break;
      }
    }          
    ?>
    <option value="<?php echo $R->id; ?>"<?php echo ($SALE->setShipRateID==$R->id && $SALE->shipType=='weight' ? ' selected="selected"' : ''); ?>>&nbsp;<?php echo $R->rWeightFrom.' - '.$R->rWeightTo.' ('.mc_currencyFormat(mc_formatPrice($R->rCost)).$tareCost; ?>)</option>
    <?php
    }
    }
    }
    if (mysql_num_rows($q_service)>0 || mysql_num_rows($q_percent)>0 || isset($FLAT->id) || isset($PER_ITEM->id)) {
    ?>
    </optgroup>
    <?php
    }
    }
    ?>
    </select> <span id="loader2" style="display:inline"></span>
    </p>
    <?php
    }
    ?>
    <p><span><?php echo $msg_viewsale29; ?>:</span><input type="text" class="box" name="cartWeight" id="cartWeight" value="<?php echo $SALE->cartWeight; ?>" /> <img style="cursor:pointer" onclick="calcWeight('<?php echo $_GET['sale']; ?>')" src="templates/images/refresh.png" alt="<?php echo mc_cleanDataEnt($msg_viewsale115); ?>" title="<?php echo mc_cleanDataEnt($msg_viewsale115); ?>" /></p>
    
  </div>
  
  <div class="right" id="totalArea">
  
    <p><span><?php echo $msg_viewsale31; ?>:</span><input type="text" class="box" name="subTotal" id="subTotal" value="<?php echo $SALE->subTotal; ?>" /></p>
    <?php
    // Global discount..
    if ($SALE->globalTotal>0) {
    ?>
    <p><span><?php echo str_replace('{percentage}',$SALE->globalDiscount,$msg_viewsale75); ?>:</span>- <input type="hidden" class="box" name="globalDiscount" value="<?php echo $SALE->globalDiscount; ?>" /><input type="text" class="box" name="globalTotal" id="globalTotal" value="<?php echo ($SALE->globalTotal>0 ? $SALE->globalTotal : '0.00'); ?>" /></p>
    <?php
    } elseif ($SALE->couponTotal>0) {
	switch ($SALE->codeType) {
	  case 'gift':
	  ?>
      <p><span><a href="?p=gift&amp;viewGift=<?php echo $SALE->couponCode; ?>" onclick="mc_Window(this.href,'<?php echo GREYBOX_PERS_HEIGHT; ?>','<?php echo GREYBOX_PERS_WIDTH; ?>',this.title);return false;"><?php echo $msg_viewsale116; ?></a>:</span>- <input type="text" class="box" name="couponTotal" id="couponTotal" value="<?php echo ($SALE->couponTotal>0 ? $SALE->couponTotal : '0.00'); ?>" /></p>
      <?php
	  break;
	  default:
	  ?>
      <p><span><?php echo $msg_viewsale20; ?>:</span>- <input type="text" class="box" name="couponTotal" id="couponTotal" value="<?php echo ($SALE->couponTotal>0 ? $SALE->couponTotal : '0.00'); ?>" /></p>
      <?php
	  break;
    }
    } else {
    ?>
    <p><span><?php echo $msg_viewsale78; ?>:</span>- <input type="text" class="box" name="manualDiscount" id="manualDiscount" value="<?php echo ($SALE->manualDiscount>0 ? $SALE->manualDiscount : '0.00'); ?>" /></p>
    <?php
    }
    if (isset($shipWithTax) && $shipWithTax=='yes') {
    ?>
    <p><span><?php echo $msg_viewsale30; ?>:</span><input type="text" class="box" name="shipTotal" id="shipTotal" value="<?php echo ($SALE->shipTotal>0 ? $SALE->shipTotal : '0.00'); ?>" /></p>
    <p><span><?php echo str_replace('{percentage}',$SALE->taxRate,$msg_viewsale23); ?>:</span><input type="hidden" name="taxRate" id="taxRate" value="<?php echo $SALE->taxRate; ?>" /><input type="text" class="box" name="taxPaid" id="taxPaid" value="<?php echo ($SALE->taxPaid>0 ? $SALE->taxPaid : '0.00'); ?>" /></p>
    <?php
    } else {
    ?>
    <p><span><?php echo str_replace('{percentage}',$SALE->taxRate,$msg_viewsale23); ?>:</span><input type="hidden" name="taxRate" id="taxRate" value="<?php echo $SALE->taxRate; ?>" /><input type="text" class="box" name="taxPaid" id="taxPaid" value="<?php echo ($SALE->taxPaid>0 ? $SALE->taxPaid : '0.00'); ?>" /></p>
    <p><span><?php echo $msg_viewsale30; ?>:</span><input type="text" class="box" name="shipTotal" id="shipTotal" value="<?php echo ($SALE->shipTotal>0 ? $SALE->shipTotal : '0.00'); ?>" /></p>
    <?php
    }
    ?>
    <p><span><?php echo $msg_viewsale97; ?>:</span><input type="text" class="box" name="insuranceTotal" id="insuranceTotal" value="<?php echo ($SALE->insuranceTotal>0 ? $SALE->insuranceTotal : '0.00'); ?>" /></p>
    <p><span><?php echo $msg_viewsale33; ?>:</span><input type="text" class="box" name="grandTotal" id="grandTotal" value="<?php echo $SALE->grandTotal; ?>" /></p>
    
    <p><span style="display:block;margin:0 0 5px 0"><b><?php echo $msg_viewsale19; ?></b>:</span>
    <select name="paymentMethod">
    <?php
    foreach ($mcSystemPaymentMethods AS $key => $value) {
	if ($value['enable']=='yes') {
    ?>
    <option value="<?php echo $key; ?>"<?php echo ($SALE->paymentMethod==$key ? ' selected="selected"' : ''); ?>><?php echo $value['lang']; ?></option>
    <?php
	}
    }
    ?>
    </select>
    </p>
  
  </div>
  
  <br class="clear" />
 
</div>

<div class="fieldHeadWrapper">
  <p><span class="float"><a class="shiplabel" href="?p=sales-view&amp;shipLabel=<?php echo $_GET['sale']; ?>" onclick="window.open(this);return false" title="<?php echo mc_cleanDataEnt($msg_viewsale105); ?>"><?php echo $msg_viewsale105; ?></a></span><?php echo $msg_viewsale98; ?>:</p>
</div>
<?php
// Legacy addresses..
if ($SALE->buyerAddress) {
  $addchop = explode(mc_defineNewline(),$SALE->buyerAddress);
  for ($i=0; $i<7; $i++) {
    if (isset($addchop[$i])) {
      $f          = 'ship_'.($i+3);
      $f2         = 'bill_'.($i+3);
      $SALE->$f   = $addchop[$i];
      $SALE->$f2  = $addchop[$i];
    }
  }
}
?>
<div class="buyerAddresses" style="padding-bottom:10px">

  <div class="left">
  
    <div>
     <div style="float:left;width:49%">
      <p><span><?php echo $msg_viewsale37; ?>:</span><input type="text" class="box" name="ship_1" value="<?php echo mc_cleanDataEnt($SALE->ship_1); ?>" /></p>
     </div>
     <div style="float:right;width:49%">
      <p><span><?php echo $msg_viewsale99; ?>:</span><input type="text" class="box" name="ship_3" value="<?php echo mc_cleanDataEnt($SALE->ship_3); ?>" /></p>
     </div>
     <br class="clear" />
    </div> 
    
    <div>
     <div style="float:left;width:49%">
      <p><span><?php echo $msg_viewsale100; ?>:</span><input type="text" class="box" name="ship_4" value="<?php echo mc_cleanDataEnt($SALE->ship_4); ?>" /></p>
     </div>
     <div style="float:right;width:49%">
      <p><span><?php echo $msg_viewsale101; ?>:</span><input type="text" class="box" name="ship_5" value="<?php echo mc_cleanDataEnt($SALE->ship_5); ?>" /></p>
     </div>
     <br class="clear" />
    </div>
    
    <div>
     <div style="float:left;width:49%">
      <p><span><?php echo $msg_viewsale102; ?>:</span><input type="text" class="box" name="ship_6" value="<?php echo mc_cleanDataEnt($SALE->ship_6); ?>" /></p>
     </div>
     <div style="float:right;width:49%">
      <p><span><?php echo $msg_viewsale103; ?>:</span><input type="text" class="box" name="ship_7" value="<?php echo mc_cleanDataEnt($SALE->ship_7); ?>" /></p>
     </div>
     <br class="clear" />
    </div>
    
    <div>
     <div style="float:left;width:49%">
      <p><span><?php echo $msg_viewsale39; ?>:</span><input type="text" class="box" name="ship_2" value="<?php echo mc_cleanDataEnt($SALE->ship_2); ?>" /></p>
     </div>
     <div style="float:right;width:49%">
      <p><span><?php echo $msg_viewsale40; ?>:</span><input type="text" class="box" name="ship_8" value="<?php echo mc_cleanDataEnt($SALE->ship_8); ?>" /></p>
     </div>
     <br class="clear" />
    </div>
    
    <?php
    // Only show shipping country in address list if not shown above..
    if ($howManyZones==0) {
    ?>
    <div>
     <div style="float:left;width:49%">
      <p><span><?php echo $msg_viewsale26; ?>:</span>
      <select name="shipSetCountry">
      <?php
      $q_ctry   = mysql_query("SELECT * FROM `".DB_PREFIX."countries` 
                  WHERE `enCountry`  = 'yes'
                  ORDER BY `cName`
                  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
      while ($CTY = mysql_fetch_object($q_ctry)) {
      ?>
      <option value="<?php echo $CTY->id; ?>"<?php echo ($SALE->shipSetCountry==$CTY->id ? ' selected="selected"' : ''); ?>><?php echo mc_cleanDataEnt($CTY->cName); ?></option>
      <?php
      }
      ?>
      </select>
      </p>
     </div>
     <div style="float:right;width:49%">
     </div>
     <br class="clear" />
    </div>
    <?php
    }
    ?>
    
    <br class="clear" />
  </div>
  
  <div class="right">
  
    <div>
     <div style="float:left;width:49%">
      <p><span><?php echo $msg_viewsale37; ?>:</span><input type="text" class="box" name="bill_1" value="<?php echo mc_cleanDataEnt($SALE->bill_1); ?>" /></p>
     </div>
     <div style="float:right;width:49%">
      <p><span><?php echo $msg_viewsale99; ?>:</span><input type="text" class="box" name="bill_3" value="<?php echo mc_cleanDataEnt($SALE->bill_3); ?>" /></p>
     </div>
     <br class="clear" />
    </div> 
    
    <div>
     <div style="float:left;width:49%">
      <p><span><?php echo $msg_viewsale100; ?>:</span><input type="text" class="box" name="bill_4" value="<?php echo mc_cleanDataEnt($SALE->bill_4); ?>" /></p>
     </div>
     <div style="float:right;width:49%">
      <p><span><?php echo $msg_viewsale101; ?>:</span><input type="text" class="box" name="bill_5" value="<?php echo mc_cleanDataEnt($SALE->bill_5); ?>" /></p>
     </div>
     <br class="clear" />
    </div> 
  
    <div>
     <div style="float:left;width:49%">
      <p><span><?php echo $msg_viewsale102; ?>:</span><input type="text" class="box" name="bill_6" value="<?php echo mc_cleanDataEnt($SALE->bill_6); ?>" /></p>
     </div>
     <div style="float:right;width:49%">
      <p><span><?php echo $msg_viewsale103; ?>:</span><input type="text" class="box" name="bill_7" value="<?php echo mc_cleanDataEnt($SALE->bill_7); ?>" /></p>
     </div>
     <br class="clear" />
    </div> 
    
    <div>
     <div style="float:left;width:49%">
      <p><span><?php echo $msg_viewsale39; ?>:</span><input type="text" class="box" name="bill_2" value="<?php echo mc_cleanDataEnt($SALE->bill_2); ?>" /></p>
     </div>
     <div style="float:right;width:49%">
      <p><span><?php echo $msg_viewsale40; ?>:</span><input type="text" class="box" name="bill_8" value="<?php echo mc_cleanDataEnt($SALE->bill_8); ?>" /></p>
     </div>
     <br class="clear" />
    </div> 
    
    <div>
     <div style="float:left;width:49%">
      <p><span><?php echo $msg_viewsale104; ?>:</span>
      <select name="bill_9">
      <?php
      $q_ctry   = mysql_query("SELECT * FROM `".DB_PREFIX."countries` 
                  WHERE `enCountry`  = 'yes'
                  ORDER BY `cName`
                  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
      while ($CTY = mysql_fetch_object($q_ctry)) {
      ?>
      <option value="<?php echo $CTY->id; ?>"<?php echo ($SALE->bill_9==$CTY->id ? ' selected="selected"' : ''); ?>><?php echo mc_cleanDataEnt($CTY->cName); ?></option>
      <?php
      }
      ?>
      </select>
      </p>
     </div>
     <div style="float:right;width:49%">
     </div>
     <br class="clear" />
    </div> 
    
    <br class="clear" />  
  </div>
  
  <br class="clear" />

</div>

<div class="fieldHeadWrapper">
  <p><?php echo $msg_viewsale7; ?>:</p>
</div>

<div class="buyerDetails" style="padding-bottom:10px">

  <p><span><?php echo $msg_viewsale41; ?>:</span><textarea rows="5" cols="20" name="saleNotes"><?php echo mc_cleanDataEnt($SALE->saleNotes); ?></textarea></p>
  <p><span><?php echo $msg_viewsale42; ?>:</span><input type="text" class="box" name="ipAddress" value="<?php echo mc_cleanDataEnt($SALE->ipAddress); ?>" /></p>
  
  <div class="saleDates">
    <div class="dateLeft">
     <p><span><?php echo $msg_viewsale43; ?>:</span>
     <?php
     $d = explode('-',$SALE->purchaseDate);
     ?>
     <select name="days">
     <?php
     foreach (range(1,31) AS $days) {
     $days = ($days<10 ? '0'.$days : $days);
     ?>
     <option value="<?php echo $days; ?>"<?php echo ($d[2]==$days ? ' selected="selected"' : ''); ?>><?php echo $days; ?></option>
     <?php
     }
     ?>
     </select>
     <select name="months">
     <?php
     foreach (range(1,12) AS $months) {
     $slot    = ($months-1);
     $months  = ($months<10 ? '0'.$months : $months);
     ?>
     <option value="<?php echo $months; ?>"<?php echo ($d[1]==$months ? ' selected="selected"' : ''); ?>><?php echo $msg_script41[$slot]; ?></option>
     <?php
     }
     ?>
     </select>
     <select name="years">
     <?php
     foreach (range(2010,date('Y')+1) AS $years) {
     ?>
     <option value="<?php echo $years; ?>"<?php echo ($d[0]==$years ? ' selected="selected"' : ''); ?>><?php echo $years; ?></option>
     <?php
     }
     ?>
     </select>
     </p>
       
     <p><span><?php echo $msg_viewsale51; ?>:</span>
     <input type="text" class="box" name="gatewayID" value="<?php echo mc_cleanDataEnt($SALE->gatewayID); ?>" />
     </p>
       
     <br class="clear" />
    </div>
      
    <div class="dateRight"> 
     <p><span><?php echo $msg_viewsale91; ?>:</span>
     <?php
     $t = explode(':',$SALE->purchaseTime);
     ?>
     <select name="hrs">
     <?php
     foreach (range(0,23) AS $hrs) {
     $hrs = ($hrs<10 ? '0'.$hrs : $hrs);
     ?>
     <option value="<?php echo $hrs; ?>"<?php echo ($t[0]==$hrs ? ' selected="selected"' : ''); ?>><?php echo $hrs; ?></option>
     <?php
     }
     ?>
     </select> : 
     <select name="mins">
     <?php
     foreach (range(0,59) AS $mins) {
     $mins  = ($mins<10 ? '0'.$mins : $mins);
     ?>
     <option value="<?php echo $mins; ?>"<?php echo ($t[1]==$mins ? ' selected="selected"' : ''); ?>><?php echo $mins; ?></option>
     <?php
     }
     ?>
     </select> : 
     <select name="secs">
     <?php
     foreach (range(0,59) AS $secs) {
     $secs  = ($secs<10 ? '0'.$secs : $secs);
     ?>
     <option value="<?php echo $secs; ?>"<?php echo ($t[2]==$secs ? ' selected="selected"' : ''); ?>><?php echo $secs; ?></option>
     <?php
     }
     ?>
     </select>
     </p>
       
     <p><span class="nextInv"><a href="#" onclick="mc_nextInvoice();return false"><?php echo $msg_sales43; ?></a></span><span><?php echo $msg_viewsale65; ?>:</span>
     <input type="text" class="box" name="invoiceNo" id="invoiceNo" value="<?php echo mc_saleInvoiceNumber($SALE->invoiceNo); ?>" />
     </p>
     <br class="clear" />
    </div>  
  </div>

  <br class="clear" />
</div>

<div class="fieldHeadWrapper">
  <p>
   <?php
   if (!in_array($SALE->paymentMethod,array('free','cod','bank','cheque','phone'))) {
   ?>
   <span class="float">
    <a href="?p=sales-view&amp;gatewayParams=<?php echo $_GET['sale']; ?>" title="<?php echo mc_cleanDataEnt($msg_viewsale107); ?>" class="gparams" onclick="mc_Window(this.href,'<?php echo GREYBOX_PERS_HEIGHT; ?>','<?php echo GREYBOX_PERS_WIDTH; ?>',this.title);return false;"><?php echo $msg_viewsale107; ?></a>
   </span>
   <?php
   }
   ?>
  <?php echo $msg_viewsale60; ?>:</p>
</div>

<div class="buyerDetails" style="padding-bottom:10px">

  <div class="left">
    <p><span><?php echo $msg_viewsale61; ?>:</span>&nbsp;<input type="checkbox" name="editStatus" value="yes" checked="checked" onclick="disableEnableBox(this.checked,'editNotes')" /> <?php echo $msg_viewsale52; ?></p>
    <p><span><?php echo $msg_viewsale56; ?>:</span>&nbsp;<select name="editStatus" id="selectStat">
    <?php
    if ($SALE->saleConfirmation=='no') {
    ?>
    <option value=""<?php echo (isset($SALE->paymentStatus) && $SALE->paymentStatus=='' ? ' selected="selected"' : ''); ?>>N/A</option>
    <?php
    }
    $payStatuses = mc_loadDefaultStatuses();
    // Get last status..
    foreach ($payStatuses AS $key => $value) {
    ?>
    <option value="<?php echo $key; ?>"<?php echo (isset($SALE->paymentStatus) && $SALE->paymentStatus==$key ? ' selected="selected"' : ''); ?>><?php echo $value; ?></option>
    <?php
    }
    // Get additional payment statuses..
    $q_add_stats = mysql_query("SELECT * FROM `".DB_PREFIX."paystatuses` 
                   WHERE `pMethod` IN('all','".$SALE->paymentMethod."')
                   ORDER BY `pMethod`,`statname`
                   ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    if (mysql_num_rows($q_add_stats)>0) {
    ?>
    <option value="0" disabled="disabled">- - - - - - - - -</option>
    <?php
    }
    while ($ST = mysql_fetch_object($q_add_stats)) {
    ?>
    <option value="<?php echo $ST->id; ?>"><?php echo mc_cleanData($ST->statname); ?></option>
    <?php
    }
    ?>
    </select>
    </p>
  </div>
  
  <div class="right">
    <p><span><?php echo $msg_viewsale62; ?>:</span><textarea rows="5" cols="20" name="editNotes" id="editNotes"><?php echo mc_cleanDataEnt($msg_viewsale53); ?></textarea></p>
  </div>
  
  <br class="clear" />

</div>  

<p style="text-align:center;margin:20px 0 50px 0">
  <input type="hidden" name="process" id="process_load" value="yes" />
  <input type="hidden" name="saleConfirm" value="<?php echo $SALE->saleConfirmation; ?>" />
  <input class="formbutton" type="submit" value="<?php echo mc_cleanDataEnt($msg_viewsale44); ?>" title="<?php echo mc_cleanDataEnt($msg_viewsale44); ?>" />
</p>

</form>
</div>

</div>
