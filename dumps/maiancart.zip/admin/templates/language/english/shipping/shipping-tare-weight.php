<?php

/*+++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  +++++++++++++++++++++++++++++++++++++++++++++
  
  This File: shipping-tare-weight.php
  Description: English Language File

  +++++++++++++++++++++++++++++++++++++++++++++*/


$msg_tare                  = 'Specify tare weight charges below. This is used in conjunction with weight based rates and is optional. You can also batch add tare rates to multiple services via the checkboxes. Hover your cursor over the help tips for information:';
$msg_tare2                 = 'Select Shipping Zone';
$msg_tare3                 = 'Add Tare Weight';
$msg_tare4                 = 'Current Tare Weight Rates - <span class="noFormat">Use links to edit or delete</span>';
$msg_tare5                 = 'Weight From';
$msg_tare6                 = 'Weight To';
$msg_tare7                 = 'Tare Weight Cost';
$msg_tare8                 = '{count} New Tare Rate(s) Added to {services} Service(s)';
$msg_tare9                 = 'Update Tare Weight';
$msg_tare10                = 'Tare Rate Deleted';
$msg_tare11                = 'Tare Rate Updated';
$msg_tare12                = 'There are currently 0 tare rates in the database.';
$msg_tare13                = 'Apply to Service(s)';
$msg_tare14                = 'Add Field';
$msg_tare15                = 'Remove Field';
$msg_tare16                = '<span class="noFormat">Filter by Service</span>';
$msg_tare17                = 'All Services';
$msg_tare18                = 'All Rates';
$msg_tare19                = 'Apply to Service';

?>
