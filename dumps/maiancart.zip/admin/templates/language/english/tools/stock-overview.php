<?php

/*+++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  +++++++++++++++++++++++++++++++++++++++++++++
  
  This File: stock-overview.php
  Description: English Language File

  +++++++++++++++++++++++++++++++++++++++++++++*/


$stock_overview          = 'This page lets you see a stock overview of your products. You can filter by category, export the results to csv and batch update stock. To export by individual category, select the category first, then click the export link. To update stock level of individual product, click the product name/attribute to edit.';
$stock_overview2         = 'There are currently 0 products in the database.';
$stock_overview3         = 'Export to CSV';
$stock_overview4         = 'Qty';
$stock_overview5         = 'Selected Items Updated';
$stock_overview6         = 'Update Selected with Stock';
$stock_overview7         = 'Update';

?>
