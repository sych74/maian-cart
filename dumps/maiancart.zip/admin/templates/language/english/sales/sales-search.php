<?php

/*+++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  +++++++++++++++++++++++++++++++++++++++++++++
  
  This File: sales-search.php
  Description: English Language File

  +++++++++++++++++++++++++++++++++++++++++++++*/


$msg_salessearch           = 'Search your sales below. At least 1 criteria must be specified. The more that are specified, the more detailed the search:';
$msg_salessearch2          = 'Search Sales';
$msg_salessearch3          = 'Invoice No';
$msg_salessearch4          = 'Purchase Date Range';
$msg_salessearch5          = 'to';
$msg_salessearch6          = 'Buyers Name';
$msg_salessearch7          = 'Buyers E-Mail';
$msg_salessearch8          = 'Coupon Code';
$msg_salessearch9          = '';
$msg_salessearch10         = '';

?>
