<?php

/*+++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  +++++++++++++++++++++++++++++++++++++++++++++
  
  This File: sales-incomplete.php
  Description: English Language File

  +++++++++++++++++++++++++++++++++++++++++++++*/


$msg_salesincomplete              = 'Sales shown here have either not been updated from a gateway callback or the buyer cancelled their order before payment. Incomplete sale data is cleared automatically if enabled in your <a href="?p=settings&amp;s=3">settings</a>. Update sales if necessary.';
$msg_salesincomplete2             = 'Product Download';
$msg_salesincomplete3             = 'IMPORTANT!\n\nThis sale is awaiting further responses from the gateway, it must not be updated until completed';

?>
