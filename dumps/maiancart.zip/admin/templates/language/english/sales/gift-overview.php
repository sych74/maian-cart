<?php

/*+++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  +++++++++++++++++++++++++++++++++++++++++++++
  
  This File: gift-overview.php
  Description: English Language File

  +++++++++++++++++++++++++++++++++++++++++++++*/


$msg_giftoverview      = 'Here you can view purchased gift certificates. Use the filter options if required or use the search option to locate a gift certificate.';
$msg_giftoverview2     = 'Gift Certificates';
$msg_giftoverview3     = 'Gift Certificate Deleted';
$msg_giftoverview4     = 'Date: {date} &#8226; Enabled: {enabled}<br />Value: {value} &#8226; Redeemed: {redeemed}';
$msg_giftoverview5     = 'There are currently 0 purchased gift certificates.';
$msg_giftoverview6     = 'Gift Certificates Disabled';
$msg_giftoverview7     = 'Go';
$msg_giftoverview8     = 'All Gift Certificates';
$msg_giftoverview9     = 'Gift Certificates Not Fully Redeemed';
$msg_giftoverview10    = 'Keywords or Date';
$msg_giftoverview11    = 'Export to CSV';
$msg_giftoverview12    = 'From,Email,To,Email,Date,Value,Redeemed,Code,Notes'; // CSV

?>
