<?php

/*+++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  +++++++++++++++++++++++++++++++++++++++++++++
  
  This File: sales-add.php
  Description: English Language File

  +++++++++++++++++++++++++++++++++++++++++++++*/


$msg_addsale              = 'Manually add a new sale below. Use the links provided to add products to the sale. Adjust totals and information as required.';
$msg_addsale2             = 'Add New Sale';
$msg_addsale3             = 'Use link to add products to new sale.';
$msg_addsale4             = 'New Sale Order Status';
$msg_addsale5             = 'New Sale Status Notes';
$msg_addsale6             = 'Sale entered into system';
$msg_addsale7             = 'Add New Sale';
$msg_addsale8             = 'Status &amp; Text';
$msg_addsale9             = 'Discount';
$msg_addsale10            = 'Clear and Reload';


?>
