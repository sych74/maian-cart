<?php

/*+++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  +++++++++++++++++++++++++++++++++++++++++++++
  
  This File: main.php
  Description: English Language File

  +++++++++++++++++++++++++++++++++++++++++++++*/


$msg_main                  = 'Today';
$msg_main2                 = 'This Week';                              
$msg_main3                 = 'Sale Totals - Today';
$msg_main4                 = 'Please fix the following security issues';
$msg_main5                 = 'Welcome to the "{website}" store administration area<br /><br />Please use the links below to manage the store. To return to this page at anytime, click the "Dashboard" link above:<br /><br />';
$msg_main6                 = 'This Year';
$msg_main7                 = 'Sub Total';
$msg_main8                 = 'Tax/Shipping';
$msg_main9                 = 'This Month';
$msg_main10                = 'Total';
$msg_main11                = 'Quick Links';
$msg_main12                = 'Apply Global Discount';
$msg_main13                = 'Manage Products';
$msg_main14                = 'Payment Settings';
$msg_main15                = 'View Sales';
$msg_main16                = 'Homepage Product Options';
$msg_main17                = '<span class="tangible">Tangible Goods</span> <span class="downloads">Downloads</span> <span class="gift">Gift Certs</span>';
$msg_main18                = 'Toggle Overview Area';
$msg_main19                = 'Sale Totals - This Week';
$msg_main20                = 'Sale Totals - This Month';
$msg_main21                = 'Sale Totals - This Year';

?>
