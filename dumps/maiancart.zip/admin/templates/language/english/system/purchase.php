<?php

/*+++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  +++++++++++++++++++++++++++++++++++++++++++++
  
  This File: purchase.php
  Description: English Language File

  +++++++++++++++++++++++++++++++++++++++++++++*/


$msg_purchase              = 'If you would like show your support for this software and enjoy the benefits of the commercial version of Maian Cart, including copyright removal, please consider purchasing a licence. This
                              unlocks the software and all future upgrades are FREE. To upgrade please complete the following:<br /><br />
                              <b>1</b> - Please visit the Maian Cart <a href="http://www.maiancart.com" title="Maian Cart" onclick="window.open(this);return false">website</a> and <a href="http://www.maiancart.com/purchase.html" onclick="window.open(this);return false">purchase</a> a commercial licence.<br /><br />
                              <b>2</b> - Once payment has been completed you will be redirected to the <a href="https://www.maiangateway.com/" onclick="window.open(this);return false">Maian Script World Licence Centre</a>. If you aren`t directed there after payment, wait awhile for the confirmation e-mail and click the link.<br /><br />
                              <b>3</b> - Generate your \'licence.lic\' licence file using the onscreen instructions. To generate a licence file you will need the product key shown below:
                              <span class="key">{licence_key}</span>
                              <b>4</b> - Upload the \'licence.lic\' file into your store installation folder and replace the default one.<br /><br />
                              <b>5</b> - Select &quot;System > Edit Footers&quot; from the above menu. (This is hidden in the free version).';


?>
