<?php

/*+++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  +++++++++++++++++++++++++++++++++++++++++++++
  
  This File: header.php
  Description: English Language File

  +++++++++++++++++++++++++++++++++++++++++++++*/


$msg_header                = 'System';
$msg_header2               = 'Catalogue';
$msg_header3               = 'Tools';
$msg_header4               = 'Shipping';
$msg_header5               = 'Sales';
$msg_header6               = 'Other Options';
$msg_header7               = 'Settings';
$msg_header8               = 'Administration Centre';
$msg_header9               = 'Dashboard';
$msg_header10              = 'Brands';
$msg_header11              = 'User: <span class="loggedUser">{user}</span>';
$msg_header12              = 'Home';
$msg_header13              = 'Help';
$msg_header14              = '<br />(Last Login: {LAST})';
$msg_header15              = '<br />(Administrator)';
$msg_header16              = 'Store';
$msg_header17              = 'Version Check';
$msg_header18              = 'Shipping Options';

?>
