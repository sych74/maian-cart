<?php

/*+++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  +++++++++++++++++++++++++++++++++++++++++++++
  
  This File: themes.php
  Description: English Language File

  +++++++++++++++++++++++++++++++++++++++++++++*/


$msg_themes              = 'The theme switcher lets you change the front end theme on any given date or date range. This is useful if you want to load different store themes at different times. Maybe holiday seasons like Christmas or during a special offer promotion. If no switch is found, the default theme is loaded.<br /><br />
                            NOTE: If a theme is specified for a <a href="?p=categories">category</a>, this will take priority and any themes in given date ranges are ignored when the category page loads';
$msg_themes2             = 'Update Theme Switch';   
$msg_themes3             = 'Add Theme Switch';
$msg_themes4             = 'From - To Date';
$msg_themes5             = 'Enable Switch';
$msg_themes6             = 'Theme to Load';
$msg_themes7             = 'Theme Switch Added';
$msg_themes8             = 'Theme Switch Updated';
$msg_themes9             = 'Theme Switch Deleted';
$msg_themes10            = 'Current Theme Switches';
$msg_themes11            = 'There are currently no theme switches in the system.';
$msg_themes12            = '[X] No additional themes found.';
$msg_themes13            = 'Date: {date} / Theme: {theme} / Enabled: {enabled}';
$msg_themes14            = 'From: {from} To: {to} / Theme: {theme} / Enabled: {enabled}';

?>
