<?php

/*+++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  +++++++++++++++++++++++++++++++++++++++++++++
  
  This File: product-export.php
  Description: English Language File

  +++++++++++++++++++++++++++++++++++++++++++++*/


$msg_productexport         = 'Here you can export your product list to CSV. Useful for exporting into other applications.';
$msg_productexport2        = 'Export Products';
$msg_productexport3        = 'There is currently no data to export.';

?>
