<?php

/*+++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  +++++++++++++++++++++++++++++++++++++++++++++
  
  This File: product-related.php
  Description: English Language File

  +++++++++++++++++++++++++++++++++++++++++++++*/


$msg_prodrelated           = 'Here you can specify related products. Related products can be any product in any category. Select categories, then use the checkboxes provided.';
$msg_prodrelated2          = 'Select Products';
$msg_prodrelated3          = 'Add Related Products';
$msg_prodrelated4          = 'Related Products';
$msg_prodrelated5          = 'Categories';
$msg_prodrelated6          = 'Products';
$msg_prodrelated7          = 'All Products';
$msg_prodrelated8          = 'This category has no products';
$msg_prodrelated9          = 'Related Products Added';
$msg_prodrelated10         = 'Related Product Deleted';
$msg_prodrelated11         = 'This product currently has no related products';
$msg_prodrelated12         = 'Mirror Product Relation';

?>
