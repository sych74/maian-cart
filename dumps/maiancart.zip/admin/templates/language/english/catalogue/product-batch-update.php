<?php

/*+++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  +++++++++++++++++++++++++++++++++++++++++++++
  
  This File: product-batch-update.php
  Description: English Language File

  +++++++++++++++++++++++++++++++++++++++++++++*/


$msg_batchupdate           = 'This feature enables you to batch update your products from CSV. Useful if you quickly need to update a lot of products in your store.';
$msg_batchupdate2          = 'Upload CSV File';
$msg_batchupdate3          = 'Update Products';
$msg_batchupdate4          = 'Lines to Read';
$msg_batchupdate5          = 'Delimited/Enclosed by';
$msg_batchupdate6          = 'Browse for CSV';
$msg_batchupdate7          = '{count} Product(s) Updated from CSV';

?>
