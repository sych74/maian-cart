<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } 
$helpTag = $cmd;
if (isset($_GET['s']) && is_numeric($_GET['s'])) {
  $helpTag = 'settings'.$_GET['s'];
}
if (file_exists(PATH.'templates/header-custom.php')) {
  include_once(PATH.'templates/header-custom.php');
} else {
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php
}
?>
<meta http-equiv="content-type" content="application/xhtml+xml; charset=<?php echo $charset; ?>" />
<title><?php echo $pageTitle.(mc_checkBetaVersion()=='yes' ? ' (BETA VERSION ONLY)' : ''); ?></title>
<link rel="stylesheet" href="templates/css/menu.css" type="text/css" />
<script type="text/javascript" src="templates/js/overlib.js"><!-- overLIB (c) Erik Bosrup --></script>
<script type="text/javascript" src="templates/js/jquery.js"></script>
<script type="text/javascript" src="templates/js/jquery.ui.js"></script>
<script type="text/javascript" src="templates/js/global.js"></script>
<script type="text/javascript" src="templates/js/plugins/jquery.impromptu.js"></script>
<script type="text/javascript" src="templates/js/admin.js"></script>
<?php
if (isset($sysCartUser[1]) && in_array($sysCartUser[1],array('admin','global'))) {
?>
<script type="text/javascript" src="templates/js/plugins/jquery.menu.js">
/***********************************************
* DD Mega Menu (c) Dynamic Drive (www.dynamicdrive.com)
* This notice MUST stay intact for legal use
* Visit http://www.dynamicdrive.com/ for this script and 100s more.
***********************************************/
</script>
<?php
}
if (SCROLL_TO_TOP_IMG) {
?>
<script type="text/javascript" src="templates/js/plugins/jquery.scrolltotop.js"></script>
<?php
}
if (isset($loadGreyBox)) {
?>
<script type="text/javascript" src="templates/js/drag.js"></script>
<script type="text/javascript" src="templates/greybox/greybox.js"></script>
<link href="templates/css/greybox.css" rel="stylesheet" type="text/css" media="all" />
<?php
}
if (isset($loadToggleSelect)) {
?>
<script type="text/javascript" src="templates/js/ajax.js"></script>
<script type="text/javascript" src="templates/js/toggle_select.js"></script>
<?php
}
if (isset($createFolder)) {
?>
<script type="text/javascript" src="templates/js/ajax.js"></script>
<script type="text/javascript" src="templates/js/toggle_select.js"></script>
<?php
}
if (isset($loadElFinder)) {
// We need to use the jquery migrate plugin for the file manager to prevent it breaking
?>
<script type="text/javascript" src="templates/js/plugins/jquery.migrate.js"></script>
<script type="text/javascript" src="templates/js/plugins/jquery.elfinder.js" charset="utf-8"></script>
<link rel="stylesheet" href="templates/css-elfinder/smoothness/jquery-ui-1.8.13.custom.css" type="text/css" media="screen" title="no title" charset="utf-8" />
<link rel="stylesheet" href="templates/css-elfinder/elfinder.css" type="text/css" media="screen" title="no title" charset="utf-8" />
<?php
}
if (isset($uiBlock)) {
?>
<script type="text/javascript" src="templates/js/plugins/jquery.blockUI.js"></script>
<?php
}
if (isset($colorbox)) {
?>
<link rel="stylesheet" href="templates/css/colorbox.css" type="text/css" />
<script type="text/javascript" src="templates/js/plugins/jquery.colorbox.js"></script>
<?php
}
if (in_array($cmd,array('stats','sales-trends','coupon-report','main','gift-report'))) {
?>
<link rel="stylesheet" href="templates/css/jqplot.css" type="text/css" />
<!--[if lte IE 9]>
<script type="text/javascript" src="templates/js/jqplot/excanvas.js"></script>
<![endif]-->
<script type="text/javascript" src="templates/js/jqplot/jquery.jqplot.js"></script>
<script type="text/javascript" src="templates/js/jqplot/jqplot.pieRenderer.js"></script>
<script type="text/javascript" src="templates/js/jqplot/jqplot.categoryAxisRenderer.js"></script>
<script type="text/javascript" src="templates/js/jqplot/jqplot.canvasTextRenderer.js"></script>
<script type="text/javascript" src="templates/js/jqplot/jqplot.labelRenderer.js"></script>
<script type="text/javascript" src="templates/js/jqplot/jqplot.highlighter.js"></script>
<script type="text/javascript" src="templates/js/jqplot/jqplot.cursor.js"></script>
<?php
if (isset($_GET['range']) && $_GET['range']=='24') {
?>
<script type="text/javascript" src="templates/js/jqplot/jqplot.canvasAxisTickRenderer.js"></script>
<?php
}
if (in_array($cmd,array('coupon-report','gift-report'))) {
?>
<script type="text/javascript" src="templates/js/jqplot/jqplot.barRenderer.js"></script>
<script type="text/javascript" src="templates/js/jqplot/jqplot.pointLabels.js"></script>
<?php
}
}
?>
<link rel="stylesheet" href="templates/css/jquery-ui.css" type="text/css" />
<link rel="stylesheet" href="templates/css/stylesheet.css" type="text/css" />
<!--[if IE 7]>
<link rel="stylesheet" href="templates/css/ie7.css" type="text/css" />
<![endif]-->
<link rel="SHORTCUT ICON" href="favicon.ico" />
</head>

<body>
<div id="overDiv" style="position:absolute; visibility:hidden; z-index:1000;"></div>

<div id="topwrapper">
<?php
include(PATH.'templates/header-top-bar.php');
?>
</div>

<div id="wrapper">
<?php
// Menu trigger can be 'click' or 'mouseover'..
if (isset($sysCartUser[1]) && in_array($sysCartUser[1],array('admin','global'))) {
?>
<div id="menu">

<script type="text/javascript">
 //<![CDATA[
 ddmegamenu.docinit({
  menuid: 'megamenu',
  trigger: 'click' 
 });
 //]]>
</script>

<?php
include(PATH.'templates/system/menu/nav-menu.php');
?>

<br class="clear" />
</div>
<?php
} else {
}
?>
