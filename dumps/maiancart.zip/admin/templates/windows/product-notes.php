<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); }
if (file_exists(PATH.'templates/header-custom.php')) {
  include_once(PATH.'templates/header-custom.php');
} else {
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php
}
$P = mc_getTableData('products','id',(int)$_GET['notes']);
?>
<meta http-equiv="content-type" content="application/xhtml+xml; charset=<?php echo $charset; ?>" />
<title><?php echo $pageTitle; ?></title>
<link rel="stylesheet" href="templates/css/stylesheet.css" type="text/css" />
<script type="text/javascript" src="templates/js/jquery.js"></script>
<script type="text/javascript" src="templates/js/plugins/jquery.impromptu.js"></script>
<script type="text/javascript" src="templates/js/admin.js"></script>
<script type="text/javascript">
//<![CDATA[
function updateProductNotes() {
  jQuery('#notes').css('background','#fff url(templates/images/loading.gif) no-repeat 98% 95%');
  jQuery(document).ready(function() {
   jQuery.post('index.php?p=manage-products&notes=<?php echo $_GET['notes']; ?>', { 
    notes: jQuery('#notes').val() 
   }, 
   function(data) {
    jQuery('#notes').css('background-image','none');
    mc_alertBox(data);
   }); 
  });  
  return false;
}
//]]>
</script>
</head>

<body class="body">

<div id="windowWrapper">

<div class="fieldHeadWrapper">
  <p><?php echo mc_cleanDataEnt($P->pName); ?></p>
</div>

<div class="productNotes">
<textarea name="productnotes" id="notes" rows="5" cols="20"><?php echo mc_cleanDataEnt($P->pNotes); ?></textarea>

<p style="text-align:center;padding-top:20px" id="loader">
 <input class="formbutton" onclick="updateProductNotes()" type="button" value="<?php echo mc_cleanDataEnt($msg_productmanage63); ?>" title="<?php echo mc_cleanDataEnt($msg_productmanage63); ?>" />
</p>
</div>

</div>

</body>
</html>
