<?php if (!defined('WINPARENT')) { die('Permission Denied'); }?>

    <script src="templates/js/bootstrap.js"></script>
    <script src="templates/js/plugins/bootstrap.dialog.js"></script>

    <script src="templates/js/mnc-admin.js"></script>
    <script src="templates/js/mnc.js"></script>

</body>
</html>