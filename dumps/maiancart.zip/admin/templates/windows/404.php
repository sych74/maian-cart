<div class="container" style="margin-top:90px">
  <div class="col-lg-8 col-lg-offset-2 text-center">
    <div class="logo">
      <h1 style="font-size:40px">404</h1>
    </div>
    <p class="lead text-muted" style="margin-top:10px"><i class="fa fa-warning fa-fw"></i> Oops, an error has occurred. Page Not Found!</p>
    <div class="clearfix"></div>
    <br>
    <div class="col-lg-6 col-lg-offset-3">
      <div class="btn-group btn-group-justified">
        <a href="index.php" class="btn btn-info"><i class="fa fa-arrow-left fa-fw"></i> Return to Dashboard</a>
      </div>
    </div>
  </div>
</div>