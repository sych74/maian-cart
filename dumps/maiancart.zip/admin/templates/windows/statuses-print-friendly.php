<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } 
$q_stat = mysql_query("SELECT *,DATE_FORMAT(dateAdded,'".$SETTINGS->mysqlDateFormat."') AS adate  
          FROM ".DB_PREFIX."statuses
          WHERE saleID = '".mc_digitSan($_GET['print'])."'
          ORDER BY id DESC
          ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
if (file_exists(PATH.'templates/header-custom.php')) {
  include_once(PATH.'templates/header-custom.php');
} else {
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php
}
?>
<meta http-equiv="content-type" content="application/xhtml+xml; charset=<?php echo $charset; ?>" />
<title><?php echo $pageTitle; ?></title>
<link rel="stylesheet" href="templates/css/stylesheet.css" type="text/css" />
</head>

<body class="body" onload="javascript:window.print()">

<div id="windowWrapper">
<?php
if (mysql_num_rows($q_stat)>0) {
  while ($STATUS = mysql_fetch_object($q_stat)) {
  ?>
  <p class="print_friendly"><?php echo statusText($STATUS->orderStatus); ?> - <b class="no_bold"><?php echo $STATUS->adate; ?> @ <?php echo $STATUS->timeAdded; ?></b>
  <span><?php echo nl2br(mc_cleanDataEnt($STATUS->statusNotes)); ?></span>
  </p>
  <?php
  }
} else {
?>
<p class="noData"><?php echo $msg_salesupdate15; ?></p>
<?php
}
?>
</div>

</body>
</html>
