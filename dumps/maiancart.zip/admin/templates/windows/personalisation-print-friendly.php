<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } 
$q_phys = mysql_query("SELECT *,".DB_PREFIX."products.id AS pid,".DB_PREFIX."purchases.id AS pcid FROM ".DB_PREFIX."purchases
          LEFT JOIN ".DB_PREFIX."products
          ON ".DB_PREFIX."purchases.productID = ".DB_PREFIX."products.id
          WHERE `saleID`                      = '".mc_digitSan($_GET['print-personalisation'])."' 
          AND `productType`                   = 'physical' 
          ORDER BY ".DB_PREFIX."purchases.id
          ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
// Sale..
$SALE = mc_getTableData('sales','id',
                     mc_digitSan($_GET['print-personalisation']),
                     '',
                     '*,DATE_FORMAT(purchaseDate,\''.$SETTINGS->mysqlDateFormat.'\') AS pdate'
        );          
if (file_exists(PATH.'templates/header-custom.php')) {
  include_once(PATH.'templates/header-custom.php');
} else {
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php
}
?>
<meta http-equiv="content-type" content="application/xhtml+xml; charset=<?php echo $charset; ?>" />
<title><?php echo $pageTitle; ?></title>
<link rel="stylesheet" href="templates/css/stylesheet.css" type="text/css" />
</head>

<body class="body"<?php echo (!isset($_GET['view-personalisation']) ? ' onload="javascript:window.print()"' : ''); ?>>

<div id="windowWrapper">
<?php
while ($PHYS = mysql_fetch_object($q_phys)) {

  $details      = '';
  $code         = ($PHYS->pCode ? $PHYS->pCode : 'N/A');
  $weight       = ($PHYS->pWeight ? $PHYS->pWeight : 'N/A');
  $PHYS->pName  = ($PHYS->pName ? $PHYS->pName : $PHYS->deletedProductName);
  $isDel        = ($PHYS->deletedProductName ? '<b class="deletedItem">'.$msg_script53.'</b>' : ''); 

$q_ps1 = mysql_query("SELECT * FROM ".DB_PREFIX."personalisation
         WHERE productID = '{$PHYS->pid}'
         AND enabled     = 'yes'
         ORDER BY id
         ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
if (mysql_num_rows($q_ps1)>0) {
?>
<p class="print_friendly">&#043; <?php echo mc_cleanDataEnt($PHYS->pName).($details ? ' ('.$details.')' : ''); ?> - <?php echo $code; ?>
<?php
while ($PS = mysql_fetch_object($q_ps1)) {
$q_ps = mysql_query("SELECT * FROM ".DB_PREFIX."purch_pers
        WHERE purchaseID       = '{$PHYS->pcid}'
        AND saleID             = '".mc_digitSan($_GET['print-personalisation'])."'
        AND productID          = '{$PHYS->pid}'
        AND personalisationID  = '{$PS->id}'
        ORDER BY id
        ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
$PERS_ITEM = mysql_fetch_object($q_ps);
if (isset($PERS_ITEM->visitorData) && $PERS_ITEM->visitorData!='' && $PERS_ITEM->visitorData!='no-option-selected') {       
?>
<span class="wrap">
  <span class="left"><?php echo mc_persTextDisplay(mc_cleanDataEnt($PS->persInstructions),true); ?></span>
  <span class="right"><?php echo nl2br(mc_cleanDataEnt($PERS_ITEM->visitorData)); ?></span>
  <br class="clear" />
</span>
<?php
}
}

?>
</p>
<?php
}
}
?>
<p class="p"><?php echo str_replace(array('{date}','{buyer}','{order_no}'),array($SALE->pdate,mc_cleanDataEnt($SALE->bill_1),mc_saleInvoiceNumber($SALE->invoiceNo)),$msg_viewsale63); ?></p>
</div>

<p>&nbsp;</p>
<p>&nbsp;</p>

</body>
</html>
