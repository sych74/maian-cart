<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); }
if (file_exists(PATH.'templates/header-custom.php')) {
  include_once(PATH.'templates/header-custom.php');
} else {
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php
}
?>
<meta http-equiv="content-type" content="application/xhtml+xml; charset=<?php echo $charset; ?>" />
<title><?php echo $pageTitle; ?></title>
<link rel="stylesheet" href="templates/css/stylesheet.css" type="text/css" />
<script type="text/javascript" src="templates/js/jquery.js"></script>
<script type="text/javascript" src="templates/js/global.js"></script>
</head>

<body class="body">

<form method="post" action="?p=gift&amp;viewGift=<?php echo $_GET['viewGift']; ?>">
<div id="windowWrapper">

<?php
if (isset($OK)) {
  echo actionCompleted($msg_giftcerts28);
}
?>

<div class="fieldHeadWrapper">
  <p><span class="float"><?php echo ($GIFT->code ? $GIFT->code : $msg_giftcerts31); ?></span><?php echo mc_cleanDataEnt($msg_giftcerts20); ?>:</p>
</div>
<?php
if (isset($GIFT->id)) {
?>
<div class="giftCertArea">

  <div class="left">
    
    <p><label><?php echo $msg_giftcerts21; ?>:</label><input type="text" class="box" name="from_name" value="<?php echo mc_cleanDataEnt($GIFT->from_name); ?>" /></p>
	<p style="padding-top:10px"><label><?php echo $msg_giftcerts22; ?>:</label><input type="text" class="box" name="to_name" value="<?php echo mc_cleanDataEnt($GIFT->to_name); ?>" /></p>
    <p style="padding-top:10px"><label><?php echo $msg_giftcerts32; ?>:</label><textarea name="message" rows="5" cols="20" style="height:100px"><?php echo mc_cleanDataEnt($GIFT->message); ?></textarea></p>
    <p style="padding-top:10px"><label><?php echo $msg_giftcerts26; ?> / <?php echo $msg_giftcerts27; ?>:</label><input type="text" class="box" name="value" style="width:20%" value="<?php echo mc_cleanDataEnt($GIFT->value); ?>" /> / <input type="text" class="box" name="redeemed" style="width:20%"  value="<?php echo mc_cleanDataEnt($GIFT->redeemed); ?>" /></p>
	
  </div>
  
  <div class="right">
  
    <p><label><?php echo $msg_giftcerts23; ?>:</label><input type="text" class="box" name="from_email" value="<?php echo mc_cleanDataEnt($GIFT->from_email); ?>" /></p>
	<p style="padding-top:10px"><label><?php echo $msg_giftcerts24; ?>:</label><input type="text" class="box" name="to_email" value="<?php echo mc_cleanDataEnt($GIFT->to_email); ?>" /></p>
    <p style="padding-top:10px"><label><?php echo $msg_giftcerts25; ?>:</label><textarea name="notes" rows="5" cols="20" style="height:100px"><?php echo mc_cleanDataEnt($GIFT->notes); ?></textarea></p>
    <p style="padding-top:10px"><label><?php echo $msg_giftcerts5; ?>:</label><?php echo $msg_script5; ?> <input type="radio" tabindex="<?php echo (++$tabIndex); ?>" name="enabled" value="yes"<?php echo ($GIFT->enabled=='yes' ? ' checked="checked"' : ''); ?> /> <?php echo $msg_script6; ?> <input tabindex="<?php echo (++$tabIndex); ?>" type="radio" name="enabled" value="no"<?php echo ($GIFT->enabled=='no' ? ' checked="checked"' : ''); ?> /></p>
	
  </div>
  
  <br class="clear" />
  
  <p style="margin:20px 0 10px 0;text-align:center">
    <input type="hidden" name="process" value="yes" />
    <input type="hidden" name="giftID" value="<?php echo $GIFT->id; ?>" />
    <input class="formbutton" type="submit" value="<?php echo mc_cleanDataEnt($msg_giftcerts7); ?>" title="<?php echo mc_cleanDataEnt($msg_giftcerts7); ?>" />
  </p>
  
</div>
<?php
} else {
?>
<p class="noData"><?php echo $msg_giftcerts29; ?></p>
<?php
}
?>
</div>
</form>

</body>
</html>
