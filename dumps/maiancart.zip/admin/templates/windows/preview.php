<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); }
if (file_exists(PATH.'templates/header-custom.php')) {
  include_once(PATH.'templates/header-custom.php');
} else {
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php
}
?>
<meta http-equiv="content-type" content="application/xhtml+xml; charset=<?php echo $charset; ?>" />
<title><?php echo $pageTitle; ?></title>
<link rel="stylesheet" href="templates/css/stylesheet.css" type="text/css" />
</head>

<body class="body">

<div id="windowWrapper">

<div class="fieldHeadWrapper">
  <p><span class="float"><a class="print" href="javascript:window.print()" title="<?php echo mc_cleanDataEnt($msg_script23); ?>"><?php echo mc_cleanDataEnt($msg_script23); ?></a></span><?php echo mc_cleanDataEnt($msg_script68); ?>:</p>
</div>

<div class="previewArea">
<?php
include(REL_PATH.'control/classes/bbCode.php');
$MCBB = new bbCode_Parser();
echo (isset($_SESSION['previewBoxText']) && $_SESSION['previewBoxText'] ?
mc_txtParsingEngine($_SESSION['previewBoxText']) :
$msg_script69);
?>
</div>

</div>

</body>
</html>
