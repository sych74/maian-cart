<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); }
if (file_exists(PATH.'templates/header-custom.php')) {
  include_once(PATH.'templates/header-custom.php');
} else {
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php
}
?>
<meta http-equiv="content-type" content="application/xhtml+xml; charset=<?php echo $charset; ?>" />
<title><?php echo $pageTitle; ?></title>
<link rel="stylesheet" href="templates/css/stylesheet.css" type="text/css" />
<script type="text/javascript" src="templates/js/jquery.js"></script>
<script type="text/javascript" src="templates/js/global.js"></script>
</head>

<body class="body">

<div id="content" style="padding:2px;border:0">
<?php
if (isset($OK)) {
  echo actionCompleted($msg_salesupdate29);
}
if (isset($_GET['deldone'])) {
  echo actionCompleted($msg_salesupdate30);
}
?>
<div class="fieldHeadWrapper">
  <p><span class="float"><?php echo str_replace('{count}',mc_rowCount('status_text'),$msg_salesupdate27); ?></span><?php echo $msg_salesupdate28; ?>:</p>
</div>

<form method="post" action="?p=sales-statuses<?php echo (isset($_GET['id']) ? '&amp;id='.mc_digitSan($_GET['id']) : ''); ?>">

<div class="statuses">
  <p>
  <select onchange="if(this.value!= 0){location=this.options[this.selectedIndex].value}">
  <option value="0">- - - - - -</option>
  <?php
  $query = mysql_query("SELECT * FROM ".DB_PREFIX."status_text ORDER BY statTitle")
           or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  while ($STATUS = mysql_fetch_object($query)) {
  ?>
  <option value="?p=sales-statuses&amp;id=<?php echo $STATUS->id; ?>"<?php echo (isset($_GET['id']) && $_GET['id']==$STATUS->id ? ' selected="selected"' : ''); ?>><?php echo mc_cleanDataEnt($STATUS->statTitle); ?></option>
  <?php
  }
  ?>
  </select>
  <?php
  if (isset($_GET['id'])) {
  ?>
  <a onclick="return confirmMessage('<?php echo mc_cleanDataEnt($msg_javascript45); ?>')" href="?p=sales-statuses&amp;del=<?php echo mc_digitSan($_GET['id']); ?>" title="<?php echo mc_cleanDataEnt($msg_salesupdate34); ?>"><?php echo $msg_salesupdate34; ?></a>
  <?php
  }
  ?>
  </p>
</div>
<?php
if (isset($_GET['id'])) {
$EDIT = mc_getTableData('status_text','id',mc_digitSan($_GET['id']));
?>
<div class="formFieldWrapper">
  <label><?php echo $msg_salesupdate31; ?>:</label>
  <input type="text" name="statTitle" value="<?php echo mc_cleanData($EDIT->statTitle); ?>" class="box" tabindex="1" />
</div>

<div class="formFieldWrapper">
 <label><?php echo $msg_salesupdate32; ?>:</label>
 <textarea rows="5" cols="30" name="statText" class="textarea" tabindex="2"><?php echo ($EDIT->statText && $EDIT->statText!=null ? mc_cleanDataEnt($EDIT->statText) : ''); ?></textarea>
</div>

<p style="text-align:center;padding:10px 0 0 0">
 <input type="hidden" name="process" value="yes" />
 <input class="formbutton" type="submit" name="update" value="<?php echo mc_cleanDataEnt($msg_salesupdate33); ?>" title="<?php echo mc_cleanDataEnt($msg_salesupdate33); ?>" />
</p>
<?php
}
?>
</form>

  
</div>

</body>
</html>
