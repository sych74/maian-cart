<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); }
echo (isset($_SESSION['previewBoxText']) && $_SESSION['previewBoxText'] ?
$_SESSION['previewBoxText'] :
$msg_script69);
?>
