<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); }
if (file_exists(PATH.'templates/header-custom.php')) {
  include_once(PATH.'templates/header-custom.php');
} else {
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php
}
?>
<meta http-equiv="content-type" content="application/xhtml+xml; charset=<?php echo $charset; ?>" />
<title><?php echo $pageTitle; ?></title>
<link rel="stylesheet" href="templates/css/stylesheet.css" type="text/css" />
<script type="text/javascript" src="templates/js/jquery.js"></script>
<script type="text/javascript" src="templates/js/global.js"></script>
</head>

<body class="body">

<div id="content" style="padding:2px;border:0">
<?php
if (isset($OK)) {
  echo actionCompleted($msg_newsletter37);
}
if (isset($_GET['deldone'])) {
  echo actionCompleted($msg_newsletter38);
}
?>
<div class="fieldHeadWrapper">
  <p><span class="float"><?php echo str_replace('{count}',mc_rowCount('newstemplates'),$msg_newsletter34); ?></span><?php echo $msg_newsletter33; ?>:</p>
</div>

<form method="post" action="?p=newsletter-templates<?php echo (isset($_GET['id']) ? '&amp;update='.mc_digitSan($_GET['id']).'&amp;id='.mc_digitSan($_GET['id']) : ''); ?>">

<div class="statuses">
  <p>
  <select onchange="if(this.value!= 0){location=this.options[this.selectedIndex].value}">
  <option value="0">- - - - - -</option>
  <?php
  $query = mysql_query("SELECT * FROM ".DB_PREFIX."newstemplates ORDER BY `subject`")
           or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  while ($TP = mysql_fetch_object($query)) {
  ?>
  <option value="?p=newsletter-templates&amp;id=<?php echo $TP->id; ?>"<?php echo (isset($_GET['id']) && $_GET['id']==$TP->id ? ' selected="selected"' : ''); ?>><?php echo mc_cleanDataEnt($TP->subject); ?></option>
  <?php
  }
  ?>
  </select>
  <?php
  if (isset($_GET['id'])) {
  ?>
  <a onclick="return confirmMessage('<?php echo mc_cleanDataEnt($msg_javascript45); ?>')" href="?p=newsletter-templates&amp;del=<?php echo mc_digitSan($_GET['id']); ?>" title="<?php echo mc_cleanDataEnt($msg_newsletter35); ?>"><?php echo $msg_newsletter35; ?></a>
  <?php
  }
  ?>
  </p>
</div>
<?php
if (isset($_GET['id'])) {
$TP = mc_getTableData('newstemplates','id',mc_digitSan($_GET['id']));
?>
<div class="formFieldWrapper">
  <div class="formLeft">
    <label><?php echo $msg_newsletter14; ?>:</label>
    <input type="text" name="from" id="from" value="<?php echo mc_cleanDataEnt($TP->name); ?>" class="box" tabindex="1" />
  </div>
  <div class="formRight">  
    <label><?php echo $msg_newsletter15; ?>:</label>
    <input type="text" name="email" id="email" value="<?php echo mc_cleanDataEnt($TP->email); ?>" class="box" tabindex="2" />
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper">
 <label><?php echo $msg_newsletter18; ?>:</label>
  <input type="text" name="subject" id="subject" value="<?php echo mc_cleanDataEnt($TP->subject); ?>" class="box" tabindex="3" />
</div>

<div class="formFieldWrapper">
  <label><?php echo $msg_newsletter16; ?>:</label>
  <textarea name="html" id="html" rows="5" class="tarea" cols="20"><?php echo mc_cleanDataEnt($TP->html); ?></textarea>
</div>

<div class="formFieldWrapper">
  <label><?php echo $msg_newsletter17; ?>:</label>
  <textarea name="plain" id="plain" rows="5" class="tarea" cols="20"><?php echo mc_cleanDataEnt($TP->plain); ?></textarea>
</div>

<p style="text-align:center;padding:10px 0 0 0">
 <input type="hidden" name="process" value="yes" />
 <input class="formbutton" type="submit" name="update" value="<?php echo mc_cleanDataEnt($msg_newsletter36); ?>" title="<?php echo mc_cleanDataEnt($msg_newsletter36); ?>" />
</p>
<?php
}
?>
</form>

  
</div>

</body>
</html>
