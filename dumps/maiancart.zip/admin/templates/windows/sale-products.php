<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); }
if (file_exists(PATH.'templates/header-custom.php')) {
  include_once(PATH.'templates/header-custom.php');
} else {
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php
}
?>
<meta http-equiv="content-type" content="application/xhtml+xml; charset=<?php echo $charset; ?>" />
<title><?php echo $pageTitle; ?></title>
<link rel="stylesheet" href="templates/css/stylesheet.css" type="text/css" />
</head>

<body class="body">

<div id="windowWrapper">

<?php
// Check for incomplete sale..
$SALE = mc_getTableData('sales','id',
          mc_digitSan($_GET['ordered']),
          '',
          '*,DATE_FORMAT(purchaseDate,\''.$SETTINGS->mysqlDateFormat.'\') AS pdate'
        );
$q_prod = mysql_query("SELECT *,`".DB_PREFIX."products`.`id` AS `pid`,`".DB_PREFIX."purchases`.`id` AS `pur_id` FROM `".DB_PREFIX."purchases`
            LEFT JOIN `".DB_PREFIX."products`
            ON `".DB_PREFIX."purchases`.`productID` = ".DB_PREFIX."products.id
            WHERE `saleID`                          = '".mc_digitSan($_GET['ordered'])."' 
            ".($SALE->saleConfirmation=='no' ? '' : 'AND `saleConfirmation` = \'yes\'')."
            ORDER BY `".DB_PREFIX."purchases`.`id`
            ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
if (mysql_num_rows($q_prod)>0) {
while ($PRODUCT = mysql_fetch_object($q_prod)) {
$details         = '';
$link            = '';
// Is this a virtual product purchase..
if ($PRODUCT->productType=='virtual' && $PRODUCT->giftID>0) {
$GIFT            = mc_getTableData('giftcerts','id',$PRODUCT->giftID);
$a_total         = $PRODUCT->attrPrice;
$p_total         = $PRODUCT->persPrice;
$code            = '';
$weight          = 'N/A';
$PRODUCT->pName  = (isset($GIFT->name) ? $GIFT->name : $PRODUCT->deletedProductName);
$isDel           = ($PRODUCT->deletedProductName ? '<b class="deletedItem">'.$msg_script53.'</b>' : '');
$img             = storeProductImg($PRODUCT->pid,$PRODUCT,false,(isset($GIFT->image) ? $GIFT->image : ''));
} else {
$a_total         = $PRODUCT->attrPrice;
$p_total         = $PRODUCT->persPrice;
$code            = ($PRODUCT->pCode ? $PRODUCT->pCode : 'N/A');
$weight          = ($PRODUCT->pWeight ? $PRODUCT->pWeight : 'N/A');
$PRODUCT->pName  = ($PRODUCT->pName ? $PRODUCT->pName : $PRODUCT->deletedProductName);
$isDel           = ($PRODUCT->deletedProductName ? '<b class="deletedItem">'.$msg_script53.'</b>' : '');
$img             = storeProductImg($PRODUCT->pid,$PRODUCT,false,'');
}
// Downloadable?
if ($PRODUCT->productType=='download') {
  if ($PRODUCT->saleConfirmation=='yes') {
    $link = '<span class="code">'.str_replace('{sale}',mc_digitSan($_GET['ordered']),$msg_sales35).'</span>';
  } else {
    $link = '<span class="code"><a href="#" onclick="return false" style="cursor:auto;text-decoration:none">'.$msg_salesincomplete2.'</a></span>';
  }
}
// Gift cert..
if ($PRODUCT->productType=='virtual') {
  $link = '<span class="code">'.str_replace(array('{sale}','{purchase}'),array(mc_digitSan($_GET['ordered']),$PRODUCT->pur_id),$msg_sales46).'</span>';
}
?>
<div class="productsOrdered">
  <div class="left"> 
    <p><?php echo $img; ?></p>
  </div>
  <div class="product">
    <p><?php echo ($code ? $code.':' : ''); ?> <?php echo mc_cleanDataEnt($PRODUCT->pName).($details ? ' <span class="highlight">('.$details.')</span>' : '').$isDel; ?>
    <?php
    //Attributes..
	if ($PRODUCT->productType=='virtual') {
	  echo mc_saleGiftCerts(mc_digitSan($_GET['ordered']),$PRODUCT->pur_id);
	} else {
      echo mc_saleAttributes(mc_digitSan($_GET['ordered']),$PRODUCT->pur_id,$PRODUCT->pid,false,$p_total);
	}
    // Personalised items..
    $run = 0;
    $q_ps = mysql_query("SELECT * FROM `".DB_PREFIX."purch_pers`
            WHERE `purchaseID` = '{$PRODUCT->pur_id}'
            ORDER BY `id`
            ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    if (mysql_num_rows($q_ps)>0) {
    ?>
    <span class="personalisation">
    <?php
    while ($PS = mysql_fetch_object($q_ps)) {
      ++$run;
      $PERSONALISED  = mc_getTableData('personalisation','id',$PS->personalisationID);
      if ($PS->visitorData && $PS->visitorData!='no-option-selected') {
        echo '<span class="option">'.mc_persTextDisplay(mc_cleanDataEnt($PERSONALISED->persInstructions),true).($PERSONALISED->persAddCost>0 ? ' (+'.mc_currencyFormat(mc_formatPrice($PERSONALISED->persAddCost)).')' : '').':</span>';
        echo '<span class="data"'.($run==mysql_num_rows($q_ps) ? ' style="margin:0"' : '').'>'.mc_cleanDataEnt($PS->visitorData).'</span>';
      }
    }  
    ?>
    </span>
    <?php  
    }
    ?>
    </p>
  </div>
  <br class="clear" />
  <p class="saleFooter">
  <?php
  if ($PRODUCT->globalDiscount>0 && $PRODUCT->globalCost>0) {
  ?>
  <span class="global"><?php echo $link.str_replace(array('{global}','{cost}'),array($PRODUCT->globalDiscount,mc_currencyFormat(mc_formatPrice($PRODUCT->globalCost))),$msg_viewsale85).($a_total>0 ? ' + '.$a_total : '').($p_total>0 ? ' + '.$p_total : ''); ?></span>
  <?php
  }
  ?>
  <span class="price"><?php echo $link.str_replace(array('{price}','{qty}'),array(mc_currencyFormat(mc_formatPrice($PRODUCT->productQty*($PRODUCT->salePrice),true)),$PRODUCT->productQty),$msg_sales36).($a_total>0 ? ' + '.$a_total : '').($p_total>0 ? ' + '.$p_total : ''); ?></span>
  </p>
</div>
<?php
}
}
?>
</div>

</body>
</html>
