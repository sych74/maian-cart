<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); }
if (file_exists(PATH.'templates/header-custom.php')) {
  include_once(PATH.'templates/header-custom.php');
} else {
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php
}
$S      = mc_getTableData('sales','id',(int)$_GET['gatewayParams']);
$params = ($S->gateparams ? explode('<-->',$S->gateparams) : array());
?>
<meta http-equiv="content-type" content="application/xhtml+xml; charset=<?php echo $charset; ?>" />
<title><?php echo $pageTitle; ?></title>
<link rel="stylesheet" href="templates/css/stylesheet.css" type="text/css" />
</head>

<body class="body">

<div id="windowWrapper">

<div class="fieldHeadWrapper">
  <p><span class="float"><a href="javascript:window.print()"><img src="templates/images/print.png" alt="" title=""  /></a></span><?php echo mc_cleanDataEnt($msg_viewsale107); ?></p>
</div>

<?php
if (!empty($params)) {
?>
<div class="paramMsg">
  <p><?php echo str_replace('{gateway}',$mcSystemPaymentMethods[$S->paymentMethod]['lang'],mc_cleanDataEnt($msg_viewsale108)); ?></p>
</div>
<?php
foreach ($params AS $gp) {
$chop = explode('=>',$gp);
?>
<div class="param">
  <div class="paramLeft"><?php echo mc_cleanDataEnt($chop[0]); ?></div>
  <div class="paramRight"><?php echo mc_cleanDataEnt($chop[1]); ?></div>
  <br class="clear" />
</div>  
<?php
}
} else {
?>
<p class="noParams"><?php echo $msg_viewsale109; ?></p>
<?php
}
?>

</div>

</body>
</html>