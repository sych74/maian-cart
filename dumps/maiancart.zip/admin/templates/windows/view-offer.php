<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); }
if (file_exists(PATH.'templates/header-custom.php')) {
  include_once(PATH.'templates/header-custom.php');
} else {
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php
}
?>
<meta http-equiv="content-type" content="application/xhtml+xml; charset=<?php echo $charset; ?>" />
<title><?php echo $pageTitle; ?></title>
<link rel="stylesheet" href="templates/css/jquery-ui.css" type="text/css" />
<link rel="stylesheet" href="templates/css/stylesheet.css" type="text/css" />
<script type="text/javascript" src="templates/js/jquery.js"></script>
<script type="text/javascript" src="templates/js/jquery.ui.js"></script>
<script type="text/javascript" src="templates/js/global.js"></script>
<script type="text/javascript">
//<![CDATA[
var scwWeekStart = <?php echo $SETTINGS->jsWeekStart; ?>;
var scwDateOutputFormat = '<?php echo $SETTINGS->jsDateFormat; ?>';
//]]>
</script>
</head>

<body class="body">

<div id="content" style="padding:2px;border:0">
<?php
if (isset($OK)) {
  echo actionCompleted($msg_productoffers9);
}
if (isset($OK2)) {
  echo actionCompleted($msg_productoffers25);
}
$CAT = mc_getTableData('categories','id',mc_digitSan($_GET['view']));
define('CALBOX', 'newExpiry');
include(PATH.'templates/date-picker.php');
?>
<div class="fieldHeadWrapper">
  <p><span class="float"><?php echo $msg_productoffers18; ?></span><?php echo str_replace('{cat}',(isset($CAT->catname) ? mc_cleanDataEnt($CAT->catname) : ''),$msg_productoffers16); ?>:</p>
</div>

<form method="post" id="form" action="?p=special-offers&amp;view=<?php echo mc_digitSan($_GET['view']); ?>" onsubmit="if(jQuery('#newPrice').val()=='0.00'){alert('<?php echo mc_cleanDataEnt($msg_javascript490); ?>');return false;}else{return confirmMessage('<?php echo mc_cleanDataEnt($msg_javascript45); ?>')}">
<div class="offerAdjustment">
  <p>
  <input type="hidden" name="processUpdateOffers" value="yes" />
  <input type="checkbox" name="log" value="all" onclick="toggleCheckBoxes(this.checked,'offer')" />
  <?php echo $msg_productoffers22; ?> <input style="width:8%" class="box" type="text" name="newPrice" id="newPrice" value="0.00" />
  <?php echo $msg_productoffers23; ?> <input style="width:8%" class="box" type="text" name="newExpiry" id="newExpiry" />
  <?php echo $msg_productoffers27; ?> <input style="width:8%" class="box" type="text" name="newBuy" id="newBuy" value="0" />
  <span style="float:right"><input type="submit" value="<?php echo mc_cleanDataEnt($msg_productoffers24); ?>" title="<?php echo mc_cleanDataEnt($msg_productoffers24); ?>" class="formbutton" /></span>
  </p>
</div>

<?php
$q_products = mysql_query("SELECT *,".DB_PREFIX."products.id AS pid,DATE_FORMAT(pOfferExpiry,'".$SETTINGS->mysqlDateFormat."') AS pEDate FROM ".DB_PREFIX."products
              LEFT JOIN ".DB_PREFIX."prod_category
              ON ".DB_PREFIX."products.id   = ".DB_PREFIX."prod_category.product
              WHERE `category`                = '".mc_digitSan($_GET['view'])."'
              AND `pEnable`                   = 'yes'
              AND `pOffer`                    > 0
              GROUP BY ".DB_PREFIX."products.id
              ORDER BY `pName`
              ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
while ($P = mysql_fetch_object($q_products)) {
?>
<div class="offer">
  <div class="name"><input type="checkbox" name="products[]" value="<?php echo $P->pid; ?>" /> <?php echo mc_cleanDataEnt($P->pName); ?><span class="offerExpiry"><?php echo $msg_productoffers21; ?>: <?php echo ($P->pEDate>0 ? $P->pEDate : 'N/A').' / '.$msg_productoffers28.': '.$P->pMultiBuy; ?></span></div>
  <div class="prices"><del><?php echo mc_currencyFormat(mc_formatPrice($P->pPrice)); ?></del> / <?php echo mc_currencyFormat(mc_formatPrice($P->pOffer)); ?></div>
  <?php
  if ($uDel=='yes') {
  ?>
  <div class="del"><a href="?p=special-offers&amp;view=<?php echo mc_digitSan($_GET['view']); ?>&amp;product=<?php echo $P->pid; ?>" title="<?php echo mc_cleanDataEnt($msg_productoffers13); ?>" onclick="return confirmMessage('<?php echo mc_cleanDataEnt($msg_javascript45); ?>')"><?php echo $msg_productoffers13; ?></a></div>
  <?php
  }
  ?>
  <br class="clear" />
</div>
<?php
}
?>  
</form>
</div>

</body>
</html>
