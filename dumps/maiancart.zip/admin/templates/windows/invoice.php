<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); }
if (file_exists(PATH.'templates/header-custom.php')) {
  include_once(PATH.'templates/header-custom.php');
} else {
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php
}
$bill  = array();
$ship  = array();
// Addresses. Check for legacy..
if ($SALE->buyerAddress) {
  $billingAddress   = nl2br(mc_cleanDataEnt($SALE->buyerAddress));
  $shippingAddress  = nl2br(mc_cleanDataEnt($SALE->buyerAddress));
} else {
  // Build addresses from fields..lazy loop..:)
  for ($i=3; $i<8; $i++) {
    $f = 'bill_'.$i;
    $s = 'ship_'.$i;
    if ($SALE->$f) {
      $bill[] = mc_cleanDataEnt($SALE->$f);
    }
    if ($SALE->$s) {
      $ship[] = mc_cleanDataEnt($SALE->$s);
    }
  }
  $billingAddress   = implode('<br />',$bill);
  $shippingAddress  = implode('<br />',$ship);
}
?>
<meta http-equiv="content-type" content="application/xhtml+xml; charset=<?php echo $charset; ?>" />
<link rel="stylesheet" href="templates/css/invoice.css" type="text/css" />
<script type="text/javascript" src="templates/js/jquery.js"></script>
<title><?php echo $title; ?></title>
</head>

<body>

<div id="wrapper">

<div id="header">

  <div class="headLeft">
   <h1><?php echo mc_cleanDataEnt($SETTINGS->cName); ?></h1>
   <p class="ptag">
    <span class="wrap">
     <span class="heading"><?php echo $msg_invoice2; ?></span>
     <span class="heading_value"><?php echo mc_saleInvoiceNumber($SALE->invoiceNo); ?></span>
     <br class="clear" />
    </span>
    <span class="wrap">
     <span class="heading"><?php echo $msg_invoice3; ?></span>
     <span class="heading_value"><?php echo $SALE->pdate; ?></span>
     <br class="clear" />
    </span>
    <span class="wrap"<?php echo ($SALE->setShipRateID==0 ? ' style="border-bottom:0"' : ''); ?>>
     <span class="heading"><?php echo $msg_invoice4; ?></span>
     <span class="heading_value"><?php echo mc_paymentMethodName($SALE->paymentMethod); ?></span>
     <br class="clear" />
    </span>
    <?php
    if ($SALE->setShipRateID>0 && in_array($SALE->shipType,array('weight'))) {
    ?>
    <span class="wrap" style="border-bottom:0">
     <span class="heading"><?php echo $msg_invoice30; ?></span>
     <span class="heading_value"><?php echo mc_getShippingService(mc_getShippingServiceFromRate($SALE->setShipRateID)); ?></span>
     <br class="clear" />
    </span>
    <?php
    }
    ?>
   </p>
   <p class="ptag2">
    <span class="billAddress">
     <span class="head"><?php echo $msg_invoice5; ?>:</span>
     <?php echo mc_cleanDataEnt($SALE->bill_1); ?><br />
     <?php echo $billingAddress; ?><br />
     <?php echo mc_getShippingCountry($SALE->bill_9); ?><br /><br />
     <b>E</b>: <?php echo mc_cleanDataEnt($SALE->bill_2); ?><br />
     <b>T</b>: <?php echo mc_cleanDataEnt($SALE->bill_8); ?>
    </span>
    <span class="delAddress">
     <span class="head"><?php echo $msg_invoice34; ?>:</span>
     <?php echo mc_cleanDataEnt($SALE->bill_1); ?><br />
     <?php echo $shippingAddress; ?><br />
     <?php echo mc_getShippingCountry($SALE->shipSetCountry); ?><br /><br />
     <b>E</b>: <?php echo mc_cleanDataEnt($SALE->ship_2); ?><br />
     <b>T</b>: <?php echo mc_cleanDataEnt($SALE->ship_8); ?>
    </span>
    <br class="clear" />
   </p>
  </div>
  
  <div class="headRight">
   <p><img src="templates/images/invoice-logo.gif" alt="<?php echo mc_cleanDataEnt($msg_invoice); ?>" title="<?php echo mc_cleanDataEnt($msg_invoice); ?>" /></p>
  </div>
  
  <br class="clear" />

</div>

<div id="content">

<table width="100%" cellspacing="0" cellpadding="0">
<tr>
  <td class="head1"><?php echo $msg_invoice6; ?></td>
  <td class="head2"><?php echo $msg_invoice7; ?></td>
  <td class="head3"><?php echo $msg_invoice8; ?></td>
  <td class="head4"><?php echo $msg_invoice31; ?></td>
  <td class="head5"><?php echo $msg_invoice9; ?></td>
</tr>
<?php
$subTotal = '0.00';
// Physical..
$q_phys = mysql_query("SELECT *,`".DB_PREFIX."products`.`id` AS `pid`,`".DB_PREFIX."purchases`.`id` AS `pcid` FROM `".DB_PREFIX."purchases`
          LEFT JOIN `".DB_PREFIX."products`
          ON `".DB_PREFIX."purchases`.`productID` = `".DB_PREFIX."products`.`id`
          WHERE `saleID`                        = '".mc_digitSan($_GET['sale'])."' 
          AND `productType`                     = 'physical'
          ORDER BY `".DB_PREFIX."purchases`.`id`
          ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
if (mysql_num_rows($q_phys)>0) {
  while ($PHYS = mysql_fetch_object($q_phys)) {
  $details      = '';
  $code         = ($PHYS->pCode ? $PHYS->pCode : 'N/A');
  $weight       = ($PHYS->pWeight ? $PHYS->pWeight : 'N/A');
  $PHYS->pName  = ($PHYS->pName ? $PHYS->pName : $PHYS->deletedProductName);
  $isDel        = ($PHYS->deletedProductName ? '<b class="deletedItem">'.$msg_script53.'</b>' : '');
  ?>
  <tr>
    <td class="sale1">[<?php echo $code; ?>] <?php echo mc_cleanDataEnt($PHYS->pName); ?>
    <?php
    // Attributes..
    echo mc_saleAttributes(mc_digitSan($_GET['sale']),$PHYS->pcid,$PHYS->pid);
    $pers_Price = '0.00';
    // Personalised items..
    $q_ps = mysql_query("SELECT * FROM `".DB_PREFIX."purch_pers`
            WHERE `purchaseID` = '{$PHYS->pcid}'
            ORDER BY `id`
            ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    if (mysql_num_rows($q_ps)>0) {
    ?>
    <p class="personalisation">
    <?php
      while ($PS = mysql_fetch_object($q_ps)) {
        $PERSONALISED  = mc_getTableData('personalisation','id',$PS->personalisationID);
        if ($PS->visitorData && $PS->visitorData!='no-option-selected') {
          echo '<span class="option">'.mc_persTextDisplay(mc_cleanDataEnt($PERSONALISED->persInstructions),true).($PERSONALISED->persAddCost>0 ? ' (+'.mc_currencyFormat(mc_formatPrice($PERSONALISED->persAddCost)).')' : '').':</span>';
          echo '<span class="data">'.mc_cleanDataEnt($PS->visitorData).'</span>';
        }
      }  
      // Pers per item..
      $pers_Price = ($PHYS->persPrice>0 ? mc_formatPrice($PHYS->persPrice) : '0.00');
    ?>
    </p>
    <?php  
    }
    ?>
    </td>
    <td class="sale2"><?php echo $PHYS->productQty; ?></td>
    <td class="sale3"><?php echo mc_currencyFormat(mc_formatPrice($PHYS->salePrice,true)); ?></td>
    <td class="sale4"><?php echo ($pers_Price>0 || $PHYS->attrPrice>0 ? mc_currencyFormat(mc_formatPrice($pers_Price+$PHYS->attrPrice,true)) : '- -'); ?></td>
    <td class="sale5"><?php echo mc_currencyFormat(mc_formatPrice(($PHYS->productQty*$PHYS->salePrice)+($pers_Price+$PHYS->attrPrice),true)); ?></td>
  </tr> 
  <?php
  $subTotal = $subTotal+mc_formatPrice(($PHYS->productQty*$PHYS->salePrice)+($PHYS->persPrice+$PHYS->attrPrice));
  }
}
// Download..
if (INCLUDE_DOWNLOADS_ON_INVOICE) {
$q_down = mysql_query("SELECT *,`".DB_PREFIX."products`.`id` AS `pid`,`".DB_PREFIX."purchases`.`id` AS `pcid` FROM `".DB_PREFIX."purchases`
          LEFT JOIN `".DB_PREFIX."products`
          ON `".DB_PREFIX."purchases`.`productID`  = `".DB_PREFIX."products`.`id`
          WHERE `saleID`                         = '".mc_digitSan($_GET['sale'])."' 
          AND `productType`                      = 'download'
          ORDER BY `".DB_PREFIX."purchases`.`id`
          ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
if (mysql_num_rows($q_down)>0) {
  while ($DOWN = mysql_fetch_object($q_down)) {
  $details      = '';
  $code         = ($DOWN->pCode ? $DOWN->pCode : 'N/A');
  $weight       = ($DOWN->pWeight ? $DOWN->pWeight : 'N/A');
  $DOWN->pName  = ($DOWN->pName ? $DOWN->pName : $DOWN->deletedProductName);
  $isDel2       = ($DOWN->deletedProductName ? '<b class="deletedItem">'.$msg_script53.'</b>' : '');
  ?>
  <tr>
    <td class="sale1">[<?php echo $code; ?>] <?php echo mc_cleanDataEnt($DOWN->pName); ?> (<b><?php echo $msg_invoice16; ?></b>)
    <?php
    // Attributes..
    echo mc_saleAttributes(mc_digitSan($_GET['sale']),$DOWN->pcid,$DOWN->pid);
    $pers_Price = '0.00';
    // Personalised items..
    $q_ps = mysql_query("SELECT * FROM `".DB_PREFIX."purch_pers`
            WHERE `purchaseID` = '{$DOWN->pcid}'
            ORDER BY `id`
            ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    if (mysql_num_rows($q_ps)>0) {
    ?>
    <p class="personalisation">
    <?php
      while ($PS = mysql_fetch_object($q_ps)) {
        $PERSONALISED  = mc_getTableData('personalisation','id',$PS->personalisationID);
        if ($PS->visitorData && $PS->visitorData!='no-option-selected') {
          echo '<span class="option">'.mc_persTextDisplay(mc_cleanDataEnt($PERSONALISED->persInstructions),true).($PERSONALISED->persAddCost>0 ? ' (+'.mc_currencyFormat(mc_formatPrice($PERSONALISED->persAddCost)).')' : '').':</span>';
          echo '<span class="data">'.mc_cleanDataEnt($PS->visitorData).'</span>';
        }
      }  
      // Pers per item..
      $pers_Price = ($DOWN->persPrice>0 ? mc_formatPrice($DOWN->persPrice) : '0.00');
    ?>
    </p>
    <?php  
    }
    ?>
    </td>
    <td class="sale2"><?php echo $DOWN->productQty; ?></td>
    <td class="sale3"><?php echo mc_currencyFormat(mc_formatPrice($DOWN->salePrice,true)); ?></td>
    <td class="sale4"><?php echo ($pers_Price>0 || $DOWN->attrPrice>0 ? mc_currencyFormat(mc_formatPrice($pers_Price+$DOWN->attrPrice,true)) : '- -'); ?></td>
    <td class="sale5"><?php echo mc_currencyFormat(mc_formatPrice($DOWN->productQty*($DOWN->salePrice+$pers_Price+$DOWN->attrPrice),true)); ?></td>
  </tr> 
  <?php
  $subTotal = $subTotal+mc_formatPrice($DOWN->productQty*$DOWN->salePrice);
  }
}
}

// Virtual..
if (INCLUDE_GIFT_ON_INVOICE) {
$q_virtual = mysql_query("SELECT *,`".DB_PREFIX."products`.`id` AS `pid`,`".DB_PREFIX."purchases`.`id` AS `pcid` FROM `".DB_PREFIX."purchases`
             LEFT JOIN `".DB_PREFIX."products`
             ON `".DB_PREFIX."purchases`.`productID`  = `".DB_PREFIX."products`.`id`
             WHERE `saleID`                         = '".mc_digitSan($_GET['sale'])."' 
             AND `productType`                      = 'virtual'
             ORDER BY `".DB_PREFIX."purchases`.`id`
             ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
if (mysql_num_rows($q_virtual)>0) {
  while ($VUTL = mysql_fetch_object($q_virtual)) {
  $GIFT         = mc_getTableData('giftcerts','id',$VUTL->giftID);
  $details      = '';
  $code         = '';
  $weight       = 'N/A';
  $VUTL->pName  = (isset($GIFT->name) ? $GIFT->name : $VUTL->deletedProductName);
  $isDel2       = ($VUTL->deletedProductName ? '<b class="deletedItem">'.$msg_script53.'</b>' : '');
  ?>
  <tr>
    <td class="sale1"><?php echo mc_cleanDataEnt($VUTL->pName); ?>
    <?php
    // Attributes..
    echo mc_saleGiftCerts(mc_digitSan($_GET['sale']),$VUTL->pcid);
    $pers_Price = '0.00';
    // Personalised items..
    $q_ps = mysql_query("SELECT * FROM `".DB_PREFIX."purch_pers`
            WHERE `purchaseID` = '{$VUTL->pcid}'
            ORDER BY `id`
            ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    if (mysql_num_rows($q_ps)>0) {
    ?>
    <p class="personalisation">
    <?php
      while ($PS = mysql_fetch_object($q_ps)) {
        $PERSONALISED  = mc_getTableData('personalisation','id',$PS->personalisationID);
        if ($PS->visitorData && $PS->visitorData!='no-option-selected') {
          echo '<span class="option">'.mc_persTextDisplay(mc_cleanDataEnt($PERSONALISED->persInstructions),true).($PERSONALISED->persAddCost>0 ? ' (+'.mc_currencyFormat(mc_formatPrice($PERSONALISED->persAddCost)).')' : '').':</span>';
          echo '<span class="data">'.mc_cleanDataEnt($PS->visitorData).'</span>';
        }
      }  
      // Pers per item..
      $pers_Price = ($VUTL->persPrice>0 ? mc_formatPrice($VUTL->persPrice) : '0.00');
    ?>
    </p>
    <?php  
    }
    ?>
    </td>
    <td class="sale2"><?php echo $VUTL->productQty; ?></td>
    <td class="sale3"><?php echo mc_currencyFormat(mc_formatPrice($VUTL->salePrice,true)); ?></td>
    <td class="sale4"><?php echo ($pers_Price>0 || $VUTL->attrPrice>0 ? mc_currencyFormat(mc_formatPrice($pers_Price+$VUTL->attrPrice,true)) : '- -'); ?></td>
    <td class="sale5"><?php echo mc_currencyFormat(mc_formatPrice($VUTL->productQty*($VUTL->salePrice+$pers_Price+$VUTL->attrPrice),true)); ?></td>
  </tr> 
  <?php
  $subTotal = $subTotal+mc_formatPrice($VUTL->productQty*$VUTL->salePrice);
  }
}
}
?>
</table>

</div>

<div id="subFooter">

 <div class="customerMessage">
   <h3><?php echo $msg_invoice10; ?>:</h3>
   <p class="message"><?php echo ($SALE->saleNotes ? nl2br(mc_cleanDataEnt($SALE->saleNotes)) : 'N/A'); ?></p>
 </div>
 
 <div class="totals">
   <p>
     <span class="total_head"><?php echo $msg_invoice17; ?><span class="value"><?php echo mc_currencyFormat(mc_formatPrice($subTotal,true)); ?></span></span>
     <?php
     if ($SALE->globalDiscount>0) {
     ?>
     <span class="total_head"><?php echo str_replace('{percentage}',$SALE->globalDiscount,$msg_invoice27); ?><span class="value_discount">- <?php echo mc_currencyFormat(mc_formatPrice($SALE->globalTotal,true)); ?></span></span>
     <?php
     } elseif ($SALE->manualDiscount>0) {
     ?>
     <span class="total_head"><?php echo $msg_invoice28; ?><span class="value_discount">- <?php echo mc_currencyFormat(mc_formatPrice($SALE->manualDiscount,true)); ?></span></span>
     <?php
     } else {
	 // Discount Coupon...
     if ($SALE->couponTotal>0 && $SALE->codeType=='discount') {
     $COUPON  = mc_getTableData('coupons','cDiscountCode',$SALE->couponCode);
     if (isset($COUPON->cCampaign)) {
     $CAMP  = mc_getTableData('campaigns','id',$COUPON->cCampaign);
     ?>
     <span class="total_head"><?php echo $msg_invoice19; ?><span class="value_discount">- <?php echo mc_currencyFormat($MCPROD->getDiscount(mc_formatPrice($subTotal),$CAMP->cDiscount)); ?></span></span>
     <?php
     }
     }
	 // Gift Certificate...
     if ($SALE->couponTotal>0 && $SALE->codeType=='gift') {
     $GIFT = mc_getTableData('giftcodes','code',$SALE->couponCode);
     if (isset($GIFT->id)) {
     ?>
     <span class="total_head"><?php echo $msg_invoice36; ?> <span style="font-weight:normal">(<?php echo $SALE->couponCode; ?>)</span><span class="value_discount">- <?php echo mc_currencyFormat($MCPROD->getDiscount(mc_formatPrice($subTotal),$SALE->couponTotal)); ?></span></span>
     <?php
     }
     }
     }
     if ($SALE->shipSetArea>0) { 
     // If tax isn`t applied to shipping, show tax before shipping..
     $A  = mc_getTableData('zone_areas','id',$SALE->shipSetArea,'','inZone');
     if (isset($A->inZone)) {
     $Z  = mc_getTableData('zones','id',$A->inZone,'','zShipping');
     }
     // Tax on shipping as well as total..
     if (isset($Z->zShipping) && $Z->zShipping=='yes') {
     if ($SALE->shipTotal>0) {
     ?>
     <span class="total_head"><?php echo $msg_invoice20; ?><span class="value"><?php echo ($SALE->shipTotal>0 ? mc_currencyFormat(mc_formatPrice($SALE->shipTotal,true)) : $msg_invoice35); ?></span></span>
     <?php
     }
     if ($SALE->taxPaid>0) {
     ?>
     <span class="total_head"><?php echo str_replace('{rate}',$SALE->taxRate.'%',$msg_invoice21); ?><span class="value"><?php echo mc_currencyFormat(mc_formatPrice($SALE->taxPaid,true)); ?></span></span>
     <?php
     }
     } else {
     // Tax on total, not shipping..
     if ($SALE->taxPaid>0) {
     ?>
     <span class="total_head"><?php echo str_replace('{rate}',$SALE->taxRate.'%',$msg_invoice21); ?><span class="value"><?php echo mc_currencyFormat(mc_formatPrice($SALE->taxPaid,true)); ?></span></span>
     <?php
     }
     if ($SALE->shipTotal>0) {
     ?>
     <span class="total_head"><?php echo $msg_invoice20; ?><span class="value"><?php echo mc_currencyFormat(mc_formatPrice($SALE->shipTotal,true)); ?></span></span>
     <?php
     }
     }
     } else {
     // If no areas are on display, but shipping does exist, show it..
     if ($SALE->shipTotal>0) {
     ?>
     <span class="total_head"><?php echo $msg_invoice20; ?><span class="value"><?php echo mc_currencyFormat(mc_formatPrice($SALE->shipTotal,true)); ?></span></span>
     <?php
     }
     }
     // Insurance if applicable..
     if ($SALE->insuranceTotal>0) {
     ?>
     <span class="total_head"><?php echo $msg_invoice33; ?><span class="value"><?php echo mc_currencyFormat(mc_formatPrice($SALE->insuranceTotal,true)); ?></span></span>
     <?php
     }
     ?>
     <span class="total_head"><?php echo $msg_invoice22; ?><span class="value_all"><?php echo mc_currencyFormat(mc_formatPrice($SALE->grandTotal,true)); ?></span></span>
   </p>
 </div>
 
 <br class="clear" />

</div>

<h4><?php echo mc_cleanDataEnt($SETTINGS->cName); ?></h4>

<div id="footer">

  <div class="footLeft">
   <p>
    <?php echo nl2br(mc_cleanDataEnt($SETTINGS->cAddress)); ?>
   </p>
  </div>
  
  <div class="footRight">
   <p>
     <span class="wrap">
      <span class="text"><?php echo $msg_invoice11; ?>:</span>
      <span class="text_value"><?php echo mc_cleanDataEnt($SETTINGS->cTel); ?></span>
      <br class="clear" />
     </span>
     <span class="wrap">
      <span class="text"><?php echo $msg_invoice14; ?>:</span>
      <span class="text_value"><?php echo mc_cleanDataEnt($SETTINGS->cFax); ?></span>
      <br class="clear" />
     </span>
     <span class="wrap">
      <span class="text"><?php echo $msg_invoice12; ?>:</span>
      <span class="text_value"><?php echo mc_cleanDataEnt($SETTINGS->email); ?></span>
      <br class="clear" />
     </span>
     <span class="wrap">
      <span class="text"><?php echo $msg_invoice13; ?>:</span>
      <span class="text_value"><?php echo mc_cleanDataEnt($SETTINGS->cWebsite); ?></span>
      <br class="clear" />
     </span>
   </p>
  </div>
  
  <br class="clear" /> 

</div>

<div id="other">
 <?php echo mc_cleanData($SETTINGS->cOther); ?>
</div>

<?php
if (INVOICE_SHOW_IP) {
?>
<p class="ip"><?php echo $msg_invoice29.$SALE->ipAddress; ?></p>
<?php
}
?>

</div>

<script type="text/javascript">
//<![CDATA[
jQuery(document).ready(function() {
  jQuery('.sale1').last().css('border-bottom','0');
  jQuery('.sale2').last().css('border-bottom','0');
  jQuery('.sale3').last().css('border-bottom','0');
  jQuery('.sale4').last().css('border-bottom','0');
  jQuery('.sale5').last().css('border-bottom','0');
});
//]]>
</script>

</body>

</html>
