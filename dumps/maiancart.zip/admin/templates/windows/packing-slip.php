<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); }
if (file_exists(PATH.'templates/header-custom.php')) {
  include_once(PATH.'templates/header-custom.php');
} else {
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php
}
$bill  = array();
$ship  = array();
// Addresses. Check for legacy..
if ($SALE->buyerAddress) {
  $billingAddress   = nl2br(mc_cleanDataEnt($SALE->buyerAddress));
  $shippingAddress  = nl2br(mc_cleanDataEnt($SALE->buyerAddress));
} else {
  // Build addresses from fields..lazy loop..:)
  for ($i=3; $i<8; $i++) {
    $f = 'bill_'.$i;
    $s = 'ship_'.$i;
    if ($SALE->$f) {
      $bill[] = mc_cleanDataEnt($SALE->$f);
    }
    if ($SALE->$s) {
      $ship[] = mc_cleanDataEnt($SALE->$s);
    }
  }
  $billingAddress   = implode('<br />',$bill);
  $shippingAddress  = implode('<br />',$ship);
}
?>
<meta http-equiv="content-type" content="application/xhtml+xml; charset=<?php echo $charset; ?>" />
<link rel="stylesheet" href="templates/css/packing-slip.css" type="text/css" />
<script type="text/javascript" src="templates/js/jquery.js"></script>
<title><?php echo $title; ?></title>
</head>

<body>

<div id="wrapper">

<div id="header">

  <div class="headLeft">
   <h1><?php echo mc_cleanDataEnt($SETTINGS->cName); ?></h1>
   <p class="ptag">
    <span class="wrap">
     <span class="heading"><?php echo $msg_invoice2; ?></span>
     <span class="heading_value"><?php echo mc_saleInvoiceNumber($SALE->invoiceNo); ?></span>
     <br class="clear" />
    </span>
    <span class="wrap">
     <span class="heading"><?php echo $msg_invoice3; ?></span>
     <span class="heading_value"><?php echo $SALE->pdate; ?></span>
     <br class="clear" />
    </span>
    <span class="wrap"<?php echo ($SALE->setShipRateID==0 ? ' style="border-bottom:0"' : ''); ?>>
     <span class="heading"><?php echo $msg_invoice4; ?></span>
     <span class="heading_value"><?php echo mc_paymentMethodName($SALE->paymentMethod); ?></span>
     <br class="clear" />
    </span>
    <?php
    if ($SALE->setShipRateID>0 && in_array($SALE->shipType,array('weight'))) {
    ?>
    <span class="wrap" style="border-bottom:0">
     <span class="heading"><?php echo $msg_invoice30; ?></span>
     <span class="heading_value"><?php echo mc_getShippingService(mc_getShippingServiceFromRate($SALE->setShipRateID)); ?></span>
     <br class="clear" />
    </span>
    <?php
    }
    ?>
   </p>
   <p class="ptag2">
    <span class="billAddress">
     <span class="head"><?php echo $msg_invoice5; ?>:</span>
     <?php echo mc_cleanDataEnt($SALE->bill_1); ?><br />
     <?php echo $billingAddress; ?><br />
     <?php echo mc_getShippingCountry($SALE->bill_9); ?><br /><br />
     <b>E</b>: <?php echo mc_cleanDataEnt($SALE->bill_2); ?><br />
     <b>T</b>: <?php echo mc_cleanDataEnt($SALE->bill_8); ?>
    </span>
    <span class="delAddress">
     <span class="head"><?php echo $msg_invoice34; ?>:</span>
     <?php echo mc_cleanDataEnt($SALE->bill_1); ?><br />
     <?php echo $shippingAddress; ?><br />
     <?php echo mc_getShippingCountry($SALE->shipSetCountry); ?><br /><br />
     <b>E</b>: <?php echo mc_cleanDataEnt($SALE->ship_2); ?><br />
     <b>T</b>: <?php echo mc_cleanDataEnt($SALE->ship_8); ?>
    </span>
    <br class="clear" />
   </p>
  </div>
  
  <div class="headRight">
   <p><img src="templates/images/packing-slip.gif" alt="<?php echo mc_cleanDataEnt($msg_invoice15); ?>" title="<?php echo mc_cleanDataEnt($msg_invoice15); ?>" /></p>
  </div>
  
  <br class="clear" />

</div>

<div id="content">

<table width="100%" cellspacing="0" cellpadding="0">
<tr>
  <td class="head1" colspan="2"><?php echo $msg_invoice6; ?></td>
  <td class="head2"><?php echo $msg_invoice7; ?></td>
</tr>
<?php
// Physical..
$q_phys = mysql_query("SELECT *,`".DB_PREFIX."products`.`id` AS `pid`,`".DB_PREFIX."purchases`.`id` AS `pcid` FROM `".DB_PREFIX."purchases`
          LEFT JOIN `".DB_PREFIX."products`
          ON `".DB_PREFIX."purchases`.`productID` = `".DB_PREFIX."products`.`id`
          WHERE `saleID`                        = '".mc_digitSan($_GET['sale'])."' 
          AND `productType`                     = 'physical' 
          ORDER BY `".DB_PREFIX."purchases`.`id`
          ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
if (mysql_num_rows($q_phys)>0) {
  while ($PHYS = mysql_fetch_object($q_phys)) {
  $details      = '';
  $code         = ($PHYS->pCode ? $PHYS->pCode : 'N/A');
  $weight       = ($PHYS->pWeight ? $PHYS->pWeight : 'N/A');
  $PHYS->pName  = ($PHYS->pName ? $PHYS->pName : $PHYS->deletedProductName);
  $isDel        = ($PHYS->deletedProductName ? '<b class="deletedItem">'.$msg_script53.'</b>' : '');
  ?>
  <tr>
    <td class="sale1"><span class="tickbox">&nbsp;</span></td>
    <td class="sale2">[<?php echo $code; ?>] <?php echo mc_cleanDataEnt($PHYS->pName); ?>
    <?php
    // Attributes..
    echo mc_saleAttributes(mc_digitSan($_GET['sale']),$PHYS->pcid,$PHYS->pid);
    $pers_Price = '0.00';
    // Personalised items..
    $q_ps = mysql_query("SELECT * FROM `".DB_PREFIX."purch_pers`
            WHERE `purchaseID`  = '{$PHYS->pcid}'
            ORDER BY `id`
            ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    if (mysql_num_rows($q_ps)>0) {
    ?>
    <p class="personalisation">
    <?php
      while ($PS = mysql_fetch_object($q_ps)) {
        $PERSONALISED  = mc_getTableData('personalisation','id',$PS->personalisationID);
        if ($PS->visitorData && $PS->visitorData!='no-option-selected') {
          echo '<span class="option">'.mc_persTextDisplay(mc_cleanDataEnt($PERSONALISED->persInstructions),true).($PERSONALISED->persAddCost>0 ? ' (+'.mc_currencyFormat(mc_formatPrice($PERSONALISED->persAddCost)).')' : '').':</span>';
          echo '<span class="data">'.mc_cleanDataEnt($PS->visitorData).'</span>';
        }
      }  
      // Pers per item..
      $pers_Price = ($PHYS->persPrice>0 ? mc_formatPrice($PHYS->persPrice) : '0.00');
    ?>
    </p>
    <?php  
    }
    ?>
    </td>
    <td class="sale3"><?php echo $PHYS->productQty; ?></td>
  </tr> 
  <?php
  }
}
// Download..
if (INCLUDE_DOWNLOADS_ON_PACKING_SLIP) {
$q_down = mysql_query("SELECT *,`".DB_PREFIX."products`.`id` AS `pid`,`".DB_PREFIX."purchases`.`id` AS `pcid` FROM `".DB_PREFIX."purchases`
          LEFT JOIN `".DB_PREFIX."products`
          ON `".DB_PREFIX."purchases`.`productID` = ".DB_PREFIX."products.id
          WHERE `saleID`                        = '".mc_digitSan($_GET['sale'])."' 
          AND `productType`                     = 'download'
          ORDER BY `".DB_PREFIX."purchases`.`id`
          ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
if (mysql_num_rows($q_down)>0) {
  while ($DOWN = mysql_fetch_object($q_down)) {
  $details      = '';
  $code         = ($DOWN->pCode ? $DOWN->pCode : 'N/A');
  $weight       = ($DOWN->pWeight ? $DOWN->pWeight : 'N/A');
  $DOWN->pName  = ($DOWN->pName ? $DOWN->pName : $DOWN->deletedProductName);
  $isDel2       = ($DOWN->deletedProductName ? '<b class="deletedItem">'.$msg_script53.'</b>' : '');
  ?>
  <tr>
    <td class="sale1">&nbsp;</td>
    <td class="sale2">[<?php echo $code; ?>] <?php echo mc_cleanDataEnt($DOWN->pName); ?> (<b><?php echo $msg_invoice16; ?></b>)
    <?php
    // Attributes..
    echo mc_saleAttributes(mc_digitSan($_GET['sale']),$DOWN->pcid,$DOWN->pid);
    $pers_Price = '0.00';
    // Personalised items..
    $q_ps = mysql_query("SELECT * FROM `".DB_PREFIX."purch_pers`
            WHERE `purchaseID` = '{$DOWN->pcid}'
            ORDER BY `id`
            ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    if (mysql_num_rows($q_ps)>0) {
    ?>
    <p class="personalisation">
    <?php
      while ($PS = mysql_fetch_object($q_ps)) {
        $PERSONALISED  = mc_getTableData('personalisation','id',$PS->personalisationID);
        if ($PS->visitorData && $PS->visitorData!='no-option-selected') {
          echo '<span class="option">'.mc_persTextDisplay(mc_cleanDataEnt($PERSONALISED->persInstructions),true).($PERSONALISED->persAddCost>0 ? ' (+'.mc_currencyFormat(mc_formatPrice($PERSONALISED->persAddCost)).')' : '').':</span>';
          echo '<span class="data">'.mc_cleanDataEnt($PS->visitorData).'</span>';
        }
      }  
      // Pers per item..
      $pers_Price = ($DOWN->persPrice>0 ? mc_formatPrice($DOWN->persPrice) : '0.00');
    ?>
    </p>
    <?php  
    }
    ?>
    </td>
    <td class="sale3"><?php echo $DOWN->productQty; ?></td>
  </tr> 
  <?php
  }
}
}

// Virtual..
if (INCLUDE_GIFT_ON_PACKING_SLIP) {
$q_virtual = mysql_query("SELECT *,`".DB_PREFIX."products`.`id` AS `pid`,`".DB_PREFIX."purchases`.`id` AS `pcid` FROM `".DB_PREFIX."purchases`
             LEFT JOIN `".DB_PREFIX."products`
             ON `".DB_PREFIX."purchases`.`productID` = ".DB_PREFIX."products.id
             WHERE `saleID`                        = '".mc_digitSan($_GET['sale'])."' 
             AND `productType`                     = 'virtual'
             ORDER BY `".DB_PREFIX."purchases`.`id`
             ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
if (mysql_num_rows($q_virtual)>0) {
  while ($VUTL = mysql_fetch_object($q_virtual)) {
  $GIFT         = mc_getTableData('giftcerts','id',$VUTL->giftID);
  $details      = '';
  $code         = '';
  $weight       = 'N/A';
  $VUTL->pName  = (isset($GIFT->name) ? $GIFT->name : $VUTL->deletedProductName);
  $isDel2       = ($VUTL->deletedProductName ? '<b class="deletedItem">'.$msg_script53.'</b>' : '');
  ?>
  <tr>
    <td class="sale1">&nbsp;</td>
    <td class="sale2"><?php echo mc_cleanDataEnt($VUTL->pName); ?>
    <?php
    // Attributes..
	echo mc_saleGiftCerts(mc_digitSan($_GET['sale']),$VUTL->pcid);
    $pers_Price = '0.00';
    // Personalised items..
    $q_ps = mysql_query("SELECT * FROM `".DB_PREFIX."purch_pers`
            WHERE `purchaseID` = '{$VUTL->pcid}'
            ORDER BY `id`
            ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    if (mysql_num_rows($q_ps)>0) {
    ?>
    <p class="personalisation">
    <?php
      while ($PS = mysql_fetch_object($q_ps)) {
        $PERSONALISED  = mc_getTableData('personalisation','id',$PS->personalisationID);
        if ($PS->visitorData && $PS->visitorData!='no-option-selected') {
          echo '<span class="option">'.mc_persTextDisplay(mc_cleanDataEnt($PERSONALISED->persInstructions),true).($PERSONALISED->persAddCost>0 ? ' (+'.mc_currencyFormat(mc_formatPrice($PERSONALISED->persAddCost)).')' : '').':</span>';
          echo '<span class="data">'.mc_cleanDataEnt($PS->visitorData).'</span>';
        }
      }  
      // Pers per item..
      $pers_Price = ($VUTL->persPrice>0 ? mc_formatPrice($VUTL->persPrice) : '0.00');
    ?>
    </p>
    <?php  
    }
    ?>
    </td>
    <td class="sale3"><?php echo $VUTL->productQty; ?></td>
  </tr> 
  <?php
  }
}
}
?>
</table>

</div>

<div id="checkedby">
  <p><?php echo $msg_invoice23; ?>:_________________________ <?php echo $msg_invoice25; ?>:_________________________</p>
  <p><?php echo $msg_invoice24; ?>:_________________________<?php echo $msg_invoice25; ?>:_________________________</p>
</div>

<h4><?php echo mc_cleanDataEnt($SETTINGS->cName); ?></h4>

<div id="footer">

  <div class="footLeft">
   <p>
    <?php echo nl2br(mc_cleanDataEnt($SETTINGS->cAddress)); ?>
   </p>
  </div>
  
  <div class="footRight">
   <p>
     <span class="wrap">
      <span class="text"><?php echo $msg_invoice11; ?>:</span>
      <span class="text_value"><?php echo mc_cleanDataEnt($SETTINGS->cTel); ?></span>
      <br class="clear" />
     </span>
     <span class="wrap">
      <span class="text"><?php echo $msg_invoice14; ?>:</span>
      <span class="text_value"><?php echo mc_cleanDataEnt($SETTINGS->cFax); ?></span>
      <br class="clear" />
     </span>
     <span class="wrap">
      <span class="text"><?php echo $msg_invoice12; ?>:</span>
      <span class="text_value"><?php echo mc_cleanDataEnt($SETTINGS->email); ?></span>
      <br class="clear" />
     </span>
     <span class="wrap">
      <span class="text"><?php echo $msg_invoice13; ?>:</span>
      <span class="text_value"><?php echo mc_cleanDataEnt($SETTINGS->cWebsite); ?></span>
      <br class="clear" />
     </span>
   </p>
  </div>
  
  <br class="clear" /> 

</div>

<div id="other">
 <?php echo mc_cleanData($SETTINGS->cOther); ?>
</div>

<?php
if (PACKING_SLIP_SHOW_IP) {
?>
<p class="ip"><?php echo $msg_invoice29.$SALE->ipAddress; ?></p>
<?php
}
?>

</div>

<script type="text/javascript">
//<![CDATA[
jQuery(document).ready(function() {
  jQuery('.sale1').last().css('border-bottom','0');
  jQuery('.sale2').last().css('border-bottom','0');
  jQuery('.sale3').last().css('border-bottom','0');
});
//]]>
</script>
</body>

</html>
