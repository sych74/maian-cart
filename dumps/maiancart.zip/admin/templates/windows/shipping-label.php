<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); }
if (file_exists(PATH.'templates/header-custom.php')) {
  include_once(PATH.'templates/header-custom.php');
} else {
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php
}
$SALE = mc_getTableData('sales','id',mc_digitSan($_GET['shipLabel']));  
?>
<meta http-equiv="content-type" content="application/xhtml+xml; charset=<?php echo $charset; ?>" />
<title><?php echo $pageTitle; ?></title>
<link rel="stylesheet" href="templates/css/stylesheet.css" type="text/css" />
<style type="text/css">
#shippingLabel {
  color:#000;
}
#shippingLabel .returns {
  font-size:12px;
  font-style:italic;
  margin-bottom:20px;
}
#shippingLabel .address {
}
#shippingLabel .address span {
  display:block;
  margin-bottom:2px;
  font-size:32px;
}
</style>
</head>

<body class="body" onload="window.print()">

<div id="shippingLabel">
  
  <?php
  if ($SETTINGS->cReturns) {
  ?>
  <p class="returns"><?php echo nl2br(mc_cleanData($SETTINGS->cReturns)); ?></p>
  <?php
  }
  ?>
  
  <p class="address">
  <?php
  foreach (array('ship_1','ship_3','ship_4','ship_5','ship_6','ship_7') AS $f) {
    if ($f) {
    if ($f=='ship_7') {
    ?>
    <span><?php echo strtoupper(mc_cleanData($SALE->{$f})); ?></span>
    <?php
    } else {
    ?>
    <span><?php echo ucwords(strtolower(mc_cleanData($SALE->{$f}))); ?></span>
    <?php
    }
    }
  }
  ?>
  <span><?php echo mc_getShippingCountry($SALE->shipSetCountry); ?></span>
  </p>

</div>

</body>
</html>
