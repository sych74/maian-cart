<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } 
$SALE  = mc_getTableData('sales','id',mc_digitSan($_GET['sale']));
if (file_exists(PATH.'templates/header-custom.php')) {
  include_once(PATH.'templates/header-custom.php');
} else {
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php
}
?>
<meta http-equiv="content-type" content="application/xhtml+xml; charset=<?php echo $charset; ?>" />
<title><?php echo $pageTitle; ?></title>
<link rel="stylesheet" href="templates/css/stylesheet.css" type="text/css" />
<script type="text/javascript" src="templates/js/jquery.js"></script>
<script type="text/javascript" src="templates/js/global.js"></script>
<script type="text/javascript" src="templates/js/admin.js"></script>
<script type="text/javascript">
//<![CDATA[
function changeButtonCount(form,type) {
  var count = 0;
  if (type=='all') {
    selectAll();
  }
  if (type=='single' && document.getElementById('log').checked==true) {
    document.getElementById('log').checked=false;
  }
  for (i = 0; i < form.elements.length; i++){
    var current = form.elements[i];
    if(current.name!='log' && current.type == 'checkbox' && current.checked){
      count++;
    }
  }
  if (count>0) {
    jQuery('#counter').val(count);
    jQuery('#button').val('<?php echo str_replace(array("'","&#039;"),array("\'","\'"),mc_cleanDataEnt($msg_viewsale9)); ?> ('+count+')');
  } else {
    jQuery('#counter').val('0');
    jQuery('#button').val('<?php echo str_replace(array("'","&#039;"),array("\'","\'"),mc_cleanDataEnt($msg_viewsale9)); ?> (0)');
  }
}
<?php
if (isset($OK)) {
?>
setTimeout("parent.document.getElementById('GB_window').style.display='none'",10000);
setTimeout("parent.window.location='index.php?p=sales-view&sale=<?php echo mc_digitSan($_GET['sale']); ?>'",1000);
<?php
}
?>

function confirmMessage_Add(txt) {
  if (jQuery('#counter').val()=='0' || jQuery('#counter').val()=='') {
    alert('<?php echo str_replace("'","\'",mc_cleanDataEnt($msg_javascript325)); ?>');
    return false;
  }
  var confirmSub = confirm(txt);
  if (confirmSub) { 
    return true;
  } else {
    return false;
  }
}
//]]>
</script>
</head>

<body class="body">

<form method="post" id="form" action="?p=add&amp;sale=<?php echo mc_digitSan($_GET['sale']); ?>" onsubmit="return confirmMessage_Add('<?php echo mc_cleanDataEnt($msg_javascript45); ?>')">
<div id="windowWrapper">
<?php
if (isset($OK)) {
$c  = (!empty($_POST['product']) ? count($_POST['product']) : '0');
?>
<p class="reloading"><?php echo str_replace('{count}',$c,$msg_viewsale12); ?></p>
<p class="reloading_img"><img src="templates/images/reloading.gif" alt="" title="" /></p>
<p class="reloading"><?php echo $msg_viewsale46; ?></p>
<?php
} else {
?>
<div class="formFieldWrapper">
  <div class="formLeft" style="width:98%;text-align:right">
    <b><?php echo $msg_viewsale66; ?></b>: <select onchange="if(this.value!= 0){location=this.options[this.selectedIndex].value}">
    <?php
    $cats   = array();
    $q_cats = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
              WHERE catLevel = '1'
              AND childOf    = '0'
              AND enCat      = 'yes'
              ORDER BY catname
              ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($CATS = mysql_fetch_object($q_cats)) {
    $cats[] = $CATS->id;
    ?>
    <option value="?p=add&amp;sale=<?php echo mc_digitSan($_GET['sale']); ?>&amp;type=<?php echo $_GET['type']; ?>&amp;catid=<?php echo $CATS->id; ?>"<?php echo (count($cats)==1 || isset($_GET['catid']) && $_GET['catid']==$CATS->id ? ' selected="selected"' : ''); ?>><?php echo mc_cleanDataEnt($CATS->catname); ?></option>
    <?php
    $q_children = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
                  WHERE catLevel = '2'
                  AND enCat      = 'yes'
                  AND childOf    = '".$CATS->id."'
                  ORDER BY catname") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($CHILDREN = mysql_fetch_object($q_children)) {
    ?>
    <option value="?p=add&amp;sale=<?php echo mc_digitSan($_GET['sale']); ?>&amp;type=<?php echo $_GET['type']; ?>&amp;catid=<?php echo $CHILDREN->id; ?>"<?php echo (isset($_GET['catid']) && $_GET['catid']==$CHILDREN->id ? ' selected="selected"' : ''); ?>>&nbsp;&nbsp;<?php echo mc_cleanDataEnt($CHILDREN->catname); ?></option>
    <?php
    $q_infants = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
                  WHERE catLevel = '3'
                  AND childOf    = '{$CHILDREN->id}'
                  AND enCat      = 'yes'
                  ORDER BY catname
                  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($INFANTS = mysql_fetch_object($q_infants)) {
    ?>
    <option value="?p=add&amp;sale=<?php echo mc_digitSan($_GET['sale']); ?>&amp;type=<?php echo $_GET['type']; ?>&amp;catid=<?php echo $INFANTS->id; ?>"<?php echo (isset($_GET['catid']) && $_GET['catid']==$INFANTS->id ? ' selected="selected"' : ''); ?>>&nbsp;&nbsp;&nbsp;&nbsp;<?php echo mc_cleanDataEnt($INFANTS->catname); ?></option>
    <?php
    }
    }
    }
    ?>
    </select>
  </div>
  <br class="clear" />
</div>  

<div class="formFieldWrapper" style="line-height:19px">
  <?php
  $q_products = mysql_query("SELECT *,".DB_PREFIX."products.id AS pid 
                FROM ".DB_PREFIX."products
                LEFT JOIN ".DB_PREFIX."prod_category
                ON ".DB_PREFIX."products.id   = ".DB_PREFIX."prod_category.product
                WHERE category                = '".(isset($_GET['catid']) ? mc_digitSan($_GET['catid']) : (isset($cats[0]) ? $cats[0] : '0'))."'
                AND pEnable                   = 'yes'
                ".(isset($_GET['type']) && $_GET['type']=='download' ? 'AND pDownload = \'yes\'' : 'AND pDownload = \'no\' AND pStock > 0')."
                GROUP BY ".DB_PREFIX."products.id
                ORDER BY pName
                ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  if (mysql_num_rows($q_products)>0) {
  ?>
  <input type="checkbox" name="log" value="all" id="log" onclick="changeButtonCount(this.form,'all')" /> <b><?php echo $msg_prodrelated7; ?></b><br />
  <?php
  while ($PR = mysql_fetch_object($q_products)) {
  ?>
  <input type="checkbox" name="product[]" value="<?php echo $PR->pid; ?>" onclick="changeButtonCount(this.form,'single')" /> <?php echo mc_cleanDataEnt($PR->pName).' - '.mc_currencyFormat(mc_formatPrice($PR->pOffer>0 ? $PR->pOffer : $PR->pPrice)); ?><br />
  <?php
  }
  } else {
  echo ($_GET['type']=='download' ? $msg_productprices18 : $msg_productprices17);
  }
  ?>
</div>
<?php
if (mysql_num_rows($q_products)>0) {
?>
<p style="text-align:center;padding-top:20px">
 <input type="hidden" name="counter" id="counter" value="0" />
 <input type="hidden" name="process" value="yes" />
 <input type="hidden" name="pCat" value="<?php echo (isset($_GET['catid']) ? mc_digitSan($_GET['catid']) : (isset($cats[0]) ? $cats[0] : '0')); ?>" />
 <input type="hidden" name="buyCode" value="<?php echo $SALE->buyCode; ?>" />
 <input type="hidden" name="purchaseDate" value="<?php echo $SALE->purchaseDate; ?>" />
 <input type="hidden" name="purchaseTime" value="<?php echo $SALE->purchaseTime; ?>" />
 <input type="hidden" name="weight" value="<?php echo $SALE->cartWeight; ?>" />
 <input type="hidden" name="status" value="<?php echo $SALE->paymentStatus; ?>" />
 <input type="hidden" name="type" value="<?php echo (in_array($_GET['type'],array('physical','download')) ? $_GET['type'] : 'physical'); ?>" />
 <input class="formbutton" type="submit" id="button" value="<?php echo mc_cleanDataEnt($msg_viewsale9); ?> (0)" title="<?php echo mc_cleanDataEnt($msg_viewsale9); ?>" />
</p>
<?php
}
}
?>
</div>
</form>

</body>
</html>
