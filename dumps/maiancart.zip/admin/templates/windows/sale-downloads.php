<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } 
$SALE = mc_getTableData('sales','id',mc_digitSan($_GET['sale']));
if (file_exists(PATH.'templates/header-custom.php')) {
  include_once(PATH.'templates/header-custom.php');
} else {
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php
}
?>
<meta http-equiv="content-type" content="application/xhtml+xml; charset=<?php echo $charset; ?>" />
<title><?php echo $pageTitle; ?></title>
<link rel="stylesheet" href="templates/css/stylesheet.css" type="text/css" />
<script type="text/javascript" src="templates/js/jquery.js"></script>
<script type="text/javascript" src="templates/js/global.js"></script>
<script type="text/javascript" src="templates/js/admin.js"></script>
<script type="text/javascript">
//<![CDATA[
function changeButtonCount(form,type) {
  var count = 0;
  if (type=='all') {
    selectAll();
  }
  if (type=='single' && document.getElementById('log').checked==true) {
    document.getElementById('log').checked=false;
  }
  for (i = 0; i < form.elements.length; i++){
    var current = form.elements[i];
    if(current.name!='log' && current.type == 'checkbox' && current.checked){
      count++;
    }
  }
  if (count>0) {
    jQuery('#button').val('<?php echo str_replace(array("'","&#039;"),array("\'","\'"),mc_cleanDataEnt($msg_viewsale5)); ?> ('+count+')');
  } else {
    jQuery('#button').val('<?php echo str_replace(array("'","&#039;"),array("\'","\'"),mc_cleanDataEnt($msg_viewsale5)); ?> (0)');
  }
}
function checkform(form) {
  <?php
  if ($SALE->bill_2=='') {
  ?>
  alert('<?php echo mc_cleanDataEnt($msg_javascript427); ?>');
  return false;
  <?php
  }
  ?>
  var message = '';
  var count   = 0;
  for (i = 0; i < form.elements.length; i++){
    var current = form.elements[i];
    if(current.type == 'checkbox' && current.checked){
      count++;
    }
  }
  if (count==0) {
    message +='- <?php echo mc_cleanDataEnt($msg_javascript145); ?>';
  }
  if (message) {
    alert(message);
    return false;
  } else {
    return confirmMessage('<?php echo mc_cleanDataEnt($msg_javascript142); ?>');
  }
}
//]]>
</script>
</head>

<body class="body">

<form method="post" id="form" action="?p=downloads&amp;sale=<?php echo mc_digitSan($_GET['sale']); ?>" onsubmit="return checkform(this)">
<div id="windowWrapper">
<?php
if (isset($OK)) {
  echo actionCompleted(str_replace('{count}',count($_POST['id']),$msg_viewsale36));
}
if (isset($OK2)) {
  echo actionCompleted($msg_viewsale83);
}
if (isset($OK3)) {
  echo actionCompleted($msg_viewsale84);
}
?>
<div class="fieldHeadWrapper">
  <p>
  <?php
  if (!isset($_GET['ch'])) {
  ?>
  <span style="float:right"><input type="checkbox" name="log" id="log" onclick="changeButtonCount(this.form,'all')" /></span>
  <?php
  }
  ?>
  <?php echo $msg_viewsale3; ?>:</p>
</div>
<?php
$q_down = mysql_query("SELECT *,`".DB_PREFIX."products`.`id` AS `pid`,`".DB_PREFIX."purchases`.`id` AS `pur_id` FROM `".DB_PREFIX."purchases`
            LEFT JOIN `".DB_PREFIX."products`
            ON `".DB_PREFIX."purchases`.`productID` = `".DB_PREFIX."products`.`id`
            WHERE `saleID`                        = '".mc_digitSan($_GET['sale'])."' 
            AND `productType`                     = 'download' 
            ".(isset($_GET['ch']) && is_numeric($_GET['ch']) ? 'AND `'.DB_PREFIX.'purchases`.`id` = \''.$_GET['ch'].'\'' : '')."
            ORDER BY `".DB_PREFIX."purchases`.`id`
            ".(isset($_GET['ch']) && is_numeric($_GET['ch']) ? 'LIMIT 1' : '')."
            ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
if (mysql_num_rows($q_down)>0) {
  while ($DOWN = mysql_fetch_object($q_down)) {
  $details      = '';
  $code         = ($DOWN->pCode ? $DOWN->pCode : 'N/A');
  $weight       = ($DOWN->pWeight ? $DOWN->pWeight : 'N/A');
  $DOWN->pName  = ($DOWN->pName ? $DOWN->pName : $DOWN->deletedProductName);
  $isDel        = ($DOWN->deletedProductName ? '<b class="deletedItem">'.$msg_script53.'</b>' : '');
  $img          = storeProductImg($DOWN->pid,$DOWN,false);
  ?>
  <div class="downloadableProduct">
    <div class="left"> 
      <p><?php echo $img; ?></p>
    </div>
    <div class="product">
      <p><?php echo mc_cleanDataEnt($DOWN->pName).($details ? ' <span class="highlight">('.$details.')</span>' : '').$isDel; ?> (<?php echo mc_currencyFormat(mc_formatPrice($DOWN->productQty*$DOWN->salePrice,true)); ?>)
      <span class="code"><?php echo str_replace(array('{code}','{qty}'),array($code,$DOWN->productQty),$msg_viewsale21); ?></span>
      <span class="click_history"><a href="?p=downloads&amp;sale=<?php echo mc_digitSan($_GET['sale']); ?>&amp;ch=<?php echo $DOWN->pur_id; ?>" title="<?php echo mc_cleanDataEnt($msg_viewsale69); ?>"><?php echo $msg_viewsale69; ?></a></span>
      </p>
    </div>
    <div class="right">  
      <p>
      <?php
      if ($isDel=='' && !isset($_GET['ch'])) {
      ?>
      <input type="checkbox" name="id[]" value="<?php echo $DOWN->pur_id; ?>" onclick="changeButtonCount(this.form,'single')" />
      <?php
      } else {
        echo '&nbsp;';
      }
      ?>
      </p>
    </div>
    <br class="clear" />  
  </div>
  <?php
  }
  if (!isset($_GET['ch'])) {
  $a      = array_merge(range('a','z'),range(1,9));
  shuffle($a);
  $append = $a[4].$a[23];
  ?>
  <p style="margin:10px 0 10px 0;text-align:right;padding-right:5px">
    <span class="downloadUrl">
     <a href="../?vOrder=<?php echo mc_digitSan($_GET['sale']).'-'.$SALE->buyCode.$append; ?>" title="<?php echo mc_cleanDataEnt($msg_viewsale80); ?>" onclick="window.open(this);return false"><?php echo $msg_viewsale80; ?></a>
     <a onclick="return confirmMessage('<?php echo mc_cleanDataEnt($msg_javascript45); ?>')" class="<?php echo ($SALE->downloadLock=='yes' ? 'unlock' : 'lock'); ?>" href="?p=downloads&amp;sale=<?php echo mc_digitSan($_GET['sale']); ?>&amp;action=<?php echo ($SALE->downloadLock=='yes' ? 'unlock' : 'lock'); ?>&amp;status=<?php echo $SALE->paymentStatus; ?>" title="<?php echo mc_cleanDataEnt(($SALE->downloadLock=='yes' ? $msg_viewsale82 : $msg_viewsale81)); ?>"><?php echo ($SALE->downloadLock=='yes' ? $msg_viewsale82 : $msg_viewsale81); ?></a>
     <?php
	 if ($SETTINGS->downloadRestrictIP=='yes') {
	 ?>
	 <a onclick="jQuery('#ipRestrictionBox').slideDown();return false" class="ips" href="#" title="<?php echo mc_cleanDataEnt($msg_viewsale122); ?>"><?php echo $msg_viewsale122; ?></a>
	 <?php
	 }
	 ?>
    </span>
    <input type="hidden" name="process" value="yes" />
    <input type="hidden" name="saleID" value="<?php echo mc_digitSan($_GET['sale']); ?>" />
    <input class="formbutton" id="button" type="submit" value="<?php echo mc_cleanDataEnt($msg_viewsale5); ?> (0)" title="<?php echo mc_cleanDataEnt($msg_viewsale5); ?>" />
  </p>
  <div id="ipRestrictionBox" style="margin-bottom:10px;display:none">
   <p><textarea name="ips" id="ips" rows="3" cols="20" style="height:75px"><?php echo mc_cleanDataEnt($SALE->ipAccess); ?></textarea>
   <span style="display:block;margin-top:5px">
    <?php echo str_replace('{sale}',mc_digitSan($_GET['sale']),$msg_viewsale123); ?>
   </span>
   </p>
  </div>
  <?php
  }
  ?>
  
  <div class="fieldHeadWrapper">
   <p><span style="float:right"><a href="javascript:window.print()"><img src="templates/images/print.png" alt="<?php echo mc_cleanDataEnt($msg_script23); ?>" title="<?php echo mc_cleanDataEnt($msg_script23); ?>" /></a></span><?php echo (isset($_GET['ch']) ? $msg_viewsale69 : $msg_viewsale17); ?>:</p>
  </div>
  <div id="restoreHistory">
  <?php
  if (isset($_GET['ch']) && is_numeric($_GET['ch'])) {
    $q_click = mysql_query("SELECT *,DATE_FORMAT(`clickDate`,'".$SETTINGS->mysqlDateFormat."') AS `cDate` FROM `".DB_PREFIX."click_history`
                    WHERE `purchaseID` = '".mc_digitSan($_GET['ch'])."'
                    ORDER BY `clickDate` DESC,`clickTime` DESC
                    ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    if (mysql_num_rows($q_click)>0) {
      while ($C = mysql_fetch_object($q_click)) {
      ?>
      <div class="clicked">
        <span><?php echo str_replace(array('{date}','{time}'),array($C->cDate,$C->clickTime),$msg_viewsale72).($C->clickIP ? ' ('.$C->clickIP.')' : ''); ?></span>
      </div>
      <?php
      }
    } else {
      ?>
      <span class="noData" style="margin-bottom:5px"><?php echo $msg_viewsale71; ?></span>
      <?php
    }
    ?>
    <p style="margin:10px 0 10px 0;text-align:right;padding-right:5px">
      <input class="formbutton2" id="button" type="button" onclick="window.location='?p=downloads&amp;sale=<?php echo mc_digitSan($_GET['sale']); ?>'" value="<?php echo mc_cleanDataEnt($msg_viewsale70); ?>" title="<?php echo mc_cleanDataEnt($msg_viewsale70); ?>" />
    </p>
  <?php
  } else {
    $q_activation = mysql_query("SELECT `restoreDate` FROM `".DB_PREFIX."activation_history`
                    WHERE `saleID` = '".mc_digitSan($_GET['sale'])."'
                    GROUP BY `saleID`,`restoreDate`
                    ORDER BY `id` DESC
                    ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    if (mysql_num_rows($q_activation)>0) {
      while ($A = mysql_fetch_object($q_activation)) {
        $q_act = mysql_query("SELECT *,DATE_FORMAT(`restoreDate`,'".$SETTINGS->mysqlDateFormat."') AS `rdate` FROM `".DB_PREFIX."activation_history`
                 WHERE `saleID`     = '".mc_digitSan($_GET['sale'])."'
                 AND `restoreDate`  = '{$A->restoreDate}'
                 ORDER BY `id` DESC
                 ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
        while ($ACT = mysql_fetch_object($q_act)) {
          if (isset($ACT->products)) {
          $P = array_map('trim',explode('|',$ACT->products));
          ?>
          <div class="restored">
          <p>
          <?php
          foreach ($P AS $id) {
            $PRD  = mc_getTableData('products','id',substr($id,1));
            echo '<span>'.(isset($PRD->pName) ? mc_cleanDataEnt($PRD->pName) : '<b class="deletedItem">'.$msg_script53.'</b>').'</span>';
          }
          ?>
          <span class="action"><?php echo str_replace(array('{user}','{time}','{date}'),array($ACT->adminUser,$ACT->restoreTime,$ACT->rdate),$msg_viewsale67); ?></span>
          </p>
          </div>
          <?php
          }
        }
      }
    } else {
    ?>
    <span class="noData" style="margin-bottom:5px"><?php echo $msg_viewsale18; ?></span>
    <?php
  }
}
?>
</div>
<?php
} else {
?>
<p class="noData" style="margin-bottom:5px"><?php echo $msg_viewsale15; ?></p>
<?php
}
?>
</div>
</form>

</body>
</html>
