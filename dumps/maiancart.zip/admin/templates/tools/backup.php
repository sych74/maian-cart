<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } ?>
<div id="content">

<?php
if (isset($OK)) {
  echo actionCompleted($msg_backup15);
}

echo $msg_backup;

$totalBackup = 0;
?>
<br /><br />
<div class="fieldHeadWrapper">
  <p><?php echo mc_cleanDataEnt($msg_backup2); ?>:</p>
</div>

<div class="mysqlSchema">

<div class="infoRow">
  <span style="width:235px"><?php echo $msg_backup3; ?></span>
  <span style="width:75px"><?php echo $msg_backup4; ?></span>
  <span style="width:85px"><?php echo $msg_backup5; ?></span>
  <span style="width:180px"><?php echo $msg_backup6; ?></span>
  <span style="width:180px"><?php echo $msg_backup7; ?></span>
  <span style="width:85px"><?php echo $msg_backup8; ?></span>
  <br class="clear" />
</div>

<div class="schema">
<?php
$query = mysql_query("SHOW TABLE STATUS FROM ".DB_NAME);
while ($DB = mysql_fetch_object($query)) {
  $SCHEMA = (array)$DB;
  $size   = ($SCHEMA['Rows']>0 ? $SCHEMA['Data_length']+$SCHEMA['Index_length'] : '0');
  $ctTS   = strtotime($SCHEMA['Create_time']);
  $utTS   = strtotime($SCHEMA['Update_time']);
  ?>
  <div class="infoRowSchema">
   <span style="width:235px"><?php echo $SCHEMA['Name']; ?></span>
   <span style="width:75px"><?php echo $SCHEMA['Rows']; ?></span>
   <span style="width:85px"><?php echo ($SCHEMA['Rows']>0 ? mc_fileSizeConversion($size) : '0'); ?></span>
   <span style="width:180px"><?php echo date(mc_backupDateFormat().' H:iA',$ctTS); ?></span>
   <span style="width:180px"><?php echo date(mc_backupDateFormat().' H:iA',$utTS); ?></span>
   <span style="width:85px"><?php echo $SCHEMA['Engine']; ?></span>
   <br class="clear" />
  </div>
<?php
$totalBackup = ($totalBackup+$size);
}
$tabIndex = 0;
?>
</div>

</div>

<div class="fieldHeadWrapper">
  <p><span class="float"><?php echo $msg_backup10; ?>: <b><?php echo mc_fileSizeConversion($totalBackup); ?></b></span><?php echo mc_cleanDataEnt($msg_backup9); ?>:</p>
</div>

<form method="post" action="?p=backup" onsubmit="return confirmMessage('<?php echo mc_cleanDataEnt($msg_javascript397); ?>')">
<div class="formFieldWrapper">
  <div class="formLeft" style="width:30%">
    <label><?php echo $msg_backup11; ?>: <?php echo mc_displayHelpTip($msg_javascript394,'RIGHT'); ?></label>
    <?php echo $msg_script5; ?> <input type="radio" tabindex="<?php echo ++$tabIndex; ?>" name="download" value="yes" checked="checked" /> <?php echo $msg_script6; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="download" value="no" />
    <br class="clear" />
  </div>
  <div class="formLeft" style="width:30%">
    <label><?php echo $msg_backup13; ?>: <?php echo mc_displayHelpTip($msg_javascript395); ?></label>
    <?php echo $msg_script5; ?> <input type="radio" tabindex="<?php echo ++$tabIndex; ?>" name="compress" value="yes" checked="checked"/> <?php echo $msg_script6; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="compress" value="no" />
    <br class="clear" />
  </div>
  <div class="formRight" style="width:39%">  
    <label><?php echo $msg_backup12; ?>: <?php echo mc_displayHelpTip($msg_javascript396,'LEFT'); ?></label>
    <input type="text" tabindex="<?php echo ++$tabIndex; ?>" name="emails" class="box" value="" />
    <br class="clear" />
  </div>
  <br class="clear" />
</div>

<p style="text-align:center;padding:10px 0 20px 0">
 <input type="hidden" name="process" value="yes" />
 <input class="formbutton" type="submit" value="<?php echo mc_cleanDataEnt($msg_backup14); ?>" title="<?php echo mc_cleanDataEnt($msg_backup14); ?>" />
</p>
</form>

</div>
