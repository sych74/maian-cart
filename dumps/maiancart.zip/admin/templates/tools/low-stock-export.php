<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } ?>
<div id="content">

<?php
echo $msg_stockexport; 
?>
<br /><br />

<div class="fieldHeadWrapper">
  <p><?php echo $msg_stockexport4; ?>:</p>
</div>

<?php
if (isset($return) && $return=='none') {
?>
<p class="noData" style="margin-bottom:5px"><?php echo $msg_stockexport3; ?></p>
<?php
}
?>

<form method="post" id="form" action="?p=low-stock-export">
<div class="formFieldWrapper">
  <div class="formLeft" style="width:43%">
    <label><?php echo $msg_stockexport2; ?>: <?php echo mc_displayHelpTip($msg_javascript320,'RIGHT'); ?></label>
    <div class="categoryBoxes">
    <input type="checkbox" tabindex="1" name="log" value="all" onclick="selectAll()" /> <b><?php echo $msg_productadd35; ?></b><br />
    <?php
    $q_cats = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
              WHERE catLevel = '1'
              AND childOf    = '0'
              AND enCat      = 'yes'
              ORDER BY catname") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($CATS = mysql_fetch_object($q_cats)) {
    ?>
    <p id="cat_<?php echo $CATS->id; ?>"><input onclick="if(this.checked){selectChildren('cat_<?php echo $CATS->id; ?>','on')}else{selectChildren('cat_<?php echo $CATS->id; ?>','off')}" tabindex="1" type="checkbox" name="range[]" value="<?php echo $CATS->id; ?>"<?php echo (isset($_POST['range']) && in_array($CATS->id,$_POST['range']) ? ' checked="checked"' : ''); ?> /> <?php echo mc_cleanDataEnt($CATS->catname); ?><br />
    <?php
    $q_children = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
                  WHERE catLevel = '2'
                  AND enCat      = 'yes'
                  AND childOf    = '".$CATS->id."'
                  ORDER BY catname") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($CHILDREN = mysql_fetch_object($q_children)) {
    ?>
    <span id="child_<?php echo $CHILDREN->id; ?>">
    &nbsp;&nbsp;<input onclick="if(this.checked){selectChildren('child_<?php echo $CHILDREN->id; ?>','on')}else{selectChildren('child_<?php echo $CHILDREN->id; ?>','off')}" tabindex="1" type="checkbox" name="range[]" value="<?php echo $CHILDREN->id; ?>"<?php echo (isset($_POST['range']) && in_array($CHILDREN->id,$_POST['range']) ? ' checked="checked"' : ''); ?> /> <?php echo mc_cleanDataEnt($CHILDREN->catname); ?><br />
    <?php
    $q_infants = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
                  WHERE catLevel = '3'
                  AND childOf    = '{$CHILDREN->id}'
                  AND enCat      = 'yes'
                  ORDER BY catname
                  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($INFANTS = mysql_fetch_object($q_infants)) {
    ?>
    &nbsp;&nbsp;&nbsp;&nbsp;<input tabindex="1" type="checkbox" name="range[]" value="<?php echo $INFANTS->id; ?>"<?php echo (isset($_POST['range']) && in_array($INFANTS->id,$_POST['range']) ? ' checked="checked"' : ''); ?> /> <?php echo mc_cleanDataEnt($INFANTS->catname); ?><br />
    <?php
    }
    ?>
    </span>
    <?php
    }
    ?>
    </p>
    <?php
    }
    ?>
    </div>
  </div>
  <div class="formRight" style="width:33%">  
    <label><?php echo $msg_stockexport5; ?>: <?php echo mc_displayHelpTip($msg_javascript321); ?></label>
    <input tabindex="2" type="text" name="from" value="<?php echo (isset($_POST['from']) ? mc_cleanDataEnt($_POST['from']) : '0'); ?>" class="box" style="width:20%" /> <?php echo $msg_stockexport6; ?>
    <input tabindex="3" type="text" name="to" value="<?php echo (isset($_POST['to']) ? mc_cleanDataEnt($_POST['to']) : $SETTINGS->searchLowStockLimit); ?>" class="box" style="width:20%" />
  </div>
  <div class="formLeft" style="width:23%">
    <label><?php echo $msg_stockexport7; ?>: <?php echo mc_displayHelpTip($msg_javascript322,'LEFT'); ?></label>
    <?php echo $msg_script5; ?> <input tabindex="6" type="radio" name="disabled" value="yes"<?php echo (isset($_POST['disabled']) && $_POST['disabled']=='yes' ? ' checked="checked"' : (!isset($_POST['disabled']) ? ' checked="checked"' : '')); ?> /> <?php echo $msg_script6; ?> <input tabindex="6" type="radio" name="disabled" value="no"<?php echo (isset($_POST['disabled']) && $_POST['disabled']=='no' ? ' checked="checked"' : ''); ?> /> 
  </div>
  <br class="clear" />
</div>

<p style="text-align:center;padding-top:20px">
 <input type="hidden" name="process" value="yes" />
 <input class="formbutton" type="submit" value="<?php echo mc_cleanDataEnt($msg_stockexport8); ?>" title="<?php echo mc_cleanDataEnt($msg_stockexport8); ?>" />
</p>
</form>

</div>
