<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } 
define('CALBOX', 'from|to');
include(PATH.'templates/date-picker.php');
?>
<div id="content">

<?php
if (isset($OK)) {
  echo actionCompleted($msg_productprices12);
}
?>

<?php echo $msg_productprices; ?><br /><br />
<?php
if (pagePermissions('update-prices-csv',false)=='yes') {
?>
<a class="addProduct" href="?p=update-prices-csv" title="<?php echo mc_cleanDataEnt($msg_productprices20); ?>"><b><?php echo $msg_productprices20; ?></b></a><br /><br />
<?php
}
?>

<form method="post" action="?p=update-prices" id="form" onsubmit="return confirmMessage('<?php echo mc_cleanDataEnt($msg_javascript45); ?>')">
<div class="fieldHeadWrapper">
  <p><?php echo $msg_productprices2; ?>:</p>
</div>

<div class="formFieldWrapper">
  <div class="formLeft">
    <label><?php echo $msg_productprices3; ?>: <?php echo mc_displayHelpTip($msg_javascript87,'RIGHT'); ?></label>
    <input type="text" name="price" value="" class="box" tabindex="1" style="width:50%" /><br /><br />
    
    <label><?php echo $msg_productprices4; ?>: <?php echo mc_displayHelpTip($msg_javascript88,'RIGHT'); ?></label>
    <?php echo $msg_productprices6; ?> <input tabindex="3" type="radio" name="type" value="incr" checked="checked" /> <?php echo $msg_productprices7; ?> <input tabindex="3" type="radio" name="type" value="decr" /> <?php echo $msg_productprices19; ?> <input type="radio" name="type" value="fixed" /><br /><br />
    
    <label><?php echo $msg_productstock17; ?>: <?php echo mc_displayHelpTip($msg_javascript414,'RIGHT'); ?></label>
    <?php echo $msg_productstock15; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="checkbox" name="table[]" value="products" checked="checked" /> <?php echo $msg_productstock16; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="checkbox" name="table[]" value="attr" />
    <br class="clear" />
  </div>
  <div class="formRight">  
    <label><?php echo $msg_productprices13; ?>: <?php echo mc_displayHelpTip($msg_javascript92,'LEFT'); ?></label>
    <?php echo $msg_productprices14; ?> <input type="text" tabindex="4" name="min" class="box" style="width:15%" value="0.00" /> <?php echo $msg_productprices15; ?> <input type="text" tabindex="5" name="max" class="box" style="width:15%" value="0.00" /><br /><br /> 
    
    <label><?php echo $msg_productprices9; ?>: <?php echo mc_displayHelpTip($msg_javascript90,'LEFT'); ?></label>
    <input type="text" name="from" class="box" tabindex="6" id="from" style="width:25%" /> <?php echo $msg_productprices10; ?> <input type="text" tabindex="7" name="to" class="box" id="to" style="width:25%" /><br /><br />
    
    <label><?php echo $msg_productprices11; ?>: <?php echo mc_displayHelpTip($msg_javascript91,'LEFT'); ?></label>
    <?php echo $msg_script5; ?> <input type="radio" tabindex="2" name="clear" value="yes" /> <?php echo $msg_script6; ?> <input tabindex="2" type="radio" name="clear" value="no" checked="checked" />
    
    <br class="clear" />
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper">
  <div class="formLeft">
    <label><?php echo $msg_productprices8; ?>: <?php echo mc_displayHelpTip($msg_javascript89,'RIGHT'); ?></label>
    <div class="categoryBoxes">
    <?php
    $cats   = array();
    $q_cats = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
              WHERE catLevel = '1'
              AND childOf    = '0'
              AND enCat      = 'yes'
              ORDER BY catname") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($CATS = mysql_fetch_object($q_cats)) {
    $cats[] = $CATS->id;
    ?>
    <input tabindex="8" onclick="loadProducts('cat-<?php echo $CATS->id; ?>','0','prices')" type="radio" name="pCat" value="<?php echo $CATS->id; ?>"<?php echo (count($cats)==1 ? ' checked="checked"' : ''); ?> /> <?php echo mc_cleanDataEnt($CATS->catname); ?><br />
    <?php
    $q_children = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
                  WHERE catLevel = '2'
                  AND enCat      = 'yes'
                  AND childOf    = '".$CATS->id."'
                  ORDER BY catname") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($CHILDREN = mysql_fetch_object($q_children)) {
    ?>
    &nbsp;&nbsp;<input tabindex="8" onclick="loadProducts('child-<?php echo $CHILDREN->id; ?>','0','prices')" type="radio" name="pCat" value="<?php echo $CHILDREN->id; ?>" /> <?php echo mc_cleanDataEnt($CHILDREN->catname); ?><br />
    <?php
    $q_infants = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
                  WHERE catLevel = '3'
                  AND childOf    = '{$CHILDREN->id}'
                  AND enCat      = 'yes'
                  ORDER BY catname
                  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($INFANTS = mysql_fetch_object($q_infants)) {
    ?>
    &nbsp;&nbsp;&nbsp;&nbsp;<input tabindex="8" onclick="loadProducts('infant-<?php echo $INFANTS->id; ?>','0','prices')" type="radio" name="pCat" value="<?php echo $INFANTS->id; ?>" /> <?php echo mc_cleanDataEnt($INFANTS->catname); ?><br />
    <?php
    }
    }
    }
    ?>
    </div>
  </div>
  <div class="formRight">
  <label><?php echo $msg_productprices16; ?>: <?php echo mc_displayHelpTip($msg_javascript218,'LEFT'); ?></label>
  <div class="categoryBoxes" id="products">
  <?php
  $q_products = mysql_query("SELECT *,".DB_PREFIX."products.id AS pid 
                FROM ".DB_PREFIX."products
                LEFT JOIN ".DB_PREFIX."prod_category
                ON ".DB_PREFIX."products.id   = ".DB_PREFIX."prod_category.product
                WHERE category                = '".(isset($cats[0]) ? $cats[0] : '0')."'
                AND pEnable                   = 'yes'
                GROUP BY ".DB_PREFIX."products.id
                ORDER BY pName
                ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  if (mysql_num_rows($q_products)>0) {
  ?>
  <input tabindex="9" type="checkbox" name="log" value="all" onclick="selectAll()" /> <b><?php echo $msg_prodrelated7; ?></b><br />
  <?php
  while ($PR = mysql_fetch_object($q_products)) {
  ?>
  <input type="hidden" name="products[]" value="<?php echo $PR->pid; ?>" />
  <input tabindex="9" type="checkbox" name="product[]" value="<?php echo $PR->pid; ?>" /> <?php echo mc_cleanDataEnt($PR->pName).' - '.mc_currencyFormat(mc_formatPrice($PR->pPrice)); ?><br />
  <?php
  }
  } else {
  echo $msg_productprices17;
  }
  ?>
  </div>
  </div>
  <br class="clear" />
</div> 

<p style="text-align:center;padding-top:20px">
 <input type="hidden" name="process" value="yes" />
 <input class="formbutton" type="submit" value="<?php echo mc_cleanDataEnt($msg_productprices5); ?>" title="<?php echo mc_cleanDataEnt($msg_productprices5); ?>" />
</p>
</form>

<p>&nbsp;</p>
<p>&nbsp;</p>
</div>
