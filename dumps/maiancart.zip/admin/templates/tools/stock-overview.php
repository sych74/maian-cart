<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } ?>
<div id="content">

<?php
if (isset($OK)) {
  echo actionCompleted($stock_overview5);
}

echo $stock_overview;
?>
<br /><br />

<div class="topWrapper">
  <div class="topLeft"><select onchange="if(this.value!= 0){location=this.options[this.selectedIndex].value}">
  <option value="?p=stock-overview"><?php echo $msg_productmanage5; ?></option>
  <?php
  $q_cats = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
            WHERE catLevel = '1'
            AND childOf    = '0'
            AND enCat      = 'yes'
            ORDER BY catname") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  while ($CATS = mysql_fetch_object($q_cats)) {
  ?>
  <option value="?p=stock-overview&amp;cat=<?php echo $CATS->id; ?>"<?php echo (isset($_GET['cat']) && mc_digitSan($_GET['cat'])==$CATS->id ? ' selected="selected"' : ''); ?>><?php echo mc_cleanDataEnt($CATS->catname); ?></option>
  <?php
  $q_children = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
                WHERE catLevel = '2'
                AND enCat      = 'yes'
                AND childOf    = '".$CATS->id."'
                ORDER BY catname") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  while ($CHILDREN = mysql_fetch_object($q_children)) {
  ?>
  <option value="?p=stock-overview&amp;cat=<?php echo $CHILDREN->id; ?>"<?php echo (isset($_GET['cat']) && mc_digitSan($_GET['cat'])==$CHILDREN->id ? ' selected="selected"' : ''); ?>>- <?php echo mc_cleanDataEnt($CHILDREN->catname); ?></option>
  <?php
  $q_infants = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
               WHERE catLevel = '3'
               AND childOf    = '{$CHILDREN->id}'
               AND enCat      = 'yes'
               ORDER BY catname
               ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  while ($INFANTS = mysql_fetch_object($q_infants)) {
  ?>
  <option value="?p=stock-overview&amp;cat=<?php echo $INFANTS->id; ?>"<?php echo (isset($_GET['cat']) && mc_digitSan($_GET['cat'])==$INFANTS->id ? ' selected="selected"' : ''); ?>>&nbsp;&nbsp;- <?php echo mc_cleanDataEnt($INFANTS->catname); ?></option>
  <?php
  }
  }
  }
  ?>
  </select></div>
  <div class="topRight"><a class="export_stock" href="?p=stock-overview&amp;export=<?php echo (isset($_GET['cat']) ? mc_digitSan($_GET['cat']) : 'all'); ?>" title="<?php echo mc_cleanDataEnt($stock_overview3); ?>"><?php echo $stock_overview3; ?></a></div>
  <br class="clear" />
</div>

<form method="post" id="form" action="?p=stock-overview<?php echo (isset($_GET['cat']) ? '&amp;cat='.mc_digitSan($_GET['cat']) : ''); ?>" onsubmit="return confirmMessage('<?php echo mc_cleanDataEnt($msg_javascript45); ?>')">
<div class="fieldHeadWrapper">
  <p><span class="float"><input type="checkbox" name="log" value="" onclick="selectAll(this.form)" /></span><?php echo mc_cleanDataEnt($msg_header19); ?>:</p>
</div>
<?php
$SQL       = '';
if (isset($_GET['cat'])) {
  $SQL = 'AND `category` = \''.mc_digitSan($_GET['cat']).'\'';
}
$q_p = mysql_query("SELECT SQL_CALC_FOUND_ROWS *,".DB_PREFIX."products.id AS `pid` FROM ".DB_PREFIX."products
       LEFT JOIN ".DB_PREFIX."prod_category
       ON ".DB_PREFIX."products.id  = ".DB_PREFIX."prod_category.product
       WHERE `pEnable`              = 'yes'
       $SQL
       GROUP BY ".DB_PREFIX."products.id
       ORDER BY `pStock` DESC,`pName`
       LIMIT $limit,".PRODUCTS_PER_PAGE."
       ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
$c = mysql_fetch_object(mysql_query("SELECT FOUND_ROWS() AS rows"));       
if (mysql_num_rows($q_p)>0) {
while ($PROD = mysql_fetch_object($q_p)) {
?>
<div class="stockOverviewWrapper">
 <div class="productName">
  <p><a href="?p=add-product&amp;edit=<?php echo $PROD->pid; ?>" title="<?php echo mc_cleanDataEnt($msg_script9).': '.mc_cleanDataEnt($PROD->pName); ?>"><?php echo mc_cleanDataEnt($PROD->pName); ?></a></p>
 </div>
 <div class="totalStock">
   <p><?php echo $stock_overview4.': '.$PROD->pStock; ?>&nbsp;&nbsp;&nbsp;&nbsp;<input type="checkbox" name="prod[]" value="<?php echo $PROD->pid; ?>" /></p>
 </div>
 <br class="clear" />
</div>
<?php
$q_products = mysql_query("SELECT * FROM ".DB_PREFIX."attr_groups
              WHERE `productID` = '{$PROD->pid}'
              ORDER BY `orderBy`
              ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
while ($AG = mysql_fetch_object($q_products)) {
$q_a = mysql_query("SELECT * FROM ".DB_PREFIX."attributes
       WHERE `attrGroup` = '{$AG->id}'
       ORDER BY `orderBy`
       ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
while ($ATTR = mysql_fetch_object($q_a)) {
// Does this product have attributes..
?>
<div class="stockOverviewWrapperAttr">
 <div class="productName">
  <p><a href="?p=product-attributes&amp;product=<?php echo $PROD->pid; ?>" title="<?php echo mc_cleanDataEnt($AG->groupName); ?> / <?php echo mc_cleanDataEnt($ATTR->attrName); ?>"><?php echo mc_cleanDataEnt($AG->groupName); ?> / <?php echo mc_cleanDataEnt($ATTR->attrName); ?></a></p>
 </div>
 <div class="totalStock">
   <p><?php echo $stock_overview4.': '.$ATTR->attrStock; ?>&nbsp;&nbsp;&nbsp;&nbsp;<input type="checkbox" name="attr[]" value="<?php echo $ATTR->id; ?>" /></p>
 </div>
 <br class="clear" />
</div>
<?php
}

}

}
?>
<div class="updateStock" style="margin-top:10px;text-align:right">
 <p>
  <input type="hidden" name="process" value="yes" />
  <?php echo $stock_overview6; ?>: <input type="text" name="stock" value="0" class="box" style="width:5%" />
  <input class="formbutton" type="submit" value="<?php echo mc_cleanDataEnt($stock_overview7); ?>" title="<?php echo mc_cleanDataEnt($stock_overview7); ?>" />
 </p>
</div>
<?php
define('PER_PAGE',PRODUCTS_PER_PAGE);
if ($c->rows>0 && $c->rows>PER_PAGE) {
  $PTION = new pagination($c->rows,'?p='.$cmd.'&amp;next=');
  echo $PTION->display();
}
} else {
?>
<span class="noData"><?php echo $stock_overview2; ?></span>
<?php
}
?>

</form>
</div>
