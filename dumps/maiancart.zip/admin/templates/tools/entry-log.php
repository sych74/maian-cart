<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } ?>
<div id="content">

<?php
if (isset($OK) && $cnt>0) {
  echo actionCompleted($msg_entrylog5);
}
?>

<?php
echo $msg_entrylog;
?>
<br /><br />

<div class="topWrapper">
  <div class="topLeft"><select onchange="if(this.value!= 0){location=this.options[this.selectedIndex].value}">
  <option value="?p=entry-log"><?php echo $msg_entrylog2; ?></option>
  <?php
  if (defined('USERNAME')) {
  ?>
  <option value="?p=entry-log&amp;user=<?php echo USERNAME; ?>"<?php echo (isset($_GET['user']) && mc_cleanData($_GET['user'])==USERNAME ? ' selected="selected"' : ''); ?>><?php echo mc_cleanDataEnt(USERNAME); ?></option>
  <?php
  }
  $q_users = mysql_query("SELECT * FROM ".DB_PREFIX."users 
             ORDER BY userName
             ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  while ($USERS = mysql_fetch_object($q_users)) {
  ?>
  <option value="?p=entry-log&amp;user=<?php echo $USERS->userName; ?>"<?php echo (isset($_GET['user']) && mc_cleanData($_GET['user'])==$USERS->userName ? ' selected="selected"' : ''); ?>><?php echo mc_cleanDataEnt($USERS->userName); ?></option>
  <?php
  }
  ?>
  </select></div>
  <div class="topRight"><?php echo ($uDel=='yes' ? '<a class="reset_hits" href="?p=entry-log&amp;reset='.(isset($_GET['user']) ? mc_cleanDataEnt($_GET['user']) : 'all').'" title="'.mc_cleanDataEnt($msg_entrylog3).'" onclick="return confirmMessage(\''.(isset($_GET['user']) ? mc_cleanDataEnt($msg_javascript268) : mc_cleanDataEnt($msg_javascript267)).'\')">'.$msg_entrylog3.'</a> ' : ''); ?><a class="export_hits" href="?p=entry-log&amp;export=<?php echo (isset($_GET['user']) ? mc_cleanDataEnt($_GET['user']) : 'all'); ?>" title="<?php echo mc_cleanDataEnt($msg_entrylog4); ?>"><?php echo $msg_entrylog4; ?></a></div>
  <br class="clear" />
</div>

<?php
$limit  = $page * LOGS_PER_PAGE - (LOGS_PER_PAGE);
$SQL    = '';
if (isset($_GET['user'])) {
  $SQL = 'WHERE userName = \''.mc_safeImportString($_GET['user']).'\'';
}
$q_l = mysql_query("SELECT SQL_CALC_FOUND_ROWS *,DATE_FORMAT(loggedDate,'".$SETTINGS->mysqlDateFormat."') AS ldate FROM ".DB_PREFIX."entry_log
       $SQL
       ORDER BY id DESC,userName
       LIMIT $limit,".LOGS_PER_PAGE."
       ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
$c = mysql_fetch_object(mysql_query("SELECT FOUND_ROWS() AS rows"));       
?>
<div class="fieldHeadWrapper">
  <p><span class="float"><?php echo $c->rows; ?></span><?php echo mc_cleanDataEnt($msg_javascript99); ?>:</p>
</div>
<?php
if (mysql_num_rows($q_l)>0) {
while ($LOG = mysql_fetch_object($q_l)) {
?>
<div class="hitsOverviewWrapper">
 <div class="productName" style="width:98%">
  <p><span style="float:right;text-align:right"><?php echo $LOG->ldate; ?> @ <?php echo $LOG->loggedTime; ?></span><?php echo mc_cleanDataEnt($LOG->userName); ?></p>
 </div>
 <br class="clear" />
</div>
<?php
}
define('PER_PAGE',LOGS_PER_PAGE);
if ($c->rows>0 && $c->rows>PER_PAGE) {
  $PTION = new pagination($c->rows,'?p='.$cmd.'&amp;next=');
  echo $PTION->display();
}
} else {
?>
<span class="noData"><?php echo $msg_entrylog6; ?></span>
<?php
}
?>
</div>
