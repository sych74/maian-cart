<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } ?>
<div id="content">

<?php
if (isset($OK2) && $cnt>0) {
  echo actionCompleted($msg_newsletter7);
}
if (isset($OK) && $cnt>0) {
  echo actionCompleted($msg_newsletter8);
}
if (isset($OK3)) {
  echo actionCompleted(str_replace('{count}',$cnt,$msg_newsletter26));
}
?>

<?php
echo $msg_newsletter;
?>
<br /><br />

<div class="topWrapper">
  <div class="topLeft"><?php echo $msg_newsletter3; ?>: <b><?php echo mc_rowCount('newsletter'); ?></b></div>
  <div class="topRight">
  <a class="batch_mail" href="?p=newsletter-mail" title="<?php echo mc_cleanDataEnt($msg_newsletter11); ?>"><?php echo $msg_newsletter11; ?></a>
  <a style="margin-left:10px" class="import_addresses" href="#" onclick="jQuery('#importArea').toggle('slow');return false" title="<?php echo mc_cleanDataEnt($msg_newsletter23); ?>"><?php echo $msg_newsletter23; ?></a>
  <a style="margin-left:10px" class="export_hits" href="?p=newsletter&amp;export=yes" title="<?php echo mc_cleanDataEnt($msg_newsletter2); ?>"><?php echo $msg_newsletter2; ?></a>
  <?php echo ($uDel=='yes' ? '<a style="margin-left:10px" class="reset_hits" href="?p=newsletter&amp;clear=all" title="'.mc_cleanDataEnt($msg_newsletter6).'" onclick="return confirmMessage(\''.mc_cleanDataEnt($msg_javascript45).'\')">'.$msg_newsletter6.'</a> ' : ''); ?>
  </div>
  <br class="clear" />
</div>

<?php
$limit  = $page * EMAILS_PER_PAGE - (EMAILS_PER_PAGE);
$q_l = mysql_query("SELECT SQL_CALC_FOUND_ROWS * FROM ".DB_PREFIX."newsletter
       ORDER BY emailAddress
       LIMIT $limit,".EMAILS_PER_PAGE."
       ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
$c = mysql_fetch_object(mysql_query("SELECT FOUND_ROWS() AS rows"));       
?>
<div id="importArea" style="display:none;height:90px">
<form method="post" action="?p=newsletter" onsubmit="if(jQuery('#email').val()=='' && jQuery('#filebox').val()==''){jQuery('#importArea').hide('slow');return false;}" enctype="multipart/form-data">
<div class="fieldHeadWrapper">
  <p><?php echo mc_cleanData($msg_newsletter23); ?>:</p>
</div>

<div class="addAddresses">
  <div class="left">
   <p><?php echo mc_displayHelpTip($msg_javascript430,'RIGHT'); ?> <input id="filebox" class="box" type="file" name="file" /></p>
  </div>
  <div class="right">
   <p><?php echo $msg_newsletter25; ?>&nbsp;&nbsp;&nbsp;<input type="text" name="email" id="email" class="box" /> <input type="hidden" name="process" value="yes" /><input type="submit" class="button" title="<?php echo mc_cleanDataEnt($msg_newsletter24); ?>" value="<?php echo mc_cleanDataEnt($msg_newsletter24); ?>" /></p>
  </div>
  <br class="clear" />  
</div>
</form>
</div>

<div class="fieldHeadWrapper">
  <p><?php echo mc_cleanData($msg_newsletter4); ?>:</p>
</div>
<?php
if (mysql_num_rows($q_l)>0) {
while ($NL = mysql_fetch_object($q_l)) {
?>
<div class="hitsOverviewWrapper">
 <div class="productName" style="width:98%">
  <p>
    <span style="float:right;text-align:right">
    <?php echo ($uDel=='yes' ? '<a href="?p=newsletter&amp;del='.$NL->id.'" onclick="return confirmMessage(\''.mc_cleanDataEnt($msg_javascript45).'\')"><img src="templates/images/delete.png" alt="'.mc_cleanDataEnt($msg_script10).'" title="'.mc_cleanDataEnt($msg_script10).'" /></a>' : ''); ?>
    </span>
    <span id="email_<?php echo $NL->id; ?>" onclick="jQuery('#email_<?php echo $NL->id; ?>').hide();jQuery('#eboxw_<?php echo $NL->id; ?>').show('slow');"><?php echo mc_cleanDataEnt($NL->emailAddress); ?></span>
    <span id="eboxw_<?php echo $NL->id; ?>" style="font-size:11px;display:none"><input type="text" name="email" value="<?php echo mc_cleanDataEnt($NL->emailAddress); ?>" class="box" style="width:30%" id="ebox_<?php echo $NL->id; ?>" /> [<a href="#" title="<?php echo mc_cleanDataEnt($msg_newsletter9); ?>" onclick="updateEmail(jQuery('#ebox_<?php echo $NL->id; ?>').val(),'<?php echo $NL->id; ?>');return false"><?php echo $msg_newsletter9; ?></a>] [<a href="#" title="<?php echo mc_cleanDataEnt($msg_newsletter10); ?>" onclick="jQuery('#eboxw_<?php echo $NL->id; ?>').hide();jQuery('#email_<?php echo $NL->id; ?>').show('slow');return false"><?php echo $msg_newsletter10; ?></a>]</span>
  </p>
 </div>
 <br class="clear" />
</div>
<?php
}
define('PER_PAGE',EMAILS_PER_PAGE);
if ($c->rows>0 && $c->rows>PER_PAGE) {
  $PTION = new pagination($c->rows,'?p='.$cmd.'&amp;next=');
  echo $PTION->display();
}
} else {
?>
<span class="noData"><?php echo $msg_newsletter5; ?></span>
<?php
}
?>
</div>
