<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } ?>
<div id="content">

<?php
if (isset($OK)) {
  echo actionCompleted($msp_productstatus11);
}

echo $msp_productstatus; 
?>
<br /><br />

<div class="fieldHeadWrapper">
  <p><?php echo $msp_productstatus4; ?>:</p>
</div>

<?php
if (isset($return) && $return=='none') {
?>
<p class="noData" style="margin-bottom:5px"><?php echo $msp_productstatus3; ?></p>
<?php
}
$tabIndex = 0;
?>

<form method="post" id="form" action="?p=product-status">
<div class="formFieldWrapper">
  <div class="formLeft" style="width:59%">
    <label><?php echo $msp_productstatus2; ?>: <?php echo mc_displayHelpTip($msg_javascript339,'RIGHT'); ?></label>
    <div class="categoryBoxes" style="height:280px">
    <input type="checkbox" tabindex="<?php echo ++$tabIndex; ?>" name="log" value="all" onclick="toggleCheckBoxes(this.checked,'categoryBoxes')" /> <b><?php echo $msg_productadd35; ?></b><br />
    <?php
    $q_cats = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
              WHERE catLevel = '1'
              AND childOf    = '0'
              ORDER BY catname") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($CATS = mysql_fetch_object($q_cats)) {
    ?>
    <p id="cat_<?php echo $CATS->id; ?>"><input onclick="if(this.checked){selectChildren('cat_<?php echo $CATS->id; ?>','on')}else{selectChildren('cat_<?php echo $CATS->id; ?>','off')}" tabindex="<?php echo ++$tabIndex; ?>" type="checkbox" name="range[]" value="<?php echo $CATS->id; ?>" /> <?php echo mc_cleanDataEnt($CATS->catname); ?><br />
    <?php
    $q_children = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
                  WHERE catLevel = '2'
                  AND childOf    = '{$CATS->id}'
                  ORDER BY catname") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($CHILDREN = mysql_fetch_object($q_children)) {
    ?>
    <span id="child_<?php echo $CHILDREN->id; ?>">
    &nbsp;&nbsp;<input onclick="if(this.checked){selectChildren('child_<?php echo $CHILDREN->id; ?>','on')}else{selectChildren('child_<?php echo $CHILDREN->id; ?>','off')}" tabindex="<?php echo ++$tabIndex; ?>" type="checkbox" name="range[]" value="<?php echo $CHILDREN->id; ?>" /> <?php echo mc_cleanDataEnt($CHILDREN->catname); ?><br />
    <?php
    $q_infants = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
                  WHERE catLevel = '3'
                  AND childOf    = '{$CHILDREN->id}'
                  AND enCat      = 'yes'
                  ORDER BY catname
                  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($INFANTS = mysql_fetch_object($q_infants)) {
    ?>
    &nbsp;&nbsp;&nbsp;&nbsp;<input tabindex="<?php echo ++$tabIndex; ?>" type="checkbox" name="range[]" value="<?php echo $INFANTS->id; ?>" /> <?php echo mc_cleanDataEnt($INFANTS->catname); ?><br />
    <?php
    }
    ?>
    </span>
    <?php
    }
    ?>
    </p>
    <?php
    }
    ?>
    </div>
  </div>
  <div class="formRight" style="width:40%">  
    <label><?php echo $msp_productstatus5; ?>: <?php echo mc_displayHelpTip($msg_javascript340,'LEFT'); ?></label>
    <p>
     <span class="radioBlock">
       <span class="radioLeft">
        <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="action_1" value="enable" checked="checked" /> <?php echo $msp_productstatus3; ?>
       </span>
       <span class="radioRight">
        <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="action_1" value="disable" /> <?php echo $msp_productstatus6; ?>
       </span>
       <br class="clear" />
     </span> 
     <span class="radioBlock">
       <span class="radioLeft">
        <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="action_3" value="enable" checked="checked" /> <?php echo $msp_productstatus12; ?>
       </span>
       <span class="radioRight">
        <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="action_3" value="disable" /> <?php echo $msp_productstatus13; ?>
       </span>
       <br class="clear" />
     </span>
     <span class="radioBlock">
       <span class="radioLeft">
        <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="action_4" value="enable" checked="checked" /> <?php echo $msp_productstatus16; ?> 
       </span>
       <span class="radioRight">
        <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="action_4" value="disable" /> <?php echo $msp_productstatus17; ?>
       </span>
       <br class="clear" />
     </span>
     <span class="radioBlock">
       <span class="radioLeft">
        <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="action_5" value="enable" checked="checked" /> <?php echo $msp_productstatus9; ?>
       </span>
       <span class="radioRight">
        <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="action_5" value="disable" /> <?php echo $msp_productstatus10; ?>
       </span>
       <br class="clear" />
     </span> 
     <span class="radioBlock">
       <span class="radioLeft">
        <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="action_6" value="disable" checked="checked" /> <?php echo $msp_productstatus18; ?>
       </span>
       <span class="radioRight">
        <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="action_6" value="enable" /> <?php echo $msp_productstatus19; ?>
       </span>
       <br class="clear" />
     </span>
     <span class="radioBlock">
       <span class="radioLeft">
        <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="action_7" value="enable" checked="checked" /> <?php echo $msp_productstatus14; ?>
       </span>
       <span class="radioRight">
        <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="action_7" value="disable" /> <?php echo $msp_productstatus15; ?>
       </span>
       <br class="clear" />
     </span>
    </p>
  </div>
  <br class="clear" />
</div>

<p style="text-align:center;padding:20px 0 20px 0">
 <input type="hidden" name="process" value="yes" />
 <input class="formbutton" type="submit" value="<?php echo mc_cleanDataEnt($msp_productstatus8); ?>" title="<?php echo mc_cleanDataEnt($msp_productstatus8); ?>" />
</p>
</form>

</div>
