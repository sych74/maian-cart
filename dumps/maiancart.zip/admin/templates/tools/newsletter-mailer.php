<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } 
if (isset($_GET['load'])) {
  $_GET['load'] = (int)$_GET['load'];
  $TP           = mc_getTableData('newstemplates','id',$_GET['load']);
}
?>
<div id="content">

<?php
if (isset($OK)) {
  echo actionCompleted(str_replace('{count}',number_format($sent),$msg_newsletter20));
}
?>

<?php
echo $msg_newsletter13;
?>
<br /><br />

<div class="fieldHeadWrapper">
  <p><span class="float">
   <a href="#" onclick="saveMailTemplate();return false"><img src="templates/images/save_status.png" alt="<?php echo mc_cleanDataEnt($msg_newsletter27); ?>" title="<?php echo mc_cleanDataEnt($msg_newsletter27); ?>" /></a>&nbsp;&nbsp;&nbsp;
   <a href="#" onclick="<?php echo (mc_rowCount('newstemplates')>0 ? 'showTemplates();' : 'alert(\''.mc_cleanDataEnt($msg_javascript468).'\');'); ?>return false"><img src="templates/images/load_status.png" alt="<?php echo mc_cleanDataEnt($msg_newsletter28); ?>" title="<?php echo mc_cleanDataEnt($msg_newsletter28); ?>" /></a>&nbsp;&nbsp;&nbsp;
   <a href="?p=newsletter-templates" title="<?php echo mc_cleanDataEnt($msg_newsletter29); ?>" onclick="mc_Window(this.href,'<?php echo GREYBOX_STATUS_HEIGHT; ?>','<?php echo GREYBOX_STATUS_WIDTH; ?>',this.title);return false;"><img src="templates/images/manage_status.png" alt="<?php echo mc_cleanDataEnt($msg_newsletter29); ?>" title="<?php echo mc_cleanDataEnt($msg_newsletter29); ?>" /></a>
  </span>
  <?php echo mc_cleanData($msg_newsletter11); ?>:</p>
</div>

<div id="newsTemplates" style="display:none">
<span class="float">
  <a href="#" onclick="jQuery('#newsTemplates').hide('slow');return false" title="<?php echo mc_cleanDataEnt($msg_script8); ?>"><img src="templates/images/close.png" alt="<?php echo mc_cleanDataEnt($msg_script8); ?>" title="<?php echo mc_cleanDataEnt($msg_script8); ?>" /></a>
</span>
<select onchange="if(this.value!=0){location=this.options[this.selectedIndex].value}" id="templateOptions"><option></option></select>
</div>

<?php
if ($SETTINGS->smtp=='yes') {
if (mc_rowCount('newsletter')>0) {
$htmlMessage   = '';
$plainMessage  = '';
if (isset($TP->html)) {
  $htmlMessage = mc_cleanData($TP->html);
} else {
  if (file_exists(MCLANG.'default-newsletter/html-message.html')) {
    $htmlMessage = str_replace('{charset}',$mail_charset,file_get_contents(MCLANG.'default-newsletter/html-message.html'));
  }
}
if (isset($TP->plain)) {
  $plainMessage = mc_cleanData($TP->plain);
} else {
  if (file_exists(MCLANG.'default-newsletter/plain-text-message.txt')) {
    $plainMessage = file_get_contents(MCLANG.'default-newsletter/plain-text-message.txt');
  }
}
?>
<form method="post" action="?p=newsletter-mail<?php echo (isset($_GET['load']) ? '&amp;load='.$_GET['load'] : ''); ?>" onsubmit="return confirmMessage('<?php echo mc_cleanDataEnt($msg_javascript45); ?>')" enctype="multipart/form-data">

<div class="formFieldWrapper">
  <div class="formLeft">
    <label><?php echo $msg_newsletter14; ?>:</label>
    <input type="text" name="from" id="from" value="<?php echo mc_cleanDataEnt((isset($TP->name) ? $TP->name : $SETTINGS->website)); ?>" class="box" tabindex="1" />
  </div>
  <div class="formRight">  
    <label><?php echo $msg_newsletter15; ?>:</label>
    <input type="text" name="email" id="email" value="<?php echo mc_cleanDataEnt((isset($TP->email) ? $TP->email : $SETTINGS->email)); ?>" class="box" tabindex="2" />
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper">
  <label><?php echo $msg_newsletter18; ?>:</label>
  <input type="text" name="subject" id="subject" value="<?php echo mc_cleanDataEnt((isset($TP->subject) ? $TP->subject : $msg_newsletter21)); ?>" class="box" tabindex="3" />
</div>

<div class="formFieldWrapper">
  <label><span class="float"><a class="newsprev" href="#" onclick="mc_loadPreviewWindow('html','newsletter');return false" title="<?php echo mc_cleanDataEnt($msg_script68); ?>"><?php echo mc_cleanDataEnt($msg_script68); ?></a></span><?php echo $msg_newsletter16; ?>: <?php echo mc_displayHelpTip(str_replace('{lang}',$SETTINGS->languagePref,$msg_javascript387),'RIGHT'); ?></label>
  <textarea name="html" id="html" rows="5" class="tarea" cols="20"><?php echo mc_cleanDataEnt($htmlMessage); ?></textarea>
</div>

<div class="formFieldWrapper">
  <label><?php echo $msg_newsletter17; ?>: <?php echo mc_displayHelpTip(str_replace('{lang}',$SETTINGS->languagePref,$msg_javascript388),'RIGHT'); ?></label>
  <textarea name="plain" id="plain" rows="5" class="tarea" cols="20"><?php echo mc_cleanDataEnt($plainMessage); ?></textarea>
</div>

<div class="formFieldWrapper">
  <div class="formLeft" style="width:33%">
    <label><?php echo $msg_newsletter22; ?>: <?php echo mc_displayHelpTip($msg_javascript389,'RIGHT'); ?></label>
    <input type="file" name="attachment[]" value="" class="box" /> 
  </div>
  <div class="formRight" style="width:33%">  
    <label><?php echo $msg_newsletter22; ?>:</label>
    <input type="file" name="attachment[]" value="" class="box" />
  </div>
  <div class="formRight" style="width:33%">  
    <label><?php echo $msg_newsletter22; ?>:</label>
    <input type="file" name="attachment[]" value="" class="box" />
  </div>
  <br class="clear" />
</div>

<?php
if (isset($TP->id)) {
?>
<div class="formFieldWrapper">
  <div class="formLeft">
    <label><?php echo $msg_newsletter32; ?>: <?php echo mc_displayHelpTip($msg_javascript469,'RIGHT'); ?></label>
    <input type="checkbox" name="updateTemp" value="yes" checked="checked" /> 
  </div>
  <div class="formRight">  
  </div>
  <br class="clear" />
</div>
<?php
}
?>

<p style="text-align:center;padding:20px 0 20px 0">
 <input type="hidden" name="process" value="yes" />
 <input class="formbutton" type="submit" value="<?php echo mc_cleanDataEnt($msg_newsletter19); ?>" title="<?php echo mc_cleanDataEnt($msg_newsletter19); ?>" />
 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input class="formbutton2" type="button" onclick="window.location='?p=newsletter'" value="<?php echo mc_cleanDataEnt($msg_script11); ?>" title="<?php echo mc_cleanDataEnt($msg_script11); ?>" />
</p>

</form>
<?php
} else {
?>
<span class="noData"><?php echo $msg_newsletter5; ?></span>
<?php
}
} else {
?>
<span class="noData"><?php echo $msg_newsletter12; ?></span>
<?php
}
?>
</div>
