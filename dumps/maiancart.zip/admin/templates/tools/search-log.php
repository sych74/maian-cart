<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } ?>
<div id="content">

<?php
if (isset($OK) && $cnt>0) {
  echo actionCompleted($msg_searchlog6);
}

echo $msg_searchlog;
?>
<br /><br />
<?php
$limit     = $page * SEARCH_LOGS_PER_PAGE - (SEARCH_LOGS_PER_PAGE);
$totalLogs = mc_rowCount('search_log');
$q_s = mysql_query("SELECT SQL_CALC_FOUND_ROWS *,count(*) AS sr FROM ".DB_PREFIX."search_log
       ".(isset($_GET['zero']) ? 'WHERE `results` = \'0\'' : '')."
       GROUP BY `keyword`
       ORDER BY 1 DESC
       LIMIT $limit,".SEARCH_LOGS_PER_PAGE."
       ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
$c = mysql_fetch_object(mysql_query("SELECT FOUND_ROWS() AS rows"));  
?>
<div class="topWrapper">
  <div class="topLeft"><?php echo str_replace('{count}',number_format($c->rows),($c->rows=='1' ? $msg_searchlog10 : $msg_searchlog4)); ?></div>
  <div class="topRight">
  <?php 
  if ($c->rows>0) {
  echo ($uDel=='yes' ? '<a class="reset_hits" href="?p=search-log&amp;clear=yes" title="'.mc_cleanDataEnt($msg_searchlog2).'" onclick="return confirmMessage(\''.mc_cleanDataEnt($msg_javascript45).'\')">'.$msg_searchlog2.'</a> ' : '');
  ?>
  <a class="export_hits" href="?p=search-log&amp;export=yes<?php echo (isset($_GET['zero']) ? '&amp;zero=yes' : ''); ?>" title="<?php echo mc_cleanDataEnt($msg_searchlog3); ?>"><?php echo $msg_searchlog3; ?></a>
  <?php
  } else {
  ?>
  &nbsp;
  <?php
  }
  ?>
  </div>
  <br class="clear" />
</div>

<div class="fieldHeadWrapper">
  <p>
  <?php
  if ($c->rows>0) {
  ?>
  <span class="float">&lt; <a href="?p=search-log&amp;zero=yes" title="<?php echo $msg_searchlog5; ?>"><?php echo $msg_searchlog5; ?></a> &gt;</span>
  <?php
  }
  ?>
  <?php echo mc_cleanDataEnt($msg_javascript108); ?>:</p>
</div>
<?php
if (mysql_num_rows($q_s)>0) {
while ($SEARCH = mysql_fetch_object($q_s)) {
$perc = 0;
// Prevent division by zero errors..
$perc = number_format($SEARCH->sr/$totalLogs*100,STATS_DECIMAL_PLACES);
?>
<div class="hitsOverviewWrapper">
 <div class="productName" style="width:71%">
  <p><?php echo mc_cleanDataEnt($SEARCH->keyword); ?><span class="small"><?php echo str_replace(array('{count}','{results}'),array(number_format($SEARCH->sr),number_format($SEARCH->results)),$msg_searchlog7); ?></span></p>
 </div>
 <div class="bar">
  <p title="<?php echo str_replace(array('{count}','{results}'),array(number_format($SEARCH->sr),number_format($SEARCH->results)),$msg_searchlog7).' @ '.$perc.'%'; ?>"><span class="progress" style="width:<?php echo $perc; ?>%"><?php echo ($SEARCH->sr>0 ? '&nbsp;' : ''); ?></span><?php echo ($SEARCH->sr==0 ? '&nbsp;' : ''); ?></p>
 </div>
 <div class="percentage">
   <p><?php echo $perc; ?>%</p>
 </div>
 <br class="clear" />
</div>
<?php
}
define('PER_PAGE',SEARCH_LOGS_PER_PAGE);
if ($c->rows>0 && $c->rows>PER_PAGE) {
  $PTION = new pagination($c->rows,'?p='.$cmd.'&amp;next=');
  echo $PTION->display();
}
} else {
?>
<span class="noData"><?php echo (isset($_GET['zero']) ? $msg_searchlog11 : $msg_searchlog9); ?></span>
<?php
}
?>
</div>
