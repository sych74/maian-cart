<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } ?>
<div id="content">

<?php
if (isset($OK)) {
  echo actionCompleted(str_replace('{count}',$updated,$msg_productprices27));
}

?>
<form method="post" action="?p=update-prices-csv" enctype="multipart/form-data" onsubmit="return confirmMessage('<?php echo mc_cleanDataEnt($msg_javascript436); ?>')">
<p><?php echo $msg_productprices21;?><br /><br /></p>
<div class="fieldHeadWrapper">
  <p><?php echo $msg_productprices25; ?>:</p>
</div>

<div class="formFieldWrapper">
  <div class="formLeft" style="width:40%">
    <label><?php echo $msg_productprices24; ?>: <?php echo mc_displayHelpTip($msg_javascript435,'RIGHT'); ?></label>
    <input type="file" name="file" value="" class="box" /> 
  </div>
  <div class="formLeft" style="width:39%">
    <label><?php echo $msg_productprices22; ?>: <?php echo mc_displayHelpTip($msg_javascript176); ?></label>
    <input type="text" name="lines" value="5000" class="box" style="width:40%" /> 
  </div>
  <div class="formRight" style="width:20%">
    <label><?php echo $msg_productprices23; ?>: <?php echo mc_displayHelpTip($msg_javascript177,'LEFT'); ?></label>
    <input type="text" name="del" value="&#044;" class="box" style="width:15%" /> <input type="text" name="enc" value="&quot;" class="box" style="width:15%" />
  </div>
  <br class="clear" />
</div>

<p style="text-align:center;padding-top:20px">
 <input type="hidden" name="import_from_csv" value="yes" />
 <input class="formbutton" type="submit" value="<?php echo mc_cleanDataEnt($msg_productprices26); ?>" title="<?php echo mc_cleanDataEnt($msg_productprices26); ?>" />
</p>

</form>
<p>&nbsp;</p>
<p>&nbsp;</p>
</div>
