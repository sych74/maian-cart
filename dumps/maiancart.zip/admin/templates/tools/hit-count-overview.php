<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } ?>
<div id="content">

<?php
if (isset($OK)) {
  echo actionCompleted($msg_hit_overview5);
}

echo $msg_hit_overview;
?>
<br /><br />

<div class="topWrapper">
  <div class="topLeft"><select onchange="if(this.value!= 0){location=this.options[this.selectedIndex].value}">
  <option value="?p=hit-count-overview"><?php echo $msg_productmanage5; ?></option>
  <?php
  $q_cats = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
            WHERE catLevel = '1'
            AND childOf    = '0'
            AND enCat      = 'yes'
            ORDER BY catname") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  while ($CATS = mysql_fetch_object($q_cats)) {
  ?>
  <option value="?p=hit-count-overview&amp;cat=<?php echo $CATS->id; ?>"<?php echo (isset($_GET['cat']) && mc_digitSan($_GET['cat'])==$CATS->id ? ' selected="selected"' : ''); ?>><?php echo mc_cleanDataEnt($CATS->catname); ?></option>
  <?php
  $q_children = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
                WHERE catLevel = '2'
                AND enCat      = 'yes'
                AND childOf    = '".$CATS->id."'
                ORDER BY catname") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  while ($CHILDREN = mysql_fetch_object($q_children)) {
  ?>
  <option value="?p=hit-count-overview&amp;cat=<?php echo $CHILDREN->id; ?>"<?php echo (isset($_GET['cat']) && mc_digitSan($_GET['cat'])==$CHILDREN->id ? ' selected="selected"' : ''); ?>>- <?php echo mc_cleanDataEnt($CHILDREN->catname); ?></option>
  <?php
  $q_infants = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
               WHERE catLevel = '3'
               AND childOf    = '{$CHILDREN->id}'
               AND enCat      = 'yes'
               ORDER BY catname
               ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  while ($INFANTS = mysql_fetch_object($q_infants)) {
  ?>
  <option value="?p=hit-count-overview&amp;cat=<?php echo $INFANTS->id; ?>"<?php echo (isset($_GET['cat']) && mc_digitSan($_GET['cat'])==$INFANTS->id ? ' selected="selected"' : ''); ?>>&nbsp;&nbsp;- <?php echo mc_cleanDataEnt($INFANTS->catname); ?></option>
  <?php
  }
  }
  }
  ?>
  </select></div>
  <div class="topRight"><?php echo ($uDel=='yes' ? '<a class="reset_hits" href="?p=hit-count-overview&amp;reset='.(isset($_GET['cat']) ? mc_digitSan($_GET['cat']) : 'all').(isset($_GET['cat']) ? '&amp;cat='.mc_digitSan($_GET['cat']) : '').'" title="'.mc_cleanDataEnt($msg_hit_overview3).'" onclick="return confirmMessage(\''.(isset($_GET['cat']) ? mc_cleanDataEnt($msg_javascript166) : mc_cleanDataEnt($msg_javascript165)).'\')">'.$msg_hit_overview3.'</a> ' : ''); ?><a class="export_hits" href="?p=hit-count-overview&amp;export=<?php echo (isset($_GET['cat']) ? mc_digitSan($_GET['cat']) : 'all').(isset($_GET['from']) ? '&amp;from='.mc_checkValidDate($_GET['from']) : '').(isset($_GET['to']) ? '&amp;to='.mc_checkValidDate($_GET['to']) : ''); ?>" title="<?php echo mc_cleanDataEnt($msg_hit_overview4); ?>"><?php echo $msg_hit_overview4; ?></a></div>
  <br class="clear" />
</div>

<div class="fieldHeadWrapper">
  <p><?php echo mc_cleanDataEnt($msg_javascript164); ?>:</p>
</div>
<?php
$totalHits = mc_sumCount('products','pVisits');
$SQL       = '';
if (isset($_GET['cat'])) {
  $SQL = 'AND category = \''.mc_digitSan($_GET['cat']).'\'';
}
$q_p = mysql_query("SELECT SQL_CALC_FOUND_ROWS *,".DB_PREFIX."products.id AS pid FROM ".DB_PREFIX."products
       LEFT JOIN ".DB_PREFIX."prod_category
       ON ".DB_PREFIX."products.id  = ".DB_PREFIX."prod_category.product
       WHERE pEnable                = 'yes'
       $SQL
       GROUP BY ".DB_PREFIX."products.id
       ORDER BY pVisits DESC,pName
       LIMIT $limit,".PRODUCTS_PER_PAGE."
       ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
$c = mysql_fetch_object(mysql_query("SELECT FOUND_ROWS() AS rows"));       
if (mysql_num_rows($q_p)>0) {
while ($PROD = mysql_fetch_object($q_p)) {
$perc = 0;
// Prevent division by zero errors..
if ($PROD->pVisits>0) {
  $perc = number_format($PROD->pVisits/$totalHits*100,STATS_DECIMAL_PLACES);
}
?>
<div class="hitsOverviewWrapper">
 <div class="productName">
  <p><a href="?p=add-product&amp;edit=<?php echo $PROD->pid; ?>" title="<?php echo mc_cleanDataEnt($msg_script9).': '.mc_cleanDataEnt($PROD->pName); ?>"><?php echo mc_cleanDataEnt($PROD->pName); ?></a></p>
 </div>
 <div class="totalHits">
   <p><?php echo number_format($PROD->pVisits); ?></p>
 </div>
 <div class="bar">
  <p title="<?php echo number_format($PROD->pVisits).' '.mc_cleanDataEnt($msg_hit_overview6).' @ '.$perc.'%'; ?>"><span class="progress" style="width:<?php echo $perc; ?>%"><?php echo ($PROD->pVisits>0 ? '&nbsp;' : ''); ?></span><?php echo ($PROD->pVisits==0 ? '&nbsp;' : ''); ?></p>
 </div>
 <div class="percentage">
   <p><?php echo $perc; ?>%</p>
 </div>
 <br class="clear" />
</div>
<?php
}
define('PER_PAGE',PRODUCTS_PER_PAGE);
if ($c->rows>0 && $c->rows>PER_PAGE) {
  $PTION = new pagination($c->rows,'?p='.$cmd.'&amp;next=');
  echo $PTION->display();
}
} else {
?>
<span class="noData"><?php echo $msg_hit_overview2; ?></span>
<?php
}
?>
</div>
