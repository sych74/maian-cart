<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } 
// Get first sale..
$q_f       = mysql_query("SELECT * FROM `".DB_PREFIX."purchases` 
             WHERE `saleConfirmation` = 'yes' 
             ORDER BY `purchaseDate`
             LIMIT 1
             ") 
             or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
$FIRST     = mysql_fetch_object($q_f);
// Filter vars..
$fromDate  = (isset($_GET['from']) ? mc_checkValidDate($_GET['from']) : (isset($FIRST->purchaseDate) ? mc_convertBoxedDate($FIRST->purchaseDate) : mc_convertBoxedDate(date('Y-m-d'))));
$toDate    = (isset($_GET['to']) ? mc_checkValidDate($_GET['to']) : mc_convertBoxedDate(date('Y-m-d')));
$cat       = (isset($_GET['cat']) ? mc_digitSan($_GET['cat']) : 0);
// Count..Physical..
$q_cnts    = mysql_query("SELECT SUM(`productQty`) AS `phys_qty` FROM `".DB_PREFIX."purchases`
             WHERE `purchaseDate` BETWEEN '".mc_convertCalToSQLFormat($fromDate)."' AND '".mc_convertCalToSQLFormat($toDate)."'
             AND `productType`       = 'physical'
             AND `saleConfirmation`  = 'yes'
             ".($cat>0 ? 'AND `categoryID` = \''.$cat.'\'' : '')."
             ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
$PHYS      = mysql_fetch_object($q_cnts);
$PHYS->phys_qty = (isset($PHYS->phys_qty) ? $PHYS->phys_qty : 0);
// Count ..Downloads..
$q_cnts2   = mysql_query("SELECT SUM(`productQty`) AS `down_qty` FROM `".DB_PREFIX."purchases`
             WHERE `purchaseDate` BETWEEN '".mc_convertCalToSQLFormat($fromDate)."' AND '".mc_convertCalToSQLFormat($toDate)."'
             AND `productType`       = 'download'
             AND `saleConfirmation`  = 'yes'
             ".($cat>0 ? 'AND `categoryID` = \''.$cat.'\'' : '')."
             ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
$DOWN      = mysql_fetch_object($q_cnts2);
$DOWN->down_qty = (isset($DOWN->down_qty) ? $DOWN->down_qty : 0);
// Count ..Virtual..
$q_cnts3   = mysql_query("SELECT SUM(`productQty`) AS `gift_qty` FROM `".DB_PREFIX."purchases`
             WHERE `purchaseDate` BETWEEN '".mc_convertCalToSQLFormat($fromDate)."' AND '".mc_convertCalToSQLFormat($toDate)."'
             AND `productType`       = 'virtual'
             AND `saleConfirmation`  = 'yes'
             ".($cat>0 ? 'AND `categoryID` = \''.$cat.'\'' : '')."
             ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
$GIFT      = mysql_fetch_object($q_cnts3);
$GIFT->gift_qty = (isset($GIFT->gift_qty) ? $GIFT->gift_qty : 0);
// Get counts..
$q_cnts  = mysql_query("SELECT count(*) AS `scount`,sum(`grandTotal`) as `gt`
           FROM ".DB_PREFIX."sales
           WHERE `saleConfirmation` = 'yes'
           AND `purchaseDate` BETWEEN '".mc_convertCalToSQLFormat($fromDate)."' AND '".mc_convertCalToSQLFormat($toDate)."'
           ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
$SUMS    = mysql_fetch_object($q_cnts);
$orderStatsArray = array();
$totalOrders     = mc_rowCount('sales WHERE `saleConfirmation` = \'yes\'');
define('CALBOX', 'from|to');
include(PATH.'templates/date-picker.php');
?>
<div id="content">

<?php
echo $msg_stats
?>
<br /><br />

<div class="statsTop">
  <div class="left">
    <select onchange="if(this.value!= 0){location=this.options[this.selectedIndex].value}">
    <option value="?p=stats"><?php echo $msg_stats6; ?></option>
    <?php
    $q_cats = mysql_query("SELECT * FROM `".DB_PREFIX."categories` 
              WHERE `catLevel` = '1'
              AND `childOf`    = '0'
              AND `enCat`      = 'yes'
              ORDER BY `catname`
			  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($CATS = mysql_fetch_object($q_cats)) {
    ?>
    <option value="?p=stats&amp;cat=<?php echo $CATS->id.'&amp;from='.$fromDate.'&amp;to='.$toDate; ?>"<?php echo (isset($_GET['cat']) && $_GET['cat']==$CATS->id ? ' selected="selected"' : ''); ?>><?php echo mc_cleanDataEnt($CATS->catname); ?></option>
    <?php
    $q_children = mysql_query("SELECT * FROM `".DB_PREFIX."categories` 
                  WHERE `catLevel` = '2'
                  AND `enCat`      = 'yes'
                  AND `childOf`    = '".$CATS->id."'
                  ORDER BY `catname`
				  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($CHILDREN = mysql_fetch_object($q_children)) {
    ?>
    <option value="?p=stats&amp;cat=<?php echo $CHILDREN->id.'&amp;from='.$fromDate.'&amp;to='.$toDate; ?>"<?php echo (isset($_GET['cat']) && $_GET['cat']==$CHILDREN->id ? ' selected="selected"' : ''); ?>>- <?php echo mc_cleanDataEnt($CHILDREN->catname); ?></option>
    <?php
    $q_infants = mysql_query("SELECT * FROM `".DB_PREFIX."categories` 
                  WHERE `catLevel` = '3'
                  AND `childOf`    = '{$CHILDREN->id}'
                  AND `enCat`      = 'yes'
                  ORDER BY `catname`
                  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($INFANTS = mysql_fetch_object($q_infants)) {
    ?>
    <option value="?p=stats&amp;cat=<?php echo $INFANTS->id.'&amp;from='.$fromDate.'&amp;to='.$toDate; ?>"<?php echo (isset($_GET['cat']) && $_GET['cat']==$INFANTS->id ? ' selected="selected"' : ''); ?>>&nbsp;&nbsp;- <?php echo mc_cleanDataEnt($INFANTS->catname); ?></option>
    <?php
    }
    }
    }
    ?>
    </select>
  </div>
  <div class="right">
  <form method="get" action="index.php">
   <p><b><?php echo $msg_stats4; ?></b>: <input type="hidden" name="p" value="stats" /><input type="hidden" name="cat" value="<?php echo (isset($_GET['cat']) ? $_GET['cat'] : 0); ?>" /><input type="text" name="from" value="<?php echo enterDatesBox($fromDate); ?>" class="box" style="width:25%" id="from" /> <?php echo $msg_salessearch5; ?> <input type="text" name="to" value="<?php echo enterDatesBox($toDate); ?>" class="box" style="width:25%" id="to" /> <input type="submit" class="formbutton" value="<?php echo mc_cleanDataEnt($msg_stats5); ?>" title="<?php echo mc_cleanDataEnt($msg_stats5); ?>" /></p>
  </form>
  </div>
  <br class="clear" />
</div>

<div class="fieldHeadWrapper">
  <p><span class="float"><a class="print" href="#" onclick="window.print();return false" title="<?php echo mc_cleanDataEnt($msg_stats17); ?>"><?php echo $msg_stats17; ?></a></span><?php echo $msg_stats2; ?>:</p>
</div>

<?php
if ($totalOrders==0) {
?>
<p class="noData"><?php echo (isset($_GET['cat']) || isset($_GET['from']) ? $msg_stats16 : $msg_sales17); ?></p>
<?php
} else {
$payStatuses = mc_loadDefaultStatuses();
?>
<div class="graphStats">
  <div class="left">
    <?php
    if ($PHYS->phys_qty>0 || $DOWN->down_qty>0 || $GIFT->gift_qty>0) {
    ?>
    <div id="chartdiv" style="height:300px;width:415px"></div>
    <script type="text/javascript">
     //<![CDATA[
     jQuery(document).ready(function() { 
      line1 = [['<?php echo str_replace("'","\'",$msg_stats12); ?>',<?php echo number_format($PHYS->phys_qty); ?>], ['<?php echo str_replace("'","\'",$msg_stats13); ?>',<?php echo number_format($DOWN->down_qty); ?>], ['<?php echo str_replace("'","\'",$msg_stats28); ?>',<?php echo number_format($GIFT->gift_qty); ?>]];
      plot1 = jQuery.jqplot('chartdiv', [line1], {
                        grid: {
                          borderWidth: 0,
                          shadow: false
                        },
                        seriesDefaults: {
                          renderer: jQuery.jqplot.PieRenderer, rendererOptions: {
                            sliceMargin: 4
                          }
                        },
                        legend: {
                          show: true
                        }
      });
     });
     //]]>
    </script>
    <?php
    }
    $urlString        = array();
    $urlExportString  = array();
    foreach ($payStatuses AS $key => $value) {
      $statCount              = getStatusStatCount($key);
      $orderStatsArray[$key]  = $statCount;
      $urlString[]            = urlencode($value).'-'.$statCount;
      $urlExportString[]      = $key.'-'.$statCount;
    }
    $defaultKeys = array_keys($orderStatsArray);
    // Get additional payment statuses..
    $q_add_stats = mysql_query("SELECT * FROM `".DB_PREFIX."paystatuses` 
                   ORDER BY `pMethod`,`statname`
                   ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($ST = mysql_fetch_object($q_add_stats)) {
      $statCount                 = getStatusStatCount($ST->id);
      $orderStatsArray[$ST->id]  = $statCount;
      $urlString[]               = urlencode(mc_cleanData($ST->statname)).'-'.$statCount;
      $urlExportString[]         = $ST->id.'-'.$statCount;
    }
    ?>
    
  </div>
  <div class="right">
    <?php 
    $fdate = enterDatesBox($fromDate);
    $tdate = enterDatesBox($toDate);
    echo str_replace(array('{from}','{to}'),array($fdate,$tdate),$msg_stats18); ?><br /><br />
    <p>
    <span class="statsRight">
    <?php
    foreach ($payStatuses AS $key => $value) {
    ?>
    <span class="status"><?php echo $value; ?>: <a href="?p=sales&amp;next=1&amp;filter=<?php echo $key; ?>" title="<?php echo mc_cleanDataEnt($value); ?>"><b><?php echo $orderStatsArray[$key]; ?></b></a></span>
    <?php
    }
    // Get additional payment statuses..
    $q_add_stats = mysql_query("SELECT * FROM `".DB_PREFIX."paystatuses` 
                   ORDER BY `pMethod`,`statname`
                   ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($ST = mysql_fetch_object($q_add_stats)) {
    ?>
    <span class="status"><?php echo mc_cleanData($ST->statname); ?>: <span class="highlight"><a href="?p=sales&amp;next=1&amp;filter=<?php echo $ST->id; ?>" title="<?php echo mc_cleanDataEnt($ST->statname); ?>"><b><?php echo $orderStatsArray[$ST->id]; ?></b></a></span></span>
    <?php
    }
    ?>
    </span>
    <?php echo $msg_stats11; ?>: <span class="highlight"><b><?php echo ($totalOrders>0 ? number_format($totalOrders) : 0); ?></b></span><br />
    <?php echo $msg_stats15; ?>: <span class="highlight"><b><?php echo ($DOWN->down_qty>0 || $PHYS->phys_qty>0 ? number_format($PHYS->phys_qty+$DOWN->down_qty+$GIFT->gift_qty) : 0); ?></b></span><br />
    <?php echo $msg_stats12; ?>: <span class="highlight"><b><?php echo ($PHYS->phys_qty>0 ? number_format($PHYS->phys_qty) : 0); ?></b></span><br />
    <?php echo $msg_stats13; ?>: <span class="highlight"><b><?php echo ($DOWN->down_qty>0 ? number_format($DOWN->down_qty) : 0); ?></b></span><br />
    <?php echo $msg_stats28; ?>: <span class="highlight"><b><?php echo ($GIFT->gift_qty>0 ? number_format($GIFT->gift_qty) : 0); ?></b></span><br /><br />
    <?php echo $msg_stats14; ?>: <span class="highlight"><b><?php echo mc_currencyFormat(($SUMS->gt>0 ? mc_formatPrice($SUMS->gt,true) : '0.00')); ?></b></span><br /><br />
    <span style="display:block;padding-bottom:30px">&nbsp;</span>
    </p>
  </div>
  <br class="clear" />
</div>

<div class="fieldHeadWrapper" style="margin-top:5px">
  <p><span class="float"><a class="print" href="#" onclick="window.print();return false" title="<?php echo mc_cleanDataEnt($msg_stats17); ?>"><?php echo $msg_stats17; ?></a></span><?php echo $msg_stats26; ?>:</p>
</div>

<div class="graphStats">
  <div class="left">
    <?php
    $mcounts = array();
    $js      = array();
    $qPMTHS  = mysql_query("SELECT `paymentMethod`,count(*) AS `cnt` FROM `".DB_PREFIX."sales`
               WHERE saleConfirmation = 'yes'
               AND `purchaseDate` BETWEEN '".mc_convertCalToSQLFormat($fromDate)."' AND '".mc_convertCalToSQLFormat($toDate)."'
               GROUP BY `paymentMethod`
               ORDER BY 2 DESC
               ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($PC = mysql_fetch_object($qPMTHS)) {
      $mcounts[$PC->paymentMethod] = $PC->cnt;
    }
    // Build js array..
    if (!empty($mcounts)) {
    foreach ($mcounts AS $k => $v) {
      if (isset($mcSystemPaymentMethods[$k])) {
        $js[] = "['".str_replace("'","\'",mc_paymentMethodName($k))."',".$mcounts[$k]."]";
      }
    }
    ?>
    <div id="chartdiv2" style="height:300px;width:415px"></div>
    <script type="text/javascript">
     //<![CDATA[
     jQuery(document).ready(function() { 
      line1 = [<?php echo implode(',',$js); ?>];
      plot1 = jQuery.jqplot('chartdiv2', [line1], {
                        grid: {
                          borderWidth: 0,
                          shadow: false
                        },
                        seriesDefaults: {
                          renderer: jQuery.jqplot.PieRenderer, rendererOptions: {
                            sliceMargin: 4
                          }
                        },
                        legend: {
                          show: true
                        }
      });
     });
     //]]>
    </script>
    <?php
    }
    ?>
  </div>
  <div class="right">
    <p>
    <?php
    if (!empty($mcounts)) {
    foreach ($mcounts AS $k => $v) {
    if (isset($methods[$k])) {
      echo $methods[$k]; 
    ?>: <span class="highlight"><a href="?p=sales&amp;pm=<?php echo $k; ?>" title="<?php echo mc_cleanDataEnt($methods[$k]); ?>"><b><?php echo $mcounts[$k]; ?></b></a></span><br />
    <?php
    }
    }
    ?>
    <span style="display:block;padding-bottom:30px">&nbsp;</span>
    <?php
    }
    ?>
    </p>
  </div>
  <br class="clear" />
</div>

<div class="fieldHeadWrapper" style="margin-top:5px">
  <p><span class="float"><a class="print" href="#" onclick="window.print();return false" title="<?php echo mc_cleanDataEnt($msg_stats17); ?>"><?php echo $msg_stats17; ?></a></span><?php echo $msg_stats27; ?>:</p>
</div>

<div class="graphStats">
  <div class="left">
    <?php
    $country  = array();
    $js       = array();
    $qPMTHS   = mysql_query("SELECT shipSetCountry,count(*) AS `cnt` FROM `".DB_PREFIX."sales`
                WHERE `saleConfirmation` = 'yes'
                AND `purchaseDate` BETWEEN '".mc_convertCalToSQLFormat($fromDate)."' AND '".mc_convertCalToSQLFormat($toDate)."'
                GROUP BY `shipSetCountry`
                ORDER BY 2 DESC
                ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($PC = mysql_fetch_object($qPMTHS)) {
      $country[$PC->shipSetCountry] = $PC->cnt;
    }
    // Build js array..
    if (!empty($country)) {
    foreach ($country AS $k => $v) {
      if (isset($country[$k])) {
        $js[] = "['".str_replace("'","\'",mc_getShippingCountry($k))."',".$country[$k]."]";
      }
    }
    ?>
    <div id="chartdiv3" style="height:300px;width:415px"></div>
    <script type="text/javascript">
     //<![CDATA[
     jQuery(document).ready(function() { 
      line1 = [<?php echo implode(',',$js); ?>];
      plot1 = jQuery.jqplot('chartdiv3', [line1], {
                        grid: {
                          borderWidth: 0,
                          shadow: false
                        },
                        seriesDefaults: {
                          renderer: jQuery.jqplot.PieRenderer, rendererOptions: {
                            sliceMargin: 4
                          }
                        },
                        legend: {
                          show: true
                        }
      });
     });
     //]]>
    </script>
    <?php
    }
    ?>
  </div>
  <div class="right">
    <p>
    <?php
    if (!empty($country)) {
    foreach ($country AS $k => $v) {
    if (isset($country[$k])) {
      echo mc_getShippingCountry($k); 
    ?>: <span class="highlight"><a href="?p=sales&amp;country=<?php echo $k; ?>" title="<?php echo mc_cleanDataEnt(mc_getShippingCountry($k)); ?>"><b><?php echo $country[$k]; ?></b></a></span><br />
    <?php
    }
    }
    ?>
    <span style="display:block;padding-bottom:30px">&nbsp;</span>
    <?php
    }
    ?>
    </p>
  </div>
  <br class="clear" />
</div>

<p class="rendering" style="text-align:right;padding:15px"><?php echo $msg_script51; ?>: <a href="http://www.jqPlot.com" onclick="window.open(this);return false" title="jqPlot">jqPlot</a> &copy; Chris Leonello</p>
<?php
}
?>

</div>
