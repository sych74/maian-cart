<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } ?>
<div id="content">
<script type="text/javascript">
//<![CDATA[
function changeButtonCount(form,type) {
  var count = 0;
  if (type=='all') {
    selectAll();
  }
  if (type=='single' && document.getElementById('log').checked==true) {
    document.getElementById('log').checked=false;
  }
  for (i = 0; i < form.elements.length; i++){
    var current = form.elements[i];
    if(current.name!='log' && current.type == 'checkbox' && current.checked){
      count++;
    }
  }
  if (count>0) {
    jQuery('#button').val('<?php echo str_replace(array("'","&#039;"),array("\'","\'"),mc_cleanDataEnt($msg_productmove7)); ?> ('+count+')');
  } else {
    jQuery('#button').val('<?php echo str_replace(array("'","&#039;"),array("\'","\'"),mc_cleanDataEnt($msg_productmove7)); ?> (0)');
  }
}
//]]>
</script>
<?php
if (isset($OK)) {
  echo actionCompleted(str_replace('{count}',count($_POST['products']),$msg_productmove10));
}
?>

<?php echo $msg_productmove; ?><br /><br />

<form method="post" id="form" action="?p=batch-move<?php echo (isset($_GET['cat']) ? '&amp;cat='.mc_digitSan($_GET['cat']) : ''); ?>" onsubmit="return confirmMessage('<?php echo mc_cleanDataEnt($msg_javascript45); ?>')">
<div class="fieldHeadWrapper">
  <p><?php echo $msg_productmove2; ?>:</p>
</div>

<div class="formFieldWrapper">
  <div class="formLeft">  
    <label><?php echo $msg_productmove4; ?>: <?php echo mc_displayHelpTip($msg_javascript205,'RIGHT'); ?></label>
    <select name="source" onchange="if(this.value!= 0){location=this.options[this.selectedIndex].value}" tabindex="1">
    <option value="0">- - - - - -</option>
    <?php
    $getFirstCat     = 0;
    $getFirstCatMan  = '';
    $q_cats = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
              WHERE catLevel = '1'
              AND childOf    = '0'
              AND enCat      = 'yes'
              ORDER BY catname") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($CATS = mysql_fetch_object($q_cats)) {
    ?>
    <option value="?p=batch-move&amp;cat=<?php echo $CATS->id; ?>"<?php echo (isset($_GET['cat']) && mc_digitSan($_GET['cat'])==$CATS->id ? ' selected="selected"' : ''); ?>><?php echo mc_cleanDataEnt($CATS->catname); ?></option>
    <?php
    $q_children = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
                  WHERE catLevel = '2'
                  AND enCat      = 'yes'
                  AND childOf    = '".$CATS->id."'
                  ORDER BY catname") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($CHILDREN = mysql_fetch_object($q_children)) {
    ?>
    <option value="?p=batch-move&amp;cat=<?php echo $CHILDREN->id; ?>"<?php echo (isset($_GET['cat']) && mc_digitSan($_GET['cat'])==$CHILDREN->id ? ' selected="selected"' : ''); ?>>- <?php echo mc_cleanDataEnt($CHILDREN->catname); ?></option>
    <?php
    $q_infants = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
                  WHERE catLevel = '3'
                  AND childOf    = '{$CHILDREN->id}'
                  AND enCat      = 'yes'
                  ORDER BY catname
                  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($INFANTS = mysql_fetch_object($q_infants)) {
    ?>
    <option value="?p=batch-move&amp;cat=<?php echo $INFANTS->id; ?>"<?php echo (isset($_GET['cat']) && mc_digitSan($_GET['cat'])==$INFANTS->id ? ' selected="selected"' : ''); ?>>&nbsp;&nbsp;- <?php echo mc_cleanDataEnt($INFANTS->catname); ?></option>
    <?php
    }
    }
    }
    ?>
  </select>
  </div>
  <div class="formRight">
    <label><?php echo $msg_productmove5; ?>: <?php echo mc_displayHelpTip($msg_javascript206); ?></label>
    <select name="destination" tabindex="2">
    <?php
    if (isset($_GET['cat'])) {
    $q_cats = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
              WHERE catLevel = '1'
              AND childOf    = '0'
              AND enCat      = 'yes'
              ORDER BY catname") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($CATS = mysql_fetch_object($q_cats)) {
    ?>
    <option value="<?php echo $CATS->id; ?>"<?php echo (isset($_GET['cat']) && mc_digitSan($_GET['cat'])==$CATS->id ? ' disabled="disabled"' : ''); ?>><?php echo mc_cleanDataEnt($CATS->catname); ?></option>
    <?php
    $q_children = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
                  WHERE catLevel = '2'
                  AND enCat      = 'yes'
                  AND childOf    = '".$CATS->id."'
                  ORDER BY catname") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($CHILDREN = mysql_fetch_object($q_children)) {
    ?>
    <option value="<?php echo $CHILDREN->id; ?>"<?php echo (isset($_GET['cat']) && mc_digitSan($_GET['cat'])==$CHILDREN->id ? ' disabled="disabled"' : ''); ?>>- <?php echo mc_cleanDataEnt($CHILDREN->catname); ?></option>
    <?php
    $q_infants = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
                  WHERE catLevel = '3'
                  AND childOf    = '{$CHILDREN->id}'
                  AND enCat      = 'yes'
                  ORDER BY catname
                  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($INFANTS = mysql_fetch_object($q_infants)) {
    ?>
    <option value="<?php echo $CHILDREN->id; ?>"<?php echo (isset($_GET['cat']) && mc_digitSan($_GET['cat'])==$INFANTS->id ? ' disabled="disabled"' : ''); ?>>&nbsp;&nbsp;- <?php echo mc_cleanDataEnt($INFANTS->catname); ?></option>
    <?php
    }
    }
    }
    } else {
    ?>
    <option value="0"><?php echo mc_cleanDataEnt($msg_productmove6); ?></option>
    <?php
    }
    ?>
  </select>
  </div>
  <br class="clear" />
</div>

<?php
if (isset($_GET['cat'])) {
$q_prod = mysql_query("SELECT *,".DB_PREFIX."products.id AS pid FROM ".DB_PREFIX."products
          LEFT JOIN ".DB_PREFIX."prod_category
          ON ".DB_PREFIX."products.id = ".DB_PREFIX."prod_category.product
          WHERE category = '".mc_digitSan($_GET['cat'])."'
          ORDER BY pName
          ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
?>
<div class="fieldHeadWrapper">
  <p>
  <?php
  if (mysql_num_rows($q_prod)>0) {
  ?>
  <span class="float"><?php echo $msg_productmove9; ?>: <input type="checkbox" id="log" name="log" onclick="changeButtonCount(this.form,'all')" /></span>
  <?php
  }
  ?>
  <?php echo $msg_productmove3; ?>:</p>
</div>
<?php
if (mysql_num_rows($q_prod)>0) {
while ($PRODUCTS = mysql_fetch_object($q_prod)) {
?>
<div class="formFieldWrapper">
  <p><span class="float"><input type="checkbox" name="products[]" value="<?php echo $PRODUCTS->pid; ?>" onclick="changeButtonCount(this.form,'single')" /></span><?php echo mc_cleanDataEnt($PRODUCTS->pName); ?></p>
</div>
<?php
}
} else {
?>
<p><span class="noData"><?php echo $msg_productmove8; ?></span></p>
<?php
}

if (mysql_num_rows($q_prod)>0) {
?>
<p style="text-align:center;padding-top:20px">
 <input type="hidden" name="process" value="1" />
 <input id="button" class="formbutton" type="submit" value="<?php echo mc_cleanDataEnt($msg_productmove7); ?> (0)" title="<?php echo mc_cleanDataEnt($msg_productmove7); ?>" />
</p>
<?php
}
}
?>
</form>

<p>&nbsp;</p>
<p>&nbsp;</p>
</div>
