<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } 
define('CALBOX', 'offlineDate');
include(PATH.'templates/date-picker.php');
?>
<div id="content">

<?php
$tabIndex = 0;
if (isset($OK)) {
  echo actionCompleted($msg_settings31);
  //Reload..
  $SETTINGS = mysql_fetch_object(mysql_query("SELECT * FROM ".DB_PREFIX."settings LIMIT 1")) 
              or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
}
?>

<?php echo $msg_settings; ?><br /><br />

<form method="post" id="form" action="?p=settings&amp;s=8">
<div class="fieldHeadWrapper">
  <p style="text-align:right"><span style="float:left;display:block;padding:3px 0 0 0"><?php echo $msg_settings77; ?></span>
  <?php
  include(PATH.'templates/system/menu.php');
  ?>
  </p>
</div>

<div class="formFieldWrapper">
  <div class="formLeft">
    <label><?php echo $msg_settings11; ?>: <?php echo mc_displayHelpTip($msg_javascript12,'RIGHT'); ?></label>
    <?php echo $msg_script5; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="enableCart" value="yes"<?php echo ($SETTINGS->enableCart=='yes' ? ' checked="checked"' : ''); ?> /> <?php echo $msg_script6; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="enableCart" value="no"<?php echo ($SETTINGS->enableCart=='no' ? ' checked="checked"' : ''); ?> /><br /><br />
    
    <label><?php echo $msg_settings85; ?>: <?php echo mc_displayHelpTip($msg_javascript228,'RIGHT'); ?></label>
    <input type="text" name="offlineDate" value="<?php echo ($SETTINGS->offlineDate!='0000-00-00' ? mc_convertMySQLDate($SETTINGS->offlineDate) : ''); ?>" class="box" style="width:30%" id="offlineDate" tabindex="<?php echo ++$tabIndex; ?>" /><br /><br />
  
    <label><?php echo $msg_settings243; ?>: <?php echo mc_displayHelpTip($msg_javascript463,'RIGHT'); ?></label>
    <input type="text" name="offlineIP" value="<?php echo $SETTINGS->offlineIP; ?>" class="box" style="width:80%" tabindex="<?php echo ++$tabIndex; ?>" /> 
  </div>
  <div class="formRight">
    <label><?php echo showBBCodeLink(false,'offlineText','offline').$msg_settings86; ?>: <?php echo mc_displayHelpTip($msg_javascript229,'LEFT'); ?></label>
    <textarea rows="5" cols="30" class="tarea" name="offlineText" id="offlineText" tabindex="<?php echo ++$tabIndex; ?>"><?php echo mc_cleanDataEnt($SETTINGS->offlineText); ?></textarea>
  </div>  
  <br class="clear" />
</div>

<p style="text-align:center;padding-top:20px">
 <input type="hidden" name="process" value="yes" />
 <input class="formbutton" type="submit" value="<?php echo mc_cleanDataEnt($msg_settings8); ?>" title="<?php echo mc_cleanDataEnt($msg_settings8); ?>" />
</p>
</form>

<p>&nbsp;</p>
<p>&nbsp;</p>
</div>
