<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } ?>
<div id="content">

<?php
$tabIndex = 0;
if (isset($OK)) {
  echo actionCompleted($msg_settings31);
  //Reload..
  $SETTINGS = mysql_fetch_object(mysql_query("SELECT * FROM ".DB_PREFIX."settings LIMIT 1")) 
              or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
}
$boxes = explode(',',$SETTINGS->contactDisplay);
?>

<?php echo $msg_settings; ?><br /><br />

<form method="post" id="form" action="?p=settings&amp;s=5">
<div class="fieldHeadWrapper">
  <p style="text-align:right"><span style="float:left;display:block;padding:3px 0 0 0"><?php echo $msg_settings77; ?></span>
  <?php
  include(PATH.'templates/system/menu.php');
  ?>
  </p>
</div>

<div class="formFieldWrapper">
  <div class="formLeft">
    <label><?php echo $msg_settings20; ?>: <?php echo mc_displayHelpTip($msg_javascript17,'RIGHT'); ?></label>
    <input type="text" name="cName" value="<?php echo mc_cleanDataEnt($SETTINGS->cName); ?>" class="box" tabindex="<?php echo ++$tabIndex; ?>" /> 
  </div>
  <div class="formRight">  
    <label><?php echo $msg_settings21; ?>: <?php echo mc_displayHelpTip($msg_javascript18,'LEFT'); ?></label>
    <input type="text" name="cWebsite" value="<?php echo mc_cleanDataEnt($SETTINGS->cWebsite); ?>" class="box" tabindex="<?php echo ++$tabIndex; ?>" />
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper">
  <div class="formLeft">
    <label><?php echo $msg_settings22; ?>: <?php echo mc_displayHelpTip($msg_javascript19,'RIGHT'); ?></label>
    <input type="text" name="cTel" value="<?php echo mc_cleanDataEnt($SETTINGS->cTel); ?>" class="box" tabindex="<?php echo ++$tabIndex; ?>" /> 
  </div>
  <div class="formRight">  
    <label><?php echo $msg_settings23; ?>: <?php echo mc_displayHelpTip($msg_javascript20,'LEFT'); ?></label>
    <input type="text" name="cFax" value="<?php echo mc_cleanDataEnt($SETTINGS->cFax); ?>" class="box" tabindex="<?php echo ++$tabIndex; ?>" />
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper">
  <div class="formLeft">
    <label><?php echo $msg_settings24; ?>: <?php echo mc_displayHelpTip($msg_javascript21,'RIGHT'); ?></label>
    <textarea rows="5" cols="30" name="cAddress" style="height:100px" tabindex="<?php echo ++$tabIndex; ?>"><?php echo mc_cleanDataEnt($SETTINGS->cAddress); ?></textarea><br />
    <label style="margin-top:8px"><?php echo $msg_settings267; ?>: <?php echo mc_displayHelpTip($msg_javascript487,'RIGHT'); ?></label>
    <textarea rows="5" cols="30" name="cReturns" style="height:100px" tabindex="<?php echo ++$tabIndex; ?>"><?php echo mc_cleanDataEnt($SETTINGS->cReturns); ?></textarea>
  </div>
  <div class="formRight">
    <label><?php echo $msg_settings32; ?>: <?php echo mc_displayHelpTip($msg_javascript98,'LEFT'); ?></label>
    <textarea rows="5" cols="30" name="cOther" style="height:250px" tabindex="<?php echo ++$tabIndex; ?>"><?php echo mc_cleanDataEnt($SETTINGS->cOther); ?></textarea>
  </div>  
  <br class="clear" />
</div>

<div class="fieldHeadWrapper">
  <p><span class="float"><a class="preview" href="../?p=contact-us" onclick="window.open(this);return false" title="<?php echo mc_cleanDataEnt($msg_settings206); ?>"><?php echo $msg_settings206; ?></a></span><?php echo $msg_settings205; ?></p>
</div>

<div class="formFieldWrapper">
  <p id="contactFields"><input type="checkbox" name="all" value="all" checked="checked" onclick="toggleCheckBoxesID(this.checked,'contactFields')" /> <b><?php echo $msg_settings207; ?></b>&nbsp;&nbsp;&nbsp;
  <?php
  foreach (
    array('cName'    => $msg_settings20,
          'cWebsite' => $msg_settings21,
          'cTel'     => $msg_settings22,
          'cFax'     => $msg_settings23,
          'cAddress' => $msg_settings24,
          'cOther'   => $msg_settings32
    ) AS $field => $value) {
    ?>
    <input type="checkbox" name="contact[]" value="<?php echo $field; ?>"<?php echo (in_array($field,$boxes) ? ' checked="checked"' : ''); ?> /> <?php echo $value; ?>&nbsp;&nbsp;&nbsp;
    <?php
  }
  ?>
  </p>
</div>

<p style="text-align:center;padding-top:20px">
 <input type="hidden" name="process" value="yes" />
 <input class="formbutton" type="submit" value="<?php echo mc_cleanDataEnt($msg_settings8); ?>" title="<?php echo mc_cleanDataEnt($msg_settings8); ?>" />
</p>
</form>

<p>&nbsp;</p>
<p>&nbsp;</p>
</div>
