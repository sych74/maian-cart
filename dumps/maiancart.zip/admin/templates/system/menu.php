<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } ?>
  <?php echo $msg_settings133; ?> <select onchange="if(this.value!= 0){location=this.options[this.selectedIndex].value}">
   <?php
   if (in_array('settings_1',$sysCartUser[3]) || $sysCartUser[1]!='restricted') {
   ?>
   <option value="?p=settings">- <?php echo $msg_settings7; ?></option>
   <?php
   }
   if (in_array('settings_3',$sysCartUser[3]) || $sysCartUser[1]!='restricted') {
   ?>
   <option value="?p=settings&amp;s=3"<?php echo (isset($_GET['s']) && $_GET['s']=='3' ? ' selected="selected"' : ''); ?>>- <?php echo $msg_settings50; ?></option>
   <?php
   }
   if (in_array('settings_8',$sysCartUser[3]) || $sysCartUser[1]!='restricted') {
   ?>
   <option value="?p=settings&amp;s=8"<?php echo (isset($_GET['s']) && $_GET['s']=='8' ? ' selected="selected"' : ''); ?>>- <?php echo $msg_settings84; ?></option>
   <?php
   }
   if (in_array('settings_2',$sysCartUser[3]) || $sysCartUser[1]!='restricted') {
   ?>
   <option value="?p=settings&amp;s=2"<?php echo (isset($_GET['s']) && $_GET['s']=='2' ? ' selected="selected"' : ''); ?>>- <?php echo $msg_settings61; ?></option>
   <?php
   }
   if (in_array('settings_9',$sysCartUser[3]) || $sysCartUser[1]!='restricted') {
   ?>
   <option value="?p=settings&amp;s=9"<?php echo (isset($_GET['s']) && $_GET['s']=='9' ? ' selected="selected"' : ''); ?>>- <?php echo $msg_settings116; ?></option>
   <?php
   }
   if (in_array('settings_4',$sysCartUser[3]) || $sysCartUser[1]!='restricted') {
   ?>
   <option value="?p=settings&amp;s=4"<?php echo (isset($_GET['s']) && $_GET['s']=='4' ? ' selected="selected"' : ''); ?>>- <?php echo $msg_settings54; ?></option>
   <?php
   }
   if (in_array('settings_5',$sysCartUser[3]) || $sysCartUser[1]!='restricted') {
   ?>
   <option value="?p=settings&amp;s=5"<?php echo (isset($_GET['s']) && $_GET['s']=='5' ? ' selected="selected"' : ''); ?>>- <?php echo $msg_settings19; ?></option>
   <?php
   }
   if (in_array('settings_6',$sysCartUser[3]) || $sysCartUser[1]!='restricted') {
   ?>
   <option value="?p=settings&amp;s=6"<?php echo (isset($_GET['s']) && $_GET['s']=='6' ? ' selected="selected"' : ''); ?>>- <?php echo $msg_settings25; ?></option>
   <?php
   }
   if (LICENCE_VER=='unlocked' && (in_array('settings_7',$sysCartUser[3]) || $sysCartUser[1]!='restricted')) {
   ?>
   <option value="?p=settings&amp;s=7"<?php echo (isset($_GET['s']) && $_GET['s']=='7' ? ' selected="selected"' : ''); ?>>- <?php echo $msg_settings65; ?></option>
   <?php
   }
   ?>
  </select>
