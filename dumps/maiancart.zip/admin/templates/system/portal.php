<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!!'); }
if (file_exists(PATH.'templates/header-custom.php')) {
  include_once(PATH.'templates/header-custom.php');
} else {
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php
}
?>
<meta http-equiv="Content-Type" content="application/xhtml+xml; charset=<?php echo $charset; ?>" />
<title><?php echo $pageTitle; ?></title>
<link href="templates/css/stylesheet.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="templates/js/overlib.js"><!-- overLIB (c) Erik Bosrup --></script>
<script type="text/javascript" src="templates/js/jquery.js"></script>
<link rel="SHORTCUT ICON" href="favicon.ico" />
<script type="text/javascript">
//<![CDATA[
function checkform() {
  var message = '';
  if (jQuery('#user').val()=='') {
    message += '- <?php echo str_replace("'","\'",mc_cleanDataEnt($msg_login5)); ?>\n';
    jQuery('#user').addClass('errorbox');
  }
  if (jQuery('#pass').val()=='') {
    message +='- <?php echo str_replace("'","\'",mc_cleanDataEnt($msg_login6)); ?>\n';
    jQuery('#pass').addClass('errorbox');
  }
  if (message) {
    alert(message);
    return false;
  }
}
//]]>
</script>
</head>


<body onload="jQuery('#user').focus()" class="loginBody">

<div id="loginWrapper">

<div id="loginHeader" class="tableTDHead">
 <p>- <?php echo $pageTitle; ?> -</p>
</div>

<div id="loginContent">
 <form method="post" id="form" action="?p=login" onsubmit="return checkform()">
 <p><label><?php echo $msg_login; ?>:</label>
 <input onkeyup="jQuery(this).removeClass('errorbox').addClass('box')" class="box" type="text" name="user" id="user" value="<?php echo (isset($_POST['user']) ? mc_cleanDataEnt($_POST['user']) : ''); ?>" />
 <?php echo (isset($U_ERROR) ? '<span class="error">[<b>X</b>] '.mc_cleanDataEnt($U_ERROR).'</span>' : ''); ?>
 <label style="margin:10px 0 0 0"><?php echo $msg_login2; ?>:</label>
 <input onkeyup="jQuery(this).removeClass('errorbox').addClass('box')" class="box" type="password" id="pass" name="pass" value="" />
 <?php echo (isset($P_ERROR) ? '<span class="error">[<b>X</b>] '.mc_cleanDataEnt($P_ERROR).'</span>' : ''); ?><br />
 <?php
 if (ENABLE_LOGIN_COOKIE) {
 ?>
 <label style="margin:10px 0 0 0"><?php echo $msg_login10; ?>: <?php echo mc_displayHelpTip($msg_javascript402); ?></label>
 <span class="rm"><?php echo $msg_script5; ?> <input type="radio" name="rm" value="yes" /> <?php echo $msg_script6; ?> <input type="radio" name="rm" value="no" checked="checked" /></span>
 <?php
 }
 ?>
 <input type="hidden" name="process" value="1" /><br />
 <span class="buttonWrapper"><input class="button" type="submit" value="<?php echo mc_cleanDataEnt($msg_login3); ?> &raquo;" title="<?php echo mc_cleanDataEnt($msg_login3); ?>" /></span>
 </p>
 </form>
</div>

</div>

</body>

</html>
