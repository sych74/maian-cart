<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } 
if (isset($_GET['edit'])) {
  $EDIT  = mc_getTableData('news_ticker','id',mc_digitSan($_GET['edit']));
}
?>
<div id="content">

<?php
if (isset($OK)) {
  echo actionCompleted($msg_newsticker5);
}
if (isset($OK2)) {
  echo actionCompleted($msg_newsticker9);
}
if (isset($OK3) && $cnt>0) {
  echo actionCompleted($msg_newsticker7);
}
?>

<?php echo $msg_newsticker11; ?><br /><br />

<form method="post" id="form" action="?p=news<?php echo (isset($EDIT->id) ? '&amp;edit='.$EDIT->id : ''); ?>">
<div class="fieldHeadWrapper">
  <p>
  <?php
  echo (isset($EDIT->id) ? $msg_newsticker6 : $msg_newsticker); ?>:</p>
</div>

<div class="formFieldWrapper">
  <div class="formLeft" style="width:79%">
    <label><?php echo $msg_newsticker2; ?>: <?php echo mc_displayHelpTip($msg_javascript422,'RIGHT'); ?></label>
    <input type="text" name="newsText" tabindex="<?php echo (++$tabIndex); ?>" value="<?php echo (isset($EDIT->newsText) ? mc_cleanDataEnt($EDIT->newsText) : ''); ?>" class="box" />
  </div>
  <div class="formRight" style="width:20%">  
    <label><?php echo $msg_newsticker8; ?>: <?php echo mc_displayHelpTip($msg_javascript423,'LEFT'); ?></label>
    <?php echo $msg_script5; ?> <input tabindex="<?php echo (++$tabIndex); ?>" type="radio" name="enabled" value="yes"<?php echo (isset($EDIT->enabled) && $EDIT->enabled=='yes' ? ' checked="checked"' : (!isset($EDIT->id) ? ' checked="checked"' : '')); ?> /> <?php echo $msg_script6; ?> <input type="radio" tabindex="<?php echo (++$tabIndex); ?>" name="enabled" value="no"<?php echo (isset($EDIT->enabled) && $EDIT->enabled=='no' ? ' checked="checked"' : ''); ?> />
  </div>
  <br class="clear" />
</div>

<p style="text-align:center;padding-top:20px">
 <input type="hidden" name="<?php echo (isset($EDIT->id) ? 'update' : 'process'); ?>" value="<?php echo (isset($EDIT->id) ? $EDIT->id : 'yes'); ?>" />
 <input class="formbutton" type="submit" value="<?php echo mc_cleanDataEnt((isset($EDIT->id) ? $msg_newsticker6 : $msg_newsticker)); ?>" title="<?php echo mc_cleanDataEnt((isset($EDIT->id) ? $msg_newsticker6 : $msg_newsticker)); ?>" /><?php echo (isset($EDIT->id) ? '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input class="formbutton2" type="button" onclick="window.location=\'?p=news\'" value="'.mc_cleanDataEnt($msg_script11).'" title="'.mc_cleanDataEnt($msg_script11).'" />' : ''); ?>
</p>
</form><br />
<?php
if (mc_rowCount('news_ticker')>0) {
?>
<script type="text/javascript">
//<![CDATA[
jQuery(document).ready(function() {
  jQuery("#sortable").sortable({
    update : function (data) {
      jQuery("#loader").load("index.php?p=news&order=yes&"+jQuery('#sortable').sortable('serialize'));
      jQuery('#loader_msg').show('slow');
      jQuery('#loader_msg').html('<?php echo mc_cleanDataEnt($msg_javascript273); ?>').fadeOut(6000);
    }
  });
});
//]]>
</script>
<?php
}
?>
<div class="fieldHeadWrapper">
  <p><span class="float" id="loader"></span><span class="float" id="loader_msg" style="display:none" onclick="jQuery(this).hide()"></span><?php echo $msg_newsticker4; ?></p>
</div>

<div id="sortable">
<?php
$q_nt = mysql_query("SELECT * FROM ".DB_PREFIX."news_ticker
        ORDER BY orderBy
        ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
if (mysql_num_rows($q_nt)>0) {
  while ($TICKER = mysql_fetch_object($q_nt)) {
  ?>
  <div class="catWrapper" id="nt-<?php echo $TICKER->id; ?>" style="cursor:move" title="<?php echo mc_cleanDataEnt($msg_newsticker10); ?>">
    <div class="catLeft" style="width:93%"><?php echo mc_cleanData($TICKER->newsText); ?></div>
    <div class="catRight" style="width:5%;text-align:center;padding:5px 0 3px 0;margin-right:0;background:#fff;float:right"><a href="?p=news&amp;edit=<?php echo $TICKER->id; ?>"><img src="templates/images/edit.png" alt="<?php echo mc_cleanDataEnt($msg_script9); ?>" title="<?php echo mc_cleanDataEnt($msg_script9); ?>" /></a><?php echo ($uDel=='yes' ? ' <a href="?p=news&amp;del='.$TICKER->id.'" onclick="return confirmMessage(\''.mc_cleanDataEnt($msg_javascript45).'\')"><img src="templates/images/delete.png" alt="'.mc_cleanDataEnt($msg_script10).'" title="'.mc_cleanDataEnt($msg_script10).'" /></a>' : ''); ?></div>
    <br class="clear" />
  </div>
  <?php
  }
} else {
?>
<span class="noData"><?php echo $msg_newsticker3; ?></span>
<?php
}
?>
</div>

<p>&nbsp;</p>
<p>&nbsp;</p>
</div>
