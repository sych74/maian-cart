<?php

// Quick links that appear on admin homepage. Add more if required..

?>
<li><a href="?p=settings&amp;s=3&amp;global=yes" title="<?php echo mc_cleanDataEnt($msg_main12); ?>"><?php echo $msg_main12; ?></a></li>
<li><a href="?p=manage-products" title="<?php echo mc_cleanDataEnt($msg_main13); ?>"><?php echo $msg_main13; ?></a></li>
<li><a href="?p=settings&amp;s=3" title="<?php echo mc_cleanDataEnt($msg_main14); ?>"><?php echo $msg_main14; ?></a></li>
<li><a href="?p=sales" title="<?php echo mc_cleanDataEnt($msg_main15); ?>"><?php echo $msg_main15; ?></a></li>
<li><a href="?p=settings&amp;s=4" title="<?php echo mc_cleanDataEnt($msg_main16); ?>"><?php echo $msg_main16; ?></a></li>
