<?php

//----------------------------------------------------------------------
// QUICK LINKS
//
// Appear on admin homepage. Examples below. Add more if required..
//
// Uncomment to use..
//----------------------------------------------------------------------

/*
?>
<div class="panel panel-default">
  <div class="panel-heading">
    <i class="fa fa-chain fa-fw"></i> Quick Links
  </div>
  <div class="panel-body">
    <a href="?p=settings&amp;s=3&amp;global=yes" title="<?php echo mc_cleanDataEntVars($msg_main12); ?>"><?php echo $msg_main12; ?></a><br>
    <a href="?p=manage-products" title="<?php echo mc_cleanDataEntVars($msg_main13); ?>"><?php echo $msg_main13; ?></a><br>
    <a href="?p=settings&amp;s=3" title="<?php echo mc_cleanDataEntVars($msg_main14); ?>"><?php echo $msg_main14; ?></a><br>
    <a href="?p=sales" title="<?php echo mc_cleanDataEntVars($msg_main15); ?>"><?php echo $msg_main15; ?></a><br>
    <a href="?p=settings&amp;s=4" title="<?php echo mc_cleanDataEntVars($msg_main16); ?>"><?php echo $msg_main16; ?></a>
  </div>
</div>
<?php
*/
?>
