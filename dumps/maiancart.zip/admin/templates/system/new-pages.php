<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } 
if (isset($_GET['edit'])) {
  $EDIT = mc_getTableData('newpages','id',mc_digitSan($_GET['edit']));
  $pos  = explode(',',$EDIT->linkPos);
}
?>
<div id="content">

<?php
if (isset($OK)) {
  echo actionCompleted($msg_newpages10);
}
if (isset($OK2)) {
  echo actionCompleted($msg_newpages11);
}
if (isset($OK3) && $cnt>0) {
  echo actionCompleted($msg_newpages12);
}
?>

<?php echo $msg_newpages; ?><br /><br />

<form method="post" action="?p=newpages<?php echo (isset($EDIT->id) ? '&amp;edit='.$EDIT->id : ''); ?>">
<div class="fieldHeadWrapper">
  <p><?php echo (isset($EDIT->id) ? $msg_newpages6 : $msg_newpages3); ?>:</p>
</div>

<div class="formFieldWrapper">
  <div class="formLeft" style="width:33%">
    <label><?php echo $msg_newpages2; ?>: <?php echo mc_displayHelpTip($msg_javascript202,'RIGHT'); ?></label>
    <input type="text" name="pageName" onkeyup="slugSuggestions(this.value)" tabindex="<?php echo (++$tabIndex); ?>" maxlength="250" value="<?php echo (isset($EDIT->pageName) ? mc_cleanDataEnt($EDIT->pageName) : ''); ?>" class="box" /> 
  </div>
  <div class="formLeft" style="width:33%">  
    <label><?php echo $msg_newpages4; ?>: <?php echo mc_displayHelpTip($msg_javascript203); ?></label>
    <input type="text" name="pageKeys" tabindex="<?php echo (++$tabIndex); ?>" value="<?php echo (isset($EDIT->pageKeys) ? mc_cleanDataEnt($EDIT->pageKeys) : ''); ?>" class="box" />
  </div>
  <div class="formRight" style="width:33%">  
    <label><?php echo $msg_newpages5; ?>: <?php echo mc_displayHelpTip($msg_javascript203,'LEFT'); ?></label>
    <input type="text" name="pageDesc" tabindex="<?php echo (++$tabIndex); ?>" value="<?php echo (isset($EDIT->pageDesc) ? mc_cleanDataEnt($EDIT->pageDesc) : ''); ?>" class="box" />
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper" id="ptWrap" style="height:280px<?php echo (!isset($EDIT->id) || isset($EDIT->id) && $EDIT->customTemplate=='' ? '' : ';display:none'); ?>">
  <label><?php echo showBBCodeLink(false,'ptTextArea','users').$msg_newpages8; ?>: <?php echo mc_displayHelpTip($msg_javascript204,'RIGHT'); ?></label>
  <textarea rows="5" cols="30" name="pageText" tabindex="<?php echo (++$tabIndex); ?>" style="height:250px;width:98%" id="ptTextArea"><?php echo (isset($EDIT->pageText) ? mc_cleanDataEnt(mc_cleanData($EDIT->pageText))  : ''); ?></textarea>
  <br class="clear" />
</div>

<?php
if ((!isset($EDIT->id) || (isset($EDIT->id) && $EDIT->id!=1))) {
?>
<div class="formFieldWrapper" id="ctWrap">
  <div class="formLeft" style="width:41%">
   <label><?php echo $msg_newpages22; ?>: <?php echo mc_displayHelpTip($msg_javascript380,'RIGHT'); ?></label>
   <select name="customTemplate" onchange="if(this.value!=''){jQuery('#ptWrap').hide('slow');}else{jQuery('#ptWrap').show('slow');}">
   <option value="">- - - - - -</option>
   <?php
   $showtmp = opendir(REL_PATH.THEME_FOLDER.'/customTemplates/');
   while (false!==($read=readdir($showtmp))) {
     if (substr($read,-8)=='.tpl.php') {
       echo '<option value="'.$read.'"'.(isset($EDIT->customTemplate) && $read==$EDIT->customTemplate ? ' selected="selected"' : '').'>'.$read.'</option>'.mc_defineNewline();
     }
   }
   closedir($showtmp);
   ?>
   </select>
  </div>
  <div class="formLeft" style="width:29%">
    <label><?php echo $msg_newpages18; ?>: <?php echo mc_displayHelpTip($msg_javascript332); ?></label>
    <?php echo $msg_script5; ?> <input type="radio" tabindex="<?php echo (++$tabIndex); ?>" name="linkExternal" value="yes"<?php echo (isset($EDIT->linkExternal) && $EDIT->linkExternal=='yes' ? ' checked="checked"' : ''); ?> /> <?php echo $msg_script6; ?> <input type="radio" tabindex="<?php echo (++$tabIndex); ?>" name="linkExternal" value="no"<?php echo (isset($EDIT->linkExternal) && $EDIT->linkExternal=='no' ? ' checked="checked"' : (!isset($EDIT->linkExternal) ? ' checked="checked"' : '')); ?> />
  </div>
  <div class="formRight" style="width:29%">
    <label><?php echo $msg_newpages24; ?>: <?php echo mc_displayHelpTip($msg_javascript404,'LEFT'); ?></label>
    <select name="linkTarget">
    <option value="new"<?php echo (isset($EDIT->linkTarget) && $EDIT->linkTarget=='new' ? ' selected="selected"' : ''); ?>><?php echo $msg_newpages26; ?></option>
    <option value="same"<?php echo (isset($EDIT->linkTarget) && $EDIT->linkTarget=='same' ? ' selected="selected"' : ''); ?>><?php echo $msg_newpages25; ?></option>
    </select>
  </div>
  <br class="clear" />
</div>
<?php
}
?>

<div class="formFieldWrapper">
  <div class="formLeft" style="width:41%">
    <label><?php echo $msg_newpages14; ?>: <?php echo mc_displayHelpTip($msg_javascript308,'RIGHT'); ?></label>
    <?php echo $msg_newpages15; ?> <input type="checkbox" tabindex="<?php echo (++$tabIndex); ?>" name="linkPos[]" value="1"<?php echo (isset($EDIT->linkPos) && in_array(1,$pos) ? ' checked="checked"' : ''); ?> />&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $msg_newpages16; ?> <input type="checkbox" tabindex="<?php echo (++$tabIndex); ?>" name="linkPos[]" value="2"<?php echo (isset($EDIT->linkPos) && in_array(2,$pos) ? ' checked="checked"' : ''); ?> />&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $msg_newpages17; ?> <input type="checkbox" tabindex="<?php echo (++$tabIndex); ?>" name="linkPos[]" value="3"<?php echo (isset($EDIT->linkPos) && in_array(3,$pos) ? ' checked="checked"' : ''); ?> />
  </div>
  <div class="formLeft" style="width:29%">
    <label><?php echo $msg_newpages27; ?>: <?php echo mc_displayHelpTip($msg_javascript418); ?></label>
    <?php echo $msg_script5; ?> <input type="radio" tabindex="<?php echo (++$tabIndex); ?>" name="landingPage" value="yes"<?php echo (isset($EDIT->landingPage) && $EDIT->landingPage=='yes' ? ' checked="checked"' : ''); ?> /> <?php echo $msg_script6; ?> <input type="radio" tabindex="<?php echo (++$tabIndex); ?>" name="landingPage" value="no"<?php echo (isset($EDIT->landingPage) && $EDIT->landingPage=='no' ? ' checked="checked"' : (!isset($EDIT->landingPage) ? ' checked="checked"' : '')); ?> />
  </div>
  <div class="formRight" style="width:29%">
    <label><?php echo $msg_newpages28; ?>: <?php echo mc_displayHelpTip($msg_javascript451,'LEFT'); ?></label>
    <?php echo $msg_newpages29; ?> <input type="radio" tabindex="<?php echo (++$tabIndex); ?>" name="leftColumn" value="yes"<?php echo (isset($EDIT->leftColumn) && $EDIT->leftColumn=='yes' ? ' checked="checked"' : (!isset($EDIT->leftColumn) ? ' checked="checked"' : '')); ?> /> <?php echo $msg_newpages30; ?> <input type="radio" tabindex="<?php echo (++$tabIndex); ?>" name="leftColumn" value="no"<?php echo (isset($EDIT->leftColumn) && $EDIT->leftColumn=='no' ? ' checked="checked"' : ''); ?> />
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper">
  <div class="formLeft" style="width:41%">
    <label><?php echo $msg_newpages31; ?>: <?php echo mc_displayHelpTip($msg_javascript470,'RIGHT'); ?></label>
    <input type="text" name="rwslug" id="rwslug" onkeyup="slugCleaner()" tabindex="<?php echo (++$tabIndex); ?>" maxlength="250" value="<?php echo (isset($EDIT->rwslug) ? mc_cleanDataEnt($EDIT->rwslug) : ''); ?>" class="box" /> 
  </div>
  <div class="formLeft" style="width:29%">
  </div>
    <label><?php echo $msg_newpages13; ?>: <?php echo mc_displayHelpTip($msg_javascript6,'RIGHT'); ?></label>
    <?php echo $msg_script5; ?> <input type="radio" tabindex="<?php echo (++$tabIndex); ?>" name="enabled" value="yes"<?php echo (isset($EDIT->enabled) && $EDIT->enabled=='yes' ? ' checked="checked"' : (!isset($EDIT->enabled) ? ' checked="checked"' : '')); ?> /> <?php echo $msg_script6; ?> <input type="radio" tabindex="<?php echo (++$tabIndex); ?>" name="enabled" value="no"<?php echo (isset($EDIT->enabled) && $EDIT->enabled=='no' ? ' checked="checked"' : ''); ?> />
  <div class="formRight" style="width:29%">
  </div>
  <br class="clear" />
</div>

<p style="text-align:center;padding-top:20px">
  <input type="hidden" name="<?php echo (isset($EDIT->id) ? 'update' : 'process'); ?>" value="yes" />
  <input class="formbutton" type="submit" value="<?php echo mc_cleanDataEnt((isset($EDIT->id) ? $msg_newpages6 : $msg_newpages3)); ?>" title="<?php echo mc_cleanDataEnt((isset($EDIT->id) ? $msg_newpages6 : $msg_newpages3)); ?>" /><?php echo (isset($EDIT->id) ? '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input class="formbutton2" type="button" onclick="window.location=\'?p=newpages\'" value="'.mc_cleanDataEnt($msg_script11).'" title="'.mc_cleanDataEnt($msg_script11).'" />' : ''); ?>
</p>
</form><br />

<div class="fieldHeadWrapper">
  <p><span class="float" id="loader"></span><span class="float" id="loader_msg" style="display:none" onclick="jQuery(this).hide()"></span><?php echo $msg_newpages7; ?>:</p>
</div>
<?php
if (mc_rowCount('newpages')>0) {
?>
<script type="text/javascript">
//<![CDATA[
jQuery(document).ready(function() {
  jQuery("#sortable").sortable({
    update : function (data) {
      jQuery("#loader").load("index.php?p=newpages&order=yes&"+jQuery('#sortable').sortable('serialize'));
      jQuery('#loader_msg').show('slow');
      jQuery('#loader_msg').html('<?php echo mc_cleanDataEnt($msg_javascript273); ?>').fadeOut(6000);
    }
  });
});
//]]>
</script>
<?php
}
?>
<div id="sortable">
<?php
$q_npages = mysql_query("SELECT * FROM ".DB_PREFIX."newpages 
            ORDER BY `orderBy`
            ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
if (mysql_num_rows($q_npages)>0) {
  while ($NPAGES = mysql_fetch_object($q_npages)) {
  ?>
  <div class="catWrapper" id="pg-<?php echo $NPAGES->id; ?>" style="cursor:move" title="<?php echo mc_cleanDataEnt($msg_cats20); ?>">
    <div class="catLeft" style="width:86%"><?php echo ($NPAGES->landingPage=='yes' ? '<span style="float:right" class="highlight">'.$msg_newpages27.'</span>' : ''); ?><a href="<?php echo ($NPAGES->linkExternal=='yes' ? mc_cleanData(trim($NPAGES->pageText)) : '../?np='.$NPAGES->id); ?>" onclick="window.open(this);return false" title="<?php echo mc_cleanDataEnt($NPAGES->pageName); ?>"><?php echo mc_cleanDataEnt($NPAGES->pageName); ?></a><?php echo ($NPAGES->customTemplate ? '<span class="newPageCustom">'.$msg_newpages23.'<span class="highlight">'.$NPAGES->customTemplate.'</span></span>' : ''); ?></div>
    <div class="catLeft" style="width:5%;text-align:center" id="status_<?php echo $NPAGES->id; ?>"><a id="alink_<?php echo $NPAGES->id; ?>" href="#" onclick="pageManagement('<?php echo $NPAGES->id; ?>');return false" title="<?php echo mc_cleanDataEnt(($NPAGES->enabled=='yes' ? $msg_newpages19 : $msg_newpages20)); ?>"><img id="img_<?php echo $NPAGES->id; ?>" src="templates/images/page_<?php echo ($NPAGES->enabled=='yes' ? 'enabled' : 'disabled'); ?>.gif" alt="<?php echo mc_cleanDataEnt($msg_newpages21); ?>" title="<?php echo mc_cleanDataEnt($msg_newpages21); ?>" /></a></div>
    <div class="catRight" style="width:5%;text-align:center;padding:5px 0 3px 0;margin-right:0;background:#fff;float:right"><a href="?p=newpages&amp;edit=<?php echo $NPAGES->id; ?>"><img src="templates/images/edit.png" alt="<?php echo mc_cleanDataEnt($msg_script9); ?>" title="<?php echo mc_cleanDataEnt($msg_script9); ?>" /></a><?php echo ($NPAGES->id>1 && $uDel=='yes' ? '<a href="?p=newpages&amp;del='.$NPAGES->id.'" onclick="return confirmMessage(\''.mc_cleanDataEnt($msg_javascript45).'\')"><img src="templates/images/delete.png" alt="'.mc_cleanDataEnt($msg_script10).'" title="'.mc_cleanDataEnt($msg_script10).'" /></a>' : ''); ?></div>
    <br class="clear" />
  </div>
  <?php
  }
} else {
?>
<span class="noData"><?php echo $msg_newpages9; ?></span>
<?php
}
?>
</div>

<p>&nbsp;</p>
<p>&nbsp;</p>
</div>
