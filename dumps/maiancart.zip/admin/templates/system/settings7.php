<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } ?>
<div id="content">

<?php
$tabIndex = 0;
if (isset($OK)) {
  echo actionCompleted($msg_settings31);
  //Reload..
  $SETTINGS = mysql_fetch_object(mysql_query("SELECT * FROM ".DB_PREFIX."settings LIMIT 1")) 
              or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
}
?>

<?php echo $msg_settings; ?><br /><br />

<form method="post" id="form" action="?p=settings&amp;s=7">
<div class="fieldHeadWrapper">
  <p style="text-align:right"><span style="float:left;display:block;padding:3px 0 0 0"><?php echo $msg_settings77; ?></span>
  <?php
  include(PATH.'templates/system/menu.php');
  ?>
  </p>
</div>

<div class="formFieldWrapper">
  <div class="formLeft">
    <label><?php echo $msg_settings66; ?>: <?php echo mc_displayHelpTip($msg_javascript211,'RIGHT'); ?></label>
    <textarea rows="5" cols="30" name="publicFooter" tabindex="<?php echo ++$tabIndex; ?>"><?php echo mc_cleanDataEnt($SETTINGS->publicFooter); ?></textarea>
  </div>
  <div class="formRight">
    <label><?php echo $msg_settings67; ?>: <?php echo mc_displayHelpTip($msg_javascript210,'LEFT'); ?></label>
    <textarea rows="5" cols="30" name="adminFooter" tabindex="<?php echo ++$tabIndex; ?>"><?php echo mc_cleanDataEnt($SETTINGS->adminFooter); ?></textarea>
  </div>  
  <br class="clear" />
</div>

<p style="text-align:center;padding-top:20px">
 <input type="hidden" name="process" value="yes" />
 <input class="formbutton" type="submit" value="<?php echo mc_cleanDataEnt($msg_settings8); ?>" title="<?php echo mc_cleanDataEnt($msg_settings8); ?>" />
</p>
</form>

<p>&nbsp;</p>
<p>&nbsp;</p>
</div>
