<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } 
$encVer = (function_exists('ioncube_loader_version') ? ioncube_loader_version() : $SETTINGS->encoderVersion);
if ($SETTINGS->prodKey=='' || strlen($SETTINGS->prodKey)!=60 || $SETTINGS->encoderVersion=='XX') {
  $productKey = mc_generateProductKey();
  mysql_query("UPDATE `".DB_PREFIX."settings` SET
  `prodKey`        = '{$productKey}',
  `encoderVersion` = '{$encVer}'
  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  $SETTINGS->prodKey = $productKey;
}
?>
<div id="content">

<?php 
echo str_replace(array('{licence_key}','{ioncube}'),array(strtoupper($SETTINGS->prodKey),$encVer),$msg_purchase); 
?> 
<br /><br />

</div>