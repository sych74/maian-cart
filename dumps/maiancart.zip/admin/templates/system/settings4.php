<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } ?>
<div id="content">

<?php
$tabIndex = 0;
if (isset($OK)) {
  echo actionCompleted($msg_settings31);
  //Reload..
  $SETTINGS = mysql_fetch_object(mysql_query("SELECT * FROM ".DB_PREFIX."settings LIMIT 1")) 
              or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
}
$pIDs   = explode(',',$SETTINGS->homeProdCats);
?>

<?php echo $msg_settings; ?><br /><br />

<form method="post" id="form" action="?p=settings&amp;s=4">
<div class="fieldHeadWrapper">
  <p style="text-align:right"><span style="float:left;display:block;padding:3px 0 0 0"><?php echo $msg_settings77; ?></span>
  <?php
  include(PATH.'templates/system/menu.php');
  ?>
  </p>
</div>

<div class="formFieldWrapper" id="topData" style="height:185px">
  <div class="formLeft">
    <label><?php echo $msg_settings55; ?>: <?php echo mc_displayHelpTip($msg_javascript189,'RIGHT'); ?></label>
    <input type="text" name="homeProdValue" value="<?php echo $SETTINGS->homeProdValue; ?>" maxlength="3" class="box" style="width:15%" /> 
    <select name="homeProdType" tabindex="<?php echo ++$tabIndex; ?>">
    <option value="latest"<?php echo ($SETTINGS->homeProdType=='latest' ? ' selected="selected"' : ''); ?>><?php echo $msg_settings56; ?></option>
    <option value="random"<?php echo ($SETTINGS->homeProdType=='random' ? ' selected="selected"' : ''); ?>><?php echo $msg_settings57; ?></option>
    </select>
  </div>
  <div class="formRight">  
    <label><?php echo $msg_settings58; ?>: <?php echo mc_displayHelpTip($msg_javascript190,'LEFT'); ?></label>
    <div class="categoryBoxes" id="homeProdCatsArea">
    <input type="checkbox" name="homeProdCats[]" value="all" onclick="toggleCheckBoxesID(this.checked,'homeProdCatsArea')"<?php echo (in_array('all',$pIDs) ? ' checked="checked"' : ''); ?> /> <b><?php echo $msg_productadd35; ?></b><br />
    <?php
    $q_cats = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
              WHERE catLevel = '1'
              AND childOf    = '0'
              AND enCat      = 'yes'
              ORDER BY catname") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($CATS = mysql_fetch_object($q_cats)) {
    ?>
    <p id="cat_<?php echo $CATS->id; ?>"><input onclick="if(this.checked){selectChildren('cat_<?php echo $CATS->id; ?>','on')}else{selectChildren('cat_<?php echo $CATS->id; ?>','off')}" tabindex="<?php echo ++$tabIndex; ?>" type="checkbox" name="homeProdCats[]" value="<?php echo $CATS->id; ?>"<?php echo (in_array($CATS->id,$pIDs) ? ' checked="checked"' : ''); ?> /> <?php echo mc_cleanDataEnt($CATS->catname); ?><br />
    <?php
    $q_children = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
                  WHERE catLevel = '2'
                  AND enCat      = 'yes'
                  AND childOf    = '".$CATS->id."'
                  ORDER BY catname") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($CHILDREN = mysql_fetch_object($q_children)) {
    ?>
    <span id="child_<?php echo $CHILDREN->id; ?>">
    &nbsp;&nbsp;<input onclick="if(this.checked){selectChildren('child_<?php echo $CHILDREN->id; ?>','on')}else{selectChildren('child_<?php echo $CHILDREN->id; ?>','off')}" type="checkbox" tabindex="<?php echo ++$tabIndex; ?>" name="homeProdCats[]" value="<?php echo $CHILDREN->id; ?>"<?php echo (in_array($CHILDREN->id,$pIDs) ? ' checked="checked"' : ''); ?> /> <?php echo mc_cleanDataEnt($CHILDREN->catname); ?><br />
    <?php
    $q_infants = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
                  WHERE catLevel = '3'
                  AND childOf    = '{$CHILDREN->id}'
                  AND enCat      = 'yes'
                  ORDER BY catname
                  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($INFANTS = mysql_fetch_object($q_infants)) {
    ?>
    &nbsp;&nbsp;&nbsp;&nbsp;<input type="checkbox" tabindex="<?php echo ++$tabIndex; ?>" name="homeProdCats[]" value="<?php echo $INFANTS->id; ?>"<?php echo (in_array($INFANTS->id,$pIDs) ? ' checked="checked"' : ''); ?> /> <?php echo mc_cleanDataEnt($INFANTS->catname); ?><br />
    <?php
    }
    ?>
    </span>
    <?php
    }
    ?>
    </p>
    <?php
    }
    ?>
    </div>
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper" id="bottomData" style="display:none;height:185px">
  <div class="formLeft">
    <label><?php echo $msg_settings148; ?>: </label>
    <div class="categoryBoxes">
    <?php
    $cats   = array();
    $q_cats = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
              WHERE catLevel = '1'
              AND childOf    = '0'
              AND enCat      = 'yes'
              ORDER BY catname") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($CATS = mysql_fetch_object($q_cats)) {
    $cats[] = $CATS->id;
    ?>
    <input tabindex="<?php echo ++$tabIndex; ?>" onclick="loadHomeProducts('cat-<?php echo $CATS->id; ?>')" type="radio" name="pCat" value="<?php echo $CATS->id; ?>"<?php echo (count($cats)==1 ? ' checked="checked"' : ''); ?> /> <?php echo mc_cleanDataEnt($CATS->catname); ?><br />
    <?php
    $q_children = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
                  WHERE catLevel = '2'
                  AND enCat      = 'yes'
                  AND childOf    = '".$CATS->id."'
                  ORDER BY catname") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($CHILDREN = mysql_fetch_object($q_children)) {
    ?>
    &nbsp;&nbsp;<input tabindex="<?php echo ++$tabIndex; ?>" onclick="loadHomeProducts('child-<?php echo $CHILDREN->id; ?>')" type="radio" name="pCat" value="<?php echo $CHILDREN->id; ?>" /> <?php echo mc_cleanDataEnt($CHILDREN->catname); ?><br />
    <?php
    $q_infants = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
                  WHERE catLevel = '3'
                  AND childOf    = '{$CHILDREN->id}'
                  AND enCat      = 'yes'
                  ORDER BY catname
                  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($INFANTS = mysql_fetch_object($q_infants)) {
    ?>
    &nbsp;&nbsp;&nbsp;&nbsp;<input tabindex="<?php echo ++$tabIndex; ?>" onclick="loadHomeProducts('infant-<?php echo $INFANTS->id; ?>')" type="radio" name="pCat" value="<?php echo $INFANTS->id; ?>" /> <?php echo mc_cleanDataEnt($INFANTS->catname); ?><br />
    <?php
    }
    }
    }
    ?>
    </div>
  </div>
  <div class="formRight">
  <label style="text-align:right">[X] <a onclick="jQuery('#bottomData').hide('slow');jQuery('#topData').show('slow');return false" href="#" title="<?php echo mc_cleanDataEnt($msg_settings149); ?>"><?php echo $msg_settings149; ?></a></label>
  <div class="categoryBoxes" id="products" style="line-height:18px">
  <?php
  $q_products = mysql_query("SELECT *,".DB_PREFIX."products.id AS pid 
                FROM ".DB_PREFIX."products
                LEFT JOIN ".DB_PREFIX."prod_category
                ON ".DB_PREFIX."products.id   = ".DB_PREFIX."prod_category.product
                WHERE category                = '".$cats[0]."'
                AND pEnable                   = 'yes'
                GROUP BY ".DB_PREFIX."products.id
                ORDER BY pName
                ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  if (mysql_num_rows($q_products)>0) {
  while ($PR = mysql_fetch_object($q_products)) {
  ?>
  <b><?php echo $PR->pid; ?></b> - <?php echo mc_cleanDataEnt($PR->pName); ?><br />
  <?php
  }
  }
  ?>
  </div>
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper">
  <div class="formLeft" style="width:96%">
    <label><?php echo $msg_settings59; ?>: <?php echo mc_displayHelpTip($msg_javascript191,'RIGHT'); ?></label>
    <input type="text" id="homeProdIDs" name="homeProdIDs" value="<?php echo mc_cleanData($SETTINGS->homeProdIDs); ?>" class="box" style="width:80%" /> (<a href="#"<?php echo (mc_rowCount('products WHERE pEnable = \'yes\'')==0 ? ' onclick="alert(\''.mc_cleanDataEnt($msg_javascript286).'\');return false" ' : ' onclick="jQuery(\'#topData\').hide(\'slow\');jQuery(\'#bottomData\').show(\'slow\');return false" '); ?>title="<?php echo mc_cleanDataEnt($msg_settings147); ?>"><?php echo $msg_settings147; ?></a>)
  </div>
  <br class="clear" />
</div>

<p style="text-align:center;padding-top:20px">
 <input type="hidden" name="process" value="yes" />
 <input class="formbutton" type="submit" value="<?php echo mc_cleanDataEnt($msg_settings8); ?>" title="<?php echo mc_cleanDataEnt($msg_settings8); ?>" />
</p>
</form>

<p>&nbsp;</p>
<p>&nbsp;</p>
</div>
