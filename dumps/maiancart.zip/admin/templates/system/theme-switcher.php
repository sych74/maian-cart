<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } 
if (isset($_GET['edit'])) {
  $EDIT = mc_getTableData('themes','id',mc_digitSan($_GET['edit']));
}
define('CALBOX', 'from|to');
include(PATH.'templates/date-picker.php');
?>
<div id="content">

<?php
if (isset($OK)) {
  echo actionCompleted($msg_themes7);
}
if (isset($OK2)) {
  echo actionCompleted($msg_themes8);
}
if (isset($OK3) && $cnt>0) {
  echo actionCompleted($msg_themes9);
}
?>

<?php echo $msg_themes; ?><br /><br />

<form method="post" action="?p=themes<?php echo (isset($EDIT->id) ? '&amp;edit='.$EDIT->id : ''); ?>">
<div class="fieldHeadWrapper">
  <p><?php echo (isset($EDIT->id) ? $msg_themes2 : $msg_themes3); ?>:</p>
</div>

<div class="formFieldWrapper">
  <div class="formLeft" style="width:40%">
    <label><?php echo $msg_themes4; ?>: <?php echo mc_displayHelpTip($msg_javascript545,'RIGHT'); ?></label>
    <input type="text" name="from" id="from" tabindex="<?php echo (++$tabIndex); ?>" maxlength="250" value="<?php echo (isset($EDIT->from) && $EDIT->from!='0000-00-00' ? mc_convertMySQLDate($EDIT->from) : ''); ?>" class="box" style="width:30%" /> -
    <input type="text" name="to" id="to" tabindex="<?php echo (++$tabIndex); ?>" value="<?php echo (isset($EDIT->to) && $EDIT->to!='0000-00-00' ? mc_convertMySQLDate($EDIT->to) : ''); ?>" class="box" style="width:30%" />
  </div>
  <div class="formLeft" style="width:39%">  
    <label><?php echo $msg_themes6; ?>: <?php echo mc_displayHelpTip($msg_javascript546); ?></label>
	<select name="theme" tabindex="<?php echo ++$tabIndex; ?>">
    <?php
	$found     = 0;
    $showtheme = opendir(REL_PATH.'content');
    while (false!==($read=readdir($showtheme))) {
      if (is_dir(REL_PATH.'content/'.$read) && substr(strtolower($read),0,6)=='_theme' && $read!=$SETTINGS->theme) {
        echo '<option value="'.$read.'"'.(isset($EDIT->theme) && $read==$EDIT->theme ? ' selected="selected"' : '').'>'.$read.'</option>'.mc_defineNewline();
		++$found;
      }
    }
    closedir($showtheme);
	// Show message if nothing found..
	if ($found==0) {
	?>
	<option value=""><?php echo $msg_themes12; ?></option>
	<?php
	}
    ?>
	</select>
  </div>
  <div class="formRight" style="width:20%">  
    <label><?php echo $msg_themes5; ?>: <?php echo mc_displayHelpTip($msg_javascript544,'LEFT'); ?></label>
    <?php echo $msg_script5; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="enabled" value="yes"<?php echo (isset($EDIT->enabled) && $EDIT->enabled=='yes' ? ' checked="checked"' : (!isset($EDIT->enabled) ? ' checked="checked"' : '')); ?> /> <?php echo $msg_script6; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="enabled" value="no"<?php echo (isset($EDIT->enabled) && $EDIT->enabled=='no' ? ' checked="checked"' : ''); ?> /><br /><br />
  </div>
  <br class="clear" />
</div>

<p style="text-align:center;padding-top:20px">
  <input type="hidden" name="<?php echo (isset($EDIT->id) ? 'update' : 'process'); ?>" value="yes" />
  <input class="formbutton" type="submit" value="<?php echo mc_cleanDataEnt((isset($EDIT->id) ? $msg_themes2 : $msg_themes3)); ?>" title="<?php echo mc_cleanDataEnt((isset($EDIT->id) ? $msg_themes2 : $msg_themes3)); ?>" /><?php echo (isset($EDIT->id) ? '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input class="formbutton2" type="button" onclick="window.location=\'?p=themes\'" value="'.mc_cleanDataEnt($msg_script11).'" title="'.mc_cleanDataEnt($msg_script11).'" />' : ''); ?>
</p>
</form><br />

<div class="fieldHeadWrapper">
  <p><?php echo $msg_themes10; ?>:</p>
</div>

<?php
$q_themes = mysql_query("SELECT * FROM ".DB_PREFIX."themes 
            ORDER BY `from`,`to`
            ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
if (mysql_num_rows($q_themes)>0) {
  while ($THEMES = mysql_fetch_object($q_themes)) {
  ?>
  <div class="themeWrapper">
    <div class="themeLeft" style="width:91%">
	<?php
	if ($THEMES->from==$THEMES->to) {
	  echo str_replace(
	   array('{date}','{theme}','{enabled}'),
	   array(
	    mc_convertMySQLDate($THEMES->from),
		$THEMES->theme,
		($THEMES->enabled=='yes' ? $msg_script5 : $msg_script6)
	   ),
	   $msg_themes13
	  );
	} else {
	  echo str_replace(
	   array('{from}','{to}','{theme}','{enabled}'),
	   array(
	    mc_convertMySQLDate($THEMES->from),
		mc_convertMySQLDate($THEMES->to),
		$THEMES->theme,
		($THEMES->enabled=='yes' ? $msg_script5 : $msg_script6)
	   ),
	   $msg_themes14
	  );
	}
	?>
	</div>
    <div class="themeRight" style="width:5%;text-align:center;padding:5px 0 3px 0;margin-right:0;background:#fff;float:right"><a href="?p=themes&amp;edit=<?php echo $THEMES->id; ?>"><img src="templates/images/edit.png" alt="<?php echo mc_cleanDataEnt($msg_script9); ?>" title="<?php echo mc_cleanDataEnt($msg_script9); ?>" /></a><?php echo ($uDel=='yes' ? '<a href="?p=themes&amp;del='.$THEMES->id.'" onclick="return confirmMessage(\''.mc_cleanDataEnt($msg_javascript45).'\')"><img src="templates/images/delete.png" alt="'.mc_cleanDataEnt($msg_script10).'" title="'.mc_cleanDataEnt($msg_script10).'" /></a>' : ''); ?></div>
    <br class="clear" />
  </div>
  <?php
  }
} else {
?>
<span class="noData"><?php echo $msg_themes11; ?></span>
<?php
}
?>

<p>&nbsp;</p>
<p>&nbsp;</p>
</div>
