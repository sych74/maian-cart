<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } 
if (isset($_GET['edit'])) {
  $EDIT = mc_getTableData('users','id',mc_digitSan($_GET['edit']));
}
?>
<div id="content">

<?php
if (isset($OK)) {
  echo actionCompleted($msg_users11);
}
if (isset($OK2)) {
  echo actionCompleted($msg_users12);
}
if (isset($OK3) && $cnt>0) {
  echo actionCompleted($msg_users13);
}
?>

<?php echo $msg_users; ?><br /><br />

<form method="post" action="?p=users<?php echo (isset($EDIT->id) ? '&amp;edit='.$EDIT->id : ''); ?>">
<div class="fieldHeadWrapper">
  <p><?php echo (isset($EDIT->id) ? $msg_users3 : $msg_users2); ?>:</p>
</div>

<div class="formFieldWrapper">
  <div class="formLeft">
    <label><?php echo $msg_users4; ?>: <?php echo mc_displayHelpTip($msg_javascript259,'RIGHT'); ?></label>
    <input type="text" name="userName" tabindex="1" value="<?php echo (isset($EDIT->userName) ? mc_cleanData($EDIT->userName) : ''); ?>" class="box" /><br /><br />
    
    <label><?php echo $msg_users5; ?>: <?php echo mc_displayHelpTip($msg_javascript260,'RIGHT'); ?></label>
    <input type="text" name="userPass" tabindex="2" value="" class="box" /><br /><br />
    
    <label><?php echo $msg_users6; ?>: <?php echo mc_displayHelpTip($msg_javascript261,'RIGHT'); ?></label>
    <?php echo $msg_users7; ?> <input type="radio" tabindex="3" name="userType" value="admin"<?php echo (isset($EDIT->userType) && $EDIT->userType=='admin' ? ' checked="checked"' : ''); ?> /> <?php echo $msg_users8; ?> <input type="radio" name="userType" tabindex="4" value="restricted"<?php echo (isset($EDIT->userType) && $EDIT->userType=='restricted' ? ' checked="checked"' : (!isset($EDIT->userType) ? ' checked="checked"' : '')); ?> /><br /><br />
    
    <div style="height:100%">
     <div style="float:left;width:48%">
      <label><?php echo $msg_users10; ?>: <?php echo mc_displayHelpTip($msg_javascript263,'RIGHT'); ?></label>
      <?php echo $msg_script5; ?> <input type="radio" tabindex="5" name="userPriv" value="yes"<?php echo (isset($EDIT->userPriv) && $EDIT->userPriv=='yes' ? ' checked="checked"' : ''); ?> /> <?php echo $msg_script6; ?> <input type="radio" tabindex="6" name="userPriv" value="no"<?php echo (isset($EDIT->userPriv) && $EDIT->userPriv=='no' ? ' checked="checked"' : (!isset($EDIT->userPriv) ? ' checked="checked"' : '')); ?> />
     </div>
     <div style="float:right;width:48%">
      <label><?php echo $msg_users16; ?>: <?php echo mc_displayHelpTip($msg_javascript264,'RIGHT'); ?></label>
      <?php echo $msg_script5; ?> <input type="radio" tabindex="7" name="enableUser" value="yes"<?php echo (isset($EDIT->enableUser) && $EDIT->enableUser=='yes' ? ' checked="checked"' : (!isset($EDIT->enableUser) ? ' checked="checked"' : '')); ?> /> <?php echo $msg_script6; ?> <input tabindex="7" type="radio" name="enableUser" value="no"<?php echo (isset($EDIT->enableUser) && $EDIT->enableUser=='no' ? ' checked="checked"' : ''); ?> />
     </div>
     <br class="clear" />
    </div>
  </div>
  <div class="formRight">  
    <label><?php echo $msg_users9; ?>: <?php echo mc_displayHelpTip($msg_javascript262,'LEFT'); ?></label>
    <div class="categoryBoxes" style="height:190px">
    <?php
    $ap = array();
    if (isset($EDIT->accessPages)) {
     $ap = explode('|',$EDIT->accessPages);
    }
    foreach ($userPageAccess AS $key => $value) {
    if (is_array($value)) {
    foreach ($value AS $key2 => $value2) {
    ?>
    <input tabindex="8" type="checkbox" name="pages[]" value="<?php echo $key; ?>_<?php echo $key2; ?>"<?php echo (in_array($key.'_'.$key2,$ap) ? ' checked="checked"' : ''); ?> /> <?php echo $value2; ?><br />
    <?php
    }
    } else {
    ?>
    <input tabindex="8" type="checkbox" name="pages[]" value="<?php echo $key; ?>"<?php echo (in_array($key,$ap) ? ' checked="checked"' : ''); ?> /> <?php echo $value; ?><br />
    <?php
    }
    }
    ?>
    </div>
  </div>
  <br class="clear" />
</div>

<p style="text-align:center;padding-top:20px">
 <input type="hidden" name="<?php echo (isset($EDIT->id) ? 'update' : 'process'); ?>" value="<?php echo (isset($EDIT->id) ? $EDIT->id : 'yes'); ?>" />
 <?php
 if (isset($EDIT->id)) {
 ?>
 <input type="hidden" name="userPass2" value="<?php echo $EDIT->userPass; ?>" />
 <?php
 }
 ?>
 <input class="formbutton" type="submit" value="<?php echo mc_cleanDataEnt((isset($EDIT->id) ? $msg_users3 : $msg_users2)); ?>" title="<?php echo mc_cleanDataEnt((isset($EDIT->id) ? $msg_users3 : $msg_users2)); ?>" /><?php echo (isset($EDIT->id) ? '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input class="formbutton2" type="button" onclick="window.location=\'?p=users\'" value="'.mc_cleanDataEnt($msg_script11).'" title="'.mc_cleanDataEnt($msg_script11).'" />' : ''); ?>
</p>
</form><br />

<div class="fieldHeadWrapper">
  <p><?php echo $msg_users14; ?>:</p>
</div>

<?php
$q_users = mysql_query("SELECT * FROM ".DB_PREFIX."users 
           ORDER BY userName
           ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
if (mysql_num_rows($q_users)>0) {
  while ($USERS = mysql_fetch_object($q_users)) {
  ?>
  <div class="userWrapper">
    <div class="userLeft" style="width:25%"><b><?php echo mc_cleanDataEnt($USERS->userName); ?></b></div>
    <div class="userMiddle" style="width:65%"><?php echo str_replace(array('{type}','{del_priv}','{enabled}'),array(userManagementType($USERS->userType),($USERS->userPriv=='yes' ? $msg_script5 : $msg_script6),($USERS->enableUser=='yes' ? $msg_script5 : $msg_script6)),$msg_users17); ?></div>
    <div class="userRight" style="width:5%;text-align:center;padding:5px 0 3px 0;margin-right:0;background:#fff"><a href="?p=users&amp;edit=<?php echo $USERS->id; ?>"><img src="templates/images/edit.png" alt="<?php echo mc_cleanDataEnt($msg_script9); ?>" title="<?php echo mc_cleanDataEnt($msg_script9); ?>" /></a> <?php echo ($uDel=='yes' ? '<a href="?p=users&amp;del='.$USERS->id.'" onclick="return confirmMessage(\''.mc_cleanDataEnt($msg_javascript45).'\')"><img src="templates/images/delete.png" alt="'.mc_cleanDataEnt($msg_script10).'" title="'.mc_cleanDataEnt($msg_script10).'" /></a>' : ''); ?></div>
    <br class="clear" />
  </div>
  <?php
  }
} else {
?>
<span class="noData"><?php echo $msg_users15; ?></span>
<?php
}
?>

<p>&nbsp;</p>
<p>&nbsp;</p>
</div>
