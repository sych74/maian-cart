<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } ?>
<div id="content">

<?php
$tabIndex = 0;
if (isset($OK)) {
  echo actionCompleted($msg_settings31);
  //Reload..
  $SETTINGS = mysql_fetch_object(mysql_query("SELECT * FROM ".DB_PREFIX."settings LIMIT 1")) 
              or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
}
?>

<?php echo $msg_settings; ?><br /><br />

<form method="post" id="form" action="?p=settings&amp;s=2" enctype="multipart/form-data">
<div class="fieldHeadWrapper">
  <p style="text-align:right"><span style="float:left;display:block;padding:3px 0 0 0"><?php echo $msg_settings77; ?></span>
  <?php
  include(PATH.'templates/system/menu.php');
  ?>
  </p>
</div>

<div class="formFieldWrapper">
  <div class="formLeft">
    <label><?php echo $msg_settings62; ?>: <?php echo mc_displayHelpTip($msg_javascript208,'RIGHT'); ?></label>
    <input type="file" name="logo" value="" class="box" tabindex="<?php echo ++$tabIndex; ?>"  /><br /><br />
    <?php
    $img   = REL_HTTP_PATH.THEME_FOLDER.'/images/logo.png';
    $link  = '';
    if ($SETTINGS->logoName && file_exists($SETTINGS->serverPath.'/'.PRODUCTS_FOLDER.'/'.$SETTINGS->logoName)) {
      $img   = REL_HTTP_PATH.PRODUCTS_FOLDER.'/'.$SETTINGS->logoName;
      $link  = '<span id="logolink">(<a href="#" title="'.mc_cleanDataEnt($msg_settings193).'" onclick="mc_resetStoreLogo(\''.$SETTINGS->logoName.'\');return false">'.$msg_settings193.'</a>)</span>';
    }
    ?>
    <b>
    <?php
    echo $msg_settings192;
    ?>
    </b>
    <?php
    echo $link; 
    ?>
    <br /><br />
    <img style="max-width:400px" id="logoimg" src="<?php echo $img; ?>" alt="" title="" />
  </div>
  <div class="formRight">  
    <label><?php echo $msg_settings63; ?>: <?php echo mc_displayHelpTip($msg_javascript209,'LEFT'); ?></label>
    <textarea rows="2" cols="30" style="height:150px" name="addThisModule" tabindex="<?php echo ++$tabIndex; ?>"><?php echo mc_cleanDataEnt($SETTINGS->addThisModule); ?></textarea>
  </div>
  <br class="clear" />
</div>

<p style="text-align:center;padding-top:20px">
 <input type="hidden" name="process" value="yes" />
 <input type="hidden" name="logo" value="<?php echo $SETTINGS->logoName; ?>" />
 <input class="formbutton" type="submit" value="<?php echo mc_cleanDataEnt($msg_settings8); ?>" title="<?php echo mc_cleanDataEnt($msg_settings8); ?>" />
</p>
</form>

<p>&nbsp;</p>
<p>&nbsp;</p>
</div>
