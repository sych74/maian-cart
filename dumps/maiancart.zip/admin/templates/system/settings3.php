<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } 
define('CALBOX', 'globalDiscountExpiry');
include(PATH.'templates/date-picker.php');
?>
<div id="content">

<?php
$tabIndex = 0;
if (isset($OK)) {
  echo actionCompleted((isset($_GET['global']) ? $msg_settings213 : $msg_settings31));
  //Reload..
  $SETTINGS = mysql_fetch_object(mysql_query("SELECT * FROM ".DB_PREFIX."settings LIMIT 1")) 
              or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
}
?>

<?php echo (isset($_GET['global']) ? $msg_settings211 : $msg_settings); ?><br /><br />

<form method="post" id="form" action="?p=settings&amp;s=3<?php echo (isset($_GET['global']) ? '&amp;global=yes' : ''); ?>">
<?php
$hideDiv = '';
if (isset($_GET['global'])) {
$hideDiv = ' style="display:none"';
}
?>
<div class="fieldHeadWrapper"<?php echo $hideDiv; ?>>
  <p style="text-align:right"><span style="float:left;display:block;padding:3px 0 0 0"><?php echo $msg_settings77; ?></span>
  <?php
  include(PATH.'templates/system/menu.php');
  ?>
  </p>
</div>

<div class="formFieldWrapper"<?php echo $hideDiv; ?>>
  <div class="formLeft">
  <label><?php echo $msg_settings49; ?>: <?php echo mc_displayHelpTip($msg_javascript186,'RIGHT'); ?></label>
  <select name="baseCurrency" tabindex="<?php echo ++$tabIndex; ?>" onchange="mc_loadCurrencyDisplay(this.value)">
    <?php
    foreach ($currencies AS $key => $value) {
      echo '<option value="'.$key.'"'.($key==$SETTINGS->baseCurrency ? ' selected="selected"' : '').($key=='' ? ' disabled="disabled"' : '').'>'.$value.'</option>'.mc_defineNewline();
    }
    ?>
    </select>
  </div>
  <div class="formRight">
    <label><?php echo $msg_settings18; ?>: <?php echo mc_displayHelpTip($msg_javascript16,'LEFT'); ?></label>
    <?php echo $msg_settings34; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="gatewayMode" value="test"<?php echo ($SETTINGS->gatewayMode=='test' ? ' checked="checked"' : ''); ?> /> <?php echo $msg_settings33; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="gatewayMode" value="live"<?php echo ($SETTINGS->gatewayMode=='live' ? ' checked="checked"' : ''); ?> />
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper"<?php echo $hideDiv; ?>>
  <div class="formLeft">
    <label><?php echo $msg_settings95; ?>: <?php echo mc_displayHelpTip($msg_javascript231,'RIGHT'); ?></label>
    <input type="text" name="currencyDisplayPref" value="<?php echo str_replace('&#','&amp;#',mc_cleanDataEnt($SETTINGS->currencyDisplayPref)); ?>" class="box" style="width:40%" maxlength="100" tabindex="<?php echo ++$tabIndex; ?>" /> 
  </div>
  <div class="formRight">
    <label><?php echo $msg_settings83; ?>: <?php echo mc_displayHelpTip($msg_javascript227,'LEFT'); ?></label>
    <select name="shipCountry" tabindex="<?php echo ++$tabIndex; ?>">
    <option value="0">- - - - -</option>
    <?php
    $q_ctry   = mysql_query("SELECT `id`,`cName` FROM ".DB_PREFIX."countries 
                WHERE `enCountry`  = 'yes'
                ORDER BY `cName`
                ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($CTY = mysql_fetch_object($q_ctry)) {
    ?>
    <option value="<?php echo $CTY->id; ?>"<?php echo ($SETTINGS->shipCountry==$CTY->id ? ' selected="selected"' : ''); ?>><?php echo mc_cleanDataEnt($CTY->cName); ?></option>
    <?php
    }
    ?>
    </select>
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper"<?php echo $hideDiv; ?>>
  <div class="formLeft">
    <label><?php echo $msg_settings132; ?>: <?php echo mc_displayHelpTip($msg_javascript274,'RIGHT'); ?></label>
    <?php echo $msg_script5; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="pendingAsComplete" value="yes"<?php echo ($SETTINGS->pendingAsComplete=='yes' ? ' checked="checked"' : ''); ?> /> <?php echo $msg_script6; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="pendingAsComplete" value="no"<?php echo ($SETTINGS->pendingAsComplete=='no' ? ' checked="checked"' : ''); ?> />
  </div>
  <div class="formRight">
    <label><?php echo $msg_settings36; ?>: <?php echo mc_displayHelpTip($msg_javascript144,'LEFT'); ?></label>
    <?php echo $msg_script5; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="enableSSL" value="yes"<?php echo ($SETTINGS->enableSSL=='yes' ? ' checked="checked"' : ''); ?> /> <?php echo $msg_script6; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="enableSSL" value="no"<?php echo ($SETTINGS->enableSSL=='no' ? ' checked="checked"' : ''); ?> />
  </div>
  <br class="clear" />
</div>

<div class="fieldHeadWrapper"<?php echo $hideDiv; ?>>
  <p><?php echo $msg_settings202; ?></p>
</div>

<div class="formFieldWrapper"<?php echo $hideDiv; ?>>
  <div class="formLeft">
    <label><?php echo $msg_settings183; ?>: <?php echo mc_displayHelpTip($msg_javascript371,'RIGHT'); ?></label>
    <select name="showOutofStock">
    <?php
    foreach (array('cat' => $msg_settings185,
                   'yes' => $msg_settings186,
                   'no'  => $msg_settings187
             ) AS $k => $v) {
    ?>
    <option value="<?php echo $k; ?>"<?php echo ($SETTINGS->showOutofStock==$k ? ' selected="selected"' : ''); ?>><?php echo $v; ?></option>
    <?php
    }
    ?>
    </select>
  </div>
  <div class="formRight">
    <label><?php echo $msg_settings274; ?>: <?php echo mc_displayHelpTip($msg_javascript493,'LEFT'); ?></label>
    <?php echo $msg_script5; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="showAttrStockLevel" value="yes"<?php echo ($SETTINGS->showAttrStockLevel=='yes' ? ' checked="checked"' : ''); ?> /> <?php echo $msg_script6; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="showAttrStockLevel" value="no"<?php echo ($SETTINGS->showAttrStockLevel=='no' ? ' checked="checked"' : ''); ?> />
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper"<?php echo $hideDiv; ?>>
  <div class="formLeft">
    <label><?php echo $msg_settings158; ?>: <?php echo mc_displayHelpTip($msg_javascript305,'RIGHT'); ?></label>
    <input type="text" name="freeShipThreshold" value="<?php echo ($SETTINGS->freeShipThreshold>0 ? $SETTINGS->freeShipThreshold : '0.00'); ?>" class="box" style="width:40%" maxlength="50" tabindex="<?php echo ++$tabIndex; ?>" /> 
  </div>
  <div class="formRight">
    <label><?php echo $msg_settings273; ?>: <?php echo mc_displayHelpTip($msg_javascript492,'LEFT'); ?></label>
    <input type="text" name="qtyStockThreshold" value="<?php echo $SETTINGS->qtyStockThreshold; ?>" class="box" style="width:15%" maxlength="5" tabindex="<?php echo ++$tabIndex; ?>" /> /
    <input type="text" name="productStockThreshold" value="<?php echo $SETTINGS->productStockThreshold; ?>" class="box" style="width:15%" maxlength="5" tabindex="<?php echo ++$tabIndex; ?>" /> 
  </div>
  <br class="clear" />
</div>

<div class="fieldHeadWrapper"<?php echo $hideDiv; ?>>
  <p><?php echo $msg_settings279; ?></p>
</div>

<div class="formFieldWrapper">
  <div class="formLeft">
    <label><?php echo $msg_settings191; ?>: <?php echo mc_displayHelpTip($msg_javascript400,'RIGHT'); ?></label>
    <input type="text" name="downloadFolder" value="<?php echo mc_cleanData($SETTINGS->downloadFolder); ?>" class="box" tabindex="<?php echo ++$tabIndex; ?>" /> 
  </div>
  <div class="formRight">  
    <label><?php echo $msg_settings197; ?>: <?php echo mc_displayHelpTip($msg_javascript383,'LEFT'); ?></label>
    <input type="text" name="globalDownloadPath" value="<?php echo mc_cleanData($SETTINGS->globalDownloadPath); ?>" class="box" tabindex="<?php echo ++$tabIndex; ?>" /> 
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper"<?php echo $hideDiv; ?>>
  <div class="formLeft">
    <label><?php echo $msg_settings178; ?>: <?php echo mc_displayHelpTip($msg_javascript362,'RIGHT'); ?></label>
    <input type="text" name="freeDownloadRestriction" value="<?php echo ($SETTINGS->freeDownloadRestriction ? $SETTINGS->freeDownloadRestriction : '0'); ?>" class="box" style="width:10%" tabindex="<?php echo ++$tabIndex; ?>" /> 
  </div>
  <div class="formRight">
    <label><?php echo $msg_settings189; ?>: <?php echo mc_displayHelpTip($msg_javascript378,'LEFT'); ?></label>
    <?php echo $msg_script5; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="reduceDownloadStock" value="yes"<?php echo ($SETTINGS->reduceDownloadStock=='yes' ? ' checked="checked"' : ''); ?> /> <?php echo $msg_script6; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="reduceDownloadStock" value="no"<?php echo ($SETTINGS->reduceDownloadStock=='no' ? ' checked="checked"' : ''); ?> />
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper"<?php echo $hideDiv; ?>>
  <div class="formLeft">
    <label><?php echo $msg_settings280; ?>: <?php echo mc_displayHelpTip($msg_javascript547,'RIGHT'); ?></label>
    <input type="text" name="freeAltRedirect" value="<?php echo $SETTINGS->freeAltRedirect; ?>" maxlength="250" class="box" tabindex="<?php echo ++$tabIndex; ?>" /> 
  </div>
  <div class="formRight">
    <label><?php echo $msg_settings297; ?>: <?php echo mc_displayHelpTip($msg_javascript580,'LEFT'); ?></label>
    <?php echo $msg_script5; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="downloadRestrictIP" value="yes"<?php echo ($SETTINGS->downloadRestrictIP=='yes' ? ' checked="checked"' : ''); ?> /> <?php echo $msg_script6; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="downloadRestrictIP" value="no"<?php echo ($SETTINGS->downloadRestrictIP=='no' ? ' checked="checked"' : ''); ?> />
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper"<?php echo $hideDiv; ?>>
  <div class="formLeft">
    <label><?php echo $msg_settings298; ?>: <?php echo mc_displayHelpTip($msg_javascript581,'RIGHT'); ?></label>
    <?php echo $msg_script5; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="downloadRestrictIPLog" value="yes"<?php echo ($SETTINGS->downloadRestrictIPLog=='yes' ? ' checked="checked"' : ''); ?> /> <?php echo $msg_script6; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="downloadRestrictIPLog" value="no"<?php echo ($SETTINGS->downloadRestrictIPLog=='no' ? ' checked="checked"' : ''); ?> />
  </div>
  <div class="formRight">
    <label><?php echo $msg_settings299; ?>: <?php echo mc_displayHelpTip($msg_javascript582,'LEFT'); ?></label>
    <input type="text" name="downloadRestrictIPLock" value="<?php echo ($SETTINGS->downloadRestrictIPLock ? $SETTINGS->downloadRestrictIPLock : '0'); ?>" maxlength="7" class="box" style="width:10%" tabindex="<?php echo ++$tabIndex; ?>" /> 
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $msg_settings300; ?>: <input type="checkbox" name="downloadRestrictIPMail" value="yes"<?php echo ($SETTINGS->downloadRestrictIPMail=='yes' ? ' checked="checked"' : ''); ?> />
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper"<?php echo $hideDiv; ?>>
  <div class="formLeft">
    <label><?php echo $msg_settings301; ?>: <?php echo mc_displayHelpTip($msg_javascript583.'<b>'.mc_getRealIPAddr().'</b>','RIGHT'); ?></label>
    <input type="text" name="downloadRestrictIPGlobal" value="<?php echo $SETTINGS->downloadRestrictIPGlobal; ?>" class="box" tabindex="<?php echo ++$tabIndex; ?>" /> 
  </div>
  <div class="formRight">
  </div>
  <br class="clear" />
</div>

<div class="fieldHeadWrapper"<?php echo $hideDiv; ?>>
  <p><?php echo $msg_settings201; ?></p>
</div>

<div class="formFieldWrapper"<?php echo $hideDiv; ?>>
  <div class="formLeft">
    <label><?php echo $msg_settings277; ?>: <?php echo mc_displayHelpTip($msg_javascript500,'RIGHT'); ?></label>
    <input type="text" name="autoClear" value="<?php echo $SETTINGS->autoClear; ?>" class="box" style="width:20%" maxlength="3" tabindex="<?php echo ++$tabIndex; ?>" /> <?php echo $msg_settings278; ?>
  </div>
  <div class="formRight">
    <label><?php echo $msg_settings184; ?>: <?php echo mc_displayHelpTip($msg_javascript372,'LEFT'); ?></label>
    <?php echo $msg_script5; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="optInNewsletter" value="yes"<?php echo ($SETTINGS->optInNewsletter=='yes' ? ' checked="checked"' : ''); ?> /> <?php echo $msg_script6; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="optInNewsletter" value="no"<?php echo ($SETTINGS->optInNewsletter=='no' ? ' checked="checked"' : ''); ?> />
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper"<?php echo $hideDiv; ?>>
  <div class="formLeft">
    <label><?php echo $msg_settings272; ?>: <?php echo mc_displayHelpTip($msg_javascript491,'RIGHT'); ?></label>
    <input type="text" name="minCheckoutAmount" value="<?php echo ($SETTINGS->minCheckoutAmount>0 ? $SETTINGS->minCheckoutAmount : '0.00'); ?>" class="box" style="width:40%" maxlength="50" tabindex="<?php echo ++$tabIndex; ?>" /> 
  </div>
  <div class="formRight">
    <label><?php echo $msg_settings182; ?>: <?php echo mc_displayHelpTip($msg_javascript370,'LEFT'); ?></label>
    <?php echo $msg_script5; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="enableCheckout" value="yes"<?php echo ($SETTINGS->enableCheckout=='yes' ? ' checked="checked"' : ''); ?> /> <?php echo $msg_script6; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="enableCheckout" value="no"<?php echo ($SETTINGS->enableCheckout=='no' ? ' checked="checked"' : ''); ?> />
  </div>
  <br class="clear" />
</div>

<div class="fieldHeadWrapper"<?php echo $hideDiv; ?>>
  <p><?php echo $msg_settings261; ?></p>
</div>

<div class="formFieldWrapper"<?php echo $hideDiv; ?>>
  <div class="formLeft">
    <label><?php echo $msg_settings224; ?>: <?php echo mc_displayHelpTip($msg_javascript452,'RIGHT'); ?></label>
    <?php echo $msg_script5; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="offerInsurance" value="yes"<?php echo ($SETTINGS->offerInsurance=='yes' ? ' checked="checked"' : ''); ?> /> <?php echo $msg_script6; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="offerInsurance" value="no"<?php echo ($SETTINGS->offerInsurance=='no' ? ' checked="checked"' : ''); ?> />
  </div>
  <div class="formRight">
    <label><?php echo $msg_settings225; ?>: <?php echo mc_displayHelpTip($msg_javascript453,'LEFT'); ?></label>
    <input type="text" name="insuranceAmount" value="<?php echo ($SETTINGS->insuranceAmount ? $SETTINGS->insuranceAmount : '0.00'); ?>" class="box" style="width:20%" maxlength="10" tabindex="<?php echo ++$tabIndex; ?>" /> 
    <select name="insuranceFilter" onchange="if(this.value!='op4' && this.value!='op8'){jQuery('#insuranceValue').val('0.00')}">
     <option value="op1"<?php echo ($SETTINGS->insuranceFilter=='op1' ? ' selected="selected"' : ''); ?>><?php echo $msg_settings226; ?></option>
     <option value="op2"<?php echo ($SETTINGS->insuranceFilter=='op2' ? ' selected="selected"' : ''); ?>><?php echo $msg_settings227; ?></option>
     <option value="op3"<?php echo ($SETTINGS->insuranceFilter=='op3' ? ' selected="selected"' : ''); ?>><?php echo $msg_settings228; ?></option>
     <option value="op4"<?php echo ($SETTINGS->insuranceFilter=='op4' ? ' selected="selected"' : ''); ?>><?php echo $msg_settings229; ?></option>
     <option disabled="disabled">- - - - -</option>
     <option value="op5"<?php echo ($SETTINGS->insuranceFilter=='op5' ? ' selected="selected"' : ''); ?>><?php echo $msg_settings230; ?></option>
     <option value="op6"<?php echo ($SETTINGS->insuranceFilter=='op6' ? ' selected="selected"' : ''); ?>><?php echo $msg_settings231; ?></option>
     <option value="op7"<?php echo ($SETTINGS->insuranceFilter=='op7' ? ' selected="selected"' : ''); ?>><?php echo $msg_settings232; ?></option>
     <option value="op8"<?php echo ($SETTINGS->insuranceFilter=='op8' ? ' selected="selected"' : ''); ?>><?php echo $msg_settings233; ?></option>
    </select>
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper"<?php echo $hideDiv; ?>>
  <div class="formLeft">
    <label><?php echo $msg_settings262; ?>: <?php echo mc_displayHelpTip($msg_javascript482,'RIGHT'); ?></label>
    <?php echo $msg_script5; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="insuranceOptional" value="yes"<?php echo ($SETTINGS->insuranceOptional=='yes' ? ' checked="checked"' : ''); ?> /> <?php echo $msg_script6; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="insuranceOptional" value="no"<?php echo ($SETTINGS->insuranceOptional=='no' ? ' checked="checked"' : ''); ?> />
  </div>
  <div class="formRight">
    <label><?php echo $msg_settings263; ?>: <?php echo mc_displayHelpTip($msg_javascript483,'LEFT'); ?></label>
    <input type="text" name="insuranceValue" id="insuranceValue" value="<?php echo ($SETTINGS->insuranceValue>0 ? $SETTINGS->insuranceValue : '0.00'); ?>" class="box" style="width:40%" maxlength="20" tabindex="<?php echo ++$tabIndex; ?>" /> 
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper">
  <label><?php echo showBBCodeLink(false,'insuranceInfo','settings').$msg_settings264; ?>: <?php echo mc_displayHelpTip($msg_javascript484,'RIGHT'); ?></label>
  <textarea rows="5" cols="30" name="insuranceInfo" tabindex="<?php echo (++$tabIndex); ?>" style="height:120px;width:98%" id="insuranceInfo"><?php echo mc_cleanDataEnt(mc_cleanData($SETTINGS->insuranceInfo)); ?></textarea>
  <br class="clear" />
</div>

<div class="fieldHeadWrapper"<?php echo $hideDiv; ?>>
  <p><?php echo $msg_settings200; ?></p>
</div>

<div class="formFieldWrapper"<?php echo $hideDiv; ?>>
  <div class="formLeft">
    <label><?php echo $msg_settings35; ?>: <?php echo mc_displayHelpTip($msg_javascript143,'RIGHT'); ?></label>
    <?php echo $msg_script5; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="logErrors" value="yes"<?php echo ($SETTINGS->logErrors=='yes' ? ' checked="checked"' : ''); ?> /> <?php echo $msg_script6; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="logErrors" value="no"<?php echo ($SETTINGS->logErrors=='no' ? ' checked="checked"' : ''); ?> />
  </div>
  <div class="formRight">
    <label><?php echo $msg_settings81; ?>: <?php echo mc_displayHelpTip($msg_javascript225,'LEFT'); ?></label>
    <input type="text" name="logFolderName" value="<?php echo mc_cleanData($SETTINGS->logFolderName); ?>" class="box" style="width:40%" maxlength="50" tabindex="<?php echo ++$tabIndex; ?>" /> 
  </div>
  <br class="clear" />
</div>

<div class="fieldHeadWrapper"<?php echo $hideDiv; ?>>
  <p><?php echo $msg_settings199; ?></p>
</div>

<div class="formFieldWrapper"<?php echo $hideDiv; ?>>
  <div class="formLeft">
    <label><?php echo $msg_settings82; ?>: <?php echo mc_displayHelpTip($msg_javascript226,'RIGHT'); ?></label>
    <?php echo $msg_script5; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="enablePickUp" value="yes"<?php echo ($SETTINGS->enablePickUp=='yes' ? ' checked="checked"' : ''); ?> /> <?php echo $msg_script6; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="enablePickUp" value="no"<?php echo ($SETTINGS->enablePickUp=='no' ? ' checked="checked"' : ''); ?> />
  </div>
  <div class="formRight">
    <label><?php echo $msg_settings203; ?>: <?php echo mc_displayHelpTip($msg_javascript405,'LEFT'); ?></label>
    <div class="categoryBoxes" id="localCountries">
    <input type="checkbox" onclick="toggleCheckBoxesID(this.checked,'localCountries')" tabindex="<?php echo (++$tabIndex); ?>" /> <b><?php echo $msg_settings204; ?></b><br />
    <?php
    $q_ctry   = mysql_query("SELECT * FROM ".DB_PREFIX."countries 
                WHERE enCountry  = 'yes'
                ORDER BY cName
                ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($CTY = mysql_fetch_object($q_ctry)) {
    ?>
    <input type="checkbox" tabindex="<?php echo (++$tabIndex); ?>" name="pickup[]" value="<?php echo $CTY->id; ?>"<?php echo ($CTY->localPickup=='yes' ? ' checked="checked"' : ''); ?> /> <?php echo mc_cleanDataEnt($CTY->cName); ?><br />
    <?php
    }
    ?>
    </div>
  </div>
  <br class="clear" />
</div>

<div class="fieldHeadWrapper">
  <p><?php echo $msg_settings166; ?></p>
</div>

<div class="formFieldWrapper">
  <div class="formLeft">
    <label><?php echo $msg_settings164; ?>: <?php echo mc_displayHelpTip($msg_javascript330,'RIGHT'); ?></label>
    <input type="text" name="globalDiscount" value="<?php echo ($SETTINGS->globalDiscount ? $SETTINGS->globalDiscount : '0'); ?>" class="box" style="width:10%" tabindex="<?php echo ++$tabIndex; ?>" />% 
  </div>
  <div class="formRight">
    <label><?php echo $msg_settings165; ?>: <?php echo mc_displayHelpTip($msg_javascript331,'LEFT'); ?></label>
    <input type="text" name="globalDiscountExpiry" value="<?php echo ($SETTINGS->globalDiscountExpiry!='0000-00-00' ? mc_convertCalToSQLFormat($SETTINGS->globalDiscountExpiry) : ''); ?>" class="box" style="width:30%" id="globalDiscountExpiry" tabindex="<?php echo ++$tabIndex; ?>" /> 
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper">
  <div class="formLeft">
    <label><?php echo $msg_settings177; ?>: <?php echo mc_displayHelpTip($msg_javascript357,'RIGHT'); ?></label>
    <?php echo $msg_script5; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="clearSpecialOffers" value="yes" /> <?php echo $msg_script6; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="clearSpecialOffers" value="no" checked="checked" />
  </div>
  <div class="formRight">
  </div>
  <br class="clear" />
</div>

<p style="text-align:center;padding-top:20px">
 <input type="hidden" name="process" value="yes" />
 <input class="formbutton" type="submit" value="<?php echo mc_cleanDataEnt((isset($_GET['global']) ? $msg_settings212 : $msg_settings8)); ?>" title="<?php echo mc_cleanDataEnt((isset($_GET['global']) ? $msg_settings212 : $msg_settings8)); ?>" />
</p>
</form>

<p>&nbsp;</p>
<p>&nbsp;</p>
</div>
