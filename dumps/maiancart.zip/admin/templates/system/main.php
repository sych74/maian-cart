<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } 
$payStatuses    = mc_loadDefaultStatuses();
$graph          = $MCSALE->homepageGraphData();
$lineOne        = $graph[0];
$lineTwo        = $graph[1];
$lineThree      = $graph[2];
$boomOne        = explode(',',$graph[0]);
$boomTwo        = explode(',',$graph[1]);
$boomThree      = explode(',',$graph[2]);
$ticks          = $graph[3];
$range          = (isset($_GET['range']) && in_array($_GET['range'],array('week','month','year')) ? $_GET['range'] : ADMIN_HOME_DEFAULT_SALES_VIEW);
$displayTotals  = $MCSALE->homepageTotalDisplay($range);
?>
<div id="content">

<?php
if (!empty($sec)) {
  echo '<span class="securityErrorHead">'.$msg_main4.':</span>';
  foreach ($sec AS $display) {
    echo '<span class="securityError">'.$display.'</span>';
  }
} else {
include(PATH.'templates/custom-user-message.php');
?>
<div id="homeArea">

  <div class="homeAreaLeft">
     <p class="bar">
     <select onchange="if(this.value!= 0){location=this.options[this.selectedIndex].value}">
     <option value="index.php"><?php echo $msg_main; ?></option>
     <option value="?range=week"<?php echo ($range=='week' ? ' selected="selected"' : ''); ?>><?php echo $msg_main2; ?></option>
     <option value="?range=month"<?php echo ($range=='month' ? ' selected="selected"' : ''); ?>><?php echo $msg_main9; ?></option>
     <option value="?range=year"<?php echo ($range=='year' ? ' selected="selected"' : ''); ?>><?php echo $msg_main6; ?></option>
    </select>
     <?php echo $msg_main17; ?>
     </p>
     <div class="graph" id="graph">
     <?php
     if (array_sum($boomOne)>0 || array_sum($boomTwo)>0 || array_sum($boomThree)>0) {
     ?>
     <div id="chartgraph"></div>
     <script type="text/javascript">
     //<![CDATA[
     jQuery(document).ready(function() {  
     line1 = [<?php echo $lineOne; ?>];
     line2 = [<?php echo $lineTwo; ?>];
	 line3 = [<?php echo $lineThree; ?>];
     ticks = [<?php echo $ticks; ?>];
     plot1 = jQuery.jqplot('chartgraph', [line1,line2,line3], {
                       grid: {
                         borderWidth: 0,
                         shadow: false
                       },
                       axes: {
                         yaxis: {
                           min: 0,
                           tickOptions: {
                             formatString: '%d'
                           }
                         },
                         xaxis: { 
                           rendererOptions: {
                           tickRenderer: jQuery.jqplot.CanvasAxisTickRenderer
                           },
                           ticks:ticks,
                           renderer: jQuery.jqplot.CategoryAxisRenderer
                         }
                       },
                       series: [{
                          lineWidth: 1
                       },{
                          lineWidth: 1
                       }],
                       legend: {
                         show: false
                       }
     });
     });
     //]]>
     </script>
     <?php
     } else {
     ?>
     <div id="chartgraph_nostats"></div>
     <?php
     }
     ?>
     </div>
  </div>
  
  <div class="homeAreaRight">
  
    <h2 class="sales">
    <?php 
    switch ($range) {
      // Today..
      case 'today':
      echo $msg_main3;
      break;
      // This week..
      case 'week':
      echo $msg_main19;
      break;
      // This month..
      case 'month':
      echo $msg_main20;
      break;
      // This year..
      case 'year':
      echo $msg_main21; 
      break;
    }  
    ?>
    </h2>
    
    <div class="data">
    
    <ul class="overview">
     <li class="sub"><span><?php echo mc_currencyFormat(mc_formatPrice($displayTotals[0],true)); ?></span><?php echo $msg_main7; ?></li>
     <li class="tax"><span><?php echo mc_currencyFormat(mc_formatPrice($displayTotals[1],true)); ?></span><?php echo $msg_main8; ?></li>
     <li class="total"><span><?php echo mc_currencyFormat(mc_formatPrice($displayTotals[2],true)); ?></span><?php echo $msg_main10; ?></li>
    </ul> 
    
    </div>
    
    <h2 class="links"><?php echo $msg_main11; ?></h2>
    
    <div class="datalinks">
    <ul class="lks">
     <?php
     include(PATH.'templates/system/main-quick-links.php');
     ?>
    </ul> 
    </div>
    
  </div>
  
  <br class="clear" />

</div>

<?php
if (SHOW_PENDING_SALES_ON_MAIN_PAGE) {
?>
<div class="fieldHeadWrapper">
  <p><span class="float"><a href="#" onclick="mc_homeSlider();return false"><img id="slider" src="templates/images/slide-up.png" alt="<?php echo mc_cleanDataEnt($msg_main18); ?>" title="<?php echo mc_cleanDataEnt($msg_main18); ?>" /></a></span><?php echo $msg_sales34; ?>:</p>
</div>
<?php
$query = mysql_query("SELECT *,DATE_FORMAT(purchaseDate,'".$SETTINGS->mysqlDateFormat."') AS sdate 
         FROM ".DB_PREFIX."sales
         WHERE saleConfirmation = 'yes'
         AND paymentStatus     IN('pending','shipping')
         ORDER BY id DESC
         ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
if (mysql_num_rows($query)>0) {         
while ($SALES = mysql_fetch_object($query)) {
?>         
<div class="productWrapper">
  <div class="productWrapper_inner">
   <div class="td1"><?php echo mc_saleInvoiceNumber($SALES->invoiceNo); ?></div>
   <div class="td2"><?php echo ($SALES->bill_1 ? mc_cleanData($SALES->bill_1) : '&nbsp;'); ?></div>
   <div class="td3"><?php echo $SALES->sdate; ?></div>
   <div class="td4"><?php echo mc_paymentMethodName($SALES->paymentMethod); ?></div>
   <div class="td5"><?php echo str_replace(array('{id}','{count}'),array($SALES->id,mc_sumCount('purchases WHERE saleID = \''.$SALES->id.'\' AND saleConfirmation = \'yes\'','productQty',true)),$msg_sales31); ?></div>
   <div class="td6"><?php echo mc_currencyFormat(mc_formatPrice($SALES->grandTotal,true)); ?></div>
   <br class="clear" />
   <p class="status"><?php echo statusText($SALES->paymentStatus); ?></p>
  </div>
  <p class="panel">
    <?php
    if ($uDel=='yes') {
    ?>
    <a class="delete" href="?p=sales&amp;delete=<?php echo $SALES->id; ?>" onclick="return confirmMessage('<?php echo mc_cleanDataEnt($msg_javascript45); ?>')" title="<?php echo mc_cleanDataEnt($msg_script10); ?>"><?php echo $msg_script10; ?></a>
    <?php
    }
    ?>
    <a class="edit" href="?p=sales-view&amp;sale=<?php echo $SALES->id; ?>" title="<?php echo mc_cleanDataEnt($msg_sales13); ?>"><?php echo $msg_sales13; ?></a>
    <a class="exp" href="?p=sales&amp;export=<?php echo $SALES->id; ?>" title="<?php echo mc_cleanDataEnt($msg_sales4); ?>"><?php echo $msg_sales4; ?></a>
    <a class="invoice" href="?p=invoice&amp;sale=<?php echo $SALES->id; ?>" onclick="window.open(this);return false" title="<?php echo mc_cleanDataEnt($msg_sales5); ?>"><?php echo $msg_sales5; ?></a>
    <?php
    // Show packing slip link if there are physical products..
    if (mc_rowCount('purchases WHERE saleID = \''.$SALES->id.'\' AND saleConfirmation = \'yes\' AND productType = \'physical\'')>0) {
    ?>
    <a class="packing" href="?p=packing-slip&amp;sale=<?php echo $SALES->id; ?>" onclick="window.open(this);return false" title="<?php echo mc_cleanDataEnt($msg_sales6); ?>"><?php echo $msg_sales6; ?></a>
    <?php
    }
    if (mc_rowCount('purch_pers WHERE saleID = \''.mc_digitSan($SALES->id).'\'')>0) {
    ?>
    <a class="pers" href="?p=sales-view&amp;view-personalisation=<?php echo $SALES->id; ?>" title="<?php echo mc_cleanDataEnt($msg_sales37); ?>" onclick="mc_Window(this.href,'<?php echo GREYBOX_PERS_HEIGHT; ?>','<?php echo GREYBOX_PERS_WIDTH; ?>',this.title);return false;"><?php echo $msg_sales37; ?></a>
    <?php
    }
    if (mc_rowCount('purchases WHERE saleID = \''.$SALES->id.'\' AND saleConfirmation = \'yes\' AND productType = \'download\'')>0) {
    ?>
    <a class="downloads" href="?p=downloads&amp;sale=<?php echo $SALES->id; ?>" title="<?php echo mc_cleanDataEnt($msg_sales38); ?>" onclick="mc_Window(this.href,'<?php echo GREYBOX_DOWNLOADS_HEIGHT; ?>','<?php echo GREYBOX_DOWNLOADS_WIDTH; ?>',this.title);return false;"><?php echo $msg_sales38; ?></a>
    <?php
    }
    ?>
    <a class="update" href="?p=sales-update&amp;sale=<?php echo $SALES->id; ?>" title="<?php echo mc_cleanDataEnt($msg_sales2); ?>"><?php echo $msg_sales2; ?></a>
    <br class="clear" />
  </p>
</div>
<?php
}
} else {
?>
<p class="noData"><?php echo $msg_sales17; ?></p>
<?php
}
}

if (SHOW_COMPLETED_SALES_ON_MAIN_PAGE>0) {
?>
<div class="fieldHeadWrapper">
  <p><?php echo (!SHOW_PENDING_SALES_ON_MAIN_PAGE ? '<span class="float"><a href="#" onclick="mc_homeSlider();return false"><img id="slider" src="templates/images/slide-up.png" alt="'.mc_cleanDataEnt($msg_main18).'" title="'.mc_cleanDataEnt($msg_main18).'" /></a></span>' : ''); ?><?php echo str_replace('{count}',SHOW_COMPLETED_SALES_ON_MAIN_PAGE,$msg_sales33); ?>:</p>
</div>
<?php
$query = mysql_query("SELECT *,DATE_FORMAT(purchaseDate,'".$SETTINGS->mysqlDateFormat."') AS sdate 
         FROM ".DB_PREFIX."sales
         WHERE saleConfirmation = 'yes'
         AND paymentStatus      = 'completed'
         ORDER BY id DESC
         LIMIT ".SHOW_COMPLETED_SALES_ON_MAIN_PAGE."
         ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
if (mysql_num_rows($query)>0) {         
while ($SALES = mysql_fetch_object($query)) {
?>         
<div class="productWrapper">
  <div class="productWrapper_inner">
   <div class="td1"><?php echo mc_saleInvoiceNumber($SALES->invoiceNo); ?></div>
   <div class="td2"><?php echo ($SALES->bill_1 ? mc_cleanData($SALES->bill_1) : '&nbsp;'); ?></div>
   <div class="td3"><?php echo $SALES->sdate; ?></div>
   <div class="td4"><?php echo mc_paymentMethodName($SALES->paymentMethod); ?></div>
   <div class="td5"><?php echo str_replace(array('{id}','{count}'),array($SALES->id,mc_sumCount('purchases WHERE saleID = \''.$SALES->id.'\' AND saleConfirmation = \'yes\'','productQty',true)),$msg_sales31); ?></div>
   <div class="td6"><?php echo mc_currencyFormat(mc_formatPrice($SALES->grandTotal,true)); ?></div>
   <br class="clear" />
   <p class="status"><?php echo statusText($SALES->paymentStatus); ?></p>
  </div>
  <p class="panel">
    <?php
    if ($uDel=='yes') {
    ?>
    <a class="delete" href="?p=sales&amp;delete=<?php echo $SALES->id; ?>" onclick="return confirmMessage('<?php echo mc_cleanDataEnt($msg_javascript45); ?>')" title="<?php echo mc_cleanDataEnt($msg_script10); ?>"><?php echo $msg_script10; ?></a>
    <?php
    }
    ?>
    <a class="edit" href="?p=sales-view&amp;sale=<?php echo $SALES->id; ?>" title="<?php echo mc_cleanDataEnt($msg_sales13); ?>"><?php echo $msg_sales13; ?></a>
    <a class="exp" href="?p=sales&amp;export=<?php echo $SALES->id; ?>" title="<?php echo mc_cleanDataEnt($msg_sales4); ?>"><?php echo $msg_sales4; ?></a>
    <a class="invoice" href="?p=invoice&amp;sale=<?php echo $SALES->id; ?>" onclick="window.open(this);return false" title="<?php echo mc_cleanDataEnt($msg_sales5); ?>"><?php echo $msg_sales5; ?></a>
    <?php
    // Show packing slip link if there are physical products..
    if (mc_rowCount('purchases WHERE saleID = \''.$SALES->id.'\' AND saleConfirmation = \'yes\' AND productType = \'physical\'')>0) {
    ?>
    <a class="packing" href="?p=packing-slip&amp;sale=<?php echo $SALES->id; ?>" onclick="window.open(this);return false" title="<?php echo mc_cleanDataEnt($msg_sales6); ?>"><?php echo $msg_sales6; ?></a>
    <?php
    }
    if (mc_rowCount('purch_pers WHERE saleID = \''.mc_digitSan($SALES->id).'\'')>0) {
    ?>
    <a class="pers" href="?p=sales-view&amp;view-personalisation=<?php echo $SALES->id; ?>" title="<?php echo mc_cleanDataEnt($msg_sales37); ?>" onclick="mc_Window(this.href,'<?php echo GREYBOX_PERS_HEIGHT; ?>','<?php echo GREYBOX_PERS_WIDTH; ?>',this.title,'<?php echo str_replace(array('\'','&#039;'),array(),$msg_javascript141); ?>');return false;"><?php echo $msg_sales37; ?></a>
    <?php
    }
    if (mc_rowCount('purchases WHERE saleID = \''.$SALES->id.'\' AND saleConfirmation = \'yes\' AND productType = \'download\'')>0) {
    ?>
    <a class="downloads" href="?p=downloads&amp;sale=<?php echo $SALES->id; ?>" title="<?php echo mc_cleanDataEnt($msg_sales38); ?>" onclick="mc_Window(this.href,'<?php echo GREYBOX_DOWNLOADS_HEIGHT; ?>','<?php echo GREYBOX_DOWNLOADS_WIDTH; ?>',this.title,'<?php echo str_replace(array('\'','&#039;'),array(),$msg_javascript141); ?>');return false;"><?php echo $msg_sales38; ?></a>
    <?php
    }
    ?>
    <a class="update" href="?p=sales-update&amp;sale=<?php echo $SALES->id; ?>" title="<?php echo mc_cleanDataEnt($msg_sales2); ?>"><?php echo $msg_sales2; ?></a>
    <br class="clear" />
  </p>
</div>
<?php
}
} else {
?>
<p class="noData"><?php echo $msg_sales17; ?></p>
<?php
}
}

// Payment statuses on dashboard..
$qPay = mysql_query("SELECT * FROM ".DB_PREFIX."paystatuses WHERE `homepage` = 'yes' ORDER BY `statname`")
        or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
while ($PST = mysql_fetch_object($qPay)) {

$query = mysql_query("SELECT *,DATE_FORMAT(purchaseDate,'".$SETTINGS->mysqlDateFormat."') AS sdate 
         FROM ".DB_PREFIX."sales
         WHERE saleConfirmation = 'yes'
         AND paymentStatus      = '{$PST->id}'
         ORDER BY id DESC
         ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
if (mysql_num_rows($query)>0) {
?>
<div class="fieldHeadWrapper">
  <p><?php echo (!SHOW_PENDING_SALES_ON_MAIN_PAGE && !SHOW_COMPLETED_SALES_ON_MAIN_PAGE ? '<span class="float"><a href="#" onclick="mc_homeSlider();return false"><img id="slider" src="templates/images/slide-up.png" alt="'.mc_cleanDataEnt($msg_main18).'" title="'.mc_cleanDataEnt($msg_main18).'" /></a></span>' : ''); ?><?php echo mc_cleanData($PST->statname).' ('.mysql_num_rows($query).')'; ?></p>
</div>
<?php     
while ($SALES = mysql_fetch_object($query)) {
?>         
<div class="productWrapper">
  <div class="productWrapper_inner">
   <div class="td1"><?php echo mc_saleInvoiceNumber($SALES->invoiceNo); ?></div>
   <div class="td2"><?php echo ($SALES->bill_1 ? mc_cleanData($SALES->bill_1) : '&nbsp;'); ?></div>
   <div class="td3"><?php echo $SALES->sdate; ?></div>
   <div class="td4"><?php echo mc_paymentMethodName($SALES->paymentMethod); ?></div>
   <div class="td5"><?php echo str_replace(array('{id}','{count}'),array($SALES->id,mc_sumCount('purchases WHERE saleID = \''.$SALES->id.'\' AND saleConfirmation = \'yes\'','productQty',true)),$msg_sales31); ?></div>
   <div class="td6"><?php echo mc_currencyFormat(mc_formatPrice($SALES->grandTotal,true)); ?></div>
   <br class="clear" />
   <p class="status"><?php echo statusText($SALES->paymentStatus); ?></p>
  </div>
  <p class="panel">
    <?php
    if ($uDel=='yes') {
    ?>
    <a class="delete" href="?p=sales&amp;delete=<?php echo $SALES->id; ?>" onclick="return confirmMessage('<?php echo mc_cleanDataEnt($msg_javascript45); ?>')" title="<?php echo mc_cleanDataEnt($msg_script10); ?>"><?php echo $msg_script10; ?></a>
    <?php
    }
    ?>
    <a class="edit" href="?p=sales-view&amp;sale=<?php echo $SALES->id; ?>" title="<?php echo mc_cleanDataEnt($msg_sales13); ?>"><?php echo $msg_sales13; ?></a>
    <a class="exp" href="?p=sales&amp;export=<?php echo $SALES->id; ?>" title="<?php echo mc_cleanDataEnt($msg_sales4); ?>"><?php echo $msg_sales4; ?></a>
    <a class="invoice" href="?p=invoice&amp;sale=<?php echo $SALES->id; ?>" onclick="window.open(this);return false" title="<?php echo mc_cleanDataEnt($msg_sales5); ?>"><?php echo $msg_sales5; ?></a>
    <?php
    // Show packing slip link if there are physical products..
    if (mc_rowCount('purchases WHERE saleID = \''.$SALES->id.'\' AND saleConfirmation = \'yes\' AND productType = \'physical\'')>0) {
    ?>
    <a class="packing" href="?p=packing-slip&amp;sale=<?php echo $SALES->id; ?>" onclick="window.open(this);return false" title="<?php echo mc_cleanDataEnt($msg_sales6); ?>"><?php echo $msg_sales6; ?></a>
    <?php
    }
    if (mc_rowCount('purch_pers WHERE saleID = \''.mc_digitSan($SALES->id).'\'')>0) {
    ?>
    <a class="pers" href="?p=sales-view&amp;view-personalisation=<?php echo $SALES->id; ?>" title="<?php echo mc_cleanDataEnt($msg_sales37); ?>" onclick="mc_Window(this.href,'<?php echo GREYBOX_PERS_HEIGHT; ?>','<?php echo GREYBOX_PERS_WIDTH; ?>',this.title,'<?php echo str_replace(array('\'','&#039;'),array(),$msg_javascript141); ?>');return false;"><?php echo $msg_sales37; ?></a>
    <?php
    }
    if (mc_rowCount('purchases WHERE saleID = \''.$SALES->id.'\' AND saleConfirmation = \'yes\' AND productType = \'download\'')>0) {
    ?>
    <a class="downloads" href="?p=downloads&amp;sale=<?php echo $SALES->id; ?>" title="<?php echo mc_cleanDataEnt($msg_sales38); ?>" onclick="mc_Window(this.href,'<?php echo GREYBOX_DOWNLOADS_HEIGHT; ?>','<?php echo GREYBOX_DOWNLOADS_WIDTH; ?>',this.title,'<?php echo str_replace(array('\'','&#039;'),array(),$msg_javascript141); ?>');return false;"><?php echo $msg_sales38; ?></a>
    <?php
    }
    ?>
    <a class="update" href="?p=sales-update&amp;sale=<?php echo $SALES->id; ?>" title="<?php echo mc_cleanDataEnt($msg_sales2); ?>"><?php echo $msg_sales2; ?></a>
    <br class="clear" />
  </p>
</div>
<?php
}
}

}

}

?>
<p style="padding:0 0 40px 0">&nbsp;</p>
</div>
