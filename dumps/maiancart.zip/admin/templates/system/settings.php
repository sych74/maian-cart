<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } ?>
<div id="content">

<?php
$tabIndex = 0;
if (isset($OK)) {
  echo actionCompleted($msg_settings31);
  //Reload..
  $SETTINGS = mysql_fetch_object(mysql_query("SELECT * FROM ".DB_PREFIX."settings LIMIT 1")) 
              or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
}
// Unserialize data..
$SLIDER = ($SETTINGS->searchSlider ? unserialize($SETTINGS->searchSlider) : array());
?>

<?php echo $msg_settings; ?><br /><br />

<form method="post" id="form" action="?p=settings">
<div class="fieldHeadWrapper">
  <p style="text-align:right"><span style="float:left;display:block;padding:3px 0 0 0"><?php echo $msg_settings77; ?></span>
  <?php
  include(PATH.'templates/system/menu.php');
  ?>
  </p>
</div>

<div class="formFieldWrapper">
  <div class="formLeft">
    <label><?php echo $msg_settings2; ?>: <?php echo mc_displayHelpTip($msg_javascript3,'RIGHT'); ?></label>
    <input type="text" name="website" value="<?php echo mc_cleanData($SETTINGS->website); ?>" class="box" tabindex="<?php echo ++$tabIndex; ?>" /> 
  </div>
  <div class="formRight">  
    <label><?php echo $msg_settings13; ?>: <?php echo mc_displayHelpTip($msg_javascript10,'LEFT'); ?></label>
    <?php echo $msg_script5; ?> <input type="radio" tabindex="<?php echo ++$tabIndex; ?>" name="en_modr" value="yes"<?php echo ($SETTINGS->en_modr=='yes' ? ' checked="checked"' : ''); ?> /> <?php echo $msg_script6; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="en_modr" value="no"<?php echo ($SETTINGS->en_modr=='no' ? ' checked="checked"' : ''); ?> />
    <span style="padding-left:50px"><?php echo $msg_settings246; ?> <input<?php echo ($SETTINGS->appendindex=='yes' ? ' checked="checked" ' : ' '); ?>type="checkbox" name="appendindex" value="yes" /></span>
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper">
  <div class="formLeft">
    <label><?php echo $msg_settings4; ?>: <?php echo mc_displayHelpTip($msg_javascript5,'RIGHT'); ?></label>
    <input type="text" name="ifolder" value="<?php echo mc_cleanData($SETTINGS->ifolder); ?>" class="box" tabindex="<?php echo ++$tabIndex; ?>" /> 
  </div>
  <div class="formRight">  
    <label><?php echo $msg_settings60; ?>: <?php echo mc_displayHelpTip($msg_javascript200,'LEFT'); ?></label>
    <input type="text" name="serverPath" value="<?php echo mc_cleanData($SETTINGS->serverPath); ?>" class="box" tabindex="<?php echo ++$tabIndex; ?>" /> 
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper">
  <div class="formLeft">
    <label><?php echo $msg_settings9; ?>: <?php echo mc_displayHelpTip($msg_javascript7,'RIGHT'); ?></label>
    <input type="text" name="metaKeys" value="<?php echo mc_cleanDataEnt($SETTINGS->metaKeys); ?>" class="box" tabindex="<?php echo ++$tabIndex; ?>" /> 
  </div>
  <div class="formRight">  
    <label><?php echo $msg_settings10; ?>: <?php echo mc_displayHelpTip($msg_javascript8,'LEFT'); ?></label>
    <input type="text" name="metaDesc" value="<?php echo mc_cleanDataEnt($SETTINGS->metaDesc); ?>" class="box" tabindex="<?php echo ++$tabIndex; ?>" />
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper">
  <div class="formLeft">
    <label><?php echo $msg_settings6; ?>: <?php echo mc_displayHelpTip($msg_javascript11,'RIGHT'); ?></label>
    <select name="languagePref" tabindex="<?php echo ++$tabIndex; ?>">
    <?php
    $showlang = opendir(REL_PATH.'content/language/');
    while (false!==($read=readdir($showlang))) {
      if (is_dir(REL_PATH.'content/language/'.$read) && !in_array($read,array('.','..'))) {
        echo '<option value="'.$read.'"'.($read==$SETTINGS->languagePref ? ' selected="selected"' : '').'>'.$read.'</option>'.mc_defineNewline();
      }
    }
    closedir($showlang);
    ?>
    </select>
  </div>
  <div class="formRight">
    <label><?php echo $msg_settings245; ?>: <?php echo mc_displayHelpTip($msg_javascript467); ?></label>
    <select name="theme" tabindex="<?php echo ++$tabIndex; ?>">
    <?php
    $showthm = opendir(REL_PATH.'content/');
    while (false!==($read=readdir($showthm))) {
      if (is_dir(REL_PATH.'content/'.$read) && substr(strtolower($read),0,6)=='_theme') {
        echo '<option'.($read==$SETTINGS->theme ? ' selected="selected"' : '').'>'.$read.'</option>'.mc_defineNewline();
      }
    }
    closedir($showthm);
    ?>
    </select>
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper">
  <div class="formLeft">
    <label><?php echo $msg_settings145; ?>: <?php echo mc_displayHelpTip($msg_javascript109,'RIGHT'); ?></label>
    <?php echo $msg_script5; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="enEntryLog" value="yes"<?php echo ($SETTINGS->enEntryLog=='yes' ? ' checked="checked"' : ''); ?> /> <?php echo $msg_script6; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="enEntryLog" value="no"<?php echo ($SETTINGS->enEntryLog=='no' ? ' checked="checked"' : ''); ?> />
  </div>
  <div class="formRight">  
    <label><?php echo $msg_settings159; ?>: <?php echo mc_displayHelpTip($msg_javascript317,'LEFT'); ?></label>
    <input type="text" name="adminFolderName" value="<?php echo mc_cleanData($SETTINGS->adminFolderName); ?>" class="box" tabindex="<?php echo ++$tabIndex; ?>" /> 
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper">
  <div class="formLeft">
    <label><?php echo $msg_settings150; ?>: <?php echo mc_displayHelpTip($msg_javascript288,'RIGHT'); ?></label>
    <?php echo $msg_script5; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="smartQuotes" value="yes"<?php echo ($SETTINGS->smartQuotes=='yes' ? ' checked="checked"' : ''); ?> /> <?php echo $msg_script6; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="smartQuotes" value="no"<?php echo ($SETTINGS->smartQuotes=='no' ? ' checked="checked"' : ''); ?> />
  </div>
  <div class="formRight">  
    <label><?php echo $msg_settings195; ?>: <?php echo mc_displayHelpTip($msg_javascript385,'LEFT'); ?></label>
    <?php echo $msg_script5; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="enableBBCode" value="yes"<?php echo ($SETTINGS->enableBBCode=='yes' ? ' checked="checked"' : ''); ?> /> <?php echo $msg_script6; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="enableBBCode" value="no"<?php echo ($SETTINGS->enableBBCode=='no' ? ' checked="checked"' : ''); ?> />
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper">
  <div class="formLeft">
    <label><?php echo $msg_settings98; ?>: <?php echo mc_displayHelpTip($msg_javascript245,'RIGHT'); ?></label>
    <?php echo $msg_script5; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="helpTips" value="yes"<?php echo ($SETTINGS->helpTips=='yes' ? ' checked="checked"' : ''); ?> /> <?php echo $msg_script6; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="helpTips" value="no"<?php echo ($SETTINGS->helpTips=='no' ? ' checked="checked"' : ''); ?> />
  </div>
  <div class="formRight">  
  </div>
  <br class="clear" />
</div>

<div class="fieldHeadWrapper">
  <p><?php echo $msg_settings140; ?></p>
</div>

<div class="formFieldWrapper">
  <div class="formLeft">
    <label><?php echo $msg_settings87; ?>: <?php echo mc_displayHelpTip($msg_javascript230,'RIGHT'); ?></label>
    <?php echo $msg_script5; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="activateEmails" value="yes"<?php echo ($SETTINGS->activateEmails=='yes' ? ' checked="checked"' : ''); ?> /> <?php echo $msg_script6; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="activateEmails" value="no"<?php echo ($SETTINGS->activateEmails=='no' ? ' checked="checked"' : ''); ?> />
  </div>
  <div class="formRight">  
    <label><?php echo $msg_settings3; ?>: <?php echo mc_displayHelpTip($msg_javascript4,'LEFT'); ?></label>
    <input type="text" name="email" value="<?php echo mc_cleanData($SETTINGS->email); ?>" class="box" tabindex="<?php echo ++$tabIndex; ?>" />
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper">
  <div class="formLeft" style="width:98%">  
    <label><?php echo $msg_settings141; ?>: <?php echo mc_displayHelpTip($msg_javascript282,'RIGHT'); ?></label>
    <input type="text" name="addEmails" value="<?php echo mc_cleanData($SETTINGS->addEmails); ?>" class="box" style="width:95%" tabindex="<?php echo ++$tabIndex; ?>" />
  </div>
  <br class="clear" />
</div>

<div class="fieldHeadWrapper">
  <p><?php echo $msg_settings142; ?></p>
</div>

<div class="formFieldWrapper">
  <div class="formLeft">
    <label><a href="http://php.net/manual/en/function.date.php" onclick="window.open(this);return false" title="<?php echo mc_cleanDataEnt($msg_settings102); ?>"><?php echo $msg_settings102; ?></a>: <?php echo mc_displayHelpTip($msg_javascript233,'RIGHT'); ?></label>
    <input type="text" name="systemDateFormat" value="<?php echo $SETTINGS->systemDateFormat; ?>" class="box" style="width:30%" maxlength="10" tabindex="<?php echo ++$tabIndex; ?>" /> 
  </div>
  <div class="formRight">  
    <label><a href="http://dev.mysql.com/doc/refman/5.1/en/date-and-time-functions.html#function_date-format" onclick="window.open(this);return false" title="<?php echo mc_cleanDataEnt($msg_settings99); ?>"><?php echo $msg_settings99; ?></a>: <?php echo mc_displayHelpTip($msg_javascript234,'LEFT'); ?></label>
    <input type="text" name="mysqlDateFormat" value="<?php echo $SETTINGS->mysqlDateFormat; ?>" class="box" style="width:30%" maxlength="30" tabindex="<?php echo ++$tabIndex; ?>" />
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper">
  <div class="formLeft">
    <label><?php echo $msg_settings96; ?>: <?php echo mc_displayHelpTip($msg_javascript235,'RIGHT'); ?></label>
    <select name="jsDateFormat" tabindex="<?php echo ++$tabIndex; ?>">
    <?php
    foreach (array('DD-MM-YYYY','DD/MM/YYYY','YYYY-MM-DD','YYYY/MM/DD','MM-DD-YYYY','MM/DD/YYYY') AS $jsf) {
    ?>
    <option value="<?php echo $jsf; ?>"<?php echo ($SETTINGS->jsDateFormat==$jsf ? ' selected="selected"' : ''); ?>><?php echo $jsf; ?></option>
    <?php
    }
    ?>
    </select>
  </div>
  <div class="formRight">
    <label><?php echo $msg_settings97; ?>: <?php echo mc_displayHelpTip($msg_javascript236,'LEFT'); ?></label>
    <?php echo $msg_settings103; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="jsWeekStart" value="0"<?php echo ($SETTINGS->jsWeekStart=='0' ? ' checked="checked"' : ''); ?> /> <?php echo $msg_settings104; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="jsWeekStart" value="1"<?php echo ($SETTINGS->jsWeekStart=='1' ? ' checked="checked"' : ''); ?> />
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper">
  <div class="formLeft">
    <label><?php echo $msg_settings100; ?>: <?php echo mc_displayHelpTip(str_replace('{offset}',date('j F Y').' @ '.date('H:iA'),$msg_javascript237),'RIGHT'); ?></label>
    <select name="timezone" tabindex="<?php echo ++$tabIndex; ?>">
    <?php
    include(REL_PATH.'control/timezones.php');
    foreach ($timezones AS $tK => $tV) {
    ?>
    <option value="<?php echo $tK; ?>"<?php echo ($SETTINGS->timezone==$tK ? ' selected="selected"' : ''); ?>><?php echo $tV; ?></option>
    <?php
    }
    ?>
    </select>
  </div>
  <div class="formRight">
    
  </div>
  <br class="clear" />
</div>

<div class="fieldHeadWrapper">
  <p><span class="float"><a class="batch" href="?p=product-status" title="<?php echo mc_cleanDataEnt($msg_settings244); ?>"><?php echo $msg_settings244; ?></a></span><?php echo $msg_settings175; ?></p>
</div>

<div class="formFieldWrapper">
  <div class="formLeft">
    <label><a href="http://www.disqus.com" onclick="window.open(this);return false" title="<?php echo mc_cleanDataEnt($msg_settings173); ?>"><?php echo $msg_settings173; ?></a>: <?php echo mc_displayHelpTip($msg_javascript342,'RIGHT'); ?></label>
    <input type="text" name="disqusShortName" value="<?php echo mc_cleanData($SETTINGS->disqusShortName); ?>" class="box" tabindex="<?php echo ++$tabIndex; ?>" maxlength="250" /> 
  </div>
  <div class="formRight">  
    <label><?php echo $msg_settings174; ?>: <?php echo mc_displayHelpTip($msg_javascript343,'LEFT'); ?></label>
    <?php echo $msg_script5; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="disqusDevMode" value="yes"<?php echo ($SETTINGS->disqusDevMode=='yes' ? ' checked="checked"' : ''); ?> /> <?php echo $msg_script6; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="disqusDevMode" value="no"<?php echo ($SETTINGS->disqusDevMode=='no' ? ' checked="checked"' : ''); ?> />
  </div>
  <br class="clear" />
</div>

<div class="fieldHeadWrapper">
  <p><?php echo $msg_settings160; ?></p>
</div>

<div class="formFieldWrapper">
  <div class="formLeft">
    <label><a href="http://www.facebook.com" onclick="window.open(this);return false" title="<?php echo mc_cleanDataEnt($msg_settings161); ?>"><?php echo $msg_settings161; ?></a>: <?php echo mc_displayHelpTip($msg_javascript327,'RIGHT'); ?></label>
    <input type="text" name="facebookLink" value="<?php echo mc_cleanData($SETTINGS->facebookLink); ?>" class="box" tabindex="<?php echo ++$tabIndex; ?>" /> 
  </div>
  <div class="formRight">  
    <label><a href="http://www.twitter.com" onclick="window.open(this);return false" title="<?php echo mc_cleanDataEnt($msg_settings162); ?>"><?php echo $msg_settings162; ?></a>: <?php echo mc_displayHelpTip($msg_javascript328,'LEFT'); ?></label>
    <input type="text" name="twitterLink" value="<?php echo mc_cleanData($SETTINGS->twitterLink); ?>" class="box" tabindex="<?php echo ++$tabIndex; ?>" /> 
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper">
  <div class="formLeft">
    <label><?php echo $msg_settings265; ?>: <?php echo mc_displayHelpTip($msg_javascript485,'RIGHT'); ?></label>
    <input type="text" name="twitterUser" value="<?php echo mc_cleanData($SETTINGS->twitterUser); ?>" class="box" tabindex="<?php echo ++$tabIndex; ?>" /> 
  </div>
  <div class="formRight">  
    <label><?php echo $msg_settings266; ?>: <?php echo mc_displayHelpTip($msg_javascript486,'LEFT'); ?></label>
    <?php echo $msg_script5; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="twitterLatest" value="yes"<?php echo ($SETTINGS->twitterLatest=='yes' ? ' checked="checked"' : ''); ?> /> <?php echo $msg_script6; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="twitterLatest" value="no"<?php echo ($SETTINGS->twitterLatest=='no' ? ' checked="checked"' : ''); ?> />
  </div>
  <br class="clear" />
</div>

<div class="fieldHeadWrapper">
  <p><?php echo $msg_settings217; ?></p>
</div>

<div class="formFieldWrapper">
  <div class="formLeft">
    <label><a href="https://isbndb.com/" onclick="window.open(this);return false" title="<?php echo mc_cleanDataEnt($msg_settings218); ?>"><?php echo $msg_settings218; ?></a>: <?php echo mc_displayHelpTip($msg_javascript419,'RIGHT'); ?></label>
    <input type="text" name="isbnAPI" value="<?php echo mc_cleanData($SETTINGS->isbnAPI); ?>" maxlength="50" class="box" tabindex="<?php echo ++$tabIndex; ?>" /> 
  </div>
  <div class="formRight">  
  </div>
  <br class="clear" />
</div>

<div class="fieldHeadWrapper">
  <p><span class="float"><a href="http://www.maiancube.com" title="Maian Cube" onclick="window.open(this);return false">www.maiancube.com</a></span><?php echo $msg_settings258; ?></p>
</div>

<div class="formFieldWrapper">
  <div class="formLeft">
    <label><?php echo $msg_settings259; ?>: <?php echo mc_displayHelpTip($msg_javascript479,'RIGHT'); ?></label>
    <input type="text" name="cubeUrl" value="<?php echo mc_cleanData($SETTINGS->cubeUrl); ?>" class="box" tabindex="<?php echo ++$tabIndex; ?>" /> 
  </div>
  <div class="formRight">  
    <label><?php echo $msg_settings260; ?>: <?php echo mc_displayHelpTip($msg_javascript480,'LEFT'); ?></label>
    <input type="text" name="cubeAPI" value="<?php echo mc_cleanData($SETTINGS->cubeAPI); ?>" class="box" tabindex="<?php echo ++$tabIndex; ?>" /> 
  </div>
  <br class="clear" />
</div>

<div class="fieldHeadWrapper">
  <p><?php echo $msg_settings143; ?></p>
</div>

<div class="formFieldWrapper">
  <div class="formLeft">
    <label><?php echo $msg_settings12; ?>: <?php echo mc_displayHelpTip($msg_javascript9,'RIGHT'); ?></label>
    <?php echo $msg_script5; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="en_rss" value="yes"<?php echo ($SETTINGS->en_rss=='yes' ? ' checked="checked"' : ''); ?> /> <?php echo $msg_script6; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="en_rss" value="no"<?php echo ($SETTINGS->en_rss=='no' ? ' checked="checked"' : ''); ?> />
  </div>
  <div class="formRight">
    <label><?php echo $msg_settings101; ?>: <?php echo mc_displayHelpTip($msg_javascript238,'LEFT'); ?></label>
    <input type="text" name="rssFeedLimit" value="<?php echo $SETTINGS->rssFeedLimit; ?>" class="box" style="width:15%" maxlength="3" tabindex="<?php echo ++$tabIndex; ?>" />
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper">
  <div class="formLeft">
    <label><?php echo $msg_settings275; ?>: <?php echo mc_displayHelpTip($msg_javascript495,'RIGHT'); ?></label>
    <?php echo $msg_script5; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="rssScroller" value="yes"<?php echo ($SETTINGS->rssScroller=='yes' ? ' checked="checked"' : ''); ?> /> <?php echo $msg_script6; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="rssScroller" value="no"<?php echo ($SETTINGS->rssScroller=='no' ? ' checked="checked"' : ''); ?> />
  </div>
  <div class="formRight">
    <label><?php echo $msg_settings276; ?>: <?php echo mc_displayHelpTip($msg_javascript496,'LEFT'); ?></label>
    <input type="text" name="rssScrollerUrl" value="<?php echo $SETTINGS->rssScrollerUrl; ?>" class="box" style="width:70%" maxlength="250" tabindex="<?php echo ++$tabIndex; ?>" /> /
    <input type="text" name="rssScrollerLimit" value="<?php echo $SETTINGS->rssScrollerLimit; ?>" class="box" style="width:10%" maxlength="3" tabindex="<?php echo ++$tabIndex; ?>" />
  </div>
  <br class="clear" />
</div>

<div class="fieldHeadWrapper">
  <p><?php echo $msg_settings238; ?></p>
</div>

<div class="formFieldWrapper">
  <div class="formLeft">
    <label><?php echo $msg_settings239; ?>: <?php echo mc_displayHelpTip($msg_javascript461,'RIGHT'); ?></label>
    <?php echo $msg_script5; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="en_sitemap" value="yes"<?php echo ($SETTINGS->en_sitemap=='yes' ? ' checked="checked"' : ''); ?> /> <?php echo $msg_script6; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="en_sitemap" value="no"<?php echo ($SETTINGS->en_sitemap=='no' ? ' checked="checked"' : ''); ?> />
  </div>
  <div class="formRight">
    <label><?php echo $msg_settings240; ?>: <?php echo mc_displayHelpTip($msg_javascript462,'LEFT'); ?></label>
    <?php echo $msg_settings241; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="sitemapPref" value="list"<?php echo ($SETTINGS->sitemapPref=='list' ? ' checked="checked"' : ''); ?> /> <?php echo $msg_settings242; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="sitemapPref" value="cat"<?php echo ($SETTINGS->sitemapPref=='cat' ? ' checked="checked"' : ''); ?> />
  </div>
  <br class="clear" />
</div>

<div class="fieldHeadWrapper">
  <p><?php echo $msg_settings144; ?></p>
</div>

<div class="formFieldWrapper">
  <div class="formLeft">
    <label><?php echo $msg_settings89; ?>: <?php echo mc_displayHelpTip($msg_javascript232,'RIGHT'); ?></label>
    <input type="text" name="productsPerPage" value="<?php echo $SETTINGS->productsPerPage; ?>" class="box" style="width:15%" tabindex="<?php echo ++$tabIndex; ?>" /> 
  </div>
  <div class="formRight">
    <label><?php echo $msg_settings107; ?>: <?php echo mc_displayHelpTip($msg_javascript247,'LEFT'); ?></label>
    <select name="minInvoiceDigits" tabindex="<?php echo ++$tabIndex; ?>">
    <?php
    foreach (range(0,20) AS $limits) {
    ?>
    <option value="<?php echo $limits; ?>"<?php echo ($SETTINGS->minInvoiceDigits==$limits ? ' selected="selected"' : ''); ?>><?php echo $limits; ?></option>
    <?php
    }
    ?>
    </select>&nbsp;&nbsp;<?php echo $msg_settings257; ?>: <input type="text" name="invoiceNo" value="<?php echo $SETTINGS->invoiceNo; ?>" class="box" style="width:15%" maxlength="11" tabindex="<?php echo ++$tabIndex; ?>" />
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper">
  <div class="formLeft">
    <label><?php echo $msg_settings93; ?>: <?php echo mc_displayHelpTip($msg_javascript239,'RIGHT'); ?></label>
    <input type="text" name="flashVideoWidth" value="<?php echo $SETTINGS->flashVideoWidth; ?>" class="box" style="width:15%" maxlength="4" tabindex="<?php echo ++$tabIndex; ?>" />px
  </div>
  <div class="formRight">  
    <label><?php echo $msg_settings94; ?>: <?php echo mc_displayHelpTip($msg_javascript240,'LEFT'); ?></label>
    <input type="text" name="flashVideoHeight" value="<?php echo $SETTINGS->flashVideoHeight; ?>" class="box" style="width:15%" maxlength="4" tabindex="<?php echo ++$tabIndex; ?>" />px
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper">
  <div class="formLeft">
    <label><?php echo $msg_settings88; ?>: <?php echo mc_displayHelpTip($msg_javascript241,'RIGHT'); ?></label>
    <input type="text" name="saleComparisonItems" value="<?php echo $SETTINGS->saleComparisonItems; ?>" class="box" style="width:15%" maxlength="6" tabindex="<?php echo ++$tabIndex; ?>" /> 
  </div>
  <div class="formRight">  
    <label><?php echo $msg_settings151; ?>: <?php echo mc_displayHelpTip($msg_javascript289,'LEFT'); ?></label>
    <?php echo $msg_script5; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="hitCounter" value="yes"<?php echo ($SETTINGS->hitCounter=='yes' ? ' checked="checked"' : ''); ?> /> <?php echo $msg_script6; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="hitCounter" value="no"<?php echo ($SETTINGS->hitCounter=='no' ? ' checked="checked"' : ''); ?> />
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper">
  <div class="formLeft">
    <label><?php echo $msg_settings90; ?>: <?php echo mc_displayHelpTip($msg_javascript243,'RIGHT'); ?></label>
    <input type="text" name="mostPopProducts" value="<?php echo $SETTINGS->mostPopProducts; ?>" class="box" style="width:15%" maxlength="5" tabindex="<?php echo ++$tabIndex; ?>" /> 
  </div>
  <div class="formRight">  
    <label><?php echo $msg_settings214; ?>: <?php echo mc_displayHelpTip($msg_javascript417,'LEFT'); ?></label>
    <?php echo $msg_settings215; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="mostPopPref" value="hits"<?php echo ($SETTINGS->mostPopPref=='hits' ? ' checked="checked"' : ''); ?> /> <?php echo $msg_settings216; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="mostPopPref" value="sales"<?php echo ($SETTINGS->mostPopPref=='sales' ? ' checked="checked"' : ''); ?> />&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $msg_settings236; ?> <input type="checkbox" name="excludeFreePop" value="yes"<?php echo ($SETTINGS->excludeFreePop=='yes' ? ' checked="checked"' : ''); ?> />
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper">
  <div class="formLeft">
    <label><?php echo $msg_settings91; ?>: <?php echo mc_displayHelpTip($msg_javascript244,'RIGHT'); ?></label>
    <?php echo $msg_settings172; ?> <input type="text" name="latestProdLimit" value="<?php echo $SETTINGS->latestProdLimit; ?>" class="box" style="width:10%" maxlength="5" tabindex="<?php echo ++$tabIndex; ?>" />
    <select name="latestProdDuration">
     <option value="days"<?php echo ($SETTINGS->latestProdDuration=='days' ? ' selected="selected"' : ''); ?>><?php echo $msg_settings169; ?></option>
     <option value="months"<?php echo ($SETTINGS->latestProdDuration=='months' ? ' selected="selected"' : ''); ?>><?php echo $msg_settings170; ?></option>
     <option value="years"<?php echo ($SETTINGS->latestProdDuration=='years' ? ' selected="selected"' : ''); ?>><?php echo $msg_settings171; ?></option>
    </select>
  </div>
  <div class="formRight">
    <label><?php echo $msg_settings163; ?>: <?php echo mc_displayHelpTip($msg_javascript329,'LEFT'); ?></label>
    <?php echo $msg_script5; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="enableRecentView" value="yes"<?php echo ($SETTINGS->enableRecentView=='yes' ? ' checked="checked"' : ''); ?> /> <?php echo $msg_script6; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="enableRecentView" value="no"<?php echo ($SETTINGS->enableRecentView=='no' ? ' checked="checked"' : ''); ?> />
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper">
  <div class="formLeft">
    <label><?php echo $msg_settings188; ?>: <?php echo mc_displayHelpTip($msg_javascript374,'RIGHT'); ?></label>
    <input type="text" name="maxProductChars" value="<?php echo $SETTINGS->maxProductChars; ?>" class="box" style="width:15%" maxlength="8" tabindex="<?php echo ++$tabIndex; ?>" /> 
  </div>
  <div class="formRight">
    <label><?php echo $msg_settings209; ?>: <?php echo mc_displayHelpTip($msg_javascript407,'LEFT'); ?></label>
    <?php echo $msg_script5; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="parentCatHomeDisplay" value="yes"<?php echo ($SETTINGS->parentCatHomeDisplay=='yes' ? ' checked="checked"' : ''); ?> /> <?php echo $msg_script6; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="parentCatHomeDisplay" value="no"<?php echo ($SETTINGS->parentCatHomeDisplay=='no' ? ' checked="checked"' : ''); ?> />
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper">
  <div class="formLeft">
    <label><?php echo $msg_settings234; ?>: <?php echo mc_displayHelpTip($msg_javascript456,'RIGHT'); ?></label>
    <input type="text" name="freeTextDisplay" value="<?php echo $SETTINGS->freeTextDisplay; ?>" class="box" style="width:30%" maxlength="10" tabindex="<?php echo ++$tabIndex; ?>" /> 
  </div>
  <div class="formRight">
    <label><?php echo $msg_settings237; ?>: <?php echo mc_displayHelpTip($msg_javascript458,'LEFT'); ?></label>
    <input type="text" name="priceTextDisplay" value="<?php echo $SETTINGS->priceTextDisplay; ?>" class="box" maxlength="100" tabindex="<?php echo ++$tabIndex; ?>" /> 
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper">
  <div class="formLeft">
    <label><?php echo $msg_settings286; ?>: <?php echo mc_displayHelpTip($msg_javascript556,'RIGHT'); ?></label>
    <?php echo $msg_script5; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="menuCatCount" value="yes"<?php echo ($SETTINGS->menuCatCount=='yes' ? ' checked="checked"' : ''); ?> /> <?php echo $msg_script6; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="menuCatCount" value="no"<?php echo ($SETTINGS->menuCatCount=='no' ? ' checked="checked"' : ''); ?> />
  </div>
  <div class="formRight">
    <label><?php echo $msg_settings295; ?>: <?php echo mc_displayHelpTip($msg_javascript573,'LEFT'); ?></label>
    <?php echo $msg_script5; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="menuBrandCount" value="yes"<?php echo ($SETTINGS->menuBrandCount=='yes' ? ' checked="checked"' : ''); ?> /> <?php echo $msg_script6; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="menuBrandCount" value="no"<?php echo ($SETTINGS->menuBrandCount=='no' ? ' checked="checked"' : ''); ?> />
  </div>
  <br class="clear" />
</div>

<div class="fieldHeadWrapper">
  <p><span class="float"><a onclick="jQuery('#customBoxController').slideDown();return false" href="#" class="custom_boxes" title="<?php echo mc_cleanDataEnt($msg_settings283); ?>"><?php echo $msg_settings283; ?></a></span><?php echo $msg_settings208; ?> <?php echo mc_displayHelpTip($msg_javascript554,'RIGHT'); ?></p>
</div>

<div class="formFieldWrapper" id="customBoxController" style="display:none">
 <div>
  <span style="display:block;padding-bottom:5px"><?php echo $msg_settings284; ?> <?php echo mc_displayHelpTip($msg_javascript555,'RIGHT'); ?></span>
  <?php
  if (empty($orderCustomBoxes)) {
  ?>
  <p class="customBoxSelect">
   <select name="temp" onchange="if(this.value!='0'){mc_addCustomBox(this.value)}">
    <option value="0">- - - - - -</option>
    <?php
	$showbox          = opendir(REL_PATH.THEME_FOLDER.'/customTemplates/');
    while (false!==($read=readdir($showbox))) {
     if (substr($read,-8)=='.tpl.php' && substr($read,0,3)=='box') {
       echo '<option value="'.$read.'"'.(isset($EDIT->customTemplate) && $read==$EDIT->customTemplate ? ' selected="selected"' : '').'>'.$read.'</option>'.mc_defineNewline();
     }
    }
    closedir($showbox);
    ?>
   </select>
  </p>
  <?php
  } else {
  }
  ?>
  <span style="display:block;padding-top:5px;text-align:right;font-size:11px">[ <a href="#" onclick="jQuery('#customBoxController').slideUp();return false"><?php echo $msg_settings285; ?></a> ]</span>
 </div>
</div>

<div class="formFieldWrapper" id="boxController">
  <div class="formLeft">
  <?php
  $boxLimit   = 8;
  $orderBoxes = unserialize($SETTINGS->leftBoxOrder);
  for ($i=0; $i<$boxLimit; $i++) {
  $text      =  mc_cleanDataEnt($orderBoxes[$i][1]);
  $textD     =  array(
   'cat'     => $msg_public_header3,
   'points'  => $msg_public_header22,
   'popular' => $msg_public_header15,
   'tweets'  => $msg_public_header34,
   'recent'  => $msg_public_header8,
   'links'   => $msg_public_header6,
   'brands'  => $msg_public_header13,
   'rss'     => $msg_public_header35
  );
  ?>
  <p style="margin-bottom:5px">
  <input type="hidden" name="marker[]" value="<?php echo $orderBoxes[$i][1]; ?>" />
  <input type="text" name="pos[]" value="<?php echo $orderBoxes[$i][0]; ?>" class="box" style="width:5%" /> <?php echo $textD[$text]; ?>
  </p>
  <?php
  }
  ?><br />
  <?php echo $msg_settings287; ?><br />
  <select name="catGiftPos" style="margin-top:5px">
   <option value="start"<?php echo ($SETTINGS->catGiftPos=='start' ? ' selected="selected"' : ''); ?>><?php echo $msg_settings288; ?></option>
   <option value="end"<?php echo ($SETTINGS->catGiftPos=='end' ? ' selected="selected"' : ''); ?>><?php echo $msg_settings289; ?></option>
   <optgroup label="<?php echo mc_cleanDataEnt($msg_settings290); ?>">
   <?php
   $q_cats = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
             WHERE `catLevel` = '1'
             AND `childOf`    = '0'
             AND `enCat`      = 'yes'
             ORDER BY `catname`
             ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
   while ($CATS = mysql_fetch_object($q_cats)) {
   ?>
   <option value="<?php echo $CATS->id; ?>"<?php echo ($SETTINGS->catGiftPos==$CATS->id ? ' selected="selected"' : ''); ?>> <?php echo mc_cleanDataEnt($CATS->catname); ?></option>
   <?php
   $q_children = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
                 WHERE `catLevel` = '2'
                 AND `enCat`      = 'yes'
                 AND `childOf`    = '".$CATS->id."'
                 ORDER BY `catname`
                 ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
   while ($CHILDREN = mysql_fetch_object($q_children)) {
   ?>
   <option value="<?php echo $CHILDREN->id; ?>"<?php echo ($SETTINGS->catGiftPos==$CHILDREN->id ? ' selected="selected"' : ''); ?>>&nbsp;&nbsp;<?php echo mc_cleanDataEnt($CHILDREN->catname); ?></option>
   <?php
   $q_infants = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
                WHERE `catLevel` = '3'
                AND `childOf`    = '{$CHILDREN->id}'
                AND `enCat`      = 'yes'
                ORDER BY `catname`
                ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
   while ($INFANTS = mysql_fetch_object($q_infants)) {
   ?>
   <option value="<?php echo $INFANTS->id; ?>"<?php echo ($SETTINGS->catGiftPos==$INFANTS->id ? ' selected="selected"' : ''); ?>>&nbsp;&nbsp;&nbsp;&nbsp;<?php echo mc_cleanDataEnt($INFANTS->catname); ?></option>
   <?php
   }
   }
   }
   ?>
   </optgroup>
  </select><br /><br />
  <?php echo $msg_settings291; ?> <?php echo mc_displayHelpTip($msg_javascript571,'RIGHT'); ?><br />
  <?php echo $msg_script5; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="showBrands" value="yes"<?php echo ($SETTINGS->showBrands=='yes' ? ' checked="checked"' : ''); ?> /> <?php echo $msg_script6; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="showBrands" value="no"<?php echo ($SETTINGS->showBrands=='no' ? ' checked="checked"' : ''); ?> />
  </div>
  <div class="formRight" id="customBoxesLoader">
  <?php
  $orderCustomBoxes = ($SETTINGS->leftBoxCustom ? unserialize($SETTINGS->leftBoxCustom) : array());
  $con              = ($boxLimit-1);
  if (!empty($orderCustomBoxes)) {
  foreach ($orderCustomBoxes AS $oK => $oV) {
  ++$con;
  $text = mc_cleanDataEnt($oV);
  $pos  = (isset($orderBoxes[$con][0]) ? $orderBoxes[$con][0] : '0');
  ?>
  <p style="margin-bottom:5px" class="CBClass" id="cus_box_<?php echo $oK; ?>">
  <input type="hidden" name="cusBox[]" value="<?php echo $oK; ?>" />
  <input type="hidden" name="marker[]" value="<?php echo $text; ?>" />
  <input type="text" name="pos[]" value="<?php echo $pos; ?>" class="box" style="width:5%" /> <?php echo $text; ?> [<a href="#" onclick="mc_removeCustomBox('<?php echo $oK; ?>');return false">X</a>]
  </p>
  <?php
  }
  } else {
  ?>
  <span class="italics"><?php echo $msg_settings282; ?></span>
  <?php
  }
  ?>
  </div>
  <br class="clear" />
</div>

<div class="fieldHeadWrapper">
  <p><?php echo $msg_settings168; ?></p>
</div>

<div class="formFieldWrapper">
  <div class="formLeft">
    <label><?php echo $msg_settings167; ?>: <?php echo mc_displayHelpTip($msg_javascript335,'RIGHT'); ?></label>
    <input type="text" name="savedSearches" value="<?php echo $SETTINGS->savedSearches; ?>" class="box" style="width:15%" maxlength="6" tabindex="<?php echo ++$tabIndex; ?>" /> 
  </div>
  <div class="formRight">  
    <label><?php echo $msg_settings92; ?>: <?php echo mc_displayHelpTip($msg_javascript242,'LEFT'); ?></label>
    <input type="text" name="searchLowStockLimit" value="<?php echo $SETTINGS->searchLowStockLimit; ?>" class="box" style="width:15%" maxlength="5" tabindex="<?php echo ++$tabIndex; ?>" />
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper">
  <div class="formLeft">  
    <label><?php echo $msg_settings271; ?>: <?php echo mc_displayHelpTip($msg_javascript488,'RIGHT'); ?></label>
    <?php echo $msg_settings268; ?> <input type="text" name="searchSlider[min]" value="<?php echo (isset($SLIDER['min']) ? $SLIDER['min'] : '0'); ?>" class="box" style="width:10%" tabindex="<?php echo ++$tabIndex; ?>" />
    <?php echo $msg_settings269; ?> <input type="text" name="searchSlider[max]" value="<?php echo (isset($SLIDER['max']) ? $SLIDER['max'] : '300'); ?>" class="box" style="width:10%" tabindex="<?php echo ++$tabIndex; ?>" />
    <?php echo $msg_settings270; ?> <input type="text" name="searchSlider[start]" value="<?php echo (isset($SLIDER['start']) ? $SLIDER['start'] : '5'); ?>" class="box" style="width:10%" tabindex="<?php echo ++$tabIndex; ?>" /> -
    <input type="text" name="searchSlider[end]" value="<?php echo (isset($SLIDER['end']) ? $SLIDER['end'] : '100'); ?>" class="box" style="width:10%" tabindex="<?php echo ++$tabIndex; ?>" /> 
  </div>
  <div class="formRight">
    <label><?php echo $msg_settings296; ?>: <?php echo mc_displayHelpTip($msg_javascript576,'LEFT'); ?></label>
    <?php echo $msg_script5; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="searchTagsOnly" value="yes"<?php echo ($SETTINGS->searchTagsOnly=='yes' ? ' checked="checked"' : ''); ?> /> <?php echo $msg_script6; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="searchTagsOnly" value="no"<?php echo ($SETTINGS->searchTagsOnly=='no' ? ' checked="checked"' : ''); ?> />
  </div>
  <br class="clear" /> 
</div>

<div class="formFieldWrapper">
  <div class="formLeft">  
    <label><?php echo $msg_settings146; ?>: <?php echo mc_displayHelpTip($msg_javascript285,'RIGHT'); ?></label>
    <?php echo $msg_script5; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="enSearchLog" value="yes"<?php echo ($SETTINGS->enSearchLog=='yes' ? ' checked="checked"' : ''); ?> /> <?php echo $msg_script6; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="enSearchLog" value="no"<?php echo ($SETTINGS->enSearchLog=='no' ? ' checked="checked"' : ''); ?> />
  </div>
  <div class="formRight">
  </div>
  <br class="clear" /> 
</div>

<div class="fieldHeadWrapper">
  <p><?php echo $msg_settings122; ?></p>
</div>

<div class="formFieldWrapper">
  <div class="formLeft">
    <label><?php echo $msg_settings179; ?>: <?php echo mc_displayHelpTip($msg_javascript365,'RIGHT'); ?></label>
    <input type="text" name="thumbWidth" value="<?php echo $SETTINGS->thumbWidth; ?>" class="box" style="width:15%" maxlength="4" tabindex="<?php echo ++$tabIndex; ?>" /> 
  </div>
  <div class="formRight">  
    <label><?php echo $msg_settings180; ?>: <?php echo mc_displayHelpTip($msg_javascript366,'LEFT'); ?></label>
    <input type="text" name="thumbHeight" value="<?php echo $SETTINGS->thumbHeight; ?>" class="box" style="width:15%" maxlength="4" tabindex="<?php echo ++$tabIndex; ?>" />
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper">
  <div class="formLeft">  
    <label><?php echo $msg_settings181; ?>: <?php echo mc_displayHelpTip($msg_javascript367,'RIGHT'); ?></label>
    <input type="text" name="thumbQuality" value="<?php echo $SETTINGS->thumbQuality; ?>" class="box" style="width:15%" maxlength="3" tabindex="<?php echo ++$tabIndex; ?>" /> 
  </div>
  <div class="formRight">
    <label><?php echo $msg_settings190; ?>: <?php echo mc_displayHelpTip($msg_javascript379,'LEFT'); ?></label>
    <select name="thumbQualityPNG">
    <?php
    foreach (range(0,9) AS $r) {
    ?>
    <option value="<?php echo $r; ?>"<?php echo ($SETTINGS->thumbQualityPNG==$r ? ' selected="selected"' : ''); ?>><?php echo $r; ?></option>
    <?php
    }
    ?>
    </select> 
  </div>
  <br class="clear" /> 
</div>

<div class="formFieldWrapper">
  <div class="formLeft">  
    <label><?php echo $msg_settings281; ?>: <?php echo mc_displayHelpTip($msg_javascript548,'RIGHT'); ?></label>
    <?php echo $msg_script5; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="aspectRatio" value="yes"<?php echo ($SETTINGS->aspectRatio=='yes' ? ' checked="checked"' : ''); ?> /> <?php echo $msg_script6; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="aspectRatio" value="no"<?php echo ($SETTINGS->aspectRatio=='no' ? ' checked="checked"' : ''); ?> />
  </div>
  <div class="formRight">
    <label><?php echo $msg_settings292; ?>: <?php echo mc_displayHelpTip($msg_javascript572,'LEFT'); ?></label>
    <?php echo $msg_script5; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="renamePics" value="yes"<?php echo ($SETTINGS->renamePics=='yes' ? ' checked="checked"' : ''); ?> /> <?php echo $msg_script6; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="renamePics" value="no"<?php echo ($SETTINGS->renamePics=='no' ? ' checked="checked"' : ''); ?> />
	&nbsp;&nbsp;&nbsp;<?php echo $msg_settings293; ?>: <input type="text" name="tmbPrefix" value="<?php echo $SETTINGS->tmbPrefix; ?>" class="box" style="width:13%" maxlength="100" tabindex="<?php echo ++$tabIndex; ?>" />
	<?php echo $msg_settings294; ?>: <input type="text" name="imgPrefix" value="<?php echo $SETTINGS->imgPrefix; ?>" class="box" style="width:13%" maxlength="100" tabindex="<?php echo ++$tabIndex; ?>" />
  </div>
  <br class="clear" /> 
</div>

<div class="fieldHeadWrapper">
  <p><?php echo $msg_settings134; ?></p>
</div>

<div class="formFieldWrapper">
  <div class="formLeft">
    <label><?php echo $msg_settings106; ?>: <?php echo mc_displayHelpTip($msg_javascript246,'RIGHT'); ?></label>
    <?php echo $msg_script5; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="enableZip" value="yes"<?php echo ($SETTINGS->enableZip=='yes' ? ' checked="checked"' : ''); ?> /> <?php echo $msg_script6; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="enableZip" value="no"<?php echo ($SETTINGS->enableZip=='no' ? ' checked="checked"' : ''); ?> />
  </div>
  <div class="formRight">  
    <label><?php echo $msg_settings135; ?>: <?php echo mc_displayHelpTip($msg_javascript277,'LEFT'); ?></label>
    <input type="text" name="zipCreationLimit" value="<?php echo $SETTINGS->zipCreationLimit; ?>" class="box" style="width:55%" maxlength="100" tabindex="<?php echo ++$tabIndex; ?>" />
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper">
  <div class="formLeft">
    <label><?php echo $msg_settings136; ?>: <?php echo mc_displayHelpTip($msg_javascript278,'RIGHT'); ?></label>
    <input type="text" name="zipLimit" value="<?php echo $SETTINGS->zipLimit; ?>" class="box" style="width:15%" maxlength="3" tabindex="<?php echo ++$tabIndex; ?>" />
  </div>
  <div class="formRight">  
    <label><?php echo $msg_settings137; ?>: <?php echo mc_displayHelpTip($msg_javascript279,'LEFT'); ?></label>
    <input type="text" name="zipTimeOut" value="<?php echo $SETTINGS->zipTimeOut; ?>" class="box" style="width:15%" maxlength="6" tabindex="<?php echo ++$tabIndex; ?>" />
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper">
  <div class="formLeft">
    <label><?php echo $msg_settings138; ?>: <?php echo mc_displayHelpTip($msg_javascript280,'RIGHT'); ?></label>
    <input type="text" name="zipMemoryLimit" value="<?php echo $SETTINGS->zipMemoryLimit; ?>" class="box" style="width:15%" maxlength="5" tabindex="<?php echo ++$tabIndex; ?>" />MB
  </div>
  <div class="formRight"> 
    <label><?php echo $msg_settings139; ?>: <?php echo mc_displayHelpTip($msg_javascript281,'LEFT'); ?></label>
    <input type="text" name="zipAdditionalFolder" value="<?php echo $SETTINGS->zipAdditionalFolder; ?>" class="box" maxlength="50" tabindex="<?php echo ++$tabIndex; ?>" /> 
  </div>
  <br class="clear" />
</div>

<p style="text-align:center;padding-top:20px">
 <input type="hidden" name="process" value="yes" />
 <input class="formbutton" type="submit" value="<?php echo mc_cleanDataEnt($msg_settings8); ?>" title="<?php echo mc_cleanDataEnt($msg_settings8); ?>" />
</p>
</form>

<p>&nbsp;</p>
<p>&nbsp;</p>
</div>
