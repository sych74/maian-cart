<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } ?>
<div id="content">
<script type="text/javascript">
//<![CDATA[
function mc_updateCurRates() {
  if (!jQuery('input[name="auto"]:checked').val()) {
    jQuery('#form').submit();
  } else {
    jQuery(document).ready(function() {
	 jQuery.blockUI({ 
	  message: '<h1 class="uiBlockH1"><?php echo str_replace("'","\'",$msg_currency9); ?></h1>' 
	 });
     jQuery.ajax({
      type: 'POST',
	  url: 'index.php?p=currency-converter&processAuto=yes',
      data: jQuery("#content > form").serialize(),
      dataType: 'html',
      success: function (data) {
        jQuery.unblockUI({
          onUnblock: function() {
		    if (data=='OK') {
			  window.location = '?p=currency-converter&ok=yes';
			} else {
			  window.location = '?p=currency-converter';
			}
          }
        });
      }
     });
    });  
    return false;
  }
}
//]]>
</script>
<?php
if (isset($OK) || isset($_GET['ok'])) {
  echo actionCompleted($msg_currency5);
}
?>

<?php echo str_replace('{base}',$currencies[$SETTINGS->baseCurrency].' ('.$SETTINGS->baseCurrency.')',$msg_currency); ?><br /><br />

<form method="post" id="form" action="?p=currency-converter">
<div class="fieldHeadWrapper">
  <p><span class="float"><?php echo $msg_currency3; ?>: <input type="checkbox" name="log" onclick="selectAll()" /></span><?php echo $msg_currency2; ?>:</p>
</div>

<div class="formFieldWrapper">
  <?php
  $r       = 0;
  $q_cur   = mysql_query("SELECT * FROM `".DB_PREFIX."currencies` 
             WHERE `curname` != ''
             AND `currency`  != '{$SETTINGS->baseCurrency}'
             ORDER BY `curname`
             ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  while ($CV = mysql_fetch_object($q_cur)) {
  $incr = (++$r);
  ?>
  <div class="converter"><input type="hidden" name="cur[<?php echo $CV->currency; ?>]" value="yes" /><input type="checkbox" name="iso[<?php echo $CV->currency; ?>]" value="<?php echo $CV->currency; ?>"<?php echo ($CV->enableCur=='yes' ? ' checked="checked"' : ''); ?> /> <?php echo mc_cleanData($CV->curname); ?><span>(<?php echo ($CV->enableCur=='yes' ? '<b>1</b>'.$SETTINGS->baseCurrency.' = <b>'.$MCCRV->convert('1.00',$CV->currency,$CV->rate).'</b>'.$CV->currency : $msg_currency10); ?>)</span></div>
  <div class="converter2"><label><?php echo $msg_currency6; ?>: <?php echo mc_displayHelpTip($msg_javascript231,($incr%2==0 ? 'LEFT' : 'RIGHT')); ?></label><input type="text" class="box" name="pref[<?php echo $CV->currency; ?>]" value="<?php echo str_replace('&#','&amp;#',mc_cleanDataEnt($CV->currencyDisplayPref)); ?>" style="width:45%" /> / <input type="text" class="box" name="rate[<?php echo $CV->currency; ?>]" value="<?php echo $CV->rate; ?>" style="width:20%" /></div>
  <?php
  if ($incr%2==0) {
  ?>
  <br class="clear" />
  <hr style="border:0;border-top:1px dashed #e5e5e5" />
  <?php
  }
  }
  ?>         
  <br class="clear" />
</div>

<p style="text-align:center;padding-top:20px">
  <input type="hidden" name="process" value="yes" />
  <input type="checkbox" name="auto" value="yes" checked="checked" /> <?php echo $msg_currency8; ?><br /><br />
  <input class="formbutton" type="button" onclick="mc_updateCurRates()" value="<?php echo mc_cleanDataEnt($msg_currency4); ?>" title="<?php echo mc_cleanDataEnt($msg_currency4); ?>" />
</p>
</form>

<p>&nbsp;</p>
<p>&nbsp;</p>
</div>
