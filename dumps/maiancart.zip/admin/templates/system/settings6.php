<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } ?>
<div id="content">

<?php
$tabIndex = 0;
if (isset($OK)) {
  echo actionCompleted($msg_settings31);
  //Reload..
  $SETTINGS = mysql_fetch_object(mysql_query("SELECT * FROM ".DB_PREFIX."settings LIMIT 1")) 
              or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
}
?>

<?php echo $msg_settings; ?><br /><br />

<form method="post" id="form" action="?p=settings&amp;s=6">
<div class="fieldHeadWrapper">
  <p style="text-align:right"><span style="float:left;display:block;padding:3px 0 0 0"><?php echo $msg_settings77; ?></span>
  <?php
  include(PATH.'templates/system/menu.php');
  ?>
  </p>
</div>

<div class="formFieldWrapper">
  <div class="formLeft">
    <label><?php echo $msg_settings29; ?>: <?php echo mc_displayHelpTip($msg_javascript22,'RIGHT'); ?></label>
    <?php echo $msg_script5; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="smtp" value="yes"<?php echo ($SETTINGS->smtp=='yes' ? ' checked="checked"' : ''); ?> /> <?php echo $msg_script6; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="smtp" value="no"<?php echo ($SETTINGS->smtp=='no' ? ' checked="checked"' : ''); ?> />
  </div>
  <div class="formRight">  
    <label><?php echo $msg_settings30; ?>: <?php echo mc_displayHelpTip($msg_javascript38,'LEFT'); ?></label>
    <input type="text" name="smtp_host" value="<?php echo mc_cleanData($SETTINGS->smtp_host); ?>" class="box" tabindex="<?php echo ++$tabIndex; ?>" />
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper">
  <div class="formLeft">
    <label><?php echo $msg_settings26; ?>: <?php echo mc_displayHelpTip($msg_javascript23,'RIGHT'); ?></label>
    <input type="text" name="smtp_user" value="<?php echo mc_cleanData($SETTINGS->smtp_user); ?>" class="box" tabindex="<?php echo ++$tabIndex; ?>" /> 
  </div>
  <div class="formRight">  
    <label><?php echo $msg_settings27; ?>: <?php echo mc_displayHelpTip($msg_javascript24,'LEFT'); ?></label>
    <input type="password" name="smtp_pass" value="<?php echo mc_cleanDataEnt($SETTINGS->smtp_pass); ?>" class="box" tabindex="<?php echo ++$tabIndex; ?>" />
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper">
  <label><?php echo $msg_settings28; ?>: <?php echo mc_displayHelpTip($msg_javascript25,'RIGHT'); ?></label>
  <input type="text" name="smtp_port" value="<?php echo $SETTINGS->smtp_port; ?>" class="box" style="width:15%" tabindex="<?php echo ++$tabIndex; ?>" />
  <br class="clear" />
</div>

<p style="text-align:center;padding-top:20px">
 <input type="hidden" name="process" value="yes" />
 <input class="formbutton" type="submit" value="<?php echo mc_cleanDataEnt($msg_settings8); ?>" title="<?php echo mc_cleanDataEnt($msg_settings8); ?>" />
</p>
</form>

<p>&nbsp;</p>
<p>&nbsp;</p>
</div>
