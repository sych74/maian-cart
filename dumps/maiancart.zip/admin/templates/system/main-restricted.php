<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } 
$payStatuses  = mc_loadDefaultStatuses();
?>
<div id="content">

<?php
echo str_replace('{website}',mc_cleanDataEnt($SETTINGS->website),$msg_main5);
$buildStrings = array('','','','','');
// Build data strings..
foreach ($userPageAccess AS $k => $v) {
  // System..
  if (in_array($k,$restrictedAccessGroups[0])) {
    if (in_array($k,array('settings','pages'))) {
      foreach ($v AS $sk => $s) {
        if (in_array($k.'_'.$sk,$sysCartUser[3])) {
          if ($k=='settings') {
            $url = '?p=settings'.($sk>1 ? '&amp;s='.$sk : '');
          } else {
            $url = '?p=pages&amp;e='.$sk;
        }
        $buildStrings[0] .= '<li><a href="'.$url.'" title="'.mc_cleanDataEnt($s).'">'.$s.'</a></li>'.mc_defineNewline();
        }
      }
    } else {
      if (in_array($k,$sysCartUser[3])) {
        $buildStrings[0] .= '<li><a href="?p='.$k.'" title="'.mc_cleanDataEnt($v).'">'.$v.'</a></li>'.mc_defineNewline();
      }
    }
  }
  // Catalogue..
  if (in_array($k,$restrictedAccessGroups[1])) {
    if (in_array($k,$sysCartUser[3])) {
      $buildStrings[1] .= '<li><a href="?p='.$k.'" title="'.mc_cleanDataEnt($v).'">'.$v.'</a></li>'.mc_defineNewline();
    }
  }
  // Shipping..
  if (in_array($k,$restrictedAccessGroups[2])) {
    if (in_array($k,$sysCartUser[3])) {
      $buildStrings[2] .= '<li><a href="?p='.$k.'" title="'.mc_cleanDataEnt($v).'">'.$v.'</a></li>'.mc_defineNewline();
    }
  }
  // Sales..
  if (in_array($k,$restrictedAccessGroups[3])) {
    if (in_array($k,$sysCartUser[3])) {
      $buildStrings[3] .= '<li><a href="?p='.$k.'" title="'.mc_cleanDataEnt($v).'">'.$v.'</a></li>'.mc_defineNewline();
    }
  }
  // Tools..
  if (in_array($k,$restrictedAccessGroups[4])) {
    if (in_array($k,$sysCartUser[3])) {
      $buildStrings[4] .= '<li><a href="?p='.$k.'" title="'.mc_cleanDataEnt($v).'">'.$v.'</a></li>'.mc_defineNewline();
    }
  }
}
?>
<div class="restrictedOptions">

  <ul>
    <?php
    if ($buildStrings[0]) {
    ?>
    <li class="menu"><span><?php echo $msg_header; ?></span>
      <ul>
        <?php echo $buildStrings[0]; ?>
      </ul>
    </li>
    <?php
    }
    if ($buildStrings[1]) {
    ?>
    <li class="menu"><span><?php echo $msg_header2; ?></span>
      <ul>
        <?php echo $buildStrings[1]; ?>
      </ul>
    </li>
    <?php
    }
    if ($buildStrings[2]) {
    ?>
    <li class="menu"><span><?php echo $msg_header4; ?></span>
      <ul>
        <?php echo $buildStrings[2]; ?>
      </ul>
    </li>
    <?php
    }
    if ($buildStrings[3]) {
    ?>
    <li class="menu"><span><?php echo $msg_header5; ?></span>
      <ul>
        <?php echo $buildStrings[3]; ?>
      </ul>
    </li>
    <?php
    }
    if ($buildStrings[4]) {
    ?>
    <li class="menu"><span><?php echo $msg_header3; ?></span>
      <ul>
        <?php echo $buildStrings[4]; ?>
      </ul>
    </li>
    <?php
    }
    if ($buildStrings[0]=='' && $buildStrings[1]=='' && $buildStrings[2]==''
        && $buildStrings[3]=='' && $buildStrings[4]=='') {
    ?>
    <li>&nbsp;</li>
    <?php
    }
    ?>
  </ul>
  
  <br class="clear" />  

</div>

<?php
if (SHOW_PENDING_SALES_ON_MAIN_PAGE && isset($sysCartUser[3]) && in_array('sales',$sysCartUser[3])) {
?>
<div class="fieldHeadWrapper">
  <p><?php echo $msg_sales34; ?>:</p>
</div>
<?php
$query = mysql_query("SELECT *,DATE_FORMAT(purchaseDate,'".$SETTINGS->mysqlDateFormat."') AS sdate 
         FROM ".DB_PREFIX."sales
         WHERE saleConfirmation  = 'yes'
         AND paymentStatus      IN('pending','shipping')
         ORDER BY id DESC
         ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
if (mysql_num_rows($query)>0) {         
while ($SALES = mysql_fetch_object($query)) {
?>         
<div class="productWrapper">
  <div class="productWrapper_inner">
   <div class="td1"><?php echo mc_saleInvoiceNumber($SALES->invoiceNo); ?></div>
   <div class="td2"><?php echo mc_cleanData($SALES->bill_1); ?></div>
   <div class="td3"><?php echo $SALES->sdate; ?></div>
   <div class="td4"><?php echo mc_paymentMethodName($SALES->paymentMethod); ?></div>
   <div class="td5"><?php echo str_replace(array('{id}','{count}'),array($SALES->id,mc_sumCount('purchases WHERE saleID = \''.$SALES->id.'\' AND saleConfirmation = \'yes\'','productQty',true)),$msg_sales31); ?></div>
   <div class="td6"><?php echo mc_currencyFormat(mc_formatPrice($SALES->grandTotal,true)); ?></div>
   <br class="clear" />
   <p class="status"><?php echo statusText($SALES->paymentStatus); ?></p>
  </div>
  <p class="panel">
    <?php
    if ($uDel=='yes') {
    ?>
    <a class="delete" href="?p=sales&amp;delete=<?php echo $SALES->id; ?>" onclick="return confirmMessage('<?php echo mc_cleanDataEnt($msg_javascript45); ?>')" title="<?php echo mc_cleanDataEnt($msg_script10); ?>"><?php echo $msg_script10; ?></a>
    <?php
    }
    ?>
    <a class="edit" href="?p=sales-view&amp;sale=<?php echo $SALES->id; ?>" title="<?php echo mc_cleanDataEnt($msg_sales13); ?>"><?php echo $msg_sales13; ?></a>
    <a class="exp" href="?p=sales&amp;export=<?php echo $SALES->id; ?>" title="<?php echo mc_cleanDataEnt($msg_sales4); ?>"><?php echo $msg_sales4; ?></a>
    <a class="invoice" href="?p=invoice&amp;sale=<?php echo $SALES->id; ?>" onclick="window.open(this);return false" title="<?php echo mc_cleanDataEnt($msg_sales5); ?>"><?php echo $msg_sales5; ?></a>
    <?php
    // Show packing slip link if there are physical products..
    if (mc_rowCount('purchases WHERE saleID = \''.$SALES->id.'\' AND saleConfirmation = \'yes\' AND productType = \'physical\'')>0) {
    ?>
    <a class="packing" href="?p=packing-slip&amp;sale=<?php echo $SALES->id; ?>" onclick="window.open(this);return false" title="<?php echo mc_cleanDataEnt($msg_sales6); ?>"><?php echo $msg_sales6; ?></a>
    <?php
    }
    if (mc_rowCount('purch_pers WHERE saleID = \''.mc_digitSan($SALES->id).'\'')>0) {
    ?>
    <a class="pers" href="?p=sales-view&amp;view-personalisation=<?php echo $SALES->id; ?>" title="<?php echo mc_cleanDataEnt($msg_sales37); ?>" onclick="mc_Window(this.href,'<?php echo GREYBOX_PERS_HEIGHT; ?>','<?php echo GREYBOX_PERS_WIDTH; ?>',this.title);return false;"><?php echo $msg_sales37; ?></a>
    <?php
    }
    if (mc_rowCount('purchases WHERE saleID = \''.$SALES->id.'\' AND saleConfirmation = \'yes\' AND productType = \'download\'')>0) {
    ?>
    <a class="downloads" href="?p=downloads&amp;sale=<?php echo $SALES->id; ?>" title="<?php echo mc_cleanDataEnt($msg_sales38); ?>" onclick="mc_Window(this.href,'<?php echo GREYBOX_DOWNLOADS_HEIGHT; ?>','<?php echo GREYBOX_DOWNLOADS_WIDTH; ?>',this.title);return false;"><?php echo $msg_sales38; ?></a>
    <?php
    }
    ?>
    <a class="update" href="?p=sales-update&amp;sale=<?php echo $SALES->id; ?>" title="<?php echo mc_cleanDataEnt($msg_sales2); ?>"><?php echo $msg_sales2; ?></a>
    <br class="clear" />
  </p>
</div>
<?php
}
} else {
?>
<p class="noData"><?php echo $msg_sales17; ?></p>
<?php
}
}

if (SHOW_COMPLETED_SALES_ON_MAIN_PAGE>0 && isset($sysCartUser[3]) && in_array('sales',$sysCartUser[3])) {
?>
<div class="fieldHeadWrapper">
  <p><?php echo str_replace('{count}',SHOW_COMPLETED_SALES_ON_MAIN_PAGE,$msg_sales33); ?>:</p>
</div>
<?php
$query = mysql_query("SELECT *,DATE_FORMAT(purchaseDate,'".$SETTINGS->mysqlDateFormat."') AS sdate 
         FROM ".DB_PREFIX."sales
         WHERE saleConfirmation = 'yes'
         AND paymentStatus      = 'completed'
         ORDER BY id DESC
         LIMIT ".SHOW_COMPLETED_SALES_ON_MAIN_PAGE."
         ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
if (mysql_num_rows($query)>0) {         
while ($SALES = mysql_fetch_object($query)) {
?>         
<div class="productWrapper">
  <div class="productWrapper_inner">
   <div class="td1"><?php echo mc_saleInvoiceNumber($SALES->invoiceNo); ?></div>
   <div class="td2"><?php echo ($SALES->bill_1 ? mc_cleanData($SALES->bill_1) : '&nbsp;'); ?></div>
   <div class="td3"><?php echo $SALES->sdate; ?></div>
   <div class="td4"><?php echo mc_paymentMethodName($SALES->paymentMethod); ?></div>
   <div class="td5"><?php echo str_replace(array('{id}','{count}'),array($SALES->id,mc_sumCount('purchases WHERE saleID = \''.$SALES->id.'\' AND saleConfirmation = \'yes\'','productQty',true)),$msg_sales31); ?></div>
   <div class="td6"><?php echo mc_currencyFormat(mc_formatPrice($SALES->grandTotal,true)); ?></div>
   <br class="clear" />
   <p class="status"><?php echo statusText($SALES->paymentStatus); ?></p>
  </div>
  <p class="panel">
    <?php
    if ($uDel=='yes') {
    ?>
    <a class="delete" href="?p=sales&amp;delete=<?php echo $SALES->id; ?>" onclick="return confirmMessage('<?php echo mc_cleanDataEnt($msg_javascript45); ?>')" title="<?php echo mc_cleanDataEnt($msg_script10); ?>"><?php echo $msg_script10; ?></a>
    <?php
    }
    ?>
    <a class="edit" href="?p=sales-view&amp;sale=<?php echo $SALES->id; ?>" title="<?php echo mc_cleanDataEnt($msg_sales13); ?>"><?php echo $msg_sales13; ?></a>
    <a class="exp" href="?p=sales&amp;export=<?php echo $SALES->id; ?>" title="<?php echo mc_cleanDataEnt($msg_sales4); ?>"><?php echo $msg_sales4; ?></a>
    <a class="invoice" href="?p=invoice&amp;sale=<?php echo $SALES->id; ?>" onclick="window.open(this);return false" title="<?php echo mc_cleanDataEnt($msg_sales5); ?>"><?php echo $msg_sales5; ?></a>
    <?php
    // Show packing slip link if there are physical products..
    if (mc_rowCount('purchases WHERE saleID = \''.$SALES->id.'\' AND saleConfirmation = \'yes\' AND productType = \'physical\'')>0) {
    ?>
    <a class="packing" href="?p=packing-slip&amp;sale=<?php echo $SALES->id; ?>" onclick="window.open(this);return false" title="<?php echo mc_cleanDataEnt($msg_sales6); ?>"><?php echo $msg_sales6; ?></a>
    <?php
    }
    if (mc_rowCount('purch_pers WHERE saleID = \''.mc_digitSan($SALES->id).'\'')>0) {
    ?>
    <a class="pers" href="?p=sales-view&amp;view-personalisation=<?php echo $SALES->id; ?>" title="<?php echo mc_cleanDataEnt($msg_sales37); ?>" onclick="mc_Window(this.href,'<?php echo GREYBOX_PERS_HEIGHT; ?>','<?php echo GREYBOX_PERS_WIDTH; ?>',this.title,'<?php echo str_replace(array('\'','&#039;'),array(),$msg_javascript141); ?>');return false;"><?php echo $msg_sales37; ?></a>
    <?php
    }
    if (mc_rowCount('purchases WHERE saleID = \''.$SALES->id.'\' AND saleConfirmation = \'yes\' AND productType = \'download\'')>0) {
    ?>
    <a class="downloads" href="?p=downloads&amp;sale=<?php echo $SALES->id; ?>" title="<?php echo mc_cleanDataEnt($msg_sales38); ?>" onclick="mc_Window(this.href,'<?php echo GREYBOX_DOWNLOADS_HEIGHT; ?>','<?php echo GREYBOX_DOWNLOADS_WIDTH; ?>',this.title,'<?php echo str_replace(array('\'','&#039;'),array(),$msg_javascript141); ?>');return false;"><?php echo $msg_sales38; ?></a>
    <?php
    }
    ?>
    <a class="update" href="?p=sales-update&amp;sale=<?php echo $SALES->id; ?>" title="<?php echo mc_cleanDataEnt($msg_sales2); ?>"><?php echo $msg_sales2; ?></a>
    <br class="clear" />
  </p>
</div>
<?php
}
} else {
?>
<p class="noData"><?php echo $msg_sales17; ?></p>
<?php
}
}

// Payment statuses on dashboard..
if (isset($sysCartUser[3]) && in_array('sales',$sysCartUser[3])) {
$qPay = mysql_query("SELECT * FROM ".DB_PREFIX."paystatuses WHERE `homepage` = 'yes' ORDER BY `statname`")
        or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
while ($PST = mysql_fetch_object($qPay)) {

$query = mysql_query("SELECT *,DATE_FORMAT(purchaseDate,'".$SETTINGS->mysqlDateFormat."') AS sdate 
         FROM ".DB_PREFIX."sales
         WHERE saleConfirmation = 'yes'
         AND paymentStatus      = '{$PST->id}'
         ORDER BY id DESC
         ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
if (mysql_num_rows($query)>0) {
?>
<div class="fieldHeadWrapper">
  <p><?php echo (!SHOW_PENDING_SALES_ON_MAIN_PAGE && !SHOW_COMPLETED_SALES_ON_MAIN_PAGE ? '<span class="float"><a href="#" onclick="mc_homeSlider();return false"><img id="slider" src="templates/images/slide-up.png" alt="'.mc_cleanDataEnt($msg_main18).'" title="'.mc_cleanDataEnt($msg_main18).'" /></a></span>' : ''); ?><?php echo mc_cleanData($PST->statname).' ('.mysql_num_rows($query).')'; ?></p>
</div>
<?php     
while ($SALES = mysql_fetch_object($query)) {
?>         
<div class="productWrapper">
  <div class="productWrapper_inner">
   <div class="td1"><?php echo mc_saleInvoiceNumber($SALES->invoiceNo); ?></div>
   <div class="td2"><?php echo ($SALES->bill_1 ? mc_cleanData($SALES->bill_1) : '&nbsp;'); ?></div>
   <div class="td3"><?php echo $SALES->sdate; ?></div>
   <div class="td4"><?php echo mc_paymentMethodName($SALES->paymentMethod); ?></div>
   <div class="td5"><?php echo str_replace(array('{id}','{count}'),array($SALES->id,mc_sumCount('purchases WHERE saleID = \''.$SALES->id.'\' AND saleConfirmation = \'yes\'','productQty',true)),$msg_sales31); ?></div>
   <div class="td6"><?php echo mc_currencyFormat(mc_formatPrice($SALES->grandTotal,true)); ?></div>
   <br class="clear" />
   <p class="status"><?php echo statusText($SALES->paymentStatus); ?></p>
  </div>
  <p class="panel">
    <?php
    if ($uDel=='yes') {
    ?>
    <a class="delete" href="?p=sales&amp;delete=<?php echo $SALES->id; ?>" onclick="return confirmMessage('<?php echo mc_cleanDataEnt($msg_javascript45); ?>')" title="<?php echo mc_cleanDataEnt($msg_script10); ?>"><?php echo $msg_script10; ?></a>
    <?php
    }
    ?>
    <a class="edit" href="?p=sales-view&amp;sale=<?php echo $SALES->id; ?>" title="<?php echo mc_cleanDataEnt($msg_sales13); ?>"><?php echo $msg_sales13; ?></a>
    <a class="exp" href="?p=sales&amp;export=<?php echo $SALES->id; ?>" title="<?php echo mc_cleanDataEnt($msg_sales4); ?>"><?php echo $msg_sales4; ?></a>
    <a class="invoice" href="?p=invoice&amp;sale=<?php echo $SALES->id; ?>" onclick="window.open(this);return false" title="<?php echo mc_cleanDataEnt($msg_sales5); ?>"><?php echo $msg_sales5; ?></a>
    <?php
    // Show packing slip link if there are physical products..
    if (mc_rowCount('purchases WHERE saleID = \''.$SALES->id.'\' AND saleConfirmation = \'yes\' AND productType = \'physical\'')>0) {
    ?>
    <a class="packing" href="?p=packing-slip&amp;sale=<?php echo $SALES->id; ?>" onclick="window.open(this);return false" title="<?php echo mc_cleanDataEnt($msg_sales6); ?>"><?php echo $msg_sales6; ?></a>
    <?php
    }
    if (mc_rowCount('purch_pers WHERE saleID = \''.mc_digitSan($SALES->id).'\'')>0) {
    ?>
    <a class="pers" href="?p=sales-view&amp;view-personalisation=<?php echo $SALES->id; ?>" title="<?php echo mc_cleanDataEnt($msg_sales37); ?>" onclick="mc_Window(this.href,'<?php echo GREYBOX_PERS_HEIGHT; ?>','<?php echo GREYBOX_PERS_WIDTH; ?>',this.title,'<?php echo str_replace(array('\'','&#039;'),array(),$msg_javascript141); ?>');return false;"><?php echo $msg_sales37; ?></a>
    <?php
    }
    if (mc_rowCount('purchases WHERE saleID = \''.$SALES->id.'\' AND saleConfirmation = \'yes\' AND productType = \'download\'')>0) {
    ?>
    <a class="downloads" href="?p=downloads&amp;sale=<?php echo $SALES->id; ?>" title="<?php echo mc_cleanDataEnt($msg_sales38); ?>" onclick="mc_Window(this.href,'<?php echo GREYBOX_DOWNLOADS_HEIGHT; ?>','<?php echo GREYBOX_DOWNLOADS_WIDTH; ?>',this.title,'<?php echo str_replace(array('\'','&#039;'),array(),$msg_javascript141); ?>');return false;"><?php echo $msg_sales38; ?></a>
    <?php
    }
    ?>
    <a class="update" href="?p=sales-update&amp;sale=<?php echo $SALES->id; ?>" title="<?php echo mc_cleanDataEnt($msg_sales2); ?>"><?php echo $msg_sales2; ?></a>
    <br class="clear" />
  </p>
</div>
<?php
}
}

}
}

?>
<p style="padding:0 0 40px 0">&nbsp;</p>
</div>
