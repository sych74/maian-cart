<?php if (!defined('PARENT')) { die('Permission Denied'); } ?>
<div id="content">

  <div class="panel panel-warning">
    <div class="panel-heading">
      <i class="fa fa-warning fa-fw mc-red"></i> <b><?php echo strtoupper($msg_acsden); ?></b>
    </div>
    <div class="panel-body">
      <?php echo $msg_acsden3; ?>
    </div>
    <div class="panel-footer">
      <a href="index.php"><i class="fa fa-angle-right fa-fw"></i> <?php echo $msg_acsden2; ?></a>
    </div>
  </div>

  <p style="height:70px">&nbsp;</p>

</div>
