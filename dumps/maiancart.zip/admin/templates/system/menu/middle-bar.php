<?php

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  This File: middle-bar.php
  Description: Top bar middle

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

echo (isset($sysCartUser[0]) ? str_replace('{user}',mc_cleanDataEnt($sysCartUser[0]),$msg_header11).'<span class="who">'.str_replace('{LAST}',($sysCartUser[4] ? $sysCartUser[4] : 'N/A'),($sysCartUser[1]!='global' ? $msg_header14 : $msg_header15)) : '').'</span>'; 

?>
