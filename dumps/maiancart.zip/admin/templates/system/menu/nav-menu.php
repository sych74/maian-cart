<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } ?>

<div id="megamenu" class="solidblockmenu">
<ul>
 <li><a href="#" title="" class="nav_first" rel="nav-menu1"><?php echo $msg_header; ?></a></li>
 <li><a href="#" title="" class="nav" rel="nav-menu2"><?php echo $msg_header2; ?></a></li>
 <li><a href="#" title="" class="nav" rel="nav-menu3"><?php echo $msg_header4; ?></a></li>
 <li><a href="#" title="" class="nav" rel="nav-menu4"><?php echo $msg_header5; ?></a></li>
 <li><a href="#" title="" class="nav_last" rel="nav-menu5"><?php echo $msg_header3; ?></a></li>
</ul>
</div>
 
<div id="nav-menu1" class="mega solidblocktheme">
 
 <div class="navleft">
  <p><a href="?p=settings" title="<?php echo mc_cleanDataEnt($msg_javascript106); ?>"><?php echo mc_cleanDataEnt($msg_javascript106); ?></a></p>
  <p><a href="?p=settings&amp;s=3" title="<?php echo mc_cleanDataEnt($msg_settings50); ?>"><?php echo mc_cleanDataEnt($msg_settings50); ?></a></p>
  <p><a href="?p=settings&amp;s=8" title="<?php echo mc_cleanDataEnt($msg_settings84); ?>"><?php echo mc_cleanDataEnt($msg_settings84); ?></a></p>
  <p><a href="?p=settings&amp;s=2" title="<?php echo mc_cleanDataEnt($msg_settings61); ?>"><?php echo mc_cleanDataEnt($msg_settings61); ?></a></p>
  <p><a href="?p=settings&amp;s=9" title="<?php echo mc_cleanDataEnt($msg_settings116); ?>"><?php echo mc_cleanDataEnt($msg_settings116); ?></a></p>
  <p><a href="?p=settings&amp;s=4" title="<?php echo mc_cleanDataEnt($msg_settings54); ?>"><?php echo mc_cleanDataEnt($msg_settings54); ?></a></p>
  <p><a href="?p=themes" title="<?php echo mc_cleanDataEnt($msg_header22); ?>"><?php echo mc_cleanDataEnt($msg_header22); ?></a></p>
 </div>
 
 <div class="navright">
  <p><a href="?p=settings&amp;s=5" title="<?php echo mc_cleanDataEnt($msg_settings131); ?>"><?php echo mc_cleanDataEnt($msg_settings131); ?></a></p>
  <p><a href="?p=settings&amp;s=6" title="<?php echo mc_cleanDataEnt($msg_settings25); ?>"><?php echo mc_cleanDataEnt($msg_settings25); ?></a></p>
  <p><a href="?p=users" title="<?php echo mc_cleanDataEnt($msg_javascript254); ?>"><?php echo mc_cleanDataEnt($msg_javascript254); ?></a></p>
  <p><a href="?p=currency-converter" title="<?php echo mc_cleanDataEnt($msg_javascript30); ?>"><?php echo mc_cleanDataEnt($msg_javascript30); ?></a></p>
  <p><a href="?p=newpages" title="<?php echo mc_cleanDataEnt($msg_javascript198); ?>"><?php echo mc_cleanDataEnt($msg_javascript198); ?></a></p>
  <p><a href="?p=news" title="<?php echo mc_cleanDataEnt($msg_javascript421); ?>"><?php echo mc_cleanDataEnt($msg_javascript421); ?></a></p>
  <?php
  if (LICENCE_VER=='unlocked') {
  ?>
  <p><a href="?p=settings&amp;s=7" title="<?php echo mc_cleanDataEnt($msg_settings65); ?>"><?php echo mc_cleanDataEnt($msg_settings65); ?></a></p>
  <?php
  }
  ?>
 </div>
 
 <br class="clear" />
 
</div>

<div id="nav-menu2" class="mega solidblocktheme">
 
 <div class="navleft">
  <p><a href="?p=add-product" title="<?php echo mc_cleanDataEnt($msg_javascript26); ?>"><?php echo mc_cleanDataEnt($msg_javascript26); ?></a></p>
  <p><a href="?p=manage-products" title="<?php echo mc_cleanDataEnt($msg_javascript27); ?>"><?php echo mc_cleanDataEnt($msg_javascript27); ?></a></p>
  <p><a href="?p=gift" title="<?php echo mc_cleanDataEnt($msg_header23); ?>"><?php echo mc_cleanDataEnt($msg_header23); ?></a></p>
  <p><a href="?p=dl-manager" title="<?php echo mc_cleanDataEnt($msg_javascript398); ?>"><?php echo mc_cleanDataEnt($msg_javascript398); ?></a></p>
  <p><a href="?p=categories" title="<?php echo mc_cleanDataEnt($msg_javascript157); ?>"><?php echo mc_cleanDataEnt($msg_javascript157); ?></a></p>
  <p><a href="?p=brands" title="<?php echo mc_cleanDataEnt($msg_javascript158); ?>"><?php echo mc_cleanDataEnt($msg_javascript158); ?></a></p>
 </div>
 
 <div class="navright">
  <p><a href="?p=price-points" title="<?php echo mc_cleanDataEnt($msg_javascript266); ?>"><?php echo mc_cleanDataEnt($msg_javascript266); ?></a></p>
  <p><a href="?p=payment-methods" title="<?php echo mc_cleanDataEnt($msg_javascript168); ?>"><?php echo mc_cleanDataEnt($msg_javascript168); ?></a></p>
  <p><a href="?p=order-statuses" title="<?php echo mc_cleanDataEnt($msg_javascript192); ?>"><?php echo mc_cleanDataEnt($msg_javascript192); ?></a></p>
  <p><a href="?p=special-offers" title="<?php echo mc_cleanDataEnt($msg_javascript62); ?>"><?php echo mc_cleanDataEnt($msg_javascript62); ?></a></p>
  <p><a href="?p=discount-coupons" title="<?php echo mc_cleanDataEnt($msg_javascript29); ?>"><?php echo mc_cleanDataEnt($msg_javascript29); ?></a></p>
 </div>
 
 <br class="clear" />
 
</div>

<div id="nav-menu3" class="mega solidblocktheme">
 
 <div class="navleft">
  <p><a href="?p=countries" title="<?php echo mc_cleanDataEnt($msg_javascript31); ?>"><?php echo mc_cleanDataEnt($msg_javascript31); ?></a></p>
  <p><a href="?p=zones" title="<?php echo mc_cleanDataEnt($msg_javascript32); ?>"><?php echo mc_cleanDataEnt($msg_javascript32); ?></a></p>
  <p><a href="?p=services" title="<?php echo mc_cleanDataEnt($msg_javascript100); ?>"><?php echo mc_cleanDataEnt($msg_javascript100); ?></a></p>
  <p><a href="?p=update-rates" title="<?php echo mc_cleanDataEnt($msg_javascript173); ?>"><?php echo mc_cleanDataEnt($msg_javascript173); ?></a></p>
  <p><a href="?p=update-tax" title="<?php echo mc_cleanDataEnt($msg_javascript283); ?>"><?php echo mc_cleanDataEnt($msg_javascript283); ?></a></p>
 </div>
 
 <div class="navright">
  <p><a href="?p=flatrate" title="<?php echo mc_cleanDataEnt($msg_javascript438); ?>"><?php echo mc_cleanDataEnt($msg_javascript438); ?></a></p>
  <p><a href="?p=itemrate" title="<?php echo mc_cleanDataEnt($msg_javascript577); ?>"><?php echo mc_cleanDataEnt($msg_javascript577); ?></a></p>
  <p><a href="?p=percent" title="<?php echo mc_cleanDataEnt($msg_javascript439); ?>"><?php echo mc_cleanDataEnt($msg_javascript439); ?></a></p>
  <p><a href="?p=rates" title="<?php echo mc_cleanDataEnt($msg_javascript33); ?>"><?php echo mc_cleanDataEnt($msg_javascript33); ?></a></p>
  <p><a href="?p=tare" title="<?php echo mc_cleanDataEnt($msg_header20); ?>"><?php echo mc_cleanDataEnt($msg_header20); ?></a></p>
 </div>
 
 <br class="clear" />
 
</div>

<div id="nav-menu4" class="mega solidblocktheme">
 
 <div class="navleft">
  <p><a href="?p=sales" title="<?php echo mc_cleanDataEnt($msg_javascript84); ?>"><?php echo mc_cleanDataEnt($msg_javascript84); ?></a></p>
  <p><a href="?p=sales-incomplete" title="<?php echo mc_cleanDataEnt($msg_header21); ?>"><?php echo mc_cleanDataEnt($msg_header21); ?></a></p>
  <p><a href="?p=sales-add" title="<?php echo mc_cleanDataEnt($msg_javascript355); ?>"><?php echo mc_cleanDataEnt($msg_javascript355); ?></a></p>
  <p><a href="?p=sales-search" title="<?php echo mc_cleanDataEnt($msg_javascript111); ?>"><?php echo mc_cleanDataEnt($msg_javascript111); ?></a></p>
  <p><a href="?p=sales-product-overview" title="<?php echo mc_cleanDataEnt($msg_javascript163); ?>"><?php echo mc_cleanDataEnt($msg_javascript163); ?></a></p>
 </div>
 
 <div class="navright">
  <p><a href="?p=sales-revenue" title="<?php echo mc_cleanDataEnt($msg_javascript425); ?>"><?php echo mc_cleanDataEnt($msg_javascript425); ?></a></p>
  <p><a href="?p=sales-trends" title="<?php echo mc_cleanDataEnt($msg_stats21); ?>"><?php echo mc_cleanDataEnt($msg_stats21); ?></a></p>
  <p><a href="?p=sales-export" title="<?php echo mc_cleanDataEnt($msg_javascript129); ?>"><?php echo mc_cleanDataEnt($msg_javascript129); ?></a></p>
  <p><a href="?p=sales-export-buyers" title="<?php echo mc_cleanDataEnt($msg_javascript134); ?>"><?php echo mc_cleanDataEnt($msg_javascript134); ?></a></p>
  <p><a href="?p=gift-overview" title="<?php echo mc_cleanDataEnt($msg_header24); ?>"><?php echo mc_cleanDataEnt($msg_header24); ?></a></p>
 </div>
 
 <br class="clear" />
 
</div>

<div id="nav-menu5" class="mega solidblocktheme">
 
 <div class="navleft">
  <p><a href="?p=update-prices" title="<?php echo mc_cleanDataEnt($msg_javascript60); ?>"><?php echo mc_cleanDataEnt($msg_javascript60); ?></a></p>
  <p><a href="?p=update-stock" title="<?php echo mc_cleanDataEnt($msg_javascript61); ?>"><?php echo mc_cleanDataEnt($msg_javascript61); ?></a></p>
  <p><a href="?p=low-stock-export" title="<?php echo mc_cleanDataEnt($msg_javascript319); ?>"><?php echo mc_cleanDataEnt($msg_javascript319); ?></a></p>
  <p><a href="?p=product-status" title="<?php echo mc_cleanDataEnt($msg_javascript338); ?>"><?php echo mc_cleanDataEnt($msg_javascript338); ?></a></p>
  <p><a href="?p=batch-move" title="<?php echo mc_cleanDataEnt($msg_javascript197); ?>"><?php echo mc_cleanDataEnt($msg_javascript197); ?></a></p>
  <p><a href="?p=backup" title="<?php echo mc_cleanDataEnt($msg_javascript393); ?>"><?php echo mc_cleanDataEnt($msg_javascript393); ?></a></p>
 </div>
 
 <div class="navright">
  <p><a href="?p=hit-count-overview" title="<?php echo mc_cleanDataEnt($msg_javascript164); ?>"><?php echo mc_cleanDataEnt($msg_javascript164); ?></a></p>
  <p><a href="?p=stock-overview" title="<?php echo mc_cleanDataEnt($msg_header19); ?>"><?php echo mc_cleanDataEnt($msg_header19); ?></a></p>
  <p><a href="?p=newsletter" title="<?php echo mc_cleanDataEnt($msg_javascript309); ?>"><?php echo mc_cleanDataEnt($msg_javascript309); ?></a></p>
  <p><a href="?p=stats" title="<?php echo mc_cleanDataEnt($msg_javascript140); ?>"><?php echo mc_cleanDataEnt($msg_javascript140); ?></a></p>
  <p><a href="?p=search-log" title="<?php echo mc_cleanDataEnt($msg_javascript108); ?>"><?php echo mc_cleanDataEnt($msg_javascript108); ?></a></p>
  <p><a href="?p=entry-log" title="<?php echo mc_cleanDataEnt($msg_javascript99); ?>"><?php echo mc_cleanDataEnt($msg_javascript99); ?></a></p>
 </div>
 
 <br class="clear" />
 
</div>