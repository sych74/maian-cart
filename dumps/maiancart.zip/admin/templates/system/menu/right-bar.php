<?php

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  This File: right-bar.php
  Description: Top bar right

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/


// Purchase link only for locked software..
if (LICENCE_VER=='locked') {
?>
<a class="purchase" href="<?php echo (isset($_GET['locked']) ? '?locked=yes&amp;purchaseRedir=yes' : '?p=purchase'); ?>" title="Purchase">Purchase</a>
<?php
}
?>
<a class="dashboard" href="index.php" title="<?php echo mc_cleanDataEnt($msg_header9); ?>"><?php echo $msg_header9; ?></a>
<a class="store" href="../" title="<?php echo mc_cleanDataEnt($msg_header16); ?>" onclick="window.open(this);return false"><?php echo $msg_header16; ?></a>
<?php
if (DISPLAY_HELP_LINK) {
?>
<a class="help" href="<?php echo (isset($helpPages[$helpTag]) ? '../docs/'.$helpPages[$helpTag].'.html' : '../docs/index.html'); ?>" onclick="window.open(this);return false" title="<?php echo mc_cleanDataEnt($msg_header13); ?>"><?php echo $msg_header13; ?></a>
<?php
}
?>
<a class="logout" href="?p=logout" onclick="return confirmMessage('<?php echo mc_cleanDataEnt($msg_javascript97); ?>')" title="<?php echo mc_cleanDataEnt($msg_javascript37); ?>"><?php echo mc_cleanDataEnt($msg_javascript37); ?></a>