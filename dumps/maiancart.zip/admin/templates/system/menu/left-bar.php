<?php

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  This File: left-bar.php
  Description: Top bar left

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

echo date(HEADER_DATE_FORMAT).(mc_checkBetaVersion()=='yes' ? ' (BETA VERSION: '.mc_getBetaVersion().')' : '');

// Display version check option..
if (DISPLAY_SOFTWARE_VERSION_CHECK && mc_checkBetaVersion()=='no') {
?>
&nbsp;&nbsp;&nbsp;(v<?php echo $SETTINGS->softwareVersion; ?> - <a href="#" onclick="jQuery(document).ready(function(){jQuery.ajax({url:'index.php',data: 'versionCheck=yes',dataType:'html',success: function (data) {alert(data)}});});return false" title="<?php echo mc_cleanDataEnt($msg_header17); ?>"><?php echo $msg_header17; ?></a>)
<?php
}
?>