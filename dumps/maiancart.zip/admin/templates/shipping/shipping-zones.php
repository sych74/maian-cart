<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } 
if (isset($_GET['edit'])) {
  $EDIT          = mc_getTableData('zones','id',mc_digitSan($_GET['edit']));
  $zoneAreaData  = array();
  $q = mysql_query("SELECT * FROM ".DB_PREFIX."zone_areas WHERE inZone = '{$EDIT->id}' ORDER BY areaName")
       or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  while ($Z_AREAS = mysql_fetch_object($q)) {
    $zoneAreaData[] = mc_cleanData($Z_AREAS->areaName);
  }
 }
?>
<div id="content">

<?php
if (isset($OK)) {
  echo actionCompleted($msg_zones8);
}
if (isset($OK2)) {
  echo actionCompleted($msg_zones11);
}
if (isset($OK3) && $cnt>0) {
  echo actionCompleted($msg_zones10);
}
?>

<?php echo $msg_zones; ?><br /><br />

<form method="post" action="?p=zones<?php echo (isset($EDIT->id) ? '&amp;edit='.$EDIT->id : ''); ?>" id="form" enctype="multipart/form-data">
<div class="fieldHeadWrapper">
  <p><?php echo (isset($EDIT->id) ? $msg_zones9 : $msg_zones3); ?>:</p>
</div>

<div class="formFieldWrapper">
  <div class="formLeft" style="width:58%">
    <label><?php echo $msg_zones5; ?>: <?php echo mc_displayHelpTip($msg_javascript47,'RIGHT'); ?></label>
    <input tabindex="1" type="text" name="zName" value="<?php echo (isset($EDIT->zName) ? mc_cleanData($EDIT->zName) : ''); ?>" class="box" maxlength="250" /><br /><br />
    
    <label><?php echo $msg_zones6; ?>: <?php echo mc_displayHelpTip($msg_javascript48,'RIGHT'); ?></label>
    <input tabindex="3" type="text" name="zRate" value="<?php echo (isset($EDIT->zRate) ? mc_cleanData($EDIT->zRate) : ''); ?>" class="box" style="width:15%" />%<br /><br />
    
    <label><?php echo $msg_zones7; ?>: <?php echo mc_displayHelpTip($msg_javascript49,'RIGHT'); ?></label>
    <?php echo $msg_script5; ?> <input tabindex="4" type="radio" name="zShipping" value="yes"<?php echo (isset($EDIT->zShipping) && $EDIT->zShipping=='yes' ? ' checked="checked"' : ''); ?> /> <?php echo $msg_script6; ?> <input tabindex="5" type="radio" name="zShipping" value="no"<?php echo (isset($EDIT->zShipping) && $EDIT->zShipping=='no' ? ' checked="checked"' : (!isset($EDIT->zShipping) ? ' checked="checked"' : '')); ?> />
  </div>
  <div class="formLeft" style="width:38%">
    <label><?php echo $msg_zones14; ?>: <?php echo mc_displayHelpTip($msg_javascript113,'LEFT'); ?></label>
    <?php
    if (isset($EDIT->id)) {
    ?>
    <select tabindex="2" name="zCountry"> 
    <?php
    $q_ctry   = mysql_query("SELECT * FROM ".DB_PREFIX."countries 
                WHERE enCountry  = 'yes'
                ORDER BY cName
                ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($COUNTRY = mysql_fetch_object($q_ctry)) {
    ?>
    <option value="<?php echo $COUNTRY->id; ?>"<?php echo (isset($EDIT->zCountry) && $EDIT->zCountry==$COUNTRY->id ? ' selected="selected"' : ''); ?>><?php echo mc_cleanData($COUNTRY->cName); ?></option>
    <?php
    }
    ?>
    </select>
    <?php
    } else {
    ?>
    <div class="categoryBoxes">
    <input type="checkbox" name="log" id="log" value="all" onclick="selectAll()" tabindex="<?php echo (++$tabIndex); ?>" /> <b><?php echo $msg_zones17; ?></b><br />
    <?php
    $q_ctry   = mysql_query("SELECT * FROM ".DB_PREFIX."countries 
                WHERE enCountry  = 'yes'
                ORDER BY cName
                ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($COUNTRY = mysql_fetch_object($q_ctry)) {
    ?>
    <input type="checkbox" name="zCountry[]" value="<?php echo $COUNTRY->id; ?>" /> <?php echo mc_cleanData($COUNTRY->cName); ?><br />
    <?php
    }
    ?>
    </div>
    <?php
    }
    ?>
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper">
  <div class="formLeft" style="width:58%">
    <label><?php echo $msg_zones20; ?>: <?php echo mc_displayHelpTip($msg_javascript373,'RIGHT'); ?></label>
    <textarea rows="5" cols="30" id="zones2" name="zones2" tabindex="5" style="height:100px"><?php echo (isset($EDIT->id) && !empty($zoneAreaData) ? mc_cleanDataEnt(implode(mc_defineNewline(),$zoneAreaData)) : ''); ?></textarea>
  </div>
  <div class="formLeft" style="width:38%">
    <label><?php echo $msg_zones13; ?>: <?php echo mc_displayHelpTip($msg_javascript112); ?></label>
    <input tabindex="5" type="file" name="zones" value="" class="box" />
  </div>
  <br class="clear" />
</div>

<p style="text-align:center;padding-top:20px"><input type="hidden" name="<?php echo (isset($EDIT->id) ? 'update' : 'process'); ?>" value="yes" />
  <input class="formbutton" type="submit" value="<?php echo mc_cleanDataEnt((isset($EDIT->id) ? $msg_zones9 : $msg_zones3)); ?>" title="<?php echo mc_cleanDataEnt((isset($EDIT->id) ? $msg_zones9 : $msg_zones3)); ?>" /><?php echo (isset($EDIT->id) ? '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input class="formbutton2" type="button" onclick="window.location=\'?p=zones\'" value="'.mc_cleanDataEnt($msg_script11).'" title="'.mc_cleanDataEnt($msg_script11).'" />' : ''); ?>
</p>
</form><br />

<div class="fieldHeadWrapper">
  <p style="text-align:right"><span style="float:left;padding-top:2px"><?php echo $msg_zones4; ?>:</span><?php echo $msg_zones16; ?>:
  <select onchange="if(this.value!= 0){location=this.options[this.selectedIndex].value}">
  <option value="?p=zones"><?php echo $msg_zones17; ?></option>
  <?php
  $q_countries = mysql_query("SELECT * FROM ".DB_PREFIX."countries
                 WHERE enCountry = 'yes' 
                 ORDER BY cName") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  while ($CTRY = mysql_fetch_object($q_countries)) {
  ?>
  <option value="?p=zones&amp;country=<?php echo $CTRY->id; ?>"<?php echo (isset($_GET['country']) && mc_digitSan($_GET['country'])==$CTRY->id ? ' selected="selected"' : ''); ?>><?php echo mc_cleanData($CTRY->cName); ?></option>
  <?php
  }
  ?>
  </select>
  </p>
</div>

<?php
$limit   = $page * ZONES_PER_PAGE - (ZONES_PER_PAGE);
$q_zones = mysql_query("SELECT SQL_CALC_FOUND_ROWS *,".DB_PREFIX."zones.id AS zid FROM ".DB_PREFIX."zones
           LEFT JOIN ".DB_PREFIX."countries
           ON ".DB_PREFIX."zones.zCountry = ".DB_PREFIX."countries.id 
           ".(isset($_GET['country']) ? 'WHERE zCountry = \''.mc_digitSan($_GET['country']).'\'' : 'WHERE enCountry = \'yes\'')."
           ORDER BY cName,zName
           LIMIT $limit,".ZONES_PER_PAGE."
           ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
$c            = mysql_fetch_object(mysql_query("SELECT FOUND_ROWS() AS rows"));
$countedRows  =  (isset($c->rows) ? $c->rows : '0');           
if (mysql_num_rows($q_zones)>0) {
  while ($ZONES = mysql_fetch_object($q_zones)) {
  ?>
  <div class="catWrapper">
    <?php
    if ((isset($curName) && $curName!=mc_cleanData($ZONES->cName)) || !isset($curName)) {
    ?>
    <span class="shipInfoHead"><?php echo mc_cleanData($ZONES->cName); ?></span>
    <?php
    }
    ?>
    <div class="catLeft" style="width:29%"><?php echo mc_cleanData($ZONES->zName); ?>
    <span class="zRateInfo"><?php echo $ZONES->zRate; ?>% / <?php echo $msg_zones15; ?>: <?php echo ($ZONES->zShipping=='yes' ? $msg_script5 : $msg_script6); ?></span>
    </div>
    <div class="catRight" style="width:62%;margin-right:5px;font-size:11px">
    <p id="sZ<?php echo $ZONES->zid; ?>">
    <?php
    $zAString = '';
    $q_area = mysql_query("SELECT * FROM ".DB_PREFIX."zone_areas 
              WHERE inZone = '$ZONES->zid'
              ORDER BY areaName
              ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    $rCount = 0;
    $cutOff = ZONE_AREA_DISPLAY_LIMIT;
    $rCt    = 0;
    while ($AREA = mysql_fetch_object($q_area)) {
      $rCt = ++$rCount;
      $zAString .= mc_cleanDataEnt($AREA->areaName);
      if ($rCt<=$cutOff) {
        echo mc_cleanDataEnt($AREA->areaName);
        if ($rCt!=$cutOff && $rCt!=mysql_num_rows($q_area)) {
          echo ', ';
        }
      }
      if ($rCt!=mysql_num_rows($q_area)) {
        $zAString .= ', ';
      }
    }
    ?>
    </p>
    <p id="sZ2<?php echo $ZONES->zid; ?>" style="display:none">
    <?php
    echo $zAString;
    ?>
    </p>
    <?php
    if ($cutOff<mysql_num_rows($q_area)) {
    ?>
    <span class="viewAll"><a href="#" onclick="jQuery('#sZ<?php echo $ZONES->zid; ?>').toggle();jQuery('#sZ2<?php echo $ZONES->zid; ?>').toggle();return false" title="<?php echo mc_cleanDataEnt($msg_zones19); ?>"><?php echo $msg_zones19; ?></a></span>
    <?php
    }
    ?>
    </div>
    <div class="catRight" style="width:5%;text-align:center;padding:5px 0 3px 0;background:#fff"><a href="?p=zones&amp;edit=<?php echo $ZONES->zid; ?>" title="<?php echo mc_cleanDataEnt($msg_script9).': '.mc_cleanDataEnt($ZONES->zName); ?>"><img src="templates/images/edit.png" alt="<?php echo mc_cleanDataEnt($msg_script9); ?>" title="<?php echo mc_cleanDataEnt($msg_script9); ?>" /></a><?php echo ($uDel=='yes' ? ' <a href="?p=zones&amp;del='.$ZONES->zid.'" onclick="return confirmMessage(\''.mc_cleanDataEnt($msg_javascript45).'\')"><img src="templates/images/delete.png" alt="'.mc_cleanDataEnt($msg_script10).': '.mc_cleanDataEnt($ZONES->zName).'" title="'.mc_cleanDataEnt($msg_script10).': '.mc_cleanDataEnt($ZONES->zName).'" /></a>' : ''); ?></div>
    <br class="clear" />
  </div>
  <?php
  $curName  = mc_cleanData($ZONES->cName);
  }
  define('PER_PAGE',ZONES_PER_PAGE);
  if ($countedRows>0 && $countedRows>PER_PAGE) {
    $PTION = new pagination($countedRows,'?p='.$cmd.'&amp;next=');
    echo $PTION->display();
  }
} else {
?>
<span class="noData"><?php echo $msg_zones12.(isset($_GET['country']) ? ' '.$msg_zones18 : ''); ?></span>
<?php
}
?>

<p>&nbsp;</p>
<p>&nbsp;</p>
</div>
