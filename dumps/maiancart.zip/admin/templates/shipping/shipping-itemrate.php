<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } 
if (isset($_GET['edit'])) {
  $EDIT       = mc_getTableData('per','id',mc_digitSan($_GET['edit']));
}
$flZones   = getFlatRateZones('per');
?>
<div id="content">

<?php
if (isset($OK)) {
  if ($run[1]>0) {
    echo actionCompleted(str_replace(array('{count}','{count2}'),array($run[0],$run[1]),$msg_itemrates8));
  } else {
    echo actionCompleted(str_replace('{count}',$run[0],$msg_itemrates8));
  }
}
if (isset($OK2)) {
  echo actionCompleted($msg_itemrates11);
}
if (isset($OK3) && $cnt>0) {
  echo actionCompleted($msg_itemrates10);
}

echo $msg_itemrates; 
?><br /><br />
<?php
if (mc_rowCount('per')>0) {
?>
<a href="#" onclick="jQuery('#addArea').hide();jQuery('#enabArea').show('slow');return false" class="enableDisable" title="<?php echo mc_cleanDataEnt($msg_itemrates20); ?>"><b><?php echo $msg_itemrates20; ?></b></a><br /><br />
<?php
}
?>

<div id="addArea">
<form method="post" id="form" action="?p=itemrate<?php echo (isset($EDIT->id) ? '&amp;edit='.$EDIT->id : ''); ?>">
<div class="fieldHeadWrapper">
  <p><?php
  echo (isset($EDIT->id) ? $msg_itemrates9 : $msg_itemrates3); ?>:</p>
</div>

<div id="fieldCloneArea">

<div class="formFieldWrapperServices">
  <div class="formLeft" style="width:66%">
    <label><?php echo $msg_itemrates2; ?>: <?php echo mc_displayHelpTip($msg_javascript441,'RIGHT'); ?></label>
    <?php
    if (isset($EDIT->id)) {
    ?>
    <select tabindex="<?php echo ($tabIndex+3); ?>" name="inZone">
    <?php
    $q_zones = mysql_query("SELECT *,`".DB_PREFIX."zones`.`id` AS `zid` FROM `".DB_PREFIX."zones` 
               LEFT JOIN `".DB_PREFIX."countries`
               ON `".DB_PREFIX."zones`.`zCountry` = `".DB_PREFIX."countries`.`id`
               WHERE `enCountry`                  = 'yes'
               ORDER BY `cName`,`zName`
               ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($ZONES = mysql_fetch_object($q_zones)) {
    if (!in_array($ZONES->zid,$flZones) || $ZONES->zid==$EDIT->inZone) {
    ?>
    <option value="<?php echo $ZONES->zid; ?>"<?php echo (isset($EDIT->inZone) && $EDIT->inZone==$ZONES->zid ? ' selected="selected"' : ''); ?>> <?php echo mc_cleanData($ZONES->cName); ?> - <?php echo mc_cleanDataEnt($ZONES->zName); ?></option>
    <?php
    }
    }
    ?>
    </select>
    <?php
    } else {
    ?>
    <div class="categoryBoxes">
    <?php
    $q_zones = mysql_query("SELECT *,`".DB_PREFIX."zones`.`id` AS `zid` FROM `".DB_PREFIX."zones` 
               LEFT JOIN `".DB_PREFIX."countries`
               ON `".DB_PREFIX."zones`.`zCountry` = `".DB_PREFIX."countries`.`id`
               WHERE `enCountry`                  = 'yes'
               ".(!empty($flZones) ? 'AND `'.DB_PREFIX.'zones`.`id` NOT IN('.implode(',',$flZones).')' : '')."
               ORDER BY `cName`,`zName`
               ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    if (mysql_num_rows($q_zones)>0) {
    ?>
    <input type="checkbox" name="log" id="log2" value="all" onclick="toggleCheckBoxes(this.checked,'categoryBoxes')" tabindex="<?php echo (++$tabIndex); ?>" /> <b><?php echo $msg_itemrates5; ?></b><br />
    <?php
    while ($ZONES = mysql_fetch_object($q_zones)) {
    ?>
    <input tabindex="<?php echo (++$tabIndex); ?>" type="checkbox" name="inZone[]" value="<?php echo $ZONES->zid; ?>" /> <?php echo mc_cleanData($ZONES->cName); ?> - <?php echo mc_cleanDataEnt($ZONES->zName); ?><br />
    <?php
    }
    } else {
    echo $msg_itemrates17;
    }
    ?>
    </div>
    <?php
    }
    ?>
  </div>
  <div class="formRight" style="width:30%">  
    <label><?php echo $msg_itemrates6; ?>: <?php echo mc_displayHelpTip($msg_javascript578,'LEFT'); ?></label>
    <input tabindex="<?php echo (++$tabIndex); ?>" type="text" name="rate" value="<?php echo (isset($EDIT->rate) ? $EDIT->rate : '0.00'); ?>" style="width:30%" class="box" /><br /><br />
    
	<label><?php echo $msg_itemrates22; ?>: <?php echo mc_displayHelpTip($msg_javascript579,'LEFT'); ?></label>
    <input tabindex="<?php echo (++$tabIndex); ?>" type="text" name="item" value="<?php echo (isset($EDIT->item) ? $EDIT->item : '0.00'); ?>" style="width:30%" class="box" /> <?php echo $msg_itemrates24; ?><br /><br />
    
    <label><?php echo $msg_itemrates13; ?>: <?php echo mc_displayHelpTip($msg_javascript443,'LEFT'); ?></label>
    <?php echo $msg_script5; ?> <input tabindex="<?php echo (++$tabIndex); ?>" type="radio" name="enable" value="yes"<?php echo (isset($EDIT->enabled) && $EDIT->enabled=='yes' ? ' checked="checked"' : (!isset($EDIT->enabled) ? ' checked="checked"' : '')); ?> /> <?php echo $msg_script6; ?> <input tabindex="<?php echo (++$tabIndex); ?>" type="radio" name="enable" value="no"<?php echo (isset($EDIT->enabled) && $EDIT->enabled=='no' ? ' checked="checked"' : ''); ?> />
     
  </div>
  <br class="clear" />
</div>

</div>

<p style="text-align:center;padding-top:20px">
  <input type="hidden" name="<?php echo (isset($EDIT->id) ? 'update' : 'process'); ?>" value="yes" />
  <input class="formbutton" type="submit" value="<?php echo mc_cleanDataEnt((isset($EDIT->id) ? $msg_itemrates9 : $msg_itemrates3)); ?>" title="<?php echo mc_cleanDataEnt((isset($EDIT->id) ? $msg_itemrates9 : $msg_itemrates3)); ?>" /><?php echo (isset($EDIT->id) ? '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input class="formbutton2" type="button" onclick="window.location=\'?p=itemrate\'" value="'.mc_cleanDataEnt($msg_script11).'" title="'.mc_cleanDataEnt($msg_script11).'" />' : ''); ?>
</p>
</form><br />
</div>

<div id="enabArea" style="display:none">
<form method="post" id="form2" action="?p=itemrate">
<div class="formFieldWrapper" id="zA_update">
  <div class="formLeft" style="width:66%">
    <label><?php echo $msg_itemrates2; ?>:</label>
    <div class="categoryBoxes">
    <?php
    $q_zones = mysql_query("SELECT *,`".DB_PREFIX."zones`.`id` AS `zid` FROM `".DB_PREFIX."zones` 
               LEFT JOIN `".DB_PREFIX."countries`
               ON `".DB_PREFIX."zones`.`zCountry` = `".DB_PREFIX."countries`.`id`
               WHERE `enCountry`                  = 'yes'
               ORDER BY `cName`,`zName`
               ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    ?>
    <input type="checkbox" name="log" id="log" value="all" onclick="toggleCheckBoxes(this.checked,'categoryBoxes')" tabindex="<?php echo (++$tabIndex); ?>" /> <b><?php echo $msg_itemrates5; ?></b><br />
    <?php
    while ($ZONES = mysql_fetch_object($q_zones)) {
    ?>
    <input tabindex="<?php echo (++$tabIndex); ?>" type="checkbox" name="inZone[]" value="<?php echo $ZONES->zid; ?>" /> <?php echo mc_cleanData($ZONES->cName); ?> - <?php echo mc_cleanDataEnt($ZONES->zName); ?><br />
    <?php
    }
    ?>
    </div>
  </div>
  <div class="formRight" style="width:30%">  
    <label><?php echo $msg_itemrates13; ?>:</label>
    <?php echo $msg_script5; ?> <input tabindex="<?php echo (++$tabIndex); ?>" type="radio" name="enable" value="yes" checked="checked" /> <?php echo $msg_script6; ?> <input tabindex="<?php echo (++$tabIndex); ?>" type="radio" name="enable" value="no" />
     
  </div>
  <br class="clear" />
</div>

<p style="text-align:center;padding-top:20px">
  <input type="hidden" name="enabdis" value="yes" />
  <input class="formbutton" type="submit" value="<?php echo mc_cleanDataEnt($msg_itemrates21); ?>" title="<?php echo mc_cleanDataEnt($msg_itemrates21); ?>" />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  <input class="formbutton2" type="button" onclick="jQuery('#enabArea').hide();jQuery('#addArea').show('slow');" value="<?php echo mc_cleanDataEnt($msg_script11); ?>" title="<?php echo mc_cleanDataEnt($msg_script11); ?>" />
</p>
</form><br />
</div>

<div class="fieldHeadWrapper">
  <p style="text-align:right"><span style="float:left;padding-top:2px"><?php echo $msg_itemrates4; ?>:</span><?php echo $msg_itemrates18; ?>:
  <select onchange="if(this.value!= 0){location=this.options[this.selectedIndex].value}">
  <option value="?p=itemrate"><?php echo $msg_itemrates19; ?></option>
  <?php
  $q_countries = mysql_query("SELECT * FROM `".DB_PREFIX."countries`
                 WHERE `enCountry` = 'yes' 
                 ORDER BY `cName`
				 ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  while ($CTRY = mysql_fetch_object($q_countries)) {
  ?>
  <option value="?p=itemrate&amp;country=<?php echo $CTRY->id; ?>"<?php echo (isset($_GET['country']) && mc_digitSan($_GET['country'])==$CTRY->id ? ' selected="selected"' : ''); ?>><?php echo mc_cleanData($CTRY->cName); ?></option>
  <?php
  }
  ?>
  </select>
  </p>
</div>

<?php
$limit   = $page * RATES_PER_PAGE - (RATES_PER_PAGE);
$q_rates = mysql_query("SELECT SQL_CALC_FOUND_ROWS *,`".DB_PREFIX."per`.`id` AS `fid`,`".DB_PREFIX."zones`.`id` AS `zid` 
           FROM `".DB_PREFIX."per` 
           LEFT JOIN `".DB_PREFIX."zones`
           ON `".DB_PREFIX."per`.`inZone` = `".DB_PREFIX."zones`.`id`
           LEFT JOIN `".DB_PREFIX."countries`
           ON `".DB_PREFIX."zones`.`zCountry`  = `".DB_PREFIX."countries`.`id`
           ".(isset($_GET['country']) ? 'WHERE `'.DB_PREFIX.'countries`.`id`   = \''.mc_digitSan($_GET['country']).'\'' : '')."
           ORDER BY `cName`,`zName`
           LIMIT $limit,".SERVICES_PER_PAGE."
           ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
$c            = mysql_fetch_object(mysql_query("SELECT FOUND_ROWS() AS `rows`"));
$countedRows  =  (isset($c->rows) ? number_format($c->rows,0,'.','') : '0');
if (mysql_num_rows($q_rates)>0) {
  while ($RATES = mysql_fetch_object($q_rates)) {
  ?>
  <div class="catWrapper">
    <?php
    if ((isset($curName) && $curName!=mc_cleanData($RATES->zCountry)) || !isset($curName)) {
    ?>
    <span class="shipInfoHead"><?php echo mc_cleanDataEnt($RATES->cName); ?></span>
    <?php
    }
    ?>
    <div class="catLeft" style="width:46%"><?php echo mc_cleanDataEnt($RATES->zName); ?></div>
    <div class="catLeft" style="width:45%;margin-right:5px"><?php echo str_replace(array('{rate}','{item}'),array(mc_currencyFormat($RATES->rate),mc_currencyFormat($RATES->item)),$msg_itemrates23); ?></div>
    <div class="catRight" style="width:5%;text-align:center;padding:5px 0 3px 0;margin-right:0;background:#fff;float:right"><a href="?p=itemrate&amp;edit=<?php echo $RATES->fid.(isset($_GET['service']) ? '&amp;service='.mc_digitSan($_GET['service']) : ''); ?>"><img src="templates/images/edit.png" alt="<?php echo mc_cleanDataEnt($msg_script9); ?>" title="<?php echo mc_cleanDataEnt($msg_script9); ?>" /></a><?php echo ($uDel=='yes' ? ' <a href="?p=itemrate&amp;del='.$RATES->fid.'" onclick="return confirmMessage(\''.mc_cleanDataEnt($msg_javascript45).'\')"><img src="templates/images/delete.png" alt="'.mc_cleanDataEnt($msg_script10).'" title="'.mc_cleanDataEnt($msg_script10).'" /></a>' : ''); ?></div>
    <br class="clear" />
  </div>
  <?php
  $curName  = mc_cleanData($RATES->zCountry);
  }
  define('PER_PAGE',RATES_PER_PAGE);
  if ($countedRows>0 && $countedRows>PER_PAGE) {
    $PTION = new pagination($countedRows,'?p='.$cmd.'&amp;next=');
    echo $PTION->display();
  }
} else {
?>
<span class="noData"><?php echo $msg_itemrates12; ?></span>
<?php
}
?>

<p>&nbsp;</p>
<p>&nbsp;</p>
</div>
