<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } 
if (isset($_GET['edit'])) {
  $EDIT       = mc_getTableData('rates','id',mc_digitSan($_GET['edit']));
}
?>
<div id="content">

<?php
if (isset($OK)) {
  echo actionCompleted(str_replace(array('{count}','{services}'),array($run[0],$run[1]),$msg_rates8));
}
if (isset($OK2)) {
  echo actionCompleted($msg_rates11);
}
if (isset($OK3) && $cnt>0) {
  echo actionCompleted($msg_rates10);
}
?>

<?php echo $msg_rates; ?><br /><br />

<form method="post" action="?p=rates<?php echo (isset($EDIT->id) ? '&amp;edit='.$EDIT->id : ''); ?>" enctype="multipart/form-data">
<div class="fieldHeadWrapper">
  <p>
  <?php 
  echo (isset($EDIT->id) ? $msg_rates9 : $msg_rates3); ?>:</p>
</div>

<div id="fieldCloneArea">

<div class="formFieldWrapperServices">
  <div class="formLeft" style="width:40%">
    <label><?php echo $msg_rates5; ?>: <?php echo mc_displayHelpTip($msg_javascript50,'RIGHT'); ?> / <?php echo $msg_rates6; ?>: <?php echo mc_displayHelpTip($msg_javascript51,'RIGHT'); ?></label>
    <input tabindex="<?php echo (++$tabIndex); ?>" type="text" style="width:38%" name="rWeightFrom" value="<?php echo (isset($EDIT->rWeightFrom) ? $EDIT->rWeightFrom : '0'); ?>" class="box" /> /
    <input tabindex="<?php echo (++$tabIndex); ?>" type="text" style="width:38%" name="rWeightTo" value="<?php echo (isset($EDIT->rWeightTo) ? $EDIT->rWeightTo : '0'); ?>" class="box" /><br /><br />
    
    <label><?php echo $msg_rates7; ?>: <?php echo mc_displayHelpTip($msg_javascript52,'RIGHT'); ?></label>
    <input tabindex="<?php echo (++$tabIndex); ?>" style="width:40%" type="text" name="rCost" value="<?php echo (isset($EDIT->rCost) ? $EDIT->rCost : '0.00'); ?>" class="box" />
    
    <?php
    if (!isset($EDIT->id)) {
    ?><br /><br />
    <label><?php echo $msg_services19; ?>: <?php echo mc_displayHelpTip($msg_javascript499,'RIGHT'); ?></label>
    <input tabindex="5" type="file" name="file" value="" class="box" />
    <?php
    }
    ?>
  </div>
  <div class="formRight" style="width:56%">  
    <label><?php echo (isset($EDIT->id) ? $msg_rates19 : $msg_rates13); ?>: <?php echo mc_displayHelpTip($msg_javascript53); ?></label>
    <?php
    if (isset($EDIT->id)) {
    ?>
    <select tabindex="<?php echo (++$tabIndex); ?>" name="rService">
    <?php
    $q_services = mysql_query("SELECT *,`".DB_PREFIX."services`.`id` AS `sid` FROM `".DB_PREFIX."services`
                  LEFT JOIN `".DB_PREFIX."zones`
                  ON `".DB_PREFIX."services`.`inZone` = `".DB_PREFIX."zones`.`id`
                  LEFT JOIN `".DB_PREFIX."countries`
                  ON `".DB_PREFIX."countries`.`id` = `".DB_PREFIX."zones`.`zCountry` 
                  WHERE `enCountry` = 'yes'
                  ORDER BY `cName`,`zName`,`sName`
                  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($SERVICES = mysql_fetch_object($q_services)) {
    ?>
    <option value="<?php echo $SERVICES->sid; ?>"<?php echo (isset($EDIT->rService) && $EDIT->rService==$SERVICES->sid ? ' selected="selected"' : ''); ?>><?php echo mc_cleanDataEnt($SERVICES->cName.' - '.$SERVICES->zName.' - '.$SERVICES->sName); ?></option>
    <?php
    }
    ?>
    </select>
    <?php
    } else {
    ?>
    <div class="categoryBoxes">
    <input type="checkbox" name="log" id="log" value="all" onclick="toggleCheckBoxes(this.checked,'categoryBoxes')" tabindex="<?php echo (++$tabIndex); ?>" /> <b><?php echo $msg_rates17; ?></b><br />
    <?php
    $q_services = mysql_query("SELECT *,`".DB_PREFIX."services`.`id` AS `sid` FROM `".DB_PREFIX."services`
                  LEFT JOIN `".DB_PREFIX."zones`
                  ON `".DB_PREFIX."services`.`inZone`  = `".DB_PREFIX."zones`.`id`
                  LEFT JOIN `".DB_PREFIX."countries`
                  ON `".DB_PREFIX."countries`.`id`     = `".DB_PREFIX."zones`.`zCountry` 
                  WHERE `enCountry`                  = 'yes'
                  ORDER BY `cName`,`zName`,`sName`
                  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($SERVICES = mysql_fetch_object($q_services)) {
    ?>
    <input tabindex="<?php echo (++$tabIndex); ?>" type="checkbox" name="rService[]" value="<?php echo $SERVICES->sid; ?>" /> <?php echo mc_cleanDataEnt($SERVICES->cName.' - '.$SERVICES->zName.' - '.$SERVICES->sName); ?><br />
    <?php
    }
    ?>
    </div>
    <?php
    }
    ?>
  </div>
  <br class="clear" />
</div>

</div>

<p style="text-align:center;padding-top:20px">
  <input type="hidden" name="<?php echo (isset($EDIT->id) ? 'update' : 'process'); ?>" value="yes" />
  <input class="formbutton" type="submit" value="<?php echo mc_cleanDataEnt((isset($EDIT->id) ? $msg_rates9 : $msg_rates3)); ?>" title="<?php echo mc_cleanDataEnt((isset($EDIT->id) ? $msg_rates9 : $msg_rates3)); ?>" /><?php echo (isset($EDIT->id) ? '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input class="formbutton2" type="button" onclick="window.location=\'?p=rates'.(isset($_GET['service']) ? '&amp;service='.mc_digitSan($_GET['service']) : '').'\'" value="'.mc_cleanDataEnt($msg_script11).'" title="'.mc_cleanDataEnt($msg_script11).'" />' : ''); ?>
</p>
</form><br />

<div class="fieldHeadWrapper">
  <p style="text-align:right"><span style="float:left;padding-top:2px"><?php echo $msg_rates4; ?>:</span><?php echo $msg_rates16; ?>:
  <select onchange="if(this.value!= 0){location=this.options[this.selectedIndex].value}">
  <option value="?p=rates"><?php echo $msg_rates18; ?></option>
  <?php
  $q_services = mysql_query("SELECT *,`".DB_PREFIX."services`.`id` AS `sid` FROM `".DB_PREFIX."services`
                LEFT JOIN `".DB_PREFIX."zones`
                ON `".DB_PREFIX."services`.`inZone` = `".DB_PREFIX."zones`.`id`
                LEFT JOIN `".DB_PREFIX."countries`
                ON `".DB_PREFIX."countries`.`id` = `".DB_PREFIX."zones`.`zCountry` 
                WHERE `enCountry` = 'yes'
                ORDER BY `cName`,`zName`,`sName`
                ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  while ($SERVICES = mysql_fetch_object($q_services)) {
  ?>
  <option value="?p=rates&amp;service=<?php echo $SERVICES->sid; ?>"<?php echo (isset($_GET['service']) && mc_digitSan($_GET['service'])==$SERVICES->sid ? ' selected="selected"' : ''); ?>><?php echo mc_cleanData($SERVICES->cName.' - '.$SERVICES->zName.' - '.$SERVICES->sName); ?></option>
  <?php
  }
  ?>
  </select>
  </p>
</div>

<?php
$limit   = $page * RATES_PER_PAGE - (RATES_PER_PAGE);
$q_rates = mysql_query("SELECT SQL_CALC_FOUND_ROWS *,`".DB_PREFIX."rates`.`id` AS `rid` FROM `".DB_PREFIX."rates`
           LEFT JOIN `".DB_PREFIX."services`
           ON `".DB_PREFIX."services`.`id`     = `".DB_PREFIX."rates`.`rService`
           LEFT JOIN `".DB_PREFIX."zones`
           ON `".DB_PREFIX."services`.`inZone` = `".DB_PREFIX."zones`.`id`
           LEFT JOIN `".DB_PREFIX."countries`
           ON `".DB_PREFIX."countries`.`id`    = `".DB_PREFIX."zones`.`zCountry` 
           ".(isset($_GET['service']) ? 'WHERE `rService`   = \''.mc_digitSan($_GET['service']).'\'' : '')."
           ORDER BY `cName`,`zName`,`sName`,`rWeightFrom`*100,`rWeightTo`*100
           LIMIT $limit,".RATES_PER_PAGE."
           ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
$c            = mysql_fetch_object(mysql_query("SELECT FOUND_ROWS() AS `rows`"));
$countedRows  = (isset($c->rows) ? $c->rows : '0');
if (mysql_num_rows($q_rates)>0) {
  while ($RATES = mysql_fetch_object($q_rates)) {
  ?>
  <div class="catWrapper">
    <?php
    if ((isset($curName) && $curName!=mc_cleanData($RATES->cName.'-'.$RATES->zName.'-'.$RATES->sName)) || !isset($curName)) {
    ?>
    <span class="shipInfoHead"><?php echo mc_cleanData($RATES->cName.' - '.$RATES->zName.' - '.$RATES->sName); ?></span>
    <?php
    }
    ?>
    <div class="catLeft" style="width:51%<?php echo (isset($curName) && $curName==mc_cleanData($RATES->sName) ? ';background:#ffffff;border:1px solid #ffffff' : ''); ?>">&gt;</div>
    <div class="catLeft" style="width:40%;margin-right:5px"><?php echo $RATES->rWeightFrom; ?> - <?php echo $RATES->rWeightTo; ?> (<b><?php echo mc_currencyFormat($RATES->rCost); ?></b>)</div>
    <div class="catRight" style="width:5%;text-align:center;padding:5px 0 3px 0;margin-right:0;background:#fff;float:right"><a href="?p=rates&amp;edit=<?php echo $RATES->rid.(isset($_GET['service']) ? '&amp;service='.mc_digitSan($_GET['service']) : ''); ?>"><img src="templates/images/edit.png" alt="<?php echo mc_cleanDataEnt($msg_script9); ?>" title="<?php echo mc_cleanDataEnt($msg_script9); ?>" /></a><?php echo ($uDel=='yes' ? ' <a href="?p=rates&amp;del='.$RATES->rid.'" onclick="return confirmMessage(\''.mc_cleanDataEnt($msg_javascript45).'\')"><img src="templates/images/delete.png" alt="'.mc_cleanDataEnt($msg_script10).'" title="'.mc_cleanDataEnt($msg_script10).'" /></a>' : ''); ?></div>
    <br class="clear" />
  </div>
  <?php
  $curName  = mc_cleanData($RATES->cName.'-'.$RATES->zName.'-'.$RATES->sName);
  }
  define('PER_PAGE',RATES_PER_PAGE);
  if ($countedRows>0 && $countedRows>PER_PAGE) {
    $PTION = new pagination($countedRows,'?p='.$cmd.'&amp;next=');
    echo $PTION->display();
  }
} else {
?>
<span class="noData"><?php echo $msg_rates12; ?></span>
<?php
}
?>

<p>&nbsp;</p>
<p>&nbsp;</p>
</div>
