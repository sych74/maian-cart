<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } ?>
<div id="content">

<?php
if (isset($OK)) {
  echo actionCompleted($msg_updaterates6);
}
echo $msg_updaterates; ?><br /><br />

<form method="post" id="form" action="?p=update-rates" onsubmit="return confirmMessage('<?php echo mc_cleanDataEnt($msg_javascript45); ?>')">
<div class="fieldHeadWrapper">
  <p><?php echo $msg_productprices2; ?>:</p>
</div>

<div class="formFieldWrapper">
  <div class="formLeft" style="width:25%">
    <label><?php echo $msg_updaterates2; ?>: <?php echo mc_displayHelpTip($msg_javascript174,'RIGHT'); ?></label>
    <input tabindex="<?php echo (++$tabIndex); ?>" type="text" name="price" value="" class="box" style="width:50%" /><br /><br />
    
    <label><?php echo $msg_updaterates10; ?>: <?php echo mc_displayHelpTip($msg_javascript447,'RIGHT'); ?></label>
    <input tabindex="<?php echo ++$tabIndex; ?>" type="checkbox" name="rpref[]" value="flat" /> <?php echo $msg_updaterates7; ?><br /> 
    <input tabindex="<?php echo ++$tabIndex; ?>" type="checkbox" name="rpref[]" value="peri" onclick="if(this.checked){jQuery('#perItemAdd').show()}else{jQuery('#perItemAdd').hide()}" /> <?php echo $msg_javascript577; ?><br />
	<input tabindex="<?php echo ++$tabIndex; ?>" type="checkbox" name="rpref[]" value="perc" /> <?php echo $msg_updaterates8; ?><br />
    <input tabindex="<?php echo ++$tabIndex; ?>" type="checkbox" name="rpref[]" value="weight" /> <?php echo $msg_updaterates9; ?><br />
    <input tabindex="<?php echo ++$tabIndex; ?>" type="checkbox" name="rpref[]" value="tare" /> <?php echo $msg_updaterates11; ?>
  </div>
  <div class="formRight" style="width:33%">  
    <label><?php echo $msg_productprices4; ?>: <?php echo mc_displayHelpTip($msg_javascript88); ?></label>
    <?php echo $msg_productprices6; ?> <input tabindex="<?php echo (++$tabIndex); ?>" type="radio" name="type" value="incr" checked="checked" /> <?php echo $msg_productprices7; ?> <input tabindex="<?php echo (++$tabIndex); ?>" type="radio" name="type" value="decr" /> <?php echo $msg_productprices19; ?> <input type="radio" name="type" value="fixed" /><br /><br />
	
	<div id="perItemAdd" style="display:none">
	<label><?php echo $msg_updaterates12; ?>: <?php echo mc_displayHelpTip($msg_javascript585); ?></label>
    <input tabindex="<?php echo (++$tabIndex); ?>" type="text" name="add" value="" class="box" style="width:30%" />
	</div>
  </div>
  <div class="formRight" style="width:38%">  
    <label><?php echo $msg_updaterates3; ?>: <?php echo mc_displayHelpTip($msg_javascript175,'LEFT'); ?></label>
    <div class="categoryBoxes">
    <input tabindex="<?php echo (++$tabIndex); ?>" type="checkbox" name="log" value="all" onclick="selectAll()" /> <b><?php echo $msg_updaterates4; ?></b><br />
    <?php
    $q_zones = mysql_query("SELECT *,`".DB_PREFIX."zones`.`id` AS `zid` FROM `".DB_PREFIX."zones` 
               LEFT JOIN `".DB_PREFIX."countries`
               ON `".DB_PREFIX."zones`.`zCountry` = `".DB_PREFIX."countries`.`id`
               WHERE `enCountry` = 'yes'
               ORDER BY `cName`,`zName`
               ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($ZONES = mysql_fetch_object($q_zones)) {
    ?>
    <input type="checkbox" tabindex="<?php echo (++$tabIndex); ?>" name="zones[]" value="<?php echo $ZONES->zid; ?>" /> <?php echo mc_cleanData($ZONES->cName); ?> - <?php echo mc_cleanData($ZONES->zName); ?><br />
    <?php
    }
    ?>
    </div>
  </div>
  <br class="clear" />
</div>

<p style="text-align:center;padding-top:20px">
 <input type="hidden" name="process" value="yes" />
 <input class="formbutton" type="submit" value="<?php echo mc_cleanDataEnt($msg_updaterates5); ?>" title="<?php echo mc_cleanDataEnt($msg_updaterates5); ?>" />
</p>
</form>

<p>&nbsp;</p>
<p>&nbsp;</p>
</div>
