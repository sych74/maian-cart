<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } 
if (isset($_GET['edit'])) {
  $EDIT = mc_getTableData('percent','id',mc_digitSan($_GET['edit']));
}
?>
<div id="content">

<?php
if (isset($OK)) {
  echo actionCompleted(str_replace('{count}',$cnt,$msg_percrates8));
}
if (isset($OK2)) {
  echo actionCompleted($msg_percrates11);
}
if (isset($OK3) && $cnt>0) {
  echo actionCompleted($msg_percrates10);
}

echo $msg_percrates; 
?><br /><br />
<?php
if (mc_rowCount('percent')>0) {
?>
<a href="#" onclick="jQuery('#addArea').hide();jQuery('#enabArea').slideDown('slow');return false" class="enableDisable" title="<?php echo mc_cleanDataEnt($msg_percrates20); ?>"><b><?php echo $msg_percrates20; ?></b></a><br /><br />
<?php
}
?>

<div id="addArea">
<form method="post" id="form" action="?p=percent<?php echo (isset($EDIT->id) ? '&amp;edit='.$EDIT->id : ''); ?>">
<div class="fieldHeadWrapper">
  <p><?php 
  echo (isset($EDIT->id) ? $msg_percrates9 : $msg_percrates3); ?>:</p>
</div>

<div id="fieldCloneArea">

<div class="formFieldWrapperServices">
  <div class="formLeft" style="width:66%">
    <label><?php echo $msg_percrates2; ?>: <?php echo mc_displayHelpTip($msg_javascript441,'RIGHT'); ?></label>
    <?php
    if (isset($EDIT->id)) {
    ?>
    <select tabindex="<?php echo ($tabIndex+3); ?>" name="inZone">
    <?php
    $q_zones = mysql_query("SELECT *,".DB_PREFIX."zones.id AS `zid` FROM ".DB_PREFIX."zones 
               LEFT JOIN ".DB_PREFIX."countries
               ON ".DB_PREFIX."zones.zCountry = ".DB_PREFIX."countries.id
               WHERE `enCountry`              = 'yes'
               ORDER BY `zName`,`cName`
               ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($ZONES = mysql_fetch_object($q_zones)) {
    ?>
    <option value="<?php echo $ZONES->zid; ?>"<?php echo (isset($EDIT->inZone) && $EDIT->inZone==$ZONES->zid ? ' selected="selected"' : ''); ?>><?php echo mc_cleanData($ZONES->cName); ?> - <?php echo mc_cleanDataEnt($ZONES->zName); ?></option>
    <?php
    }
    ?>
    </select>
    <?php
    } else {
    ?>
    <div class="categoryBoxes">
    <input type="checkbox" name="log" id="log2" value="all" onclick="toggleCheckBoxes(this.checked,'categoryBoxes')" tabindex="<?php echo (++$tabIndex); ?>" /> <b><?php echo $msg_percrates18; ?></b><br />
    <?php
    $q_zones = mysql_query("SELECT *,".DB_PREFIX."zones.id AS `zid` FROM ".DB_PREFIX."zones 
               LEFT JOIN ".DB_PREFIX."countries
               ON ".DB_PREFIX."zones.zCountry = ".DB_PREFIX."countries.id
               WHERE `enCountry`              = 'yes'
               ORDER BY `cName`,`zName`
               ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($ZONES = mysql_fetch_object($q_zones)) {
    ?>
    <input tabindex="<?php echo (++$tabIndex); ?>" type="checkbox" name="inZone[]" value="<?php echo $ZONES->zid; ?>" /> <?php echo mc_cleanData($ZONES->cName); ?> - <?php echo mc_cleanDataEnt($ZONES->zName); ?><br />
    <?php
    }
    ?>
    </div>
    <?php
    }
    ?>
  </div>
  <div class="formRight" style="width:30%">  
    <label><?php echo $msg_percrates6; ?>: <?php echo mc_displayHelpTip($msg_javascript444,'LEFT'); ?></label>
    <input tabindex="<?php echo (++$tabIndex); ?>" type="text" name="priceFrom" value="<?php echo (isset($EDIT->priceFrom) ? $EDIT->priceFrom : '0.00'); ?>" style="width:30%" class="box" /> <?php echo $msg_percrates14; ?>
    <input tabindex="<?php echo (++$tabIndex); ?>" type="text" name="priceTo" value="<?php echo (isset($EDIT->priceTo) ? $EDIT->priceTo : '0.00'); ?>" style="width:30%" class="box" /><br /><br />
    
    <label><?php echo $msg_percrates15; ?>: <?php echo mc_displayHelpTip($msg_javascript445,'LEFT'); ?></label>
    <input tabindex="<?php echo (++$tabIndex); ?>" type="text" name="percentage" value="<?php echo (isset($EDIT->percentage) ? rateCleaner($EDIT->percentage) : '0'); ?>" style="width:20%" class="box" />%<br /><br />
    
    <label><?php echo $msg_percrates13; ?>: <?php echo mc_displayHelpTip($msg_javascript443,'LEFT'); ?></label>
    <?php echo $msg_script5; ?> <input tabindex="<?php echo (++$tabIndex); ?>" type="radio" name="enable" value="yes"<?php echo (isset($EDIT->enabled) && $EDIT->enabled=='yes' ? ' checked="checked"' : (!isset($EDIT->enabled) ? ' checked="checked"' : '')); ?> /> <?php echo $msg_script6; ?> <input tabindex="<?php echo (++$tabIndex); ?>" type="radio" name="enable" value="no"<?php echo (isset($EDIT->enabled) && $EDIT->enabled=='no' ? ' checked="checked"' : ''); ?> />
  </div>
  <br class="clear" />
</div>

</div>

<p style="text-align:center;padding-top:20px">
  <input type="hidden" name="<?php echo (isset($EDIT->id) ? 'update' : 'process'); ?>" value="yes" />
  <input class="formbutton" type="submit" value="<?php echo mc_cleanDataEnt((isset($EDIT->id) ? $msg_percrates9 : $msg_percrates3)); ?>" title="<?php echo mc_cleanDataEnt((isset($EDIT->id) ? $msg_percrates9 : $msg_percrates3)); ?>" /><?php echo (isset($EDIT->id) ? '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input class="formbutton2" type="button" onclick="window.location=\'?p=percent'.(isset($_GET['service']) ? '&amp;service='.mc_digitSan($_GET['service']) : '').'\'" value="'.mc_cleanDataEnt($msg_script11).'" title="'.mc_cleanDataEnt($msg_script11).'" />' : ''); ?>
</p>
</form><br />
</div>

<div id="enabArea" style="display:none">
<form method="post" id="form2" action="?p=percent">
<div class="formFieldWrapper" id="zA_update">
  <div class="formLeft" style="width:66%">
    <label><?php echo $msg_percrates2; ?>:</label>
    <div class="categoryBoxes">
    <?php
    $q_zones = mysql_query("SELECT *,".DB_PREFIX."zones.id AS zid FROM ".DB_PREFIX."zones 
               LEFT JOIN ".DB_PREFIX."countries
               ON ".DB_PREFIX."zones.zCountry = ".DB_PREFIX."countries.id
               WHERE enCountry                = 'yes'
               ORDER BY cName,zName
               ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    ?>
    <input type="checkbox" name="log" id="log" value="all" onclick="toggleCheckBoxes(this.checked,'categoryBoxes')" tabindex="<?php echo (++$tabIndex); ?>" /> <b><?php echo $msg_percrates18; ?></b><br />
    <?php
    while ($ZONES = mysql_fetch_object($q_zones)) {
    ?>
    <input tabindex="<?php echo (++$tabIndex); ?>" type="checkbox" name="inZone[]" value="<?php echo $ZONES->zid; ?>" /> <?php echo mc_cleanData($ZONES->cName); ?> - <?php echo mc_cleanDataEnt($ZONES->zName); ?><br />
    <?php
    }
    ?>
    </div>
  </div>
  <div class="formRight" style="width:30%">  
    <label><?php echo $msg_percrates13; ?>:</label>
    <?php echo $msg_script5; ?> <input tabindex="<?php echo (++$tabIndex); ?>" type="radio" name="enable" value="yes" checked="checked" /> <?php echo $msg_script6; ?> <input tabindex="<?php echo (++$tabIndex); ?>" type="radio" name="enable" value="no" />
     
  </div>
  <br class="clear" />
</div>

<p style="text-align:center;padding-top:20px">
  <input type="hidden" name="enabdis" value="yes" />
  <input class="formbutton" type="submit" value="<?php echo mc_cleanDataEnt($msg_percrates21); ?>" title="<?php echo mc_cleanDataEnt($msg_percrates21); ?>" />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  <input class="formbutton2" type="button" onclick="jQuery('#enabArea').hide();jQuery('#addArea').show();" value="<?php echo mc_cleanDataEnt($msg_script11); ?>" title="<?php echo mc_cleanDataEnt($msg_script11); ?>" />
</p>
</form><br />
</div>

<div class="fieldHeadWrapper">
  <p style="text-align:right"><span style="float:left;padding-top:2px"><?php echo $msg_percrates4; ?>:</span><?php echo $msg_percrates19; ?>:
  <select onchange="if(this.value!= 0){location=this.options[this.selectedIndex].value}">
  <option value="?p=services"><?php echo $msg_percrates18; ?></option>
  <?php
  $q_zones = mysql_query("SELECT *,".DB_PREFIX."zones.id AS zid FROM ".DB_PREFIX."zones 
             LEFT JOIN ".DB_PREFIX."countries
             ON ".DB_PREFIX."zones.zCountry = ".DB_PREFIX."countries.id
             WHERE enCountry                = 'yes'
             ORDER BY cName,zName
             ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  while ($ZONES = mysql_fetch_object($q_zones)) {
  ?>
  <option value="?p=percent&amp;zone=<?php echo $ZONES->zid; ?>"<?php echo (isset($_GET['zone']) && mc_digitSan($_GET['zone'])==$ZONES->zid ? ' selected="selected"' : ''); ?>><?php echo mc_cleanData($ZONES->cName); ?> - <?php echo mc_cleanData($ZONES->zName); ?></option>
  <?php
  }
  ?>
  </select>
  </p>
</div>

<?php
$limit   = $page * RATES_PER_PAGE - (RATES_PER_PAGE);
$q_rates = mysql_query("SELECT SQL_CALC_FOUND_ROWS *,".DB_PREFIX."percent.id AS pid,".DB_PREFIX."zones.id AS zid 
           FROM ".DB_PREFIX."percent 
           LEFT JOIN ".DB_PREFIX."zones
           ON ".DB_PREFIX."percent.inZone = ".DB_PREFIX."zones.id
           LEFT JOIN ".DB_PREFIX."countries
           ON ".DB_PREFIX."zones.zCountry  = ".DB_PREFIX."countries.id
           ".(isset($_GET['zone']) ? 'WHERE inZone   = \''.mc_digitSan($_GET['zone']).'\'' : '')."
           ORDER BY cName,zName,priceFrom*100,priceTo*100
           LIMIT $limit,".SERVICES_PER_PAGE."
           ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
$c            = mysql_fetch_object(mysql_query("SELECT FOUND_ROWS() AS rows"));
$countedRows  =  (isset($c->rows) ? number_format($c->rows,0,'.','') : '0');
if (mysql_num_rows($q_rates)>0) {
  while ($RATES = mysql_fetch_object($q_rates)) {
  ?>
  <div class="catWrapper">
    <?php
    if ((isset($curName) && $curName!=mc_cleanData($RATES->zName).$RATES->zCountry) || !isset($curName)) {
    ?>
    <span class="shipInfoHead"><?php echo mc_cleanDataEnt($RATES->cName.' - '.$RATES->zName); ?></span>
    <?php
    }
    ?>
    <div class="catLeft" style="width:51%"><?php echo mc_currencyFormat($RATES->priceFrom); ?> - <?php echo mc_currencyFormat($RATES->priceTo); ?></div>
    <div class="catLeft" style="width:40%;margin-right:5px"><?php echo $RATES->percentage; ?>%</div>
    <div class="catRight" style="width:5%;text-align:center;padding:5px 0 3px 0;margin-right:0;background:#fff;float:right"><a href="?p=percent&amp;edit=<?php echo $RATES->pid.(isset($_GET['service']) ? '&amp;service='.mc_digitSan($_GET['service']) : ''); ?>"><img src="templates/images/edit.png" alt="<?php echo mc_cleanDataEnt($msg_script9); ?>" title="<?php echo mc_cleanDataEnt($msg_script9); ?>" /></a><?php echo ($uDel=='yes' ? ' <a href="?p=percent&amp;del='.$RATES->pid.'" onclick="return confirmMessage(\''.mc_cleanDataEnt($msg_javascript45).'\')"><img src="templates/images/delete.png" alt="'.mc_cleanDataEnt($msg_script10).'" title="'.mc_cleanDataEnt($msg_script10).'" /></a>' : ''); ?></div>
    <br class="clear" />
  </div>
  <?php
  $curName  = mc_cleanData($RATES->zName).$RATES->zCountry;
  }
  define('PER_PAGE',RATES_PER_PAGE);
  if ($countedRows>0 && $countedRows>PER_PAGE) {
    $PTION = new pagination($countedRows,'?p='.$cmd.'&amp;next=');
    echo $PTION->display();
  }
} else {
?>
<span class="noData"><?php echo $msg_percrates12; ?></span>
<?php
}
?>

<p>&nbsp;</p>
<p>&nbsp;</p>
</div>
