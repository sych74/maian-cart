<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } ?>
<div id="content">
<?php
$minFields = MIN_FIELDS_COUNTRIES;
$maxFields = MAX_FIELDS_COUNTRIES;
if (isset($_GET['edit'])) {
  $EDIT = mc_getTableData('countries','id',mc_digitSan($_GET['edit']));
  $maxFields  = 1;
}

if (isset($OK)) {
  echo actionCompleted($msg_countries5);
}
if (isset($OK2) && $count>0) {
  echo actionCompleted(($count>1 ? str_replace('{count}',$count,$msg_countries20) : $msg_countries13));
}
if (isset($OK3)) {
  echo actionCompleted($msg_countries14);
}
if (isset($OK4) && $count>0) {
  echo actionCompleted(($count>1 ? str_replace('{count}',$count,$msg_countries16) : $msg_countries21));
}

$tabIndex = 0;

?>

<?php echo $msg_countries; ?><br /><br />

<form method="post" action="?p=countries" id="form">
<div class="fieldHeadWrapper">
  <p><?php echo mc_cleanDataEnt($msg_javascript31); ?>:</p>
</div>
<script type="text/javascript">
//<![CDATA[
function changeButtonCount(form,type) {
  var count = 0;
  if (type=='all') {
    selectCountries();
  }
  if (type=='single' && document.getElementById('log').checked==true) {
    document.getElementById('log').checked=false;
  }
  for (i = 0; i < form.elements.length; i++){
	  var current = form.elements[i];
	  if(current.name!='log' && current.type == 'checkbox' && current.checked){
		  count++;
	  }
  }
  if (document.getElementById('delbutton')!=undefined) {
    if (count>0) {
      jQuery('#delbutton').val('<?php echo str_replace(array("'","&#039;"),array("\'","\'"),mc_cleanDataEnt($msg_countries15)); ?> ('+count+')');
    } else {
      jQuery('#delbutton').val('<?php echo str_replace(array("'","&#039;"),array("\'","\'"),mc_cleanDataEnt($msg_countries15)); ?> (0)');
    }
  }
}
//]]>
</script>
<div class="formFieldWrapper">
  <div class="formLeft" style="width:46%">
    <label style="padding-left:6px"><input type="checkbox" id="log" name="log" onclick="changeButtonCount(this.form,'all')" /> <?php echo $msg_countries2; ?>:</label>
    <div id="fromBoxWrapper" style="margin-bottom:5px">
     <?php echo implode('<br />',loadCountries('no','',true)); ?>
    </div>
    <?php
    if ($uDel=='yes') {
    ?>
    <input class="formbutton3" id="delbutton" onclick="return confirmMessage('<?php echo mc_cleanDataEnt($msg_javascript45); ?>')" type="submit" name="deleteSelected" value="<?php echo mc_cleanDataEnt($msg_countries15); ?> (0)" title="<?php echo mc_cleanDataEnt($msg_countries15); ?>" />
    <?php
    }
    ?>
  </div>
  <div class="countryCopy" style="width:5%;padding-top:80px">
    <input type="submit" class="formbutton" name="yes_go" value="&gt;&gt;" title="<?php echo mc_cleanDataEnt($msg_countries6); ?>" /><br /><br /><br />
    <input type="submit" class="formbutton" name="no_go" value="&lt;&lt;" title="<?php echo mc_cleanDataEnt($msg_countries7); ?>" />
  </div>
  <div class="formRight" style="width:46%">  
    <label><?php echo $msg_countries3; ?>:</label>
    <div id="toBoxWrapper">
     <?php echo implode('<br />',loadCountries('yes','',true)); ?>
    </div>
  </div>
  <br class="clear" />
</div>

</form>

<div class="fieldHeadWrapper">
  <p>
  <?php 
  if (!isset($EDIT->id)) {
  ?>
  <span class="float"><img style="cursor:pointer" src="templates/images/add.png" alt="<?php echo mc_cleanDataEnt($msg_countries18); ?>" title="<?php echo mc_cleanDataEnt($msg_countries18); ?>" onclick="addFieldBoxes(1,<?php echo $minFields; ?>,<?php echo $maxFields; ?>)" /> <img src="templates/images/remove.png" alt="<?php echo mc_cleanDataEnt($msg_countries19); ?>" style="cursor:pointer" title="<?php echo mc_cleanDataEnt($msg_countries19); ?>" onclick="addFieldBoxes(-1,<?php echo $minFields; ?>,<?php echo $maxFields; ?>)" /></span>
  <?php
  }
  echo (isset($EDIT->id) ? mc_cleanDataEnt($msg_countries12) : mc_cleanDataEnt($msg_countries11)); ?>:</p>
</div>

<form method="post" action="?p=countries<?php echo (isset($EDIT->id) ? '&amp;edit='.$EDIT->id : ''); ?>" id="form2">
<?php
for ($i=1; $i<=$maxFields; $i++) {
$tabIndex = ($i*10);
?>
<div id="row<?php echo $i; ?>"<?php echo ($i<=$minFields ? '' : ' style="display:none"'); ?>>
<?php
// Add spacer line to separate..
if ($i>1) {
?>
<hr class="spacerLine" />
<?php
}
?>
<div class="formFieldWrapper">
  <div class="formLeft" style="width:33%">  
    <label><?php echo $msg_countries8; ?>: <?php echo mc_displayHelpTip($msg_javascript390,'RIGHT'); ?></label>
    <input type="text" maxlength="250" name="cName[]" tabindex="<?php echo (++$tabIndex); ?>" value="<?php echo (isset($EDIT->cName) ? mc_cleanDataEnt($EDIT->cName) : ''); ?>" class="box" />
  </div>
  <div class="formLeft" style="width:17%">  
    <label><?php echo $msg_countries9; ?>: <?php echo mc_displayHelpTip($msg_javascript391); ?></label>
    <input type="text" name="cISO[]" style="width:30%" maxlength="3" tabindex="<?php echo (++$tabIndex); ?>" value="<?php echo (isset($EDIT->cISO) ? mc_cleanData($EDIT->cISO) : ''); ?>" class="box" />
  </div>
  <div class="formLeft" style="width:17%">  
    <label><?php echo $msg_countries23; ?>: <?php echo mc_displayHelpTip($msg_javascript391); ?></label>
    <input type="text" name="cISO_2[]" style="width:30%" maxlength="2" tabindex="<?php echo (++$tabIndex); ?>" value="<?php echo (isset($EDIT->cISO_2) ? mc_cleanData($EDIT->cISO_2) : ''); ?>" class="box" />
  </div>
  <div class="formLeft" style="width:17%">  
    <label><?php echo $msg_countries22; ?>: <?php echo mc_displayHelpTip($msg_javascript510,'LEFT'); ?></label>
    <input type="text" name="iso4217[]" style="width:30%" maxlength="3" tabindex="<?php echo (++$tabIndex); ?>" value="<?php echo (isset($EDIT->iso4217) ? mc_cleanData($EDIT->iso4217) : ''); ?>" class="box" />
  </div>
  <div class="formRight" style="width:15%">  
    <label><?php echo $msg_countries10; ?>: <?php echo mc_displayHelpTip($msg_javascript392,'LEFT'); ?></label>
    <?php echo $msg_script5; ?> <input type="radio" tabindex="<?php echo (++$tabIndex); ?>" name="enCountry[<?php echo $i; ?>][]" value="yes"<?php echo (isset($EDIT->enCountry) && $EDIT->enCountry=='yes' ? ' checked="checked"' : (!isset($EDIT->enCountry) ? ' checked="checked"' : '')); ?> /> <?php echo $msg_script6; ?> <input tabindex="<?php echo (++$tabIndex); ?>" type="radio" name="enCountry[<?php echo $i; ?>][]" value="no"<?php echo (isset($EDIT->enCountry) && $EDIT->enCountry=='no' ? ' checked="checked"' : ''); ?> />
  </div>
  <br class="clear" />
</div>
</div>
<?php
}
?>

<p style="text-align:center;padding-top:20px">
 <input type="hidden" name="<?php echo (isset($EDIT->id) ? 'update_country' : 'add_country'); ?>" value="yes" />
 <input type="hidden" name="num" id="num" value="<?php echo $minFields; ?>" />
 <input class="formbutton" type="submit" value="<?php echo (isset($EDIT->id) ? mc_cleanDataEnt($msg_countries12) : mc_cleanDataEnt($msg_countries11)); ?>" title="<?php echo (isset($EDIT->id) ? mc_cleanDataEnt($msg_countries12) : mc_cleanDataEnt($msg_countries11)); ?>" />
 <?php
 if (isset($EDIT->id)) {
 ?>
 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
 <input class="formbutton2" type="button" onclick="window.location='?p=countries'" value="<?php echo mc_cleanDataEnt($msg_script11); ?>" title="<?php echo mc_cleanDataEnt($msg_script11); ?>" />
 <?php
 }
 ?>
</p>

</form>

<p>&nbsp;</p>
<p>&nbsp;</p>
</div>
