<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } ?>
<div id="content">

<?php
if (isset($OK)) {
  unset($FIELD_MAPPING,$PRODUCT_OPTIONS);
  echo actionCompleted(str_replace('{count}',$added,$msg_import11));
}

if (isset($FIELD_MAPPING)) {
?>
<form method="post" action="?p=product-attributes-import" onsubmit="return confirmMessage('<?php echo mc_cleanDataEnt($msg_javascript302); ?>')">
<p><?php echo $msg_import19;?><br /><br /></p>
<div class="fieldHeadWrapper">
  <p><span class="float"><a onclick="mc_Window(this.href,'<?php echo GREYBOX_FIELD_INFO_HEIGHT; ?>','<?php echo GREYBOX_FIELD_INFO_WIDTH; ?>',this.title);return false;" href="?p=product-import&amp;field=attributes" title="<?php echo mc_cleanDataEnt($msg_import27); ?>"><?php echo $msg_import27; ?></a></span><?php echo str_replace('{count}',count($fields),$msg_import9); ?>:</p>
</div>

<?php
for ($i=0; $i<count($fields); $i++) {
?>
<div class="formFieldImportWrapper">
  <p class="field"><?php echo nl2br(mc_cleanDataEnt($fields[$i])); ?></p>
  <p class="mapto"><b><?php echo $msg_import55; ?></b>
  <select name="dbFields[]" id="select_<?php echo $i ?>" onchange="if(this.value==0){jQuery('#alt_text_<?php echo $i ?>').hide('slow');jQuery('#alt_box_<?php echo $i ?>').val('');jQuery('#alt_<?php echo $i ?>').hide('slow');jQuery('#alt_textarea_'+id).val('');}">
     <option value="0"><?php echo $msg_import53; ?></option>
     <?php
     foreach ($fieldMapping_vars AS $k => $v) {
     ?>
     <option value="<?php echo $k; ?>"><?php echo $v; ?></option>
     <?php
     }
     $boxValue = '';
     ?>
    </select> <a href="#" onclick="showNewValueImportBox('<?php echo $i; ?>');return false" title="<?php echo mc_cleanDataEnt($msg_import25); ?>"><?php echo mc_cleanDataEnt($msg_import25); ?></a> <?php echo mc_displayHelpTip($msg_javascript346,'LEFT'); ?>
  </p>
  <p class="value" id="alt_<?php echo $i; ?>" style="display:none">
    <input type="text" class="box" name="altFields[]" id="alt_box_<?php echo $i; ?>" value="<?php echo $boxValue; ?>" /> <span style="display:block;margin:5px 0 5px 0">(<a href="#" onclick="jQuery('#alt_<?php echo $i; ?>').hide('slow');jQuery('#alt_box_<?php echo $i; ?>').val('');return false;" title="<?php echo mc_cleanDataEnt($msg_script8); ?>"><?php echo $msg_script8; ?></a>)</span>
  </p>
  <p class="value" id="alt_text_<?php echo $i; ?>" style="display:none">
    <textarea style="height:100px" class="tarea" name="altTextFields[]" id="alt_textarea_<?php echo $i; ?>" rows="5" cols="20"><?php echo $boxValue; ?></textarea> <span style="display:block;margin:5px 0 5px 0">(<a href="#" onclick="jQuery('#alt_text_<?php echo $i; ?>').hide('slow');jQuery('#alt_textarea_<?php echo $i; ?>').val('');return false;" title="<?php echo mc_cleanDataEnt($msg_script8); ?>"><?php echo $msg_script8; ?></a>)</span>
  </p>
</div>
<?php
}
?>

<p style="text-align:center;padding:20px 0 20px 0">
 <input type="hidden" name="process-attributes-mapping" value="yes" />
 <input type="hidden" name="file" value="<?php echo (isset($_SESSION['curImportFile']) ? $_SESSION['curImportFile'] : ''); ?>" />
 <input class="formbutton" type="submit" value="<?php echo mc_cleanDataEnt($msg_import7); ?>" title="<?php echo mc_cleanDataEnt($msg_import7); ?>" />
</p>
<?php
} elseif (isset($PRODUCT_OPTIONS)) {
?>
<form method="post" action="?p=product-attributes-import" onsubmit="return confirmMessage('<?php echo mc_cleanDataEnt($msg_javascript304); ?>')">
<p><?php echo $msg_import22;?><br /><br /></p>

<div class="fieldHeadWrapper">
  <p><?php echo $msg_import3; ?>:</p>
</div>

<div class="formFieldWrapper">
  <div class="formLeft" style="width:48%">  
    <label><?php echo $msg_import14; ?>:</label>
    <select name="category" id="maian_cart_categories" onchange="getCategoryList(this)" tabindex="<?php echo (++$tabIndex); ?>">
    <option value="0">- - - - - -</option>
    <?php
    $getFirstCat     = 0;
    $getFirstCatMan  = '';
    $q_cats = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
              WHERE catLevel = '1'
              AND childOf    = '0'
              AND enCat      = 'yes'
              ORDER BY catname") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($CATS = mysql_fetch_object($q_cats)) {
    ?>
    <option value="<?php echo $CATS->id; ?>"><?php echo mc_cleanDataEnt($CATS->catname); ?></option>
    <?php
    $q_children = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
                  WHERE catLevel = '2'
                  AND enCat      = 'yes'
                  AND childOf    = '{$CATS->id}'
                  ORDER BY catname") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($CHILDREN = mysql_fetch_object($q_children)) {
    ?>
    <option value="<?php echo $CHILDREN->id; ?>">- <?php echo mc_cleanDataEnt($CHILDREN->catname); ?></option>
    <?php
    $q_infants = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
                  WHERE catLevel = '3'
                  AND childOf    = '{$CHILDREN->id}'
                  AND enCat      = 'yes'
                  ORDER BY catname
                  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($INFANTS = mysql_fetch_object($q_infants)) {
    ?>
    <option value="<?php echo $INFANTS->id; ?>">&nbsp;&nbsp;- <?php echo mc_cleanDataEnt($INFANTS->catname); ?></option>
    <?php
    }
    }
    }
    ?>
    </select><br /><br />
  </div>
  <div class="formRight" style="width:48%">  
    <label><?php echo $msg_import15; ?>:</label>
    <select name="product" id="maian_cart_products" tabindex="<?php echo (++$tabIndex); ?>">
    <option value="0"><?php echo $msg_import14; ?></option>
    </select><br /><br />
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper">
  <div class="formLeft" style="width:48%">  
    <label><?php echo $msg_import56; ?>: <?php echo mc_displayHelpTip($msg_javascript416,'RIGHT'); ?></label>
    <input tabindex="<?php echo (++$tabIndex); ?>" maxlength="100" type="text" class="box" style="width:40%" name="attrGroup" value="" />
  </div>
  <div class="formLeft" style="width:24%">
    <label><?php echo $msg_prodattributes29; ?>: <?php echo mc_displayHelpTip($msg_javascript428); ?></label>
    <?php echo $msg_script5; ?> <input type="radio" tabindex="<?php echo (++$tabIndex); ?>" name="allowMultiple" value="yes" /> <?php echo $msg_script6; ?> <input tabindex="<?php echo (++$tabIndex); ?>" type="radio" name="allowMultiple" value="no" checked="checked" /> 
  </div>
  <div class="formRight" style="width:24%"> 
    <label><?php echo $msg_prodattributes31; ?>: <?php echo mc_displayHelpTip($msg_javascript434,'LEFT'); ?></label>
   <?php echo $msg_script5; ?> <input type="radio" tabindex="<?php echo (++$tabIndex); ?>" name="isRequired" value="yes" /> <?php echo $msg_script6; ?> <input tabindex="<?php echo (++$tabIndex); ?>" type="radio" name="isRequired" value="no" checked="checked" />
  </div>
  <br class="clear" />
</div>

<p style="text-align:center;padding-top:20px">
 <input type="hidden" name="process-attributes" value="yes" />
 <input type="hidden" name="file" value="<?php echo (isset($_SESSION['curImportFile']) ? $_SESSION['curImportFile'] : ''); ?>" />
 <input class="formbutton" type="submit" value="<?php echo mc_cleanDataEnt($msg_import12); ?>" title="<?php echo mc_cleanDataEnt($msg_import12); ?>" />
</p>
<?php
} else {
?>
<form method="post" action="?p=product-attributes-import" enctype="multipart/form-data" onsubmit="return confirmMessage('<?php echo mc_cleanDataEnt($msg_javascript180); ?>')">
<p><?php echo $msg_import2;?><br /><br /></p>
<div class="fieldHeadWrapper">
  <p><?php echo $msg_import18; ?>:</p>
</div>

<div class="formFieldWrapper">
  <div class="formLeft" style="width:40%">
    <label><?php echo $msg_import8; ?>: <?php echo mc_displayHelpTip($msg_javascript179,'RIGHT'); ?></label>
    <input type="file" name="file" value="" class="box" /> 
  </div>
  <div class="formLeft" style="width:39%">
    <label><?php echo $msg_import5; ?>: <?php echo mc_displayHelpTip($msg_javascript176); ?></label>
    <input type="text" name="lines" value="5000" class="box" style="width:40%" /> 
  </div>
  <div class="formRight" style="width:20%">
    <label><?php echo $msg_import6; ?>: <?php echo mc_displayHelpTip($msg_javascript177,'LEFT'); ?></label>
    <input type="text" name="del" value="&#044;" class="box" style="width:15%" /> <input type="text" name="enc" value="&quot;" class="box" style="width:15%" />
  </div>
  <br class="clear" />
</div>

<p style="text-align:center;padding-top:20px">
 <input type="hidden" name="process-upload" value="yes" />
 <input class="formbutton" type="submit" value="<?php echo mc_cleanDataEnt($msg_import7); ?>" title="<?php echo mc_cleanDataEnt($msg_import7); ?>" />
</p>
<?php
}
?>
</form>

</div>
