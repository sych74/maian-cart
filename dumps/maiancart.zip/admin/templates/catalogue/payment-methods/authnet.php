<?php
if (!defined('PARENT') || !in_array($_GET['conf'],array_keys($mcSystemPaymentMethods))) {
  die('Invalid parameter: "conf='.mc_cleanDataEnt($_GET['conf']).'" is not supported');
}
$skipStatusDisplay = array('refunded','pending','cancelled');
$PM = mysql_fetch_object(mysql_query("SELECT * FROM ".DB_PREFIX."methods WHERE `method` = '{$_GET['conf']}' LIMIT 1")) 
      or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
// Parameters..
$params = array();
$q      = mysql_query("SELECT * FROM `".DB_PREFIX."methods_params` WHERE `method` = '{$_GET['conf']}'");
while ($M = mysql_fetch_object($q)) {
  $params[$M->param] = $M->value;
}
?>
<div class="fieldHeadWrapper">
  <p><?php echo $PM->display; ?></p>
</div>
<?php
if (function_exists('hash_hmac') || function_exists('mhash')) {
?>
<div class="formFieldWrapper">
  <div class="formLeft">
    <label><?php echo $msg_paymethods25; ?>: <?php echo mc_displayHelpTip($msg_javascript534,'RIGHT'); ?></label>
    <input type="text" name="params[login-id]" value="<?php echo mc_cleanData($params['login-id']); ?>" class="box" tabindex="<?php echo ++$tabIndex; ?>" /> 
  </div>
  <div class="formRight">
    <label><?php echo $msg_paymethods26; ?>: <?php echo mc_displayHelpTip($msg_javascript535); ?></label>
    <input type="text" name="params[transaction-key]" value="<?php echo mc_cleanData($params['transaction-key']); ?>" class="box" style="width:35%" tabindex="<?php echo ++$tabIndex; ?>" /> /
	<input type="password" name="params[response-key]" value="<?php echo mc_cleanData($params['response-key']); ?>" class="box" style="width:35%" tabindex="<?php echo ++$tabIndex; ?>" />
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper">
 <label><?php echo showBBCodeLink(false,'info','pm').$msg_settings68; ?>: <?php echo mc_displayHelpTip($msg_javascript67,'RIGHT'); ?></label>
 <textarea rows="5" cols="30" name="info" id="info" class="textarea" tabindex="<?php echo ++$tabIndex; ?>"><?php echo mc_cleanDataEnt($PM->info); ?></textarea>
</div>

<?php
// Payment statuses..
include(PATH.'templates/catalogue/payment-methods/statuses.php');
?>

<div class="formFieldWrapper">
 <label><?php echo $msg_settings235; ?>: <?php echo mc_displayHelpTip($msg_javascript457,'RIGHT'); ?></label>
 <input type="text" name="redirect" class="box" value="<?php echo mc_cleanDataEnt($PM->redirect); ?>" tabindex="<?php echo ++$tabIndex; ?>" />
</div>

<div class="formFieldWrapper">
  <div class="formLeft">
    <label><?php echo $msg_settings79; ?>: <?php echo mc_displayHelpTip($msg_javascript503,'RIGHT'); ?></label>
    <input type="text" name="liveserver" value="<?php echo mc_cleanData($PM->liveserver); ?>" class="box" tabindex="<?php echo ++$tabIndex; ?>" /> 
  </div>
  <div class="formRight">
    <label><?php echo $msg_settings80; ?>: <?php echo mc_displayHelpTip($msg_javascript533); ?></label>
    <input type="text" name="sandboxserver" value="<?php echo mc_cleanData($PM->sandboxserver); ?>" class="box" tabindex="<?php echo ++$tabIndex; ?>" />
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper">
  <div class="formLeft">
    <label><?php echo $msg_settings76.' '.$PM->display; ?>:</label>
   <?php echo $msg_script5; ?> <input type="radio" tabindex="<?php echo ++$tabIndex; ?>" name="status" value="yes"<?php echo ($PM->status=='yes' ? ' checked="checked"' : ''); ?> /> <?php echo $msg_script6; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="status" value="no"<?php echo ($PM->status=='no' ? ' checked="checked"' : ''); ?> />
  </div>
  <div class="formRight">
  </div>
  <br class="clear" />
</div>

<p style="text-align:center;padding:20px 0 20px 0">
 <input type="hidden" name="process" value="yes" />
 <input type="hidden" name="area" value="<?php echo $_GET['conf']; ?>" />
 <input class="formbutton" type="submit" value="<?php echo mc_cleanDataEnt($msg_settings42); ?>" title="<?php echo mc_cleanDataEnt($msg_settings42); ?>" />
 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input class="formbutton2" type="button" onclick="window.location='?p=payment-methods'" value="<?php echo mc_cleanDataEnt($msg_script11); ?>" title="<?php echo mc_cleanDataEnt($msg_script11); ?>" />
</p>
<?php
} else {
?>
<div><span class="gatewayLoadErr"><?php echo $gateway_errors['either']; ?><br /><br />
&#8226; <a href="http://php.net/manual/en/function.hash-hmac.php" onclick="window.open(this);return false">hash_hmac</a> (<?php echo (function_exists('hash_hmac') ? 'OK' : 'ERROR - NOT AVAILABLE'); ?>)<br /><br />
&#8226; <a href="http://php.net/manual/en/book.mhash.php" onclick="window.open(this);return false">Mhash Functions</a> (<?php echo (function_exists('mhash') ? 'OK' : 'ERROR - NOT AVAILABLE'); ?>)<br />
<br /><?php echo $gateway_errors['refresh2']; ?></span></div>
<?php
}
?>