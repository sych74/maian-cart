<?php
if (!defined('PARENT') || !in_array($_GET['conf'],array_keys($mcSystemPaymentMethods))) {
  die('Invalid parameter: "conf='.mc_cleanDataEnt($_GET['conf']).'" is not supported');
}
$skipStatusDisplay = array('cancelled');
$PM = mysql_fetch_object(mysql_query("SELECT * FROM ".DB_PREFIX."methods WHERE `method` = '{$_GET['conf']}' LIMIT 1")) 
      or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
// Parameters..
$params = array();
$q      = mysql_query("SELECT * FROM `".DB_PREFIX."methods_params` WHERE `method` = '{$_GET['conf']}'");
while ($M = mysql_fetch_object($q)) {
  $params[$M->param] = $M->value;
}
?>
<div class="fieldHeadWrapper">
  <p><?php echo $PM->display; ?></p>
</div>
<?php
if (function_exists('curl_init')) {
?>
<div class="formFieldWrapper">
  <div class="formLeft">
    <label><?php echo $msg_settings15; ?>: <?php echo mc_displayHelpTip($msg_javascript13,'RIGHT'); ?></label>
    <input type="text" name="params[email]" value="<?php echo mc_cleanData($params['email']); ?>" class="box" tabindex="<?php echo ++$tabIndex; ?>" /> 
  </div>
  <div class="formRight">
    <label><?php echo $msg_settings17; ?>: <?php echo mc_displayHelpTip($msg_javascript15); ?></label>
    <input type="text" name="params[pagestyle]" value="<?php echo mc_cleanData($params['pagestyle']); ?>" class="box" tabindex="<?php echo ++$tabIndex; ?>" />
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper">
 <label><?php echo showBBCodeLink(false,'info','pm').$msg_settings68; ?>: <?php echo mc_displayHelpTip($msg_javascript67,'RIGHT'); ?></label>
 <textarea rows="5" cols="30" name="info" id="info" class="textarea" tabindex="<?php echo ++$tabIndex; ?>"><?php echo mc_cleanDataEnt($PM->info); ?></textarea>
</div>

<?php
// Payment statuses..
include(PATH.'templates/catalogue/payment-methods/statuses.php');
?>

<div class="formFieldWrapper">
 <label><?php echo $msg_settings235; ?>: <?php echo mc_displayHelpTip($msg_javascript457,'RIGHT'); ?></label>
 <input type="text" name="redirect" class="box" value="<?php echo mc_cleanDataEnt($PM->redirect); ?>" tabindex="<?php echo ++$tabIndex; ?>" />
</div>

<div class="formFieldWrapper">
  <div class="formLeft">
    <label><?php echo $msg_settings79; ?>: <?php echo mc_displayHelpTip($msg_javascript503,'RIGHT'); ?></label>
    <input type="text" name="liveserver" value="<?php echo mc_cleanData($PM->liveserver); ?>" class="box" tabindex="<?php echo ++$tabIndex; ?>" /> 
  </div>
  <div class="formRight">
    <label><?php echo $msg_settings80; ?>: <?php echo mc_displayHelpTip($msg_javascript504); ?></label>
    <input type="text" name="sandboxserver" value="<?php echo mc_cleanData($PM->sandboxserver); ?>" class="box" tabindex="<?php echo ++$tabIndex; ?>" />
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper">
  <div class="formLeft">
    <label><?php echo $msg_settings78; ?>: <?php echo mc_displayHelpTip($msg_javascript223,'RIGHT'); ?></label>
    <input type="text" name="params[locale]" value="<?php echo mc_cleanData($params['locale']); ?>" class="box" style="width:30%" tabindex="<?php echo ++$tabIndex; ?>" /> 
  </div>
  <div class="formRight">
    <label><?php echo $msg_settings76.' '.$PM->display; ?>:</label>
   <?php echo $msg_script5; ?> <input type="radio" tabindex="<?php echo ++$tabIndex; ?>" name="status" value="yes"<?php echo ($PM->status=='yes' ? ' checked="checked"' : ''); ?> /> <?php echo $msg_script6; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="status" value="no"<?php echo ($PM->status=='no' ? ' checked="checked"' : ''); ?> />
  </div>
  <br class="clear" />
</div>

<p style="text-align:center;padding:20px 0 20px 0">
 <input type="hidden" name="process" value="yes" />
 <input type="hidden" name="area" value="<?php echo $_GET['conf']; ?>" />
 <input class="formbutton" type="submit" value="<?php echo mc_cleanDataEnt($msg_settings42); ?>" title="<?php echo mc_cleanDataEnt($msg_settings42); ?>" />
 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input class="formbutton2" type="button" onclick="window.location='?p=payment-methods'" value="<?php echo mc_cleanDataEnt($msg_script11); ?>" title="<?php echo mc_cleanDataEnt($msg_script11); ?>" />
</p>
<?php
} else {
?>
<div><span class="gatewayLoadErr"><?php echo $gateway_errors['curl']; ?><br /><br />&#8226; <a href="http://php.net/manual/en/book.curl.php" onclick="window.open(this);return false">CURL</a><br /><br /><?php echo $gateway_errors['refresh']; ?></span></div>
<?php
}
?>