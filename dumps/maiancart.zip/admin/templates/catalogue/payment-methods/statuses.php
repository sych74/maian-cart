<?php
$ops          = array(
 'completed'  => $callBack['completed'],
 'download'   => $callBack['download'],
 'virtual'    => $callBack['virtual'],
 'pending'    => $callBack['pending'],
 'cancelled'  => $callBack['cancelled'],
 'refunded'   => $callBack['refunded']
);
$defaults     = array(
 'completed'  => 'shipping',
 'download'   => 'completed',
 'virtual'    => 'completed',
 'pending'    => 'pending',
 'cancelled'  => 'cancelled',
 'refunded'   => 'refund'
);
$pS  = mc_loadDefaultStatuses();
$cS  = array();
$cuR = ($PM->statuses ? unserialize($PM->statuses) : $defaults);
// Get additional payment statuses..
$qS  = mysql_query("SELECT * FROM `".DB_PREFIX."paystatuses` 
       WHERE `pMethod` IN('all','{$_GET['conf']}')
       ORDER BY `pMethod`,`statname`
       ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
if (mysql_num_rows($qS)>0) {
  $cS['none'] = '- - - - - - - -';
  while ($ST = mysql_fetch_object($qS)) {
    $cS[$ST->id] = mc_cleanData($ST->statname);
  }
}
// What doesn`t apply to this gateway...
?>
<div class="formFieldWrapper">
 <label><?php echo $msg_paymethods27; ?>: <?php echo mc_displayHelpTip($msg_javascript537,'RIGHT'); ?></label>
 <?php
 foreach ($ops AS $sK => $V) {
 if (!in_array($sK,$skipStatusDisplay)) {
 ?>
 <div class="orderStatus">
  <div class="oSLeft">
  <select name="orderStatus[<?php echo $sK; ?>]">
  <?php
  foreach (array_merge($pS,$cS) AS $k => $v) {
  ?>
  <option value="<?php echo $k; ?>"<?php echo ($k!='none' && isset($cuR[$sK]) && $cuR[$sK]==$k ? ' selected="selected"' : ''); ?>><?php echo $v; ?></option>
  <?php
  }
  ?>
  </select>
  </div>
  <div class="oSRight">
  <?php echo $V; ?>
  </div>
  <br class="clear" />
 </div>
 <?php
 }
 }
 ?>
</div>