<?php
if (!defined('PARENT') || !in_array($_GET['conf'],array_keys($mcSystemPaymentMethods))) {
  die('Invalid parameter: "conf='.mc_cleanDataEnt($_GET['conf']).'" is not supported');
}
$skipStatusDisplay = array('refunded','pending','cancelled');
$PM = mysql_fetch_object(mysql_query("SELECT * FROM ".DB_PREFIX."methods WHERE `method` = '{$_GET['conf']}' LIMIT 1")) 
      or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
// Parameters..
$params = array();
$q      = mysql_query("SELECT * FROM `".DB_PREFIX."methods_params` WHERE `method` = '{$_GET['conf']}'");
while ($M = mysql_fetch_object($q)) {
  $params[$M->param] = $M->value;
}
?>
<div class="fieldHeadWrapper">
  <p><?php echo $PM->display; ?></p>
</div>
<?php
if (function_exists('curl_init') && function_exists('simplexml_load_string')) {
?>
<div class="formFieldWrapper">
  <div class="formLeft">
    <label><?php echo $msg_paymethods12; ?>: <?php echo mc_displayHelpTip($msg_javascript515,'RIGHT'); ?></label>
    <input type="text" name="params[customer-id]" value="<?php echo mc_cleanData($params['customer-id']); ?>" class="box" tabindex="<?php echo ++$tabIndex; ?>" />
  </div>
  <div class="formRight">
    <label><?php echo $msg_paymethods13; ?>: <?php echo mc_displayHelpTip($msg_javascript516); ?></label>
    <input type="password" name="params[username]" value="<?php echo mc_cleanData($params['username']); ?>" class="box" tabindex="<?php echo ++$tabIndex; ?>" />
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper">
 <label><?php echo showBBCodeLink(false,'info','pm').$msg_settings68; ?>: <?php echo mc_displayHelpTip($msg_javascript67,'RIGHT'); ?></label>
 <textarea rows="5" cols="30" name="info" id="info" class="textarea" tabindex="<?php echo ++$tabIndex; ?>"><?php echo mc_cleanDataEnt($PM->info); ?></textarea>
</div>

<?php
// Payment statuses..
include(PATH.'templates/catalogue/payment-methods/statuses.php');
?>

<div class="formFieldWrapper">
  <div class="formLeft">
   <label><?php echo $msg_settings235; ?>: <?php echo mc_displayHelpTip($msg_javascript457,'RIGHT'); ?></label>
   <input type="text" name="redirect" class="box" value="<?php echo mc_cleanDataEnt($PM->redirect); ?>" tabindex="<?php echo ++$tabIndex; ?>" />
  </div>
  <div class="formRight">
   <label><?php echo $msg_paymethods16; ?>: <?php echo mc_displayHelpTip($msg_javascript517,'LEFT'); ?></label>
   <input type="text" name="params[page-title]" value="<?php echo mc_cleanData($params['page-title']); ?>" class="box" tabindex="<?php echo ++$tabIndex; ?>" />
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper">
  <div class="formLeft">
    <label><?php echo $msg_paymethods17; ?>: <?php echo mc_displayHelpTip($msg_javascript518,'RIGHT'); ?></label>
    <input type="text" name="params[page-footer]" value="<?php echo mc_cleanData($params['page-footer']); ?>" class="box" tabindex="<?php echo ++$tabIndex; ?>" />
  </div>
  <div class="formRight">
   <label><?php echo $msg_paymethods18; ?>: <?php echo mc_displayHelpTip($msg_javascript519,'LEFT'); ?></label>
   <input type="text" name="params[page-desc]" value="<?php echo mc_cleanData($params['page-desc']); ?>" class="box" tabindex="<?php echo ++$tabIndex; ?>" />
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper">
  <div class="formLeft">
    <label><?php echo $msg_settings153; ?>: <?php echo mc_displayHelpTip($msg_javascript513,'RIGHT'); ?></label>
    <input type="text" name="params[company-logo]" value="<?php echo ($params['company-logo'] ? mc_cleanData($params['company-logo']) : ''); ?>" class="box" tabindex="<?php echo ++$tabIndex; ?>" />
  </div>
  <div class="formRight">
   <label><?php echo $msg_paymethods11; ?>: <?php echo mc_displayHelpTip($msg_javascript513,'LEFT'); ?></label>
   <input type="text" name="params[page-banner]" value="<?php echo ($params['page-banner'] ? mc_cleanData($params['page-banner']) : ''); ?>" class="box" tabindex="<?php echo ++$tabIndex; ?>" />
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper">
  <div class="formLeft">
   <label><?php echo $msg_paymethods14; ?>: <?php echo mc_displayHelpTip($msg_javascript520,'RIGHT'); ?></label>
   <input type="text" name="liveserver" value="<?php echo mc_cleanData($PM->liveserver); ?>" class="box" tabindex="<?php echo ++$tabIndex; ?>" /> 
  </div>
  <div class="formRight">
   <label><?php echo $msg_paymethods15; ?>: <?php echo mc_displayHelpTip($msg_javascript521,'LEFT'); ?></label>
   <input type="text" name="sandboxserver" value="<?php echo mc_cleanData($PM->sandboxserver); ?>" class="box" tabindex="<?php echo ++$tabIndex; ?>" /> 
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper">
 <div class="formLeft">
 <label><?php echo $msg_settings156; ?>: <?php echo mc_displayHelpTip($msg_javascript514,'RIGHT'); ?></label>
  <select name="params[language]">
  <?php
  foreach ($ewayLanguages AS $k => $v) {
  ?>
  <option value="<?php echo $k; ?>"<?php echo ($params['language']==$k ? ' selected="selected"' : ''); ?>><?php echo $v; ?></option>
  <?php
  }
  ?>
  </select>
 </div>
 <div class="formRight">
  <label><?php echo $msg_settings76.' '.$PM->display; ?>:</label>
  <?php echo $msg_script5; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="status" value="yes"<?php echo ($PM->status=='yes' ? ' checked="checked"' : ''); ?> /> <?php echo $msg_script6; ?> <input tabindex="<?php echo ++$tabIndex; ?>" type="radio" name="status" value="no"<?php echo ($PM->status=='no' ? ' checked="checked"' : ''); ?> />
 </div>
 <br class="clear" />
</div>

<p style="text-align:center;padding:20px 0 20px 0">
 <input type="hidden" name="process" value="yes" />
 <input type="hidden" name="area" value="<?php echo $_GET['conf']; ?>" />
 <input class="formbutton" type="submit" value="<?php echo mc_cleanDataEnt($msg_settings42); ?>" title="<?php echo mc_cleanDataEnt($msg_settings42); ?>" />
 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input class="formbutton2" type="button" onclick="window.location='?p=payment-methods'" value="<?php echo mc_cleanDataEnt($msg_script11); ?>" title="<?php echo mc_cleanDataEnt($msg_script11); ?>" />
</p>
<?php
} else {
?>
<div><span class="gatewayLoadErr"><?php echo $gateway_errors['curl']; ?><br /><br />
&#8226; <a href="http://php.net/manual/en/book.curl.php" onclick="window.open(this);return false">CURL</a> (<?php echo (function_exists('curl_init') ? 'OK' : 'ERROR - NOT AVAILABLE'); ?>)<br />
&#8226; <a href="http://php.net/manual/en/book.simplexml.php" onclick="window.open(this);return false">Simple XML</a> (<?php echo (function_exists('simplexml_load_string') ? 'OK' : 'ERROR - NOT AVAILABLE'); ?>)<br />
<br /><?php echo $gateway_errors['refresh']; ?></span></div>
<?php
}
?>
