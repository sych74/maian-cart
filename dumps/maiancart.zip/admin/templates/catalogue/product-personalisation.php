<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } 
if (isset($_GET['edit'])) {
  $EDIT  = mc_getTableData('personalisation','id',mc_digitSan($_GET['edit']));
}
?>
<div id="content">

<?php
if (isset($OK)) {
  echo actionCompleted($msg_personalisation15);
}
if (isset($OK2)) {
  echo actionCompleted($msg_personalisation16);
}
if (isset($OK3) && $cnt>0) {
  echo actionCompleted($msg_personalisation17);
}
?>

<?php echo $msg_personalisation; ?><br /><br />
<div class="prodTop">
  <?php
  $P = mc_getTableData('products','id',mc_digitSan($_GET['product']));
  ?>
  <p><span class="float"><?php echo mc_cleanData($P->pName); ?></span>
  <b><?php echo $msg_productpictures14; ?></b>: 
  <select onchange="if(this.value!= 0){location=this.options[this.selectedIndex].value}">
  <option value="0">- - - -</option>
  <option value="?p=product-pictures&amp;product=<?php echo mc_digitSan($_GET['product']); ?>"><?php echo $msg_productadd38; ?></option>
  <option value="?p=add-product&amp;edit=<?php echo mc_digitSan($_GET['product']); ?>"><?php echo $msg_productpictures15; ?></option>
  <option value="?p=add-product&amp;copyp=<?php echo mc_digitSan($_GET['product']); ?>"><?php echo $msg_productpictures16; ?></option>
  <option value="?p=product-attributes&amp;product=<?php echo mc_digitSan($_GET['product']); ?>"><?php echo $msg_productpictures17; ?></option>
  <option value="?p=product-related&amp;product=<?php echo mc_digitSan($_GET['product']); ?>"><?php echo $msg_productpictures18; ?></option>
  <?php
  if (PRODUCT_MP3_PREVIEWS) {
  ?>
  <option value="?p=product-mp3&amp;product=<?php echo mc_digitSan($_GET['product']); ?>"><?php echo $msg_productmanage19; ?></option>
  <?php
  }
  ?>
  </select>
  <br class="clear" />
  </p>
</div>
<?php
if ($P->pDownload=='no') {
?>
<form method="post" id="form" action="?p=product-personalisation&amp;product=<?php echo mc_digitSan($_GET['product']).(isset($EDIT->id) ? '&amp;edit='.$EDIT->id : ''); ?>">
<div class="fieldHeadWrapper">
  <p><?php echo (isset($EDIT->id) ? $msg_personalisation3 : $msg_personalisation2); ?>:</p>
</div>

<div class="formFieldWrapper">
  <div class="formLeft" style="width:60%">
    <label><?php echo $msg_personalisation5; ?>: <?php echo mc_displayHelpTip($msg_javascript298); ?></label>
    <input tabindex="2" type="text" name="persInstructions" value="<?php echo (isset($EDIT->persInstructions) ? mc_cleanDataEnt($EDIT->persInstructions) : ''); ?>" class="box" /><br /><br />
    
    <label><?php echo $msg_personalisation11; ?>: <?php echo mc_displayHelpTip($msg_javascript300); ?></label>
    <textarea tabindex="3" name="persOptions" rows="5" cols="20" style="height:85px"><?php echo (isset($EDIT->persOptions) ? mc_cleanDataEnt(str_replace('||',mc_defineNewline(),$EDIT->persOptions)) : ''); ?></textarea>
  </div>
  <div class="formRight" style="width:18%">
    <label><?php echo $msg_personalisation6; ?>: <?php echo mc_displayHelpTip($msg_javascript299,'LEFT'); ?></label>
    <input tabindex="4" type="text" name="maxChars" value="<?php echo (isset($EDIT->maxChars) ? mc_cleanData($EDIT->maxChars) : '0'); ?>" class="box" style="width:30%" /><br /><br />
    
    <label><?php echo $msg_personalisation8; ?>: <?php echo mc_displayHelpTip($msg_javascript287,'LEFT'); ?></label>
    <?php echo $msg_script5; ?> <input type="radio" tabindex="5" name="reqField" value="yes"<?php echo (isset($EDIT->reqField) && $EDIT->reqField=='yes' ? ' checked="checked"' : (!isset($EDIT->enable) ? ' checked="checked"' : '')); ?> /> <?php echo $msg_script6; ?> <input tabindex="5" type="radio" name="reqField" value="no"<?php echo (isset($EDIT->reqField) && $EDIT->reqField=='no' ? ' checked="checked"' : ''); ?> /><br /><br />
  
    <label><?php echo $msg_personalisation14; ?>: <?php echo mc_displayHelpTip($msg_javascript303,'LEFT'); ?></label> 
    <?php echo $msg_script5; ?> <input type="radio" tabindex="6" name="enabled" value="yes"<?php echo (isset($EDIT->enabled) && $EDIT->enabled=='yes' ? ' checked="checked"' : (!isset($EDIT->enable) ? ' checked="checked"' : '')); ?> /> <?php echo $msg_script6; ?> <input tabindex="6" type="radio" name="enabled" value="no"<?php echo (isset($EDIT->enabled) && $EDIT->enabled=='no' ? ' checked="checked"' : ''); ?> />
  </div>
  <div class="formRight" style="width:18%">
    <label><?php echo $msg_personalisation12; ?>: <?php echo mc_displayHelpTip($msg_javascript301,'LEFT'); ?></label>
    <input tabindex="7" type="text" name="persAddCost" value="<?php echo (isset($EDIT->persAddCost) ? mc_cleanData($EDIT->persAddCost) : '0.00'); ?>" class="box" style="width:30%" /> <br /><br />
    
    <label><?php echo $msg_personalisation9; ?>: <?php echo mc_displayHelpTip($msg_javascript272,'LEFT'); ?></label>
    <?php echo $msg_personalisation13; ?> <input type="radio" tabindex="8" name="boxType" value="input"<?php echo (isset($EDIT->boxType) && $EDIT->boxType=='input' ? ' checked="checked"' : (!isset($EDIT->boxType) ? ' checked="checked"' : '')); ?> /> <?php echo $msg_personalisation19; ?> <input tabindex="8" type="radio" name="boxType" value="textarea"<?php echo (isset($EDIT->boxType) && $EDIT->boxType=='textarea' ? ' checked="checked"' : ''); ?> /><br /><br />
  </div>
  <br class="clear" />
</div>

<p style="text-align:center;padding-top:20px">
 <input type="hidden" name="<?php echo (isset($EDIT->id) ? 'update' : 'process'); ?>" value="<?php echo (isset($EDIT->id) ? $EDIT->id : 'yes'); ?>" />
 <input class="formbutton" type="submit" value="<?php echo mc_cleanDataEnt((isset($EDIT->id) ? $msg_personalisation3 : $msg_personalisation2)); ?>" title="<?php echo mc_cleanDataEnt((isset($EDIT->id) ? $msg_personalisation3 : $msg_personalisation2)); ?>" /><?php echo (isset($EDIT->id) ? '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input class="formbutton2" type="button" onclick="window.location=\'?p=product-personalisation&amp;product='.mc_digitSan($_GET['product']).'\'" value="'.mc_cleanDataEnt($msg_script11).'" title="'.mc_cleanDataEnt($msg_script11).'" />' : ''); ?>
</p>
</form><br />

<div class="fieldHeadWrapper">
  <p><span class="float" id="loader"></span><?php echo $msg_personalisation7; ?>:</p>
</div>
<?php
if (mc_rowCount('personalisation WHERE productID = \''.mc_digitSan($_GET['product']).'\'')>0) {
?>
<script type="text/javascript">
//<![CDATA[
jQuery(document).ready(function() {
  jQuery("#sortable").sortable({
    update : function (data) {
      jQuery("#loader").load("index.php?p=product-personalisation&order=<?php echo mc_digitSan($_GET['product']); ?>&"+jQuery('#sortable').sortable('serialize'));
    }
  });
});
//]]>
</script>
<?php
}
?>
<div id="sortable">
<?php
$q_pe = mysql_query("SELECT * FROM ".DB_PREFIX."personalisation
        WHERE productID = '".mc_digitSan($_GET['product'])."'
        ORDER BY orderBy
        ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
if (mysql_num_rows($q_pe)>0) {
  while ($PRS = mysql_fetch_object($q_pe)) {
  $find     = array('{options}','{max}','{cost}','{enabled}','{required}','{boxtype}');
  $replace  = array(($PRS->persOptions!='' ? count(explode('||',$PRS->persOptions)) : '0'),
                    $PRS->maxChars,
                    mc_currencyFormat($PRS->persAddCost),
                    ($PRS->enabled=='yes' ? $msg_script5 : $msg_script6),
                    ($PRS->reqField=='yes' ? $msg_script5 : $msg_script6),
                    ($PRS->persOptions!='' ? 'N/A' : ($PRS->boxType=='input' ? $msg_personalisation13 : $msg_personalisation19))
              );
  ?>
  <div class="catWrapper" id="pers-<?php echo $PRS->id; ?>" style="cursor:move" title="<?php echo mc_cleanDataEnt($msg_cats20); ?>">
    <div class="catLeft" style="width:92%"><?php echo mc_cleanData($PRS->persInstructions); ?><span style="display:block;margin:5px;font-size:11px"><?php echo str_replace($find,$replace,$msg_personalisation18); ?></span></div>
    <div class="catRight" style="width:5%;text-align:center;padding:5px 0 3px 0;margin-right:0;background:#fff"><a href="?p=product-personalisation&amp;product=<?php echo mc_digitSan($_GET['product']); ?>&amp;edit=<?php echo $PRS->id; ?>"><img src="templates/images/edit.png" alt="<?php echo mc_cleanDataEnt($msg_script9); ?>" title="<?php echo mc_cleanDataEnt($msg_script9); ?>" /></a><?php echo ($uDel=='yes' ? ' <a href="?p=product-personalisation&amp;product='.mc_digitSan($_GET['product']).'&amp;del='.$PRS->id.'" onclick="return confirmMessage(\''.mc_cleanDataEnt($msg_javascript45).'\')"><img src="templates/images/delete.png" alt="'.mc_cleanDataEnt($msg_script10).'" title="'.mc_cleanDataEnt($msg_script10).'" /></a>' : ''); ?></div>
    <br class="clear" />
  </div>
  <?php
  }
} else {
?>
<span class="noData"><?php echo $msg_personalisation10; ?></span>
<?php
}
} else {
?>
<span class="noData"><?php echo $msg_personalisation20; ?></span>
<?php
}
?>
</div>

<p>&nbsp;</p>
<p>&nbsp;</p>
</div>
