<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } 
if (isset($_GET['edit'])) {
  $EDIT = mc_getTableData('giftcerts','id',mc_digitSan($_GET['edit']));
}
?>
<div id="content">

<?php
if (isset($OK)) {
  echo actionCompleted($msg_giftcerts10);
}
if (isset($OK2)) {
  echo actionCompleted($msg_giftcerts11);
}
if (isset($OK3) && $cnt>0) {
  echo actionCompleted($msg_giftcerts12);
}

?>

<?php echo $msg_giftcerts; ?><br /><br />

<form method="post" id="form" action="?p=gift<?php echo (isset($EDIT->id) ? '&amp;edit='.$EDIT->id : ''); ?>" enctype="multipart/form-data">
<div class="fieldHeadWrapper">
  <p><?php echo (isset($EDIT->id) ? $msg_giftcerts9 : $msg_giftcerts2); ?>:</p>
</div>

<div class="formFieldWrapper">
  <div class="formLeft" style="width:40%">
    <label><?php echo $msg_giftcerts3; ?>: <?php echo mc_displayHelpTip($msg_javascript549,'RIGHT'); ?></label>
    <input type="text" name="name" tabindex="<?php echo (++$tabIndex); ?>" maxlength="250" value="<?php echo (isset($EDIT->name) ? mc_cleanDataEnt($EDIT->name) : ''); ?>" class="box" /> 
  </div>
  <div class="formLeft" style="width:26%">  
    <label><?php echo $msg_giftcerts6; ?>: <?php echo mc_displayHelpTip($msg_javascript550); ?></label>
    <input type="file" name="image" tabindex="<?php echo (++$tabIndex); ?>" id="img" value="" class="box" />
  </div>
  <div class="formLeft" style="width:15%">  
    <label><?php echo $msg_giftcerts4; ?>: <?php echo mc_displayHelpTip($msg_javascript551); ?></label>
    <input type="text" name="value" tabindex="<?php echo (++$tabIndex); ?>" id="value" value="<?php echo (isset($EDIT->value) ? $EDIT->value : '1.00'); ?>" class="box" style="width:50%" />
  </div>
  <div class="formRight" style="width:15%">  
    <label><?php echo $msg_giftcerts5; ?>: <?php echo mc_displayHelpTip($msg_javascript552,'LEFT'); ?></label>
    <?php echo $msg_script5; ?> <input type="radio" tabindex="<?php echo (++$tabIndex); ?>" name="enabled" value="yes"<?php echo (isset($EDIT->enabled) && $EDIT->enabled=='yes' ? ' checked="checked"' : (!isset($EDIT->enabled) ? ' checked="checked"' : '')); ?> /> <?php echo $msg_script6; ?> <input tabindex="<?php echo (++$tabIndex); ?>" type="radio" name="enabled" value="no"<?php echo (isset($EDIT->enabled) && $EDIT->enabled=='no' ? ' checked="checked"' : ''); ?> />
  </div>
  <br class="clear" />
</div>

<p style="text-align:center;padding-top:20px">
 <input type="hidden" name="<?php echo (isset($EDIT->id) ? 'update' : 'process'); ?>" value="yes" />
 <?php
 // Existing image for edit..
 if (isset($EDIT->id)) {
 ?>
 <input type="hidden" name="curimage" value="<?php echo $EDIT->image; ?>" />
 <?php
 }
 ?>
 <input class="formbutton" type="submit" tabindex="10" value="<?php echo mc_cleanDataEnt((isset($EDIT->id) ? $msg_giftcerts9 : $msg_giftcerts2)); ?>" title="<?php echo mc_cleanDataEnt((isset($EDIT->id) ? $msg_giftcerts9 : $msg_giftcerts2)); ?>" /><?php echo (isset($EDIT->id) ? '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input class="formbutton2" type="button" onclick="window.location=\'?p=gift\'" value="'.mc_cleanDataEnt($msg_script11).'" title="'.mc_cleanDataEnt($msg_script11).'" />' : ''); ?>
</p>
</form><br />

<div class="fieldHeadWrapper">
  <p><?php echo $msg_giftcerts8; ?>:</p>
</div>

<p id="loader" style="display:none"></p>
<?php
if (mc_rowCount('giftcerts')>0) {
?>
<script type="text/javascript"> 
//<![CDATA[
jQuery(document).ready(function() {
  jQuery("#sortable").sortable({
    update : function (data) {
      jQuery("#loader").load("index.php?p=gift&order=yes&"+jQuery('#sortable').sortable('serialize'));
    }
  });
});
//]]>
</script>
<?php
}
?>

<div id="sortable">
<?php
$q_certs = mysql_query("SELECT * FROM `".DB_PREFIX."giftcerts` ORDER BY `orderBy`") 
           or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
if (mysql_num_rows($q_certs)>0) {
  while ($GC = mysql_fetch_object($q_certs)) {
  $img = $SETTINGS->ifolder.'/'.PRODUCTS_FOLDER.'/'.($GC->image ? $GC->image : 'no-gift-cert.gif');
  $sum = mc_sumCount('giftcodes WHERE `giftID` = \''.$GC->id.'\' AND `active` = \'yes\'','value');
  ?>
  <div class="catWrapper" id="gcode-<?php echo $GC->id; ?>" style="cursor:move" title="<?php echo mc_cleanDataEnt($msg_giftcerts30); ?>">
    <div class="catLeft" style="width:20%"><img src="<?php echo $img; ?>" style="max-width:180px" alt="<?php echo mc_cleanDataEnt($GC->name); ?>" title="<?php echo mc_cleanDataEnt($GC->name); ?>" /></div> 
    <div class="catLeft" style="width:63%"><?php echo mc_cleanDataEnt($GC->name); ?>
	<span style="display:block;font-size:11px"><?php echo str_replace(array('{value}','{enabled}','{revenue}'),array(mc_currencyFormat($GC->value),($GC->enabled=='yes' ? $msg_script5 : $msg_script6),mc_currencyFormat(mc_formatPrice($sum,true))),$msg_giftcerts13); ?></span>
	</div> 
    <div class="catRight" style="width:12%;text-align:center;padding:5px 0 3px 0;background:#fff;float:right">
     <a href="?p=gift-report&amp;code=<?php echo $GC->id; ?>"><img src="templates/images/stats.png" alt="<?php echo mc_cleanDataEnt($msg_script12); ?>" title="<?php echo mc_cleanDataEnt($msg_script12); ?>" /></a>&nbsp;&nbsp;
     <a href="?p=gift&amp;edit=<?php echo $GC->id; ?>"><img src="templates/images/edit.png" alt="<?php echo mc_cleanDataEnt($msg_script9); ?>" title="<?php echo mc_cleanDataEnt($msg_script9); ?>" /></a>&nbsp;&nbsp;
     <?php
     if ($uDel=='yes') {
     ?>
     <a href="?p=gift&amp;del=<?php echo $GC->id; ?>" onclick="return confirmMessage('<?php echo mc_cleanDataEnt($msg_javascript45); ?>')"><img src="templates/images/delete.png" alt="<?php echo mc_cleanDataEnt($msg_script10); ?>" title="<?php echo mc_cleanDataEnt($msg_script10); ?>" /></a>
     <?php
     }
     ?>
    </div>
    <br class="clear" />
  </div>
  <?php
  }
} else {
?>
<span class="noData"><?php echo $msg_giftcerts14; ?></span>
<?php
}
?>
</div>

<p>&nbsp;</p>
<p>&nbsp;</p>
</div>
