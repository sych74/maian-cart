<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } 
if (isset($_GET['edit']) && $_GET['edit']!='batch-mode') {
  $EDIT          = mc_getTableData('products','id',mc_digitSan($_GET['edit']));
  $CTS           = getProductCategories(mc_digitSan($_GET['edit']),false);
  $BRD           = explode(',',$EDIT->pBrands);
}
if (isset($_GET['edit']) && $_GET['edit']=='batch-mode' && isset($_POST['productIDs'])) {
  define('BATCH_EDIT_MODE',1);
  if (isset($_POST['productsUpdated'])) {
    $batchCount = $_POST['productsUpdated'];
  } else {
    $batchCount = count($_POST['productIDs']);
  }
}
if (isset($_GET['copyp'])) {
  $EDIT = new stdclass();
  $COPY = mc_getTableData('products','id',mc_digitSan($_GET['copyp']));
  $CTS  = getProductCategories(mc_digitSan($_GET['copyp']),false);
  $BRD  = explode(',',$COPY->pBrands);
  foreach ($COPY AS $key => $value) {
    $EDIT->$key = $value;
  }
}
$tabIndex = 0;
?>
<div id="content">
<script type="text/javascript">
//<![CDATA[
function checkForm() {
  if (jQuery('#pName').val()=='') {
    alert('<?php echo mc_cleanDataEnt($msg_javascript384); ?>');
    jQuery('#pName').focus();
    return false;
  }
}
function codeChecker() {
  // Check product code..
  if (jQuery('#pCode').val()!='') {
    jQuery(document).ready(function() {
      jQuery.ajax({
        url: 'index.php',
        data: 'p=add-product&codeCheck='+jQuery('#pCode').val()<?php echo (isset($_GET['edit']) ? '+\'&edit='.$_GET['edit'].'\'' : ''); ?>,
        dataType: 'html',
        success: function (data) {
          if (data=='exists') {
            jQuery('#codeExists').html('<img src="templates/images/code-exists.png" alt="<?php echo mc_cleanDataEnt($msg_javascript431); ?>" title="<?php echo mc_cleanDataEnt($msg_javascript431); ?>" />');
          } else {
            jQuery('#codeExists').html('<img src="templates/images/code-ok.png" alt="<?php echo mc_cleanDataEnt($msg_javascript432); ?>" title="<?php echo mc_cleanDataEnt($msg_javascript432); ?>" />');
          }
        }
      });
    });
  }
  return false;
}
//]]>
</script>
<?php
define('CALBOX', 'pOfferExpiry');
include(PATH.'templates/date-picker.php');
if (isset($OK)) {
  echo actionCompletedProducts($msg_productadd13,$newProductID);
}
if (isset($OK2)) {
  echo actionCompletedProducts($msg_productadd21,mc_digitSan($_GET['edit']));
}
if (isset($OK3)) {
  unset($_SESSION['batchFieldPrefs']);
  echo actionCompleted(str_replace(array('{count}','{fields}'),array($_POST['productsUpdated'],$fields),$msg_productadd80));
}
?>

<?php 
if (defined('BATCH_EDIT_MODE')) { 
echo str_replace('{count}',$batchCount,$msg_productmanage53).'<br /><br />';
} else {
echo (isset($EDIT->id) && !isset($_GET['copyp']) ? $msg_productadd16 : (isset($_GET['copyp']) ? $msg_productadd25 : $msg_productadd)); ?><br /><br /><?php echo (!isset($EDIT->id) && !isset($_GET['copyp']) && pagePermissions('product-import',false)=='yes' ? '<a class="addProduct" href="?p=product-import" title="'.mc_cleanDataEnt($msg_productadd3).'"><b>'.$msg_productadd3.'</b></a><br /><br />' : ''); 
}
if (isset($_GET['edit']) && $_GET['edit']!='batch-mode') {
// Clear batch session..
if (isset($_SESSION['batchFieldPrefs'])) {
  unset($_SESSION['batchFieldPrefs']);
}
?>
<div class="prodTop">
  <?php
  $P = mc_getTableData('products','id',mc_digitSan($_GET['edit']));
  ?>
  <p><span class="float"><?php echo mc_cleanData($P->pName); ?></span>
  <b><?php echo $msg_productadd46; ?></b>: 
  <select onchange="if(this.value!= 0){location=this.options[this.selectedIndex].value}">
  <option value="0">- - - -</option>
  <option value="?p=product-pictures&amp;product=<?php echo mc_digitSan($_GET['edit']); ?>"><?php echo $msg_productadd38; ?></option>
  <option value="?p=add-product&amp;copyp=<?php echo mc_digitSan($_GET['edit']); ?>"><?php echo $msg_productpictures16; ?></option>
  <option value="?p=product-attributes&amp;product=<?php echo mc_digitSan($_GET['edit']); ?>"><?php echo $msg_productpictures17; ?></option>
  <option value="?p=product-related&amp;product=<?php echo mc_digitSan($_GET['edit']); ?>"><?php echo $msg_productpictures18; ?></option>
  <?php
  if (PRODUCT_MP3_PREVIEWS) {
  ?>
  <option value="?p=product-mp3&amp;product=<?php echo mc_digitSan($_GET['edit']); ?>"><?php echo $msg_productmanage19; ?></option>
  <?php
  }
  if ($P->pDownload=='no') {
  ?>
  <option value="?p=product-personalisation&amp;product=<?php echo mc_digitSan($_GET['edit']); ?>"><?php echo $msg_productmanage20; ?></option>
  <?php
  }
  ?>
  </select>
  <br class="clear" />
  </p>
</div>
<?php
}
if (isset($_GET['copyp'])) {
?>
<div class="prodTop">
  <?php
  $P = mc_getTableData('products','id',mc_digitSan($_GET['copyp']));
  ?>
  <p><span class="float"><?php echo mc_cleanData($P->pName); ?></span>
  <b><?php echo $msg_productpictures14; ?></b>: 
  <select onchange="if(this.value!= 0){location=this.options[this.selectedIndex].value}">
  <option value="0">- - - -</option>
  <option value="?p=product-pictures&amp;product=<?php echo mc_digitSan($_GET['copyp']); ?>"><?php echo $msg_productadd38; ?></option>
  <option value="?p=add-product&amp;edit=<?php echo mc_digitSan($_GET['copyp']); ?>"><?php echo $msg_productpictures15; ?></option>
  <option value="?p=product-attributes&amp;product=<?php echo mc_digitSan($_GET['copyp']); ?>"><?php echo $msg_productpictures17; ?></option>
  <option value="?p=product-related&amp;product=<?php echo mc_digitSan($_GET['copyp']); ?>"><?php echo $msg_productpictures18; ?></option>
  <?php
  if (PRODUCT_MP3_PREVIEWS) {
  ?>
  <option value="?p=product-mp3&amp;product=<?php echo mc_digitSan($_GET['copyp']); ?>"><?php echo $msg_productmanage19; ?></option>
  <?php
  }
  ?>
  <option value="?p=product-personalisation&amp;product=<?php echo mc_digitSan($_GET['copyp']); ?>"><?php echo $msg_productmanage20; ?></option>
  </select>
  <br class="clear" />
  </p>
</div>
<?php
}
?>


<form method="post" id="form" action="?p=add-product<?php echo (isset($EDIT->id) && !isset($_GET['copyp']) ? '&amp;edit='.$EDIT->id : '').(defined('BATCH_EDIT_MODE') ? '&amp;edit=batch-mode' : '').(isset($_GET['copyp']) ? '&amp;copyp='.mc_digitSan($_GET['copyp']) : ''); ?>"<?php echo (!defined('BATCH_EDIT_MODE') ? ' enctype="multipart/form-data" ' : ' '); ?>onsubmit="return checkForm()">
<?php
if (!defined('BATCH_EDIT_MODE')) {
?>
<div class="fieldHeadWrapper">
  <p><?php echo (isset($EDIT->id) && !isset($_GET['copyp']) ? $msg_productadd15 : $msg_productadd2); ?>:</p>
</div>
<div class="formFieldWrapper">
  <div class="formLeft" style="width:98%">
    <label><?php echo ($SETTINGS->isbnAPI ? $msg_productadd73 : $msg_productadd4); ?>: <?php echo mc_displayHelpTip(($SETTINGS->isbnAPI ? $msg_javascript420 : $msg_javascript69),'RIGHT'); ?></label>
    <input type="text" maxlength="250" onkeyup="slugSuggestions(this.value)" name="pName" id="pName" value="<?php echo (isset($EDIT->pName) ? mc_cleanDataEnt($EDIT->pName) : ''); ?>" class="box" tabindex="<?php echo (++$tabIndex); ?>" /> <?php echo ($SETTINGS->isbnAPI ? ' <a class="isbn" href="#" onclick="isbnLookup();return false" title="'.mc_cleanDataEnt($msg_productadd72).'">'.$msg_productadd72.'</a>' : ''); ?>
  </div>
  <br class="clear" />
</div>  
<?php
}
?>
<div class="fieldHeadWrapper">
  <p><?php echo $msg_productadd61; ?>:</p>
</div>

<div class="formFieldWrapper">
  <div class="formLeft" style="width:50%;margin-right:20px">  
    <label><?php echo hideShowBatchOperation('checkGrid','pCat').$msg_productadd5; ?>: <?php echo mc_displayHelpTip($msg_javascript70,'RIGHT'); ?></label>
    <div class="categoryAddBoxes" style="width:99%<?php echo (isset($_SESSION['batchFieldPrefs']) && in_array('pCat',$_SESSION['batchFieldPrefs']) ? ';display:none' : ''); ?>" id="checkGrid">
    <input type="checkbox" id="all" name="log" value="all" onclick="toggleCheckBoxesID(this.checked,'checkGrid')" tabindex="<?php echo (++$tabIndex); ?>" /> <b><?php echo $msg_productadd35; ?></b> (<a href="#" title="<?php echo mc_cleanDataEnt($msg_productadd74); ?>" onclick="parentsOnly();return false"><?php echo $msg_productadd74; ?></a>)<br />
    <?php
    $q_cats = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
              WHERE catLevel = '1'
              AND childOf    = '0'
              ".(SHOW_DISABLED_CATS_ADD_PRODUCT ? 'AND enCat = \'yes\'' : '')."
              ORDER BY catname
              ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($CATS = mysql_fetch_object($q_cats)) {
    ?>
    <p id="cat_<?php echo $CATS->id; ?>"><input id="pnt_<?php echo $CATS->id; ?>" onclick="if(this.checked){selectChildren('cat_<?php echo $CATS->id; ?>','on')}else{selectChildren('cat_<?php echo $CATS->id; ?>','off')}" tabindex="<?php echo (++$tabIndex); ?>" type="checkbox" name="pCat[]" value="<?php echo $CATS->id; ?>"<?php echo (isset($CTS) && !empty($CTS) && in_array($CATS->id,$CTS) ? ' checked="checked"' : ''); ?> /> <?php echo mc_cleanDataEnt($CATS->catname); ?><br />
    <?php
    $q_children = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
                  WHERE catLevel = '2'
                  AND childOf    = '{$CATS->id}'
                  AND enCat      = 'yes'
                  ".(SHOW_DISABLED_CATS_ADD_PRODUCT ? 'AND enCat = \'yes\'' : '')."
                  ORDER BY catname
                  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($CHILDREN = mysql_fetch_object($q_children)) {
    ?>
    <span id="child_<?php echo $CHILDREN->id; ?>">
    &nbsp;&nbsp;<input id="cld_<?php echo $CHILDREN->id; ?>" onclick="if(this.checked){selectChildren('child_<?php echo $CHILDREN->id; ?>','on')}else{selectChildren('child_<?php echo $CHILDREN->id; ?>','off')}" tabindex="<?php echo (++$tabIndex); ?>" type="checkbox" name="pCat[]" value="<?php echo $CHILDREN->id; ?>"<?php echo (isset($CTS) && !empty($CTS) && in_array($CHILDREN->id,$CTS) ? ' checked="checked"' : ''); ?> /> <?php echo mc_cleanDataEnt($CHILDREN->catname); ?><br />
    <?php
    $q_infants = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
                  WHERE catLevel = '3'
                  AND childOf    = '{$CHILDREN->id}'
                  AND enCat      = 'yes'
                  ".(SHOW_DISABLED_CATS_ADD_PRODUCT ? 'AND enCat = \'yes\'' : '')."
                  ORDER BY catname
                  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($INFANTS = mysql_fetch_object($q_infants)) {
    ?>
    &nbsp;&nbsp;&nbsp;&nbsp;<input id="inf_<?php echo $INFANTS->id; ?>" tabindex="<?php echo (++$tabIndex); ?>" type="checkbox" name="pCat[]" value="<?php echo $INFANTS->id; ?>"<?php echo (isset($CTS) && !empty($CTS) && in_array($INFANTS->id,$CTS) ? ' checked="checked"' : ''); ?> /> <?php echo mc_cleanDataEnt($INFANTS->catname); ?><br />
    <?php
    }
    ?>
    </span>
    <?php
    }
    ?>
    </p>
    <?php
    }
    ?>
    </div>
  </div>
  <div class="formRight" style="width:47%">
    <label><?php echo hideShowBatchOperation('batch_field_1','pBrand').$msg_productadd32; ?>: <?php echo mc_displayHelpTip($msg_javascript162); ?></label>
    <div class="categoryAddBoxes" id="batch_field_1"<?php echo (isset($_SESSION['batchFieldPrefs']) && in_array('pBrand',$_SESSION['batchFieldPrefs']) ? ' style="display:none"' : ''); ?>>
    <input type="checkbox" name="log2" value="all" onclick="toggleCheckBoxesID(this.checked,'batch_field_1')" tabindex="<?php echo (++$tabIndex); ?>" /> <b><?php echo $msg_productadd50; ?></b><br />
    <?php
    $q_mans = mysql_query("SELECT *,".DB_PREFIX."brands.id AS bid FROM ".DB_PREFIX."brands
              LEFT JOIN ".DB_PREFIX."categories
              ON ".DB_PREFIX."brands.bCat = ".DB_PREFIX."categories.id
              WHERE enBrand               = 'yes'
              ORDER BY catname
              ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($BRAND = mysql_fetch_object($q_mans)) {
    $parents = '';
	if ($BRAND->bCat=='all') {
	  $parents = '';
	} else {
      switch ($BRAND->catLevel) {
        case '2':
        $CAT      = mc_getTableData('categories','id',$BRAND->childOf);
        $parents  = $CAT->catname.'/';
        break;
        case '3':
        $CAT      = mc_getTableData('categories','id',$BRAND->childOf);
        $CAT2     = mc_getTableData('categories','id',$CAT->childOf);
        $parents  = $CAT2->catname.'/'.$CAT->catname.'/';
        break;
      }
	}
    ?>
    <input tabindex="<?php echo (++$tabIndex); ?>" type="checkbox" name="pBrand[]" value="<?php echo $BRAND->bid; ?>"<?php echo (isset($BRD) && !empty($BRD) && in_array($BRAND->bid,$BRD) ? ' checked="checked"' : ''); ?> /> <?php echo mc_cleanDataEnt($parents.($BRAND->catname ? $BRAND->catname.'/' : '').$BRAND->name); ?><br />
    <?php
    }
    ?>
    </div>
  </div>
  <br class="clear" />
</div>

<?php
if (!defined('BATCH_EDIT_MODE')) {
?>
<div class="fieldHeadWrapper">
  <p><?php echo $msg_productadd65; ?>:</p>
</div>

<div class="formFieldWrapper">
  <label><?php echo $msg_productadd64; ?>: <a href="#" onclick="if(jQuery('#desc').val()!=''){jQuery('#short_desc').val(jQuery('#desc').val())}return false;" title="<?php echo mc_cleanDataEnt($msg_productadd71); ?>" class="a_normal"><?php echo $msg_productadd71; ?></a> <?php echo mc_displayHelpTip($msg_javascript386,'RIGHT'); ?></label>
  <textarea class="shortarea" rows="5" cols="30" id="short_desc" name="pShortDescription" tabindex="<?php echo (++$tabIndex); ?>"><?php echo (isset($EDIT->pShortDescription) ? mc_cleanDataEnt(mc_cleanData($EDIT->pShortDescription)) : ''); ?></textarea>
  <br class="clear" />
</div>

<div class="formFieldWrapper">
  <label><?php echo showBBCodeLink(false,'desc','add').$msg_productadd6; ?>: <a href="#" onclick="if(jQuery('#short_desc').val()!=''){jQuery('#desc').val(jQuery('#short_desc').val())}return false;" title="<?php echo mc_cleanDataEnt($msg_productadd70); ?>" class="a_normal"><?php echo $msg_productadd70; ?></a> <?php echo mc_displayHelpTip($msg_javascript71,'RIGHT'); ?></label>
  <textarea rows="5" cols="30" class="tarea" id="desc" name="pDescription" tabindex="<?php echo (++$tabIndex); ?>"><?php echo (isset($EDIT->pDescription) ? mc_cleanDataEnt(mc_cleanData($EDIT->pDescription)) : ''); ?></textarea>
  <br class="clear" />
</div>

<div class="fieldHeadWrapper">
  <p><?php echo $msg_productadd63; ?>:</p>
</div>

<div class="formFieldWrapper">
  <label><?php echo $msg_productadd75; ?>: <a href="#" onclick="if(jQuery('#pName').val()!=''){jQuery('#pTitle').val(jQuery('#pName').val())}return false;" title="<?php echo mc_cleanDataEnt($msg_productadd76); ?>" class="a_normal"><?php echo $msg_productadd76; ?></a> <?php echo mc_displayHelpTip($msg_javascript449,'RIGHT'); ?></label>
  <input class="box" type="text" maxlength="250" id="pTitle" name="pTitle" tabindex="<?php echo (++$tabIndex); ?>" value="<?php echo (isset($EDIT->pTitle) ? mc_cleanDataEnt($EDIT->pTitle) : ''); ?>" />
  <br class="clear" />
</div>

<div class="formFieldWrapper">
  <label><?php echo $msg_productadd18; ?>: <?php echo mc_displayHelpTip($msg_javascript78,'RIGHT'); ?></label>
  <input class="box" type="text" id="keys" name="pMetaKeys" tabindex="<?php echo (++$tabIndex); ?>" value="<?php echo (isset($EDIT->pMetaKeys) ? mc_cleanDataEnt($EDIT->pMetaKeys) : ''); ?>" />
  <br class="clear" />
</div>

<div class="formFieldWrapper">
  <label><?php echo $msg_productadd19; ?>: <?php echo mc_displayHelpTip($msg_javascript79,'RIGHT'); ?></label>
  <input class="box" type="text" id="mdesc" name="pMetaDesc" tabindex="<?php echo (++$tabIndex); ?>" value="<?php echo (isset($EDIT->pMetaDesc) ? mc_cleanDataEnt($EDIT->pMetaDesc) : ''); ?>" />
  <br class="clear" />
</div>

<div class="formFieldWrapper">
  <label><?php echo $msg_newpages31; ?>: <?php echo mc_displayHelpTip($msg_javascript472,'RIGHT'); ?></label>
  <input type="text" name="rwslug" id="rwslug" onkeyup="slugCleaner()" tabindex="<?php echo (++$tabIndex); ?>" maxlength="250" value="<?php echo (isset($EDIT->rwslug) ? mc_cleanDataEnt($EDIT->rwslug) : ''); ?>" class="box" /> 
  <br class="clear" />
</div>

<div class="formFieldWrapper">
  <label><?php echo $msg_productadd11; ?>: <a href="#" onclick="if(jQuery('#keys').val()!=''){jQuery('#tags').val(jQuery('#keys').val())}return false;" title="<?php echo mc_cleanDataEnt($msg_productadd34); ?>" class="a_normal"><?php echo $msg_productadd34; ?></a> | <a href="#" onclick="if(jQuery('#mdesc').val()!=''){createTagsFromField('mdesc')}return false;" title="<?php echo mc_cleanDataEnt($msg_productadd37); ?>" class="a_normal"><?php echo $msg_productadd37; ?></a> | <a href="#" onclick="if(jQuery('#desc').val()!=''){createTagsFromField('desc')}return false" title="<?php echo mc_cleanDataEnt($msg_productadd36); ?>" class="a_normal"><?php echo $msg_productadd36; ?></a> <?php echo mc_displayHelpTip($msg_javascript76,'LEFT'); ?></label>
  <textarea rows="5" cols="30" id="tags" name="pTags" style="height:80px" tabindex="<?php echo (++$tabIndex); ?>"><?php echo (isset($EDIT->pTags) ? mc_cleanDataEnt($EDIT->pTags) : ''); ?></textarea>
  <br class="clear" />
</div>
<?php
}
if (!defined('BATCH_EDIT_MODE')) {
?>
<div class="fieldHeadWrapper">
  <p><?php echo $msg_productadd55; ?>:</p>
</div>

<div class="formFieldWrapper">
  <div class="formLeft" style="width:25%">  
    <label><?php echo $msg_productadd8; ?>: <?php echo mc_displayHelpTip($msg_javascript72,'RIGHT'); ?></label>
    <?php echo $msg_script5; ?> <input onclick="if(this.checked){jQuery('#loadPers').hide()}" type="radio" tabindex="<?php echo (++$tabIndex); ?>" name="pDownload" value="yes"<?php echo (isset($EDIT->pDownload) && $EDIT->pDownload=='yes' ? ' checked="checked"' : (!isset($EDIT->pDownload) && IS_PRODUCT_DOWNLOAD=='yes' ? ' checked="checked"' : '')); ?> /> <?php echo $msg_script6; ?> <input onclick="if(this.checked){jQuery('#loadPers').show()}" tabindex="<?php echo (++$tabIndex); ?>" type="radio" name="pDownload" value="no"<?php echo (isset($EDIT->pDownload) && $EDIT->pDownload=='no' ? ' checked="checked"' : (!isset($EDIT->pDownload) && IS_PRODUCT_DOWNLOAD=='no' ? ' checked="checked"' : '')); ?> />
  </div>
  <div class="formLeft" style="width:59%">  
    <label><?php echo $msg_productadd9; ?>: (<a href="#" onclick="mc_loadLocalFiles();return false" title="<?php echo mc_cleanDataEnt($msg_productadd66); ?>"><?php echo $msg_productadd66; ?></a>) <?php echo mc_displayHelpTip($msg_javascript73); ?></label>
    <input type="text" id="pDownloadPath" name="pDownloadPath" tabindex="<?php echo (++$tabIndex); ?>" value="<?php echo (isset($EDIT->pDownloadPath) ? mc_cleanData($EDIT->pDownloadPath) : ''); ?>" class="box" />
  </div>
  <div class="formRight" style="width:15%">  
    <label><?php echo $msg_productadd10; ?>: <?php echo mc_displayHelpTip($msg_javascript74,'LEFT'); ?></label>
    <input type="text" name="pDownloadLimit" tabindex="<?php echo (++$tabIndex); ?>" value="<?php echo (isset($EDIT->pDownloadLimit) ? mc_cleanData($EDIT->pDownloadLimit) : '0'); ?>" class="box" style="width:50%" />
  </div>
  <br class="clear" />
  <div class="localFile" id="localFile" style="display:none">
   <p class="fileError" id="fileError" style="display:none"><span>(<a href="#" onclick="jQuery('#fileError').hide('slow');jQuery('#localFile').hide('slow');return false" title="<?php echo mc_cleanDataEnt($msg_script8); ?>"><?php echo $msg_script8; ?></a>)</span><?php echo $msg_productadd68; ?></p>
   <p id="fileList"><span>(<a href="#" onclick="jQuery('#localFile').hide('slow');return false" title="<?php echo mc_cleanDataEnt($msg_script8); ?>"><?php echo $msg_script8; ?></a>)</span><b><?php echo $msg_productadd67; ?></b>:
    <select name="pathlocator" id="pathlocator" onchange="if(this.value!='0'){jQuery('#pDownloadPath').val(this.value);jQuery('#localFile').hide('slow')}">
     <option>1</option>
    </select>
   </p>
  </div>
</div>

<div class="fieldHeadWrapper">
  <p><?php echo $msg_productadd56; ?>:</p>
</div>

<div class="formFieldWrapper">
  <div class="formLeft" style="width:74%"> 
    <label><?php echo $msg_productadd29; ?>: <?php echo mc_displayHelpTip($msg_javascript110,'RIGHT'); ?></label>
    <select name="pVideo" tabindex="<?php echo (++$tabIndex); ?>">
    <option value="0"><?php echo $msg_productadd30; ?></option>
    <?php
    $showvideo = opendir(REL_HTTP_PATH.'content/video/');
    while (false!==($read=readdir($showvideo))) {
      if (in_array(strtolower(strrchr($read, '.')),array('.flv'))) {
        echo '<option'.(isset($EDIT->pVideo) && $EDIT->pVideo==$read ? ' selected="selected"' : '').'>'.$read.'</option>'.mc_defineNewline();
      }
    }
    closedir($showvideo);
    ?>
    </select>
  </div>
  <div class="formLeft" style="width:25%">
    <label><?php echo $msg_productadd53; ?>: <?php echo mc_displayHelpTip($msg_javascript344,'LEFT'); ?></label>
    <?php echo $msg_script5; ?> <input type="radio" tabindex="<?php echo (++$tabIndex); ?>" name="enDisqus" value="yes"<?php echo (isset($EDIT->enDisqus) && $EDIT->enDisqus=='yes' ? ' checked="checked"' : ''); ?> /> <?php echo $msg_script6; ?> <input tabindex="<?php echo (++$tabIndex); ?>" type="radio" name="enDisqus" value="no"<?php echo (isset($EDIT->enDisqus) && $EDIT->enDisqus=='no' ? ' checked="checked"' : (!isset($EDIT->enDisqus) ? ' checked="checked"' : '')); ?> />
  </div>
  <br class="clear" />
</div>
<?php
} else {
?>
<div class="fieldHeadWrapper">
  <p><?php echo $msg_productmanage54; ?>:</p>
</div>

<div class="formFieldWrapper">
  <div class="formLeft" style="width:33%">  
    <label><?php echo hideShowBatchOperation('batch_field_2','pDownload').$msg_productadd8; ?>: <?php echo mc_displayHelpTip($msg_javascript72,'RIGHT'); ?></label>
    <div id="batch_field_2"<?php echo (isset($_SESSION['batchFieldPrefs']) && in_array('pDownload',$_SESSION['batchFieldPrefs']) ? ' style="display:none"' : ''); ?>><?php echo $msg_script5; ?> <input type="radio" tabindex="<?php echo (++$tabIndex); ?>" name="pDownload" value="yes"<?php echo (isset($EDIT->pDownload) && $EDIT->pDownload=='yes' ? ' checked="checked"' : ''); ?> /> <?php echo $msg_script6; ?> <input onclick="if(this.checked){jQuery('#loadPers').show()}" tabindex="<?php echo (++$tabIndex); ?>" type="radio" name="pDownload" value="no"<?php echo (isset($EDIT->pDownload) && $EDIT->pDownload=='no' ? ' checked="checked"' : (!isset($EDIT->pDownload) ? ' checked="checked"' : '')); ?> /></div>
  </div>
  <div class="formRight" style="width:33%">  
    <label><?php echo hideShowBatchOperation('batch_field_3','pDownloadLimit').$msg_productadd10; ?>: <?php echo mc_displayHelpTip($msg_javascript74); ?></label>
    <input id="batch_field_3" type="text" name="pDownloadLimit" tabindex="<?php echo (++$tabIndex); ?>" value="<?php echo (isset($EDIT->pDownloadLimit) ? mc_cleanData($EDIT->pDownloadLimit) : '0'); ?>" class="box" style="width:50%<?php echo (isset($_SESSION['batchFieldPrefs']) && in_array('pDownloadLimit',$_SESSION['batchFieldPrefs']) ? ';display:none' : ''); ?>" />
  </div>
  <div class="formLeft" style="width:33%">
    <label><?php echo hideShowBatchOperation('batch_field_4','enDisqus').$msg_productadd53; ?>: <?php echo mc_displayHelpTip($msg_javascript344,'LEFT'); ?></label>
    <div id="batch_field_4"<?php echo (isset($_SESSION['batchFieldPrefs']) && in_array('enDisqus',$_SESSION['batchFieldPrefs']) ? ' style="display:none"' : ''); ?>><?php echo $msg_script5; ?> <input type="radio" tabindex="<?php echo (++$tabIndex); ?>" name="enDisqus" value="yes"<?php echo (isset($EDIT->enDisqus) && $EDIT->enDisqus=='yes' ? ' checked="checked"' : ''); ?> /> <?php echo $msg_script6; ?> <input tabindex="<?php echo (++$tabIndex); ?>" type="radio" name="enDisqus" value="no"<?php echo (isset($EDIT->enDisqus) && $EDIT->enDisqus=='no' ? ' checked="checked"' : (!isset($EDIT->enDisqus) ? ' checked="checked"' : '')); ?> /></div>
  </div>
  <br class="clear" />
</div>

<?php
}
?>
<div class="fieldHeadWrapper">
  <p><?php echo $msg_productadd81; ?>:</p>
</div>

<div class="formFieldWrapper">
  <div class="formLeft" style="width:49%">  
    <label><?php echo hideShowBatchOperation('batch_field_5','countryRestrictions').$msg_productadd82; ?>: <?php echo mc_displayHelpTip($msg_javascript459,'RIGHT'); ?></label>
    <div class="categoryBoxes" id="batch_field_5"<?php echo (isset($_SESSION['batchFieldPrefs']) && in_array('countryRestrictions',$_SESSION['batchFieldPrefs']) ? ' style="display:none"' : ''); ?>>
    <?php
    $ctRest   = (isset($EDIT->countryRestrictions) && $EDIT->countryRestrictions ? unserialize($EDIT->countryRestrictions) : array());
    $q_ctry   = mysql_query("SELECT * FROM ".DB_PREFIX."countries 
                WHERE enCountry  = 'yes'
                ORDER BY cName
                ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($COUNTRY = mysql_fetch_object($q_ctry)) {
    ?>
    <input type="checkbox" name="countryRestrictions[]" value="<?php echo $COUNTRY->id; ?>"<?php echo (in_array($COUNTRY->id,$ctRest) ? ' checked="checked"' : ''); ?> /> <?php echo mc_cleanData($COUNTRY->cName); ?><br />
    <?php
    }
    ?>
    </div>
  </div>
  <div class="formRight" style="width:49%">
    <label><?php echo hideShowBatchOperation('batch_field_6','checkoutTextDisplay').$msg_productadd83; ?>: <?php echo mc_displayHelpTip($msg_javascript460,'LEFT'); ?></label>
    <input id="batch_field_6" type="text" name="checkoutTextDisplay" tabindex="<?php echo (++$tabIndex); ?>" value="<?php echo (isset($EDIT->checkoutTextDisplay) ? mc_cleanDataEnt($EDIT->checkoutTextDisplay) : ''); ?>" maxlength="100" class="box" style="width:70%<?php echo (isset($_SESSION['batchFieldPrefs']) && in_array('checkoutTextDisplay',$_SESSION['batchFieldPrefs']) ? ';display:none' : ''); ?>" /><br /><br />
    
    <div style="height:100%">
      <div style="width:48%;float:left">
       <label><?php echo hideShowBatchOperation('batch_field_7','minPurchaseQty').$msg_productadd79; ?>: <?php echo mc_displayHelpTip($msg_javascript454); ?></label>
       <input id="batch_field_7" type="text" name="minPurchaseQty" tabindex="<?php echo (++$tabIndex); ?>" value="<?php echo (isset($EDIT->minPurchaseQty) ? $EDIT->minPurchaseQty : '0'); ?>" class="box" style="width:60%<?php echo (isset($_SESSION['batchFieldPrefs']) && in_array('minPurchaseQty',$_SESSION['batchFieldPrefs']) ? ';display:none' : ''); ?>" />
      </div>
      <div style="width:48%;float:right">
       <label><?php echo hideShowBatchOperation('batch_field_19','maxPurchaseQty').$msg_productadd88; ?>: <?php echo mc_displayHelpTip($msg_javascript497,'LEFT'); ?></label>
       <input id="batch_field_19" type="text" name="maxPurchaseQty" tabindex="<?php echo (++$tabIndex); ?>" value="<?php echo (isset($EDIT->maxPurchaseQty) ? $EDIT->maxPurchaseQty : '0'); ?>" class="box" style="width:60%<?php echo (isset($_SESSION['batchFieldPrefs']) && in_array('maxPurchaseQty',$_SESSION['batchFieldPrefs']) ? ';display:none' : ''); ?>" />
      </div>
      <br class="clear" />
    </div>
  </div>
  <br class="clear" />
</div>

<div class="fieldHeadWrapper">
  <p><?php echo $msg_productadd57; ?>:</p>
</div>

<div class="formFieldWrapper">
  <div class="formLeft" style="width:24%">  
    <label><?php echo hideShowBatchOperation('batch_field_8','pStock').$msg_productadd43; ?>: <?php echo mc_displayHelpTip($msg_javascript83,'RIGHT'); ?></label>
    <input id="batch_field_8" type="text" name="pStock" tabindex="<?php echo (++$tabIndex); ?>" value="<?php echo (isset($EDIT->pStock) ? $EDIT->pStock : '1'); ?>" maxlength="7" class="box" style="width:60%<?php echo (isset($_SESSION['batchFieldPrefs']) && in_array('pStock',$_SESSION['batchFieldPrefs']) ? ';display:none' : ''); ?>" />
  </div>
  <div class="formLeft" style="width:24%">
    <label><?php echo hideShowBatchOperation('batch_field_9','pStockNotify').$msg_productadd20; ?>: <?php echo mc_displayHelpTip($msg_javascript80); ?></label>
    <input id="batch_field_9" type="text" name="pStockNotify" tabindex="<?php echo (++$tabIndex); ?>" value="<?php echo (isset($EDIT->pStockNotify) ? mc_cleanData($EDIT->pStockNotify) : '0'); ?>" class="box" style="width:60%<?php echo (isset($_SESSION['batchFieldPrefs']) && in_array('pStockNotify',$_SESSION['batchFieldPrefs']) ? ';display:none' : ''); ?>" /> 
  </div>
  <div class="formLeft" style="width:48%">  
    <label><?php echo hideShowBatchOperation('batch_field_18','pAvailableText').$msg_productadd85; ?>: <?php echo mc_displayHelpTip($msg_javascript473); ?></label>
    <input id="batch_field_18" type="text" name="pAvailableText" tabindex="<?php echo (++$tabIndex); ?>" maxlength="250" value="<?php echo (isset($EDIT->pAvailableText) ? mc_cleanData($EDIT->pAvailableText) : ''); ?>" class="box" style="width:80%<?php echo (isset($_SESSION['batchFieldPrefs']) && in_array('pAvailableText',$_SESSION['batchFieldPrefs']) ? ';display:none' : ''); ?>" /> 
  </div>
  <br class="clear" />
</div>

<div class="fieldHeadWrapper">
  <p><?php echo $msg_productadd86; ?>:</p>
</div>

<div class="formFieldWrapper">
  <div class="formLeft" style="width:33%">  
    <label><?php echo hideShowBatchOperation('batch_field_10','pVisits').$msg_productadd31; ?>: <?php echo mc_displayHelpTip($msg_javascript151); ?></label>
    <input id="batch_field_10" type="text" name="pVisits" tabindex="<?php echo (++$tabIndex); ?>" value="<?php echo (isset($EDIT->pVisits) ? mc_cleanData($EDIT->pVisits) : '0'); ?>" class="box" style="width:60%<?php echo (isset($_SESSION['batchFieldPrefs']) && in_array('pVisits',$_SESSION['batchFieldPrefs']) ? ';display:none' : ''); ?>" /> 
  </div>
  <div class="formRight" style="width:33%">
    <label><?php echo hideShowBatchOperation('pCode','pCode').$msg_productadd45; ?>: <?php echo mc_displayHelpTip($msg_javascript68); ?></label>
    <input type="text" name="pCode" onkeyup="codeChecker()" id="pCode" tabindex="<?php echo (++$tabIndex); ?>" value="<?php echo (isset($EDIT->pCode) ? mc_cleanDataEnt($EDIT->pCode) : ''); ?>" class="box" style="width:60%<?php echo (isset($_SESSION['batchFieldPrefs']) && in_array('pCode',$_SESSION['batchFieldPrefs']) ? ';display:none' : ''); ?>" /> <span id="codeExists"></span> 
  </div>
  <div class="formRight" style="width:33%">
    <label><?php echo hideShowBatchOperation('pCube','pCube').$msg_productadd87; ?>: <?php echo mc_displayHelpTip($msg_javascript481,'LEFT'); ?></label>
    <input type="text" name="pCube" id="pCube" tabindex="<?php echo (++$tabIndex); ?>" value="<?php echo (isset($EDIT->pCube) && $EDIT->pCube>0 ? mc_cleanDataEnt($EDIT->pCube) : ''); ?>" class="box" style="width:60%<?php echo (isset($_SESSION['batchFieldPrefs']) && in_array('pCube',$_SESSION['batchFieldPrefs']) ? ';display:none' : ''); ?>" /> 
  </div>
  <br class="clear" />
</div>

<div class="fieldHeadWrapper">
  <p><?php echo $msg_productadd58; ?>:</p>
</div>

<div class="formFieldWrapper">
  <div class="formLeft" style="width:25%">  
    <label><?php echo hideShowBatchOperation('batch_field_12','pWeight').$msg_productadd42; ?>: <?php echo mc_displayHelpTip($msg_javascript82,'RIGHT'); ?></label>
    <input id="batch_field_12" type="text" name="pWeight" tabindex="<?php echo (++$tabIndex); ?>" value="<?php echo (isset($EDIT->pWeight) ? $EDIT->pWeight : '0'); ?>" class="box" style="width:60%<?php echo (isset($_SESSION['batchFieldPrefs']) && in_array('pWeight',$_SESSION['batchFieldPrefs']) ? ';display:none' : ''); ?>" />
  </div>
  <div class="formLeft" style="width:25%">  
    <label><?php echo hideShowBatchOperation('batch_field_13','pPrice').$msg_productadd44; ?>: <?php echo mc_displayHelpTip($msg_javascript114); ?></label>
    <input id="batch_field_13" type="text" name="pPrice" tabindex="<?php echo (++$tabIndex); ?>" value="<?php echo (isset($EDIT->pPrice) ? mc_formatPrice($EDIT->pPrice) : '0.00'); ?>" class="box" style="width:60%<?php echo (isset($_SESSION['batchFieldPrefs']) && in_array('pPrice',$_SESSION['batchFieldPrefs']) ? ';display:none' : ''); ?>" />
  </div>
  <div class="formLeft" style="width:25%">  
    <label><?php echo hideShowBatchOperation('batch_field_14','pOffer').$msg_productadd39; ?>: <?php echo mc_displayHelpTip($msg_javascript216); ?></label>
    <input id="batch_field_14" type="text" name="pOffer" tabindex="<?php echo (++$tabIndex); ?>" value="<?php echo (isset($EDIT->pOffer) && $EDIT->pOffer>0 ? mc_formatPrice($EDIT->pOffer) : '0.00'); ?>" class="box" style="width:60%<?php echo (isset($_SESSION['batchFieldPrefs']) && in_array('pOffer',$_SESSION['batchFieldPrefs']) ? ';display:none' : ''); ?>" />
  </div>
  <div class="formRight" style="width:24%">
    <label><?php echo hideShowBatchOperation('pOfferExpiry','pOfferExpiry').$msg_productadd40; ?>: <?php echo mc_displayHelpTip($msg_javascript217,'LEFT'); ?></label>
    <input type="text" name="pOfferExpiry" tabindex="<?php echo (++$tabIndex); ?>" value="<?php echo (isset($EDIT->pOfferExpiry) && mc_checkValidDate($EDIT->pOfferExpiry)!='0000-00-00' ? mc_convertMySQLDate($EDIT->pOfferExpiry) : ''); ?>" class="box" id="pOfferExpiry" style="width:60%<?php echo (isset($_SESSION['batchFieldPrefs']) && in_array('pOfferExpiry',$_SESSION['batchFieldPrefs']) ? ';display:none' : ''); ?>" /> 
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper">
  <div class="formLeft" style="width:25%">
    <label><?php echo hideShowBatchOperation('batch_field_15','freeShipping').$msg_productadd54; ?>: <?php echo mc_displayHelpTip($msg_javascript352,'RIGHT'); ?></label>
    <div id="batch_field_15"<?php echo (isset($_SESSION['batchFieldPrefs']) && in_array('freeShipping',$_SESSION['batchFieldPrefs']) ? ' style="display:none"' : ''); ?>><?php echo $msg_script5; ?> <input type="radio" tabindex="<?php echo (++$tabIndex); ?>" name="freeShipping" value="yes"<?php echo (isset($EDIT->freeShipping) && $EDIT->freeShipping=='yes' ? ' checked="checked"' : ''); ?> /> <?php echo $msg_script6; ?> <input tabindex="<?php echo (++$tabIndex); ?>" type="radio" name="freeShipping" value="no"<?php echo (isset($EDIT->freeShipping) && $EDIT->freeShipping=='no' ? ' checked="checked"' : (!isset($EDIT->freeShipping) ? ' checked="checked"' : '')); ?> /></div>
  </div>
  <div class="formRight" style="width:25%">  
    <label><?php echo hideShowBatchOperation('batch_field_16','pPurchase').$msg_productadd69; ?>: <?php echo mc_displayHelpTip($msg_javascript401); ?></label>
    <div id="batch_field_16"<?php echo (isset($_SESSION['batchFieldPrefs']) && in_array('pPurchase',$_SESSION['batchFieldPrefs']) ? ' style="display:none"' : ''); ?>><?php echo $msg_script5; ?> <input tabindex="<?php echo (++$tabIndex); ?>" type="radio" name="pPurchase" value="yes"<?php echo (isset($EDIT->pPurchase) && $EDIT->pPurchase=='yes' ? ' checked="checked"' : (!isset($EDIT->pPurchase) ? ' checked="checked"' : '')); ?> /> <?php echo $msg_script6; ?> <input tabindex="<?php echo (++$tabIndex); ?>" type="radio" name="pPurchase" value="no"<?php echo (isset($EDIT->pPurchase) && $EDIT->pPurchase=='no' ? ' checked="checked"' : ''); ?> /></div>
  </div>
  <div class="formLeft" style="width:25%">
    <label><?php echo hideShowBatchOperation('batch_field_17','pEnable').$msg_productadd12; ?>: <?php echo mc_displayHelpTip($msg_javascript77); ?></label>
    <div id="batch_field_17"<?php echo (isset($_SESSION['batchFieldPrefs']) && in_array('pEnable',$_SESSION['batchFieldPrefs']) ? ' style="display:none"' : ''); ?>><?php echo $msg_script5; ?> <input tabindex="<?php echo (++$tabIndex); ?>" type="radio" name="pEnable" value="yes"<?php echo (isset($EDIT->pEnable) && $EDIT->pEnable=='yes' ? ' checked="checked"' : (!isset($EDIT->pEnable) ? ' checked="checked"' : '')); ?> /> <?php echo $msg_script6; ?> <input tabindex="<?php echo (++$tabIndex); ?>" type="radio" name="pEnable" value="no"<?php echo (isset($EDIT->pEnable) && $EDIT->pEnable=='no' ? ' checked="checked"' : ''); ?> /></div>
  </div>
  <div class="formRight" style="width:24%">  
  </div>
  <br class="clear" />
</div>

<?php
if (!isset($_GET['copyp']) && !isset($EDIT->id) && !defined('BATCH_EDIT_MODE')) {
?>

<div class="fieldHeadWrapper">
  <p><?php echo $msg_productadd60; ?>:</p>
</div>

<div class="formFieldWrapper">
  <div class="formLeft" style="width:48%">  
    <label><?php echo $msg_productadd59; ?>: <?php echo mc_displayHelpTip($msg_javascript376,'RIGHT'); ?></label>
    <input type="file" name="image[]" value="" class="box" /> 
  </div>
  <div class="formRight" style="width:48%">
    <label><?php echo $msg_productadd62; ?>: <?php echo mc_displayHelpTip($msg_javascript377); ?></label>
    templates/<select name="folder" id="folderList">
      <option value="products">products/ <?php echo $msg_productpictures12; ?></option>
      <?php
      $dir = opendir(REL_HTTP_PATH.PRODUCTS_FOLDER);
      while (false!==($read=readdir($dir))) {
        if (!in_array($read,array('.','..')) && is_dir(REL_HTTP_PATH.PRODUCTS_FOLDER.'/'.$read)) {
        ?>
        <option value="<?php echo $read; ?>"<?php echo (isset($EDIT->catFolder) && $EDIT->catFolder==$read ? ' selected="selected"' : ''); ?>>products/<?php echo $read; ?></option>
        <?php
        }
      }
      closedir($dir);
      ?>
    </select> <input type="button" onclick="createPictureFolder('<?php echo mc_cleanDataEnt($msg_javascript152); ?>')" class="createfolderbutton" name="<?php echo mc_cleanDataEnt($msg_salesupdate13); ?>" value="+" />  
  </div>
  <br class="clear" />
</div>

<div class="fieldHeadWrapper">
  <p><?php echo $msg_productadd77; ?>:</p>
</div>

<div class="formFieldWrapper">
  <div class="formLeft" style="width:33%">  
    <input type="file" name="addimg[]" value="" class="box" /> 
  </div>
  <div class="formLeft" style="width:33%">  
    <input type="file" name="addimg[]" value="" class="box" /> 
  </div>
  <div class="formLeft" style="width:33%">  
    <input type="file" name="addimg[]" value="" class="box" /> 
  </div>
  <br class="clear" />
</div>
<?php
} else {
if (isset($_GET['copyp'])) {
?>
<div class="fieldHeadWrapper">
  <p><?php echo $msg_productadd60; ?>:</p>
</div>

<div class="formFieldWrapper">
  <div class="formLeft" style="width:48%">  
    <label><?php echo $msg_productadd59; ?>: <?php echo mc_displayHelpTip($msg_javascript376,'RIGHT'); ?></label>
    <input type="file" name="image[]" value="" class="box" /> 
  </div>
  <div class="formRight" style="width:48%">
    <label><?php echo $msg_productadd62; ?>: <?php echo mc_displayHelpTip($msg_javascript377); ?></label>
    templates/<select name="folder" id="folderList">
      <option value="products">products/ <?php echo $msg_productpictures12; ?></option>
      <?php
      $dir = opendir(REL_HTTP_PATH.PRODUCTS_FOLDER);
      while (false!==($read=readdir($dir))) {
        if (!in_array($read,array('.','..')) && is_dir(REL_HTTP_PATH.PRODUCTS_FOLDER.'/'.$read)) {
        ?>
        <option value="<?php echo $read; ?>"<?php echo (isset($EDIT->catFolder) && $EDIT->catFolder==$read ? ' selected="selected"' : ''); ?>>products/<?php echo $read; ?></option>
        <?php
        }
      }
      closedir($dir);
      ?>
    </select> <input type="button" onclick="createPictureFolder('<?php echo mc_cleanDataEnt($msg_javascript152); ?>')" class="createfolderbutton" name="<?php echo mc_cleanDataEnt($msg_salesupdate13); ?>" value="+" />  
  </div>
  <br class="clear" />
</div>

<div class="fieldHeadWrapper">
  <p><?php echo $msg_productadd77; ?>:</p>
</div>

<div class="formFieldWrapper">
  <div class="formLeft" style="width:33%">  
    <input type="file" name="addimg[]" value="" class="box" /> 
  </div>
  <div class="formLeft" style="width:33%">  
    <input type="file" name="addimg[]" value="" class="box" /> 
  </div>
  <div class="formLeft" style="width:33%">  
    <input type="file" name="addimg[]" value="" class="box" /> 
  </div>
  <br class="clear" />
</div>
<?php
}
}

if (isset($_GET['copyp'])) {
?>
<div class="formFieldWrapper" id="copyOptionsArea">
  <label><?php echo $msg_productadd26; ?>: <?php echo mc_displayHelpTip($msg_javascript105); ?></label>
  <b><?php echo $msg_productadd78; ?></b>: <input onclick="toggleCheckBoxesID(this.checked,'copyOptionsArea')" type="checkbox" name="checker" value="yes" />&nbsp;&nbsp;&nbsp;
  <?php echo $msg_productadd27; ?>: <input tabindex="<?php echo (++$tabIndex); ?>" type="checkbox" id="copyPictures" name="copyPictures" value="yes" />&nbsp;&nbsp;&nbsp;
  <?php echo $msg_productadd28; ?>: <input tabindex="<?php echo (++$tabIndex); ?>" type="checkbox" id="copyAttributes" name="copyAttributes" value="yes" />&nbsp;&nbsp;&nbsp;
  <?php echo $msg_productadd47; ?>: <input tabindex="<?php echo (++$tabIndex); ?>" type="checkbox" id="copyRelated" name="copyRelated" value="yes" />&nbsp;&nbsp;&nbsp;
  <?php echo $msg_productadd48; ?>: <input tabindex="<?php echo (++$tabIndex); ?>" type="checkbox" id="copyMP3" name="copyMP3" value="yes" />&nbsp;&nbsp;&nbsp;
  <span id="loadPers"<?php echo (isset($EDIT->pDownload) && $EDIT->pDownload=='yes' ? ' style="display:none"' : ''); ?>><?php echo $msg_productadd51; ?>: <input tabindex="<?php echo (++$tabIndex); ?>" id="copyPersonalisation" type="checkbox" name="copyPersonalisation" value="yes" /></span>
  <br class="clear" />
</div>
<?php
}
?>

<p style="text-align:center;padding-top:20px">
<?php
if (isset($EDIT->id) && !isset($_GET['copyp'])) {
?>
<input type="hidden" name="update" value="yes" />
<input class="formbutton" type="submit" value="<?php echo mc_cleanDataEnt($msg_productadd15); ?>" title="<?php echo mc_cleanDataEnt($msg_productadd15); ?>" />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input class="formbutton2" type="button" onclick="window.location='?p=manage-products'" value="<?php echo mc_cleanDataEnt($msg_script11); ?>" title="<?php echo mc_cleanDataEnt($msg_script11); ?>" />
<?php
} else {
if (defined('BATCH_EDIT_MODE')) {
?>
<input type="hidden" name="productIDs" value="<?php echo (isset($_POST['productsUpdated']) ? $_POST['productIDs'] : implode(',',$_POST['productIDs'])); ?>" />
<input type="hidden" name="productsUpdated" value="<?php echo $batchCount; ?>" />
<input class="formbutton" type="submit" value="<?php echo str_replace('{count}',$batchCount,mc_cleanDataEnt($msg_productmanage55)); ?>" title="<?php echo str_replace('{count}',$batchCount,mc_cleanDataEnt($msg_productmanage55)); ?>" />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input class="formbutton2" type="button" onclick="window.location='?p=manage-products'" value="<?php echo mc_cleanDataEnt($msg_script11); ?>" title="<?php echo mc_cleanDataEnt($msg_script11); ?>" />
<?php
} else {
?>
<input type="hidden" name="process" value="yes" />
<input class="formbutton" type="submit" value="<?php echo mc_cleanDataEnt($msg_productadd2); ?>" title="<?php echo mc_cleanDataEnt($msg_productadd2); ?>" />
<?php
}
}
?>
</p>
</form>

<p>&nbsp;</p>
<p>&nbsp;</p>
</div>
