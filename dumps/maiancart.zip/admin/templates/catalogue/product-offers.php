<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } 
define('CALBOX', 'oExpiry');
include(PATH.'templates/date-picker.php');
?>
<div id="content">

<?php
if (isset($OK)) {
  echo actionCompleted($msg_productoffers8);
}
if (isset($OK2)) {
  echo actionCompleted($msg_productoffers9);
}
?>

<?php echo $msg_productoffers; ?><br /><br />

<form method="post" id="form" action="?p=special-offers<?php echo (isset($EDIT->id) ? '&amp;edit='.$EDIT->id : ''); ?>">
<div class="fieldHeadWrapper">
  <p><?php echo (isset($EDIT->id) ? $msg_productoffers14 : $msg_productoffers5); ?>:</p>
</div>

<div class="formFieldWrapper">
  <div class="formLeft" style="width:75%">
    <label><?php echo $msg_productoffers19; ?>:</label>
    <div class="categoryBoxes" style="height:175px">
    <?php
    $cats   = array();
    $q_cats = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
              WHERE catLevel = '1'
              AND childOf    = '0'
              AND enCat      = 'yes'
              ORDER BY catname") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($CATS = mysql_fetch_object($q_cats)) {
    $cats[] = $CATS->id;
    ?>
    <input tabindex="<?php echo (++$tabIndex); ?>" onclick="loadProducts('cat-<?php echo $CATS->id; ?>','0','offers')" type="radio" name="pCat" value="cat-<?php echo $CATS->id; ?>"<?php echo (count($cats)==1 ? ' checked="checked"' : ''); ?> /> <?php echo mc_cleanDataEnt($CATS->catname); ?><br />
    <?php
    $q_children = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
                  WHERE catLevel = '2'
                  AND enCat      = 'yes'
                  AND childOf    = '".$CATS->id."'
                  ORDER BY catname
                  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($CHILDREN = mysql_fetch_object($q_children)) {
    ?>
    &nbsp;&nbsp;<input tabindex="<?php echo (++$tabIndex); ?>" onclick="loadProducts('child-<?php echo $CHILDREN->id; ?>','0','offers')" type="radio" name="pCat" value="child-<?php echo $CHILDREN->id; ?>" /> <?php echo mc_cleanDataEnt($CHILDREN->catname); ?><br />
    <?php
    $q_infants = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
                  WHERE catLevel = '3'
                  AND childOf    = '{$CHILDREN->id}'
                  AND enCat      = 'yes'
                  ORDER BY catname
                  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($INFANTS = mysql_fetch_object($q_infants)) {
    ?>
    &nbsp;&nbsp;&nbsp;&nbsp;<input tabindex="<?php echo (++$tabIndex); ?>" onclick="loadProducts('infant-<?php echo $INFANTS->id; ?>','0','offers')" type="radio" name="pCat" value="child-<?php echo $INFANTS->id; ?>" /> <?php echo mc_cleanDataEnt($INFANTS->catname); ?><br />
    <?php
    }
    }
    }
    ?>
    </div>
  </div>
  <div class="formRight" style="float:right;width:23%">  
    <label><?php echo $msg_productoffers2; ?>: <?php echo mc_displayHelpTip($msg_javascript87,'LEFT'); ?></label>
    <input tabindex="<?php echo (++$tabIndex); ?>" type="text" name="oRate" value="0.00" class="box" style="width:40%" /><br /><br />
    
    <label><?php echo $msg_productoffers4; ?>: <?php echo mc_displayHelpTip($msg_javascript66,'LEFT'); ?></label>
    <input tabindex="<?php echo (++$tabIndex); ?>" type="text" name="oExpiry" value="" class="box" id="oExpiry" style="width:60%" /><br /><br />
    
    <label><?php echo $msg_productoffers26; ?>: <?php echo mc_displayHelpTip($msg_javascript489,'LEFT'); ?></label>
    <input tabindex="<?php echo (++$tabIndex); ?>" type="text" name="multiBuy" value="0" class="box" id="multiBuy" style="width:60%" />    
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper">
  <label><?php echo $msg_productoffers7; ?>: <?php echo mc_displayHelpTip($msg_javascript65); ?></label>
  <div class="categoryBoxes" id="products" style="width:99%">
  <?php
  $q_products = mysql_query("SELECT *,".DB_PREFIX."products.id AS pid 
                FROM ".DB_PREFIX."products
                LEFT JOIN ".DB_PREFIX."prod_category
                ON ".DB_PREFIX."products.id   = ".DB_PREFIX."prod_category.product
                WHERE category                          = '".(isset($cats[0]) ? $cats[0] : '0')."'
                AND pEnable                             = 'yes'
                AND (pOffer                             = '' OR pOffer <= 0)
                GROUP BY ".DB_PREFIX."products.id
                ORDER BY pName
                ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  if (mysql_num_rows($q_products)>0) {
  ?>
  <input tabindex="<?php echo (++$tabIndex); ?>" type="checkbox" name="log" value="all" onclick="selectAll()" /> <b><?php echo $msg_productoffers20; ?></b><br />
  <?php
  while ($PR = mysql_fetch_object($q_products)) {
  ?>
  <input type="hidden" name="products[]" value="<?php echo $PR->pid; ?>" />
  <input type="checkbox" tabindex="<?php echo (++$tabIndex); ?>" name="product[]" value="<?php echo $PR->pid; ?>" /> <?php echo mc_cleanDataEnt($PR->pName).' - '.mc_currencyFormat(mc_formatPrice($PR->pPrice)); ?><br />
  <?php
  }
  } else {
  echo $msg_productoffers14;
  }
  ?>
  </div>
  <br class="clear" />
</div>

<p style="text-align:center;padding-top:20px">
 <input type="hidden" name="process" value="yes" />
 <input class="formbutton" type="submit" value="<?php echo mc_cleanDataEnt($msg_productoffers5); ?>" title="<?php echo mc_cleanDataEnt($msg_productoffers5); ?>" />
</p>
</form><br />
<?php
$rIS = mc_rowCount('products WHERE pEnable = \'yes\' AND pOffer > 0');
?>
<div class="fieldHeadWrapper">
  <p><?php echo ($uDel=='yes' && $rIS ? '<span style="float:right"><a style="color:#555" href="?p=special-offers&amp;clearall=yes" title="'.mc_cleanDataEnt($msg_productoffers17).'" onclick="return confirmMessage(\''.mc_cleanDataEnt($msg_javascript45).'\')">'.$msg_productoffers17.'</a></span>' : ''); ?><?php echo $msg_productoffers10; ?>:</p>
</div>
<?php
$some = 0;
if ($rIS>0) {
$q_cats = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
          WHERE catLevel = '1'
          AND childOf    = '0'
          AND enCat      = 'yes'
          ORDER BY catname") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
while ($CATS = mysql_fetch_object($q_cats)) {
  $oc = getCatOfferCount($CATS->id);
  if ($oc>0) {
  ++$some;
  ?>
  <div class="hitsOverviewWrapper" style="border-width:2px">
   <div class="productName" style="width:75%">
    <p><?php echo str_replace(array('{category}','{count}'),array(mc_cleanDataEnt($CATS->catname),$oc),$msg_productoffers11); ?></p>
   </div>
   <div class="percentage" style="width:23%">
    <?php
    if ($oc>0) {
    ?>
    <p>
     <a href="?p=special-offers&amp;view=<?php echo $CATS->id; ?>" title="<?php echo mc_cleanDataEnt($msg_productoffers12); ?>" onclick="mc_Window(this.href,'<?php echo GREYBOX_HEIGHT; ?>','<?php echo GREYBOX_WIDTH; ?>',this.title);return false;"><?php echo $msg_productoffers12; ?></a>
     <?php
     if ($uDel=='yes') {
     ?>
     | <a href="?p=special-offers&amp;clear=<?php echo $CATS->id; ?>" title="<?php echo mc_cleanDataEnt($msg_productoffers13); ?>" onclick="return confirmMessage('<?php echo mc_cleanDataEnt($msg_javascript45); ?>')"><?php echo $msg_productoffers13; ?></a>
     <?php
     }
     ?>
    </p>
    <?php
    } else {
    ?>
    <p>&nbsp;</p>
    <?php
    }
    ?>
   </div>
   <br class="clear" />
  </div>
  <?php
  }
  $q_children = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
                WHERE catLevel = '2'
                AND enCat      = 'yes'
                AND childOf    = '".$CATS->id."'
                ORDER BY catname
                ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  while ($CHILDREN = mysql_fetch_object($q_children)) {
  $oc = getCatOfferCount($CHILDREN->id);
  if ($oc>0) {
  ++$some;
  ?>
  <div class="hitsOverviewWrapper" style="background:#fbfbfb">
   <div class="productName" style="width:75%">
    <p>&nbsp;&nbsp;<?php echo str_replace(array('{category}','{count}'),array(mc_cleanDataEnt($CHILDREN->catname),$oc),$msg_productoffers11); ?></p>
   </div>
   <div class="percentage" style="width:23%">
    <?php
    if ($oc>0) {
    ?>
    <p>
     <a href="?p=special-offers&amp;view=<?php echo $CHILDREN->id; ?>" title="<?php echo mc_cleanDataEnt($msg_productoffers12); ?>" onclick="mc_Window(this.href,'<?php echo GREYBOX_HEIGHT; ?>','<?php echo GREYBOX_WIDTH; ?>',this.title);return false;"><?php echo $msg_productoffers12; ?></a> | 
     <a href="?p=special-offers&amp;clear=<?php echo $CHILDREN->id; ?>" title="<?php echo mc_cleanDataEnt($msg_productoffers13); ?>" onclick="return confirmMessage('<?php echo mc_cleanDataEnt($msg_javascript45); ?>')"><?php echo $msg_productoffers13; ?></a>
    </p>
    <?php
    } else {
    ?>
    <p>&nbsp;</p>
    <?php
    }
    ?>
   </div>
   <br class="clear" />
  </div>
  <?php
  }
  $q_infants = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
               WHERE catLevel = '3'
               AND enCat      = 'yes'
               AND childOf    = '{$CHILDREN->id}'
               ORDER BY catname
               ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  while ($INFANTS = mysql_fetch_object($q_infants)) {
  $oc = getCatOfferCount($INFANTS->id);
  if ($oc>0) {
  ++$some;
  ?>
  <div class="hitsOverviewWrapper" style="background:#fbfbfb">
   <div class="productName" style="width:75%">
    <p>&nbsp;&nbsp;&nbsp;&nbsp;<?php echo str_replace(array('{category}','{count}'),array(mc_cleanDataEnt($INFANTS->catname),$oc),$msg_productoffers11); ?></p>
   </div>
   <div class="percentage" style="width:23%">
    <?php
    if ($oc>0) {
    ?>
    <p>
     <a href="?p=special-offers&amp;view=<?php echo $INFANTS->id; ?>" title="<?php echo mc_cleanDataEnt($msg_productoffers12); ?>" onclick="mc_Window(this.href,'<?php echo GREYBOX_HEIGHT; ?>','<?php echo GREYBOX_WIDTH; ?>',this.title);return false;"><?php echo $msg_productoffers12; ?></a> | 
     <a href="?p=special-offers&amp;clear=<?php echo $INFANTS->id; ?>" title="<?php echo mc_cleanDataEnt($msg_productoffers13); ?>" onclick="return confirmMessage('<?php echo mc_cleanDataEnt($msg_javascript45); ?>')"><?php echo $msg_productoffers13; ?></a>
    </p>
    <?php
    } else {
    ?>
    <p>&nbsp;</p>
    <?php
    }
    ?>
   </div>
   <br class="clear" />
  </div>
  <?php
  }
  }
  
  }
}
if ($some==0) {
?>
<span class="noData"><?php echo $msg_productoffers15; ?></span>
<?php
}
} else {
?>
<span class="noData"><?php echo $msg_productoffers15; ?></span>
<?php
}
?>

<p>&nbsp;</p>
<p>&nbsp;</p>
</div>
