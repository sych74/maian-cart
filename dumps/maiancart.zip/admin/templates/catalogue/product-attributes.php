<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } 
if (isset($_GET['edit'])) {
  $EDIT     = mc_getTableData('attributes','attrGroup',mc_digitSan($_GET['edit']),' ORDER BY id');
  $attRows  = mc_rowCount('attributes WHERE productID = \''.mc_digitSan($_GET['product']).'\' AND attrGroup = \''.mc_digitSan($_GET['edit']).'\'');
}
$MCPRODUCT  = mc_getTableData('products','id',mc_digitSan($_GET['product']));
?>
<div id="content">

<?php
if (isset($OK)) {
  echo actionCompleted(str_replace('{count}',$run,$msg_prodattributes13));
}
if (isset($OK2)) {
  echo actionCompleted($msg_prodattributes17);
}
if (isset($OK3) && $cnt>0) {
  echo actionCompleted($msg_prodattributes14);
}
if (isset($OK4)) {
  echo actionCompleted($msg_prodattributes16);
}
if (isset($OK5)) {
  echo actionCompleted($msg_prodattributes20);
}
if (isset($OK6) && $cnt>0) {
  echo actionCompleted($msg_prodattributes22);
}
?>

<?php echo $msg_prodattributes; ?>
<br /><br />
<?php
$P = mc_getTableData('products','id',mc_digitSan($_GET['product']));
?>
<a class="addProduct" href="?p=product-attributes-import" title="<?php echo mc_cleanDataEnt($msg_prodattributes2); ?>"><b><?php echo $msg_prodattributes2; ?></b></a>
<a class="copyAttributes" href="?p=copy-attributes&amp;product=<?php echo mc_digitSan($_GET['product']); ?>" title="<?php echo mc_cleanDataEnt($msg_prodattributes24); ?>" onclick="mc_Window(this.href,'<?php echo GREYBOX_HEIGHT; ?>','<?php echo GREYBOX_WIDTH; ?>',this.title);return false;"><b><?php echo $msg_prodattributes24; ?></b></a>
<br />
<br />
<div class="prodTop">
  <p><span class="float"><?php echo mc_cleanData($P->pName); ?></span>
  <b><?php echo $msg_productpictures14; ?></b>: 
  <select onchange="if(this.value!= 0){location=this.options[this.selectedIndex].value}">
  <option value="0">- - - -</option>
  <option value="?p=product-pictures&amp;product=<?php echo mc_digitSan($_GET['product']); ?>"><?php echo $msg_productadd38; ?></option>
  <option value="?p=add-product&amp;copyp=<?php echo mc_digitSan($_GET['product']); ?>"><?php echo $msg_productpictures16; ?></option>
  <option value="?p=add-product&amp;edit=<?php echo mc_digitSan($_GET['product']); ?>"><?php echo $msg_productpictures15; ?></option>
  <option value="?p=product-related&amp;product=<?php echo mc_digitSan($_GET['product']); ?>"><?php echo $msg_productpictures18; ?></option>
  <?php
  if (PRODUCT_MP3_PREVIEWS) {
  ?>
  <option value="?p=product-mp3&amp;product=<?php echo mc_digitSan($_GET['product']); ?>"><?php echo $msg_productmanage19; ?></option>
  <?php
  }
  if ($P->pDownload=='no') {
  ?>
  <option value="?p=product-personalisation&amp;product=<?php echo mc_digitSan($_GET['product']); ?>"><?php echo $msg_productmanage20; ?></option>
  <?php
  }
  ?>
  </select>
  <br class="clear" />
  </p>
</div>

<form method="post" action="?p=product-attributes&amp;product=<?php echo mc_digitSan($_GET['product']).(isset($_GET['edit']) ? '&amp;edit='.mc_digitSan($_GET['edit']) : ''); ?>">
<div class="attributeWrapper">

  <div class="attributeGroups">
  
   <div class="fieldHeadWrapper">
    <p><?php echo $msg_prodattributes3; ?></p>
   </div>
   
   <div class="manageGroups">
   
   <p>
   <label><span id="add_label"><?php echo $msg_prodattributes8; ?></span>: <?php echo mc_displayHelpTip($msg_javascript350,'RIGHT'); ?></label>
   <input type="text" name="group" class="box" tabindex="<?php echo (++$tabIndex); ?>" maxlength="100" id="newgroup" style="width:70%" /> 
   <input class="formbutton" name="add_new_group" type="submit" onclick="if(jQuery('#newgroup').val()==''){jQuery('#newgroup').focus();return false;}" value="+" title="<?php echo mc_cleanDataEnt($msg_prodattributes8); ?>" />
   
   <label style="margin-top:20px"><span id="add_multi_label"><?php echo $msg_prodattributes29; ?></span>: <?php echo mc_displayHelpTip($msg_javascript428,'RIGHT'); ?></label>
   <?php echo $msg_script5; ?> <input type="radio" tabindex="<?php echo (++$tabIndex); ?>" name="allowMultiple" value="yes"<?php echo (isset($EDIT->allowMultiple) && $EDIT->allowMultiple=='yes' ? ' checked="checked"' : ''); ?> /> <?php echo $msg_script6; ?> <input tabindex="<?php echo (++$tabIndex); ?>" type="radio" name="allowMultiple" value="no"<?php echo (isset($EDIT->allowMultiple) && $EDIT->allowMultiple=='no' ? ' checked="checked"' : (!isset($EDIT->allowMultiple) ? ' checked="checked"' : '')); ?> />
   
   <label style="margin-top:20px"><?php echo $msg_prodattributes31; ?>: <?php echo mc_displayHelpTip($msg_javascript434,'RIGHT'); ?></label>
   <?php echo $msg_script5; ?> <input type="radio" tabindex="<?php echo (++$tabIndex); ?>" name="isRequired" value="yes"<?php echo (isset($EDIT->isRequired) && $EDIT->isRequired=='yes' ? ' checked="checked"' : ''); ?> /> <?php echo $msg_script6; ?> <input tabindex="<?php echo (++$tabIndex); ?>" type="radio" name="isRequired" value="no"<?php echo (isset($EDIT->isRequired) && $EDIT->isRequired=='no' ? ' checked="checked"' : (!isset($EDIT->isRequired) ? ' checked="checked"' : '')); ?> />
   
   </p>
   
   </div>
   
  </div>
  
  <div class="attributes">
  
   <div class="fieldHeadWrapper">
    <p>
    <span class="float"><img style="cursor:pointer" src="templates/images/add.png" alt="<?php echo mc_cleanDataEnt($msg_rates14); ?>" title="<?php echo mc_cleanDataEnt($msg_rates14); ?>" onclick="manageAttributeBoxes('add')" /> <img src="templates/images/remove.png" alt="<?php echo mc_cleanDataEnt($msg_rates15); ?>" style="cursor:pointer" title="<?php echo mc_cleanDataEnt($msg_rates15); ?>" onclick="manageAttributeBoxes('remove')" /></span>
    <?php echo $msg_prodattributes4; ?></p>
   </div>
   
   <div class="manageAttributes">
   
   <div id="attrBoxSet">
   
   <p>
   
   <span class="text">
     <label><?php echo $msg_prodattributes9; ?>: <?php echo mc_displayHelpTip($msg_javascript409,'RIGHT'); ?></label>
     <input type="text" name="name[]" tabindex="<?php echo (++$tabIndex); ?>" maxlength="100" class="box" value="<?php echo (isset($EDIT->id) ? mc_cleanDataEnt($EDIT->attrName) : ''); ?>" />
   </span>
   
   <span class="cost">
     <label><?php echo $msg_prodattributes10; ?>: <?php echo mc_displayHelpTip($msg_javascript410); ?></label>
     <input type="text" name="cost[]" tabindex="<?php echo (++$tabIndex); ?>" class="box" value="<?php echo (isset($EDIT->id) ? mc_cleanDataEnt($EDIT->attrCost) : '0.00'); ?>" />
   </span>
   
   <span class="weight">
     <label><?php echo $msg_prodattributes15; ?>: <?php echo mc_displayHelpTip($msg_javascript411); ?></label>
     <input type="text" name="weight[]" tabindex="<?php echo (++$tabIndex); ?>" class="box" value="<?php echo (isset($EDIT->id) ? mc_cleanDataEnt($EDIT->attrWeight) : '0'); ?>" />
   </span>
   
   <span class="stock">
     <label><?php echo $msg_prodattributes5; ?>: <?php echo mc_displayHelpTip($msg_javascript412,'LEFT'); ?></label>
     <input type="text" name="stock[]" tabindex="<?php echo (++$tabIndex); ?>" class="box" value="<?php echo (isset($EDIT->id) ? mc_cleanDataEnt($EDIT->attrStock) : '1'); ?>" />
   </span>
   
   <span class="order">
     <label><?php echo $msg_prodattributes11; ?>: <?php echo mc_displayHelpTip($msg_javascript413,'LEFT'); ?></label>
     <select name="order[]" tabindex="<?php echo (++$tabIndex); ?>">
     <?php 
     if (isset($EDIT->id)) {
     for ($i=1; $i<$attRows+1; $i++) {
     ?>
     <option value="<?php echo $i; ?>"<?php echo ($EDIT->orderBy==$i ? ' selected="selected"' : ''); ?>><?php echo $i; ?></option>
     <?php
     }
     } else {
     ?>
     <option value="1">1</option>
     <?php
     }
     ?>
     </select>
   </span>
   
   <br class="clear" />
   </p>
   
   <?php
   if (isset($_GET['edit'])) {
   $q = mysql_query("SELECT * FROM ".DB_PREFIX."attributes 
        WHERE attrGroup = '".mc_digitSan($_GET['edit'])."'
        AND id         != '{$EDIT->id}'
        ORDER BY orderBy
        ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
   while ($ATT = mysql_fetch_object($q)) {
   ?>
   <p style="margin:5px 0 0 0">
   <span class="text"><input type="text" maxlength="100" name="name[]" class="box" value="<?php echo mc_cleanDataEnt($ATT->attrName); ?>" /></span>
   <span class="cost"><input type="text" name="cost[]" class="box" value="<?php echo mc_cleanDataEnt($ATT->attrCost); ?>" /></span>
   <span class="weight"><input type="text" name="weight[]" class="box" value="<?php echo mc_cleanDataEnt($ATT->attrWeight); ?>" /></span>
   <span class="stock"><input type="text" name="stock[]" class="box" value="<?php echo mc_cleanDataEnt($ATT->attrStock); ?>" /></span>
   <span class="order">
   <select name="order[]">
   <?php 
   for ($i=1; $i<$attRows+1; $i++) {
   ?>
   <option value="<?php echo $i; ?>"<?php echo ($ATT->orderBy==$i ? ' selected="selected"' : ''); ?>><?php echo $i; ?></option>
   <?php
   }
   ?>
   </select>
   </span><br class="clear" />
   </p>
   <?php
   }
   }
   ?>
   
   </div>
   
   <br class="clear" />
   
   <div class="attrSelector">
     
     <div class="left">
      <p><label><?php echo $msg_prodattributes7; ?>: <?php echo mc_displayHelpTip($msg_javascript354,'RIGHT'); ?></label>
      <select name="groups" id="groups" tabindex="<?php echo (++$tabIndex); ?>">
      <option value="0">- - - - - - -</option>
      <?php
      $q = mysql_query("SELECT * FROM ".DB_PREFIX."attr_groups
           WHERE productID = '".mc_digitSan($_GET['product'])."'
           ORDER BY orderBy,groupName
           ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
      while ($AG = mysql_fetch_object($q)) {
      ?>
      <option value="<?php echo $AG->id; ?>"<?php echo (isset($EDIT->attrGroup) && $EDIT->attrGroup==$AG->id ? ' selected="selected"' : ''); ?>><?php echo mc_cleanDataEnt($AG->groupName); ?></option>
      <?php
      }
      ?>
      </select>
     </p>
     </div>
     
     <div class="right">  
      
     </div>
     
     <br class="clear" />
   </div>  
   
   <span class="attributeButtonWrapper">
    <input onclick="if(jQuery('#groups').val()=='0'){alert('<?php echo mc_cleanDataEnt($msg_javascript257); ?>');return false;}" name="<?php echo (isset($_GET['edit']) ? 'update' : 'process'); ?>" class="formbutton" type="submit" value="<?php echo mc_cleanDataEnt((isset($_GET['edit']) ? $msg_prodattributes23 : $msg_prodattributes6)); ?>" title="<?php echo mc_cleanDataEnt((isset($_GET['edit']) ? $msg_prodattributes23 : $msg_prodattributes6)); ?>" /><?php echo (isset($_GET['edit']) ? '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input class="formbutton2" type="button" onclick="window.location=\'?p=product-attributes&amp;product='.mc_digitSan($_GET['product']).'\'" value="'.mc_cleanDataEnt($msg_script11).'" title="'.mc_cleanDataEnt($msg_script11).'" />' : ''); ?>
   </span>
   
   </div>
   
  </div>
  
</div>
</form>

<br />

<form method="post" action="?p=product-attributes&amp;product=<?php echo mc_digitSan($_GET['product']); ?>" onsubmit="return confirmMessage('<?php echo mc_cleanDataEnt($msg_javascript45); ?>')">
<div class="fieldHeadWrapper">
  <p><?php echo $msg_prodattributes4; ?>:</p>
</div>
<?php
$q_products = mysql_query("SELECT * FROM ".DB_PREFIX."attr_groups
              WHERE productID = '".mc_digitSan($_GET['product'])."'
              ORDER BY orderBy
              ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
if (mysql_num_rows($q_products)>0) {
  while ($AG = mysql_fetch_object($q_products)) {
  ?> 
  <div class="attrWrapper">
    <div class="catLeft" style="width:30%">
    <input type="hidden" name="groups[]" value="<?php echo $AG->id; ?>" />
    <select name="order[]" tabindex="<?php echo (++$tabIndex); ?>">
    <?php
    for ($i=1; $i<(mysql_num_rows($q_products)+1); $i++) {
    ?>
    <option value="<?php echo $i; ?>"<?php echo ($i==$AG->orderBy ? ' selected="selected"' : ''); ?>><?php echo $i; ?></option>
    <?php
    }
    ?>
    </select>
    <input type="text" tabindex="<?php echo (++$tabIndex); ?>" class="box" name="groupName[]" style="width:75%" value="<?php echo mc_cleanDataEnt($AG->groupName); ?>" />
    <span style="display:block;margin:5px 0 0 0">
    <?php echo $msg_prodattributes30.': '.$msg_script5; ?> <input type="radio" name="allowMultiple_<?php echo $AG->id; ?>" value="yes"<?php echo ($AG->allowMultiple=='yes' ? ' checked="checked"' : ''); ?> /> <?php echo $msg_script6; ?> <input type="radio" name="allowMultiple_<?php echo $AG->id; ?>" value="no"<?php echo ($AG->allowMultiple=='no' ? ' checked="checked"' : ''); ?> /><br />
    <?php echo $msg_prodattributes31.': '.$msg_script5; ?> <input type="radio" name="isRequired_<?php echo $AG->id; ?>" value="yes"<?php echo ($AG->isRequired=='yes' ? ' checked="checked"' : ''); ?> /> <?php echo $msg_script6; ?> <input type="radio" name="isRequired_<?php echo $AG->id; ?>" value="no"<?php echo ($AG->isRequired=='no' ? ' checked="checked"' : ''); ?> />
    </span>
    </div>
    <div class="attributes" style="width:<?php echo ($uDel=='yes' ? '59' : '64'); ?>%">
    <?php
    $q = mysql_query("SELECT * FROM ".DB_PREFIX."attributes
         WHERE attrGroup = '{$AG->id}'
         ORDER BY orderBy
         ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    if (mysql_num_rows($q)>0) {
    ?>
    <span style="float:right">
    <a href="?p=product-attributes&amp;edit=<?php echo $AG->id; ?>&amp;product=<?php echo mc_digitSan($_GET['product']); ?>"><img src="templates/images/edit.png" alt="<?php echo mc_cleanDataEnt($msg_script9); ?>" title="<?php echo mc_cleanDataEnt($msg_script9); ?>" /></a>
    </span>
    <?php
    while ($ATTR = mysql_fetch_object($q)) {
    ?>
    <span class="attr"><?php echo ($uDel=='yes' ? ' <a href="?p=product-attributes&amp;delattr='.$ATTR->id.'&amp;product='.mc_digitSan($_GET['product']).'" onclick="return confirmMessage(\''.mc_cleanDataEnt($msg_javascript45).'\')"><img style="vertical-align:bottom" src="templates/images/delete.png" alt="'.mc_cleanDataEnt($msg_script10).'" title="'.mc_cleanDataEnt($msg_script10).'" /></a>' : ''); ?> <?php echo mc_cleanDataEnt($ATTR->attrName).($ATTR->attrCost ? ' (+'.mc_currencyFormat($ATTR->attrCost).')' : ''); ?></span>
    <span class="attr2"><?php echo str_replace(array('{weight}','{stock}'),array($ATTR->attrWeight,$ATTR->attrStock),$msg_prodattributes21); ?></span>
    <?php
    }
    } else {
    ?>
    <span class="none"><?php echo $msg_prodattributes18; ?></span>
    <?php
    }
    ?>
    </div>
    <?php 
    if ($uDel=='yes') {
    ?>
    <div class="attributes" style="width:5%;text-align:center;background:#fff;float:right"><?php echo ($uDel=='yes' ? ' <a href="?p=product-attributes&amp;del='.$AG->id.'&amp;product='.mc_digitSan($_GET['product']).'" onclick="return confirmMessage(\''.mc_cleanDataEnt($msg_javascript45).'\')"><img src="templates/images/delete.png" alt="'.mc_cleanDataEnt($msg_script10).'" title="'.mc_cleanDataEnt($msg_script10).'" /></a>' : ''); ?></div>
    <?php
    }
    ?>
    <br class="clear" />
  </div>
  <?php 
  }
?>
<p style="margin-top:10px">
<input type="hidden" name="update_groups" value="yes" />
<input class="formbutton" type="submit" value="<?php echo mc_cleanDataEnt($msg_prodattributes19); ?>" title="<?php echo mc_cleanDataEnt($msg_prodattributes19); ?>" />
</p>
<?php  
} else {
  ?>
  <p><span class="noData"><?php echo $msg_prodattributes12; ?></span></p>
  <?php
}
?>
</form>

<p>&nbsp;</p>
<p>&nbsp;</p>
</div>
