<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } ?>
<div id="content">
<?php

if (isset($OK) && $cnt>0) {
  echo actionCompleted($msg_productmanage37);
}
$SQL      = '';
$orderBy  = (isset($_GET['orderby']) && in_array($_GET['orderby'],array('name_asc','name_desc','id_asc','id_desc','price_asc','price_desc','stock_asc','stock_desc','hits_asc','hits_desc')) ? $_GET['orderby'] : 'name_asc');
switch ($orderBy) {
  case 'name_asc':
  $orderBySQL = '`pName`';
  break;
  case 'name_desc':
  $orderBySQL = '`pName` DESC';
  break;
  case 'id_asc':
  $orderBySQL = '`pid`';
  break;
  case 'id_desc':
  $orderBySQL = '`pid` DESC';
  break;
  case 'price_asc':
  $orderBySQL = 'IF (`pOffer`>0,`pOffer`,`pPrice`)*100';
  break;
  case 'price_desc':
  $orderBySQL = 'IF (pOffer>0,pOffer,pPrice)*100 DESC';
  break;
  case 'stock_asc':
  $orderBySQL = '`pStock`';
  break;
  case 'stock_desc':
  $orderBySQL = '`pStock` DESC';
  break;
  case 'hits_asc':
  $orderBySQL = '`pVisits`';
  break;
  case 'hits_desc':
  $orderBySQL = '`pVisits` DESC';
  break;
}
if (isset($_GET['keys']) && $_GET['keys']) {
  $SQL = 'WHERE '.DB_PREFIX.'products.id = \''.mysql_real_escape_string($_GET['keys']).'\' OR `pName` LIKE \'%'.mysql_real_escape_string($_GET['keys']).'%\' OR pDescription LIKE \'%'.mysql_real_escape_string($_GET['keys']).'%\' OR `pNotes` LIKE \'%'.mysql_real_escape_string($_GET['keys']).'%\' OR `pCode` LIKE \'%'.mysql_real_escape_string($_GET['keys']).'%\'';
}
if (isset($_GET['cat'])) {
  $SQL .= ($SQL ? 'AND ' : 'WHERE ').' `category` = \''.mc_digitSan($_GET['cat']).'\'';
}
if (isset($_GET['status'])) {
  switch ($_GET['status']) {
    case 'yes':
    case 'no':
    $SQL .= ($SQL ? 'AND ' : 'WHERE ').' `pEnable` = \''.$_GET['status'].'\'';
    break;
    case 'puryes':
    case 'purno':
    $SQL .= ($SQL ? 'AND ' : 'WHERE ').' `pPurchase` = \''.substr($_GET['status'],3).'\'';
    break;
    case 'disyes':
    case 'disno':
    $SQL .= ($SQL ? 'AND ' : 'WHERE ').' `enDisqus` = \''.substr($_GET['status'],3).'\'';
    break;
    case 'down':
    $SQL .= ($SQL ? 'AND ' : 'WHERE ').' `pDownload` = \'yes\'';
    break;
    case 'ship':
    $SQL .= ($SQL ? 'AND ' : 'WHERE ').' `freeShipping` = \'yes\'';
    break;
    case 'video':
    $SQL .= ($SQL ? 'AND ' : 'WHERE ').' `pVideo` NOT IN(\'\',\'0\')';
    break;
    case 'offer':
    $SQL .= ($SQL ? 'AND ' : 'WHERE ').' `pOffer` > \'0\'';
    break;
    case 'minqty':
    $SQL .= ($SQL ? 'AND ' : 'WHERE ').' `minPurchaseQty` > \'1\'';
    break;
    case 'restricted':
    $SQL .= ($SQL ? 'AND ' : 'WHERE ').' `countryRestrictions` != \'\'';
    break;
    case 'notes':
    $SQL .= ($SQL ? 'AND ' : 'WHERE ').' `pNotes` != \'\'';
    break;
	case 'cube':
    $SQL .= ($SQL ? 'AND ' : 'WHERE ').' `pCube` > \'0\'';
    break;
  }
}

echo $msg_productmanage9; 

// Main query..
$q_prod = mysql_query("SELECT SQL_CALC_FOUND_ROWS *,
          DATE_FORMAT(pDateAdded,'".$SETTINGS->mysqlDateFormat."') AS adate,
          ".DB_PREFIX."products.id AS pid 
          FROM ".DB_PREFIX."products
          LEFT JOIN ".DB_PREFIX."prod_category
          ON ".DB_PREFIX."products.id = ".DB_PREFIX."prod_category.product
          $SQL
          GROUP BY ".DB_PREFIX."products.id
          ORDER BY $orderBySQL
          LIMIT $limit,".PRODUCTS_PER_PAGE."
          ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
$c            = mysql_fetch_object(mysql_query("SELECT FOUND_ROWS() AS rows"));
$countedRows  = (isset($c->rows) ? number_format($c->rows,0,'.','') : '0');
?>
<br /><br />
<div class="headOptionBar">
 <div class="left">
 <?php
 if (pagePermissions('product-export',false)=='yes') {
 ?>
 <a class="export" style="display:inline" href="?p=product-export" title="<?php echo mc_cleanDataEnt($msg_productmanage59); ?>"><b><?php echo $msg_productmanage59; ?></b></a></div>
 <?php
 }
 ?>
 <div class="right">
 <?php
 if (pagePermissions('product-batch-update',false)=='yes') {
 ?>
 <a class="batchcsv" href="?p=product-batch-update" title="<?php echo mc_cleanDataEnt($msg_productmanage66); ?>"><b><?php echo $msg_productmanage66; ?></b></a>
 <?php
 }
 ?>
 </div>
 <br class="clear" />
</div> 
<br />

<div class="statsTop">
  <div class="topLeft"><select onchange="if(this.value!= 0){location=this.options[this.selectedIndex].value}">
  <option value="?p=manage-products<?php echo (isset($_GET['keys']) ? '&amp;keys='.$_GET['keys'] : '').(isset($_GET['orderby']) ? '&amp;orderby='.$_GET['orderby'] : '').(isset($_GET['status']) ? '&amp;status='.$_GET['status'] : ''); ?>"><?php echo $msg_productmanage5; ?></option>
  <?php
  $q_cats = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
            WHERE `catLevel` = '1'
            AND `childOf`    = '0'
            AND `enCat`      = 'yes'
            ORDER BY `catname`
            ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  while ($CATS = mysql_fetch_object($q_cats)) {
  ?>
  <option value="?p=manage-products&amp;cat=<?php echo $CATS->id; ?>&amp;page=<?php echo $page.(isset($_GET['keys']) ? '&amp;keys='.$_GET['keys'] : '').(isset($_GET['orderby']) ? '&amp;orderby='.$_GET['orderby'] : '').(isset($_GET['status']) ? '&amp;status='.$_GET['status'] : ''); ?>"<?php echo (isset($_GET['cat']) && mc_digitSan($_GET['cat'])==$CATS->id ? ' selected="selected"' : ''); ?>><?php echo mc_cleanDataEnt($CATS->catname); ?></option>
  <?php
  $q_children = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
                WHERE `catLevel` = '2'
                AND `enCat`      = 'yes'
                AND `childOf`    = '".$CATS->id."'
                ORDER BY `catname`
                ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  while ($CHILDREN = mysql_fetch_object($q_children)) {
  ?>
  <option value="?p=manage-products&amp;cat=<?php echo $CHILDREN->id; ?>&amp;page=<?php echo $page.(isset($_GET['keys']) ? '&amp;keys='.$_GET['keys'] : '').(isset($_GET['orderby']) ? '&amp;orderby='.$_GET['orderby'] : '').(isset($_GET['status']) ? '&amp;status='.$_GET['status'] : ''); ?>"<?php echo (isset($_GET['cat']) && mc_digitSan($_GET['cat'])==$CHILDREN->id ? ' selected="selected"' : ''); ?>>- <?php echo mc_cleanDataEnt($CHILDREN->catname); ?></option>
  <?php
  $q_infants = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
               WHERE `catLevel` = '3'
               AND `childOf`    = '{$CHILDREN->id}'
               AND `enCat`      = 'yes'
               ORDER BY `catname`
               ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  while ($INFANTS = mysql_fetch_object($q_infants)) {
  ?>
  <option value="?p=manage-products&amp;cat=<?php echo $INFANTS->id; ?>&amp;page=<?php echo $page.(isset($_GET['keys']) ? '&amp;keys='.$_GET['keys'] : '').(isset($_GET['orderby']) ? '&amp;orderby='.$_GET['orderby'] : '').(isset($_GET['status']) ? '&amp;status='.$_GET['status'] : ''); ?>"<?php echo (isset($_GET['cat']) && mc_digitSan($_GET['cat'])==$INFANTS->id ? ' selected="selected"' : ''); ?>>&nbsp;&nbsp;- <?php echo mc_cleanDataEnt($INFANTS->catname); ?></option>
  <?php
  }
  }
  }
  ?>
  </select></div>
  <div class="topRight"><form method="get" action="index.php"><p><input type="hidden" name="p" value="manage-products" /><?php echo $msg_productmanage4; ?>: <input type="text" name="keys" class="box" value="<?php echo (isset($_GET['keys']) ? mc_cleanDataEnt($_GET['keys']) : $msg_productmanage3); ?>" onclick="this.value=''" style="width:50%" /> <input type="submit" class="formbutton" value="<?php echo mc_cleanDataEnt($msg_productmanage10); ?>" title="<?php echo mc_cleanDataEnt($msg_productmanage10); ?>" /></p></form></div>
  <br class="clear" />
</div>

<div class="salesTopFilter">
  <p>
    <span class="float">
    <?php echo $msg_productmanage34; ?>: <select onchange="if(this.value!= 0){location=this.options[this.selectedIndex].value}">
    <option value="?p=manage-products&amp;orderby=name_asc&amp;page=<?php echo $page.(isset($_GET['keys']) ? '&amp;keys='.$_GET['keys'] : '').(isset($_GET['cat']) ? '&amp;cat='.$_GET['cat'] : '').(isset($_GET['status']) ? '&amp;status='.$_GET['status'] : ''); ?>"<?php echo (isset($_GET['orderby']) && $_GET['orderby']=='name_asc' ? ' selected="selected"' : ''); ?>><?php echo $msg_productmanage30; ?></option>
    <option value="?p=manage-products&amp;orderby=name_desc&amp;page=<?php echo $page.(isset($_GET['keys']) ? '&amp;keys='.$_GET['keys'] : '').(isset($_GET['cat']) ? '&amp;cat='.$_GET['cat'] : '').(isset($_GET['status']) ? '&amp;status='.$_GET['status'] : ''); ?>"<?php echo (isset($_GET['orderby']) && $_GET['orderby']=='name_desc' ? ' selected="selected"' : ''); ?>><?php echo $msg_productmanage31; ?></option>
    <option value="?p=manage-products&amp;orderby=id_asc&amp;page=<?php echo $page.(isset($_GET['keys']) ? '&amp;keys='.$_GET['keys'] : '').(isset($_GET['cat']) ? '&amp;cat='.$_GET['cat'] : '').(isset($_GET['status']) ? '&amp;status='.$_GET['status'] : ''); ?>"<?php echo (isset($_GET['orderby']) && $_GET['orderby']=='id_asc' ? ' selected="selected"' : ''); ?>><?php echo $msg_productmanage25; ?></option>
    <option value="?p=manage-products&amp;orderby=id_desc&amp;page=<?php echo $page.(isset($_GET['keys']) ? '&amp;keys='.$_GET['keys'] : '').(isset($_GET['cat']) ? '&amp;cat='.$_GET['cat'] : '').(isset($_GET['status']) ? '&amp;status='.$_GET['status'] : ''); ?>"<?php echo (isset($_GET['orderby']) && $_GET['orderby']=='id_desc' ? ' selected="selected"' : ''); ?>><?php echo $msg_productmanage24; ?></option>
    <option value="?p=manage-products&amp;orderby=price_asc&amp;page=<?php echo $page.(isset($_GET['keys']) ? '&amp;keys='.$_GET['keys'] : '').(isset($_GET['cat']) ? '&amp;cat='.$_GET['cat'] : '').(isset($_GET['status']) ? '&amp;status='.$_GET['status'] : ''); ?>"<?php echo (isset($_GET['orderby']) && $_GET['orderby']=='price_asc' ? ' selected="selected"' : ''); ?>><?php echo $msg_productmanage35; ?></option>
    <option value="?p=manage-products&amp;orderby=price_desc&amp;page=<?php echo $page.(isset($_GET['keys']) ? '&amp;keys='.$_GET['keys'] : '').(isset($_GET['cat']) ? '&amp;cat='.$_GET['cat'] : '').(isset($_GET['status']) ? '&amp;status='.$_GET['status'] : ''); ?>"<?php echo (isset($_GET['orderby']) && $_GET['orderby']=='price_desc' ? ' selected="selected"' : ''); ?>><?php echo $msg_productmanage36; ?></option>
    <option value="?p=manage-products&amp;orderby=stock_asc&amp;page=<?php echo $page.(isset($_GET['keys']) ? '&amp;keys='.$_GET['keys'] : '').(isset($_GET['cat']) ? '&amp;cat='.$_GET['cat'] : '').(isset($_GET['status']) ? '&amp;status='.$_GET['status'] : ''); ?>"<?php echo (isset($_GET['orderby']) && $_GET['orderby']=='stock_asc' ? ' selected="selected"' : ''); ?>><?php echo $msg_productmanage26; ?></option>
    <option value="?p=manage-products&amp;orderby=stock_desc&amp;page=<?php echo $page.(isset($_GET['keys']) ? '&amp;keys='.$_GET['keys'] : '').(isset($_GET['cat']) ? '&amp;cat='.$_GET['cat'] : '').(isset($_GET['status']) ? '&amp;status='.$_GET['status'] : ''); ?>"<?php echo (isset($_GET['orderby']) && $_GET['orderby']=='stock_desc' ? ' selected="selected"' : ''); ?>><?php echo $msg_productmanage27; ?></option>
    <option value="?p=manage-products&amp;orderby=hits_asc&amp;page=<?php echo $page.(isset($_GET['keys']) ? '&amp;keys='.$_GET['keys'] : '').(isset($_GET['cat']) ? '&amp;cat='.$_GET['cat'] : '').(isset($_GET['status']) ? '&amp;status='.$_GET['status'] : ''); ?>"<?php echo (isset($_GET['orderby']) && $_GET['orderby']=='hits_asc' ? ' selected="selected"' : ''); ?>><?php echo $msg_productmanage29; ?></option>
    <option value="?p=manage-products&amp;orderby=hits_desc&amp;page=<?php echo $page.(isset($_GET['keys']) ? '&amp;keys='.$_GET['keys'] : '').(isset($_GET['cat']) ? '&amp;cat='.$_GET['cat'] : '').(isset($_GET['status']) ? '&amp;status='.$_GET['status'] : ''); ?>"<?php echo (isset($_GET['orderby']) && $_GET['orderby']=='hits_desc' ? ' selected="selected"' : ''); ?>><?php echo $msg_productmanage28; ?></option>
    </select>
    </span>
    <?php echo $msg_productmanage32; ?>:
    <select onchange="if(this.value!= 0){location=this.options[this.selectedIndex].value}">
    <option value="?p=manage-products<?php echo (isset($_GET['keys']) ? '&amp;keys='.$_GET['keys'] : '').(isset($_GET['cat']) ? '&amp;cat='.$_GET['cat'] : '').(isset($_GET['orderby']) ? '&amp;orderby='.$_GET['orderby'] : ''); ?>"><?php echo $msg_productmanage33; ?></option>
    <option value="?p=manage-products&amp;status=yes&amp;page=<?php echo $page.(isset($_GET['keys']) ? '&amp;keys='.$_GET['keys'] : '').(isset($_GET['cat']) ? '&amp;cat='.$_GET['cat'] : '').(isset($_GET['orderby']) ? '&amp;orderby='.$_GET['orderby'] : ''); ?>"<?php echo (isset($_GET['status']) && $_GET['status']=='yes' ? ' selected="selected"' : ''); ?>><?php echo $msg_productmanage48; ?></option>
    <option value="?p=manage-products&amp;status=no&amp;page=<?php echo $page.(isset($_GET['keys']) ? '&amp;keys='.$_GET['keys'] : '').(isset($_GET['cat']) ? '&amp;cat='.$_GET['cat'] : '').(isset($_GET['orderby']) ? '&amp;orderby='.$_GET['orderby'] : ''); ?>"<?php echo (isset($_GET['status']) && $_GET['status']=='no' ? ' selected="selected"' : ''); ?>><?php echo $msg_productmanage49; ?></option>
    <option value="?p=manage-products&amp;status=puryes&amp;page=<?php echo $page.(isset($_GET['keys']) ? '&amp;keys='.$_GET['keys'] : '').(isset($_GET['cat']) ? '&amp;cat='.$_GET['cat'] : '').(isset($_GET['orderby']) ? '&amp;orderby='.$_GET['orderby'] : ''); ?>"<?php echo (isset($_GET['status']) && $_GET['status']=='puryes' ? ' selected="selected"' : ''); ?>><?php echo $msg_productmanage44; ?></option>
    <option value="?p=manage-products&amp;status=purno&amp;page=<?php echo $page.(isset($_GET['keys']) ? '&amp;keys='.$_GET['keys'] : '').(isset($_GET['cat']) ? '&amp;cat='.$_GET['cat'] : '').(isset($_GET['orderby']) ? '&amp;orderby='.$_GET['orderby'] : ''); ?>"<?php echo (isset($_GET['status']) && $_GET['status']=='purno' ? ' selected="selected"' : ''); ?>><?php echo $msg_productmanage43; ?></option>
    <option value="?p=manage-products&amp;status=disyes&amp;page=<?php echo $page.(isset($_GET['keys']) ? '&amp;keys='.$_GET['keys'] : '').(isset($_GET['cat']) ? '&amp;cat='.$_GET['cat'] : '').(isset($_GET['orderby']) ? '&amp;orderby='.$_GET['orderby'] : ''); ?>"<?php echo (isset($_GET['status']) && $_GET['status']=='disyes' ? ' selected="selected"' : ''); ?>><?php echo $msg_productmanage45; ?></option>
    <option value="?p=manage-products&amp;status=disno&amp;page=<?php echo $page.(isset($_GET['keys']) ? '&amp;keys='.$_GET['keys'] : '').(isset($_GET['cat']) ? '&amp;cat='.$_GET['cat'] : '').(isset($_GET['orderby']) ? '&amp;orderby='.$_GET['orderby'] : ''); ?>"<?php echo (isset($_GET['status']) && $_GET['status']=='disno' ? ' selected="selected"' : ''); ?>><?php echo $msg_productmanage46; ?></option>
    <option value="?p=manage-products&amp;status=down&amp;page=<?php echo $page.(isset($_GET['keys']) ? '&amp;keys='.$_GET['keys'] : '').(isset($_GET['cat']) ? '&amp;cat='.$_GET['cat'] : '').(isset($_GET['orderby']) ? '&amp;orderby='.$_GET['orderby'] : ''); ?>"<?php echo (isset($_GET['status']) && $_GET['status']=='down' ? ' selected="selected"' : ''); ?>><?php echo $msg_productmanage41; ?></option>
    <option value="?p=manage-products&amp;status=ship&amp;page=<?php echo $page.(isset($_GET['keys']) ? '&amp;keys='.$_GET['keys'] : '').(isset($_GET['cat']) ? '&amp;cat='.$_GET['cat'] : '').(isset($_GET['orderby']) ? '&amp;orderby='.$_GET['orderby'] : ''); ?>"<?php echo (isset($_GET['status']) && $_GET['status']=='ship' ? ' selected="selected"' : ''); ?>><?php echo $msg_productmanage42; ?></option>
    <option value="?p=manage-products&amp;status=video&amp;page=<?php echo $page.(isset($_GET['keys']) ? '&amp;keys='.$_GET['keys'] : '').(isset($_GET['cat']) ? '&amp;cat='.$_GET['cat'] : '').(isset($_GET['orderby']) ? '&amp;orderby='.$_GET['orderby'] : ''); ?>"<?php echo (isset($_GET['status']) && $_GET['status']=='video' ? ' selected="selected"' : ''); ?>><?php echo $msg_productmanage47; ?></option>
    <option value="?p=manage-products&amp;status=minqty&amp;page=<?php echo $page.(isset($_GET['keys']) ? '&amp;keys='.$_GET['keys'] : '').(isset($_GET['cat']) ? '&amp;cat='.$_GET['cat'] : '').(isset($_GET['orderby']) ? '&amp;orderby='.$_GET['orderby'] : ''); ?>"<?php echo (isset($_GET['status']) && $_GET['status']=='minqty' ? ' selected="selected"' : ''); ?>><?php echo $msg_productmanage51; ?></option>
    <option value="?p=manage-products&amp;status=restricted&amp;page=<?php echo $page.(isset($_GET['keys']) ? '&amp;keys='.$_GET['keys'] : '').(isset($_GET['cat']) ? '&amp;cat='.$_GET['cat'] : '').(isset($_GET['orderby']) ? '&amp;orderby='.$_GET['orderby'] : ''); ?>"<?php echo (isset($_GET['status']) && $_GET['status']=='restricted' ? ' selected="selected"' : ''); ?>><?php echo $msg_productmanage56; ?></option>
    <option value="?p=manage-products&amp;status=notes&amp;page=<?php echo $page.(isset($_GET['keys']) ? '&amp;keys='.$_GET['keys'] : '').(isset($_GET['cat']) ? '&amp;cat='.$_GET['cat'] : '').(isset($_GET['orderby']) ? '&amp;orderby='.$_GET['orderby'] : ''); ?>"<?php echo (isset($_GET['status']) && $_GET['status']=='notes' ? ' selected="selected"' : ''); ?>><?php echo $msg_productmanage65; ?></option>
    <?php
	// Show only if Maian Cube enabled..
	if ($SETTINGS->cubeAPI && $SETTINGS->cubeUrl) {
	?>
	<option value="?p=manage-products&amp;status=cube&amp;page=<?php echo $page.(isset($_GET['keys']) ? '&amp;keys='.$_GET['keys'] : '').(isset($_GET['cat']) ? '&amp;cat='.$_GET['cat'] : '').(isset($_GET['orderby']) ? '&amp;orderby='.$_GET['orderby'] : ''); ?>"<?php echo (isset($_GET['status']) && $_GET['status']=='cube' ? ' selected="selected"' : ''); ?>><?php echo $msg_productmanage68; ?></option>
    <?php
    }
	?>
	<option value="?p=manage-products&amp;status=offer&amp;page=<?php echo $page.(isset($_GET['keys']) ? '&amp;keys='.$_GET['keys'] : '').(isset($_GET['cat']) ? '&amp;cat='.$_GET['cat'] : '').(isset($_GET['orderby']) ? '&amp;orderby='.$_GET['orderby'] : ''); ?>"<?php echo (isset($_GET['status']) && $_GET['status']=='offer' ? ' selected="selected"' : ''); ?>><?php echo $msg_productmanage50; ?></option>
    </select>
  </p>
</div>

<div id="formField">
<form method="post" action="?p=add-product&amp;edit=batch-mode">
<div class="fieldHeadWrapper">
  <p><span class="float"><?php echo $msg_productmanage2; ?>: <b><?php echo $countedRows; ?></b></span><?php echo $msg_productmanage; ?>:</p>
</div>
<?php
if (mysql_num_rows($q_prod)>0) {
while ($PRODUCTS = mysql_fetch_object($q_prod)) {
$img = storeProductImg($PRODUCTS->pid,$PRODUCTS);
?>
<div class="productWrapper">
  <div class="productWrapper_inner">
   <div class="innerLeft">
    <p><?php echo $img; ?></p>
   </div>
   <div class="innerRight">
    <div class="product"><span><?php echo ($PRODUCTS->pOffer>0 ? '<del>'.mc_currencyFormat(mc_formatPrice($PRODUCTS->pPrice)).'</del> '.mc_currencyFormat(mc_formatPrice($PRODUCTS->pOffer)) : mc_currencyFormat(mc_formatPrice($PRODUCTS->pPrice))); ?></span><?php echo mc_cleanDataEnt($PRODUCTS->pName); ?></div>
    <br class="clear" />
    <p class="status_middle"><?php echo $msg_productmanage18; ?>: <?php echo $PRODUCTS->pCode; ?> | <?php echo $msg_productmanage67; ?>: <?php echo $PRODUCTS->pid; ?> | <?php echo $msg_productmanage11; ?>: <?php echo $PRODUCTS->adate; ?> | <?php echo $msg_productmanage13; ?>: <?php echo ($PRODUCTS->pStock>0 ? number_format($PRODUCTS->pStock) : '0'); ?> | <?php echo $msg_productmanage21; ?>: <?php echo ($PRODUCTS->pVisits>0 ? number_format($PRODUCTS->pVisits) : '0'); ?> <a class="notes" href="?p=manage-products&amp;notes=<?php echo $PRODUCTS->pid; ?>" onclick="mc_Window(this.href,'<?php echo GREYBOX_NOTES_HEIGHT; ?>','<?php echo GREYBOX_NOTES_WIDTH; ?>',this.title);return false;" title="<?php echo mc_cleanDataEnt($msg_productmanage62); ?>"><?php echo $msg_productmanage62; ?></a></p>
    <p class="status"><span onclick="mc_enableDisableProduct('<?php echo $PRODUCTS->pid; ?>')" id="endis_<?php echo $PRODUCTS->pid; ?>" style="cursor:pointer" title="<?php echo mc_cleanDataEnt($PRODUCTS->pEnable=='yes' ? $msg_productmanage39 : $msg_productmanage38); ?>"><?php echo ($PRODUCTS->pEnable=='yes' ? $msg_productmanage22 : $msg_productmanage23); ?></span></p>
   </div>
   <br class="clear" />
  </div>
  <p class="panel">
    <span class="checkbox">
     <input type="checkbox" name="productIDs[]" value="<?php echo $PRODUCTS->pid; ?>" />
    </span>
    <?php
    $PRODUCTS->pName = str_replace("'","\'",mc_cleanDataEnt($PRODUCTS->pName));
    if ($uDel=='yes') {
    ?>
    <a class="delete" href="?p=manage-products&amp;delete=<?php echo $PRODUCTS->pid; ?>" onclick="return confirmMessage('<?php echo str_replace('{product}',mc_cleanDataEnt($PRODUCTS->pName),$msg_javascript85); ?>')" title="<?php echo mc_cleanDataEnt($msg_script10); ?>"><?php echo $msg_script10; ?></a>
    <?php
    }
    ?>
    <a class="view" href="../?pID=<?php echo $PRODUCTS->pid; ?>" title="<?php echo mc_cleanDataEnt($msg_productmanage8); ?>" onclick="window.open(this);return false"><?php echo $msg_productmanage8; ?></a>
    <a class="related" href="?p=product-related&amp;product=<?php echo $PRODUCTS->pid; ?>" title="<?php echo mc_cleanDataEnt($msg_productmanage17); ?> (<?php echo mc_rowCount('prod_relation WHERE `product` = \''.$PRODUCTS->pid.'\''); ?>)"><?php echo $msg_productmanage17; ?></a>
    <?php
	if (PRODUCT_MP3_PREVIEWS) {
	?>
	<a class="mp3" href="?p=product-mp3&amp;product=<?php echo $PRODUCTS->pid; ?>" title="<?php echo mc_cleanDataEnt($msg_productmanage19); ?> (<?php echo mc_rowCount('mp3 WHERE `product_id` = \''.$PRODUCTS->pid.'\''); ?>)"><?php echo $msg_productmanage19; ?></a>
    <?php
	}
    if ($PRODUCTS->pDownload=='no') {
    ?>
    <a class="pers" href="?p=product-personalisation&amp;product=<?php echo $PRODUCTS->pid; ?>" title="<?php echo mc_cleanDataEnt($msg_productmanage20); ?> (<?php echo mc_rowCount('personalisation WHERE `productID` = \''.$PRODUCTS->pid.'\''); ?>)"><?php echo $msg_productmanage20; ?></a>
    <?php
    }
    ?>
    <a class="pictures" href="?p=product-pictures&amp;product=<?php echo $PRODUCTS->pid; ?>" title="<?php echo mc_cleanDataEnt($msg_productmanage14); ?> (<?php echo mc_rowCount('pictures WHERE `product_id` = \''.$PRODUCTS->pid.'\''); ?>)"><?php echo $msg_productmanage14; ?></a>
    <a class="attributes" href="?p=product-attributes&amp;product=<?php echo $PRODUCTS->pid; ?>" title="<?php echo mc_cleanDataEnt($msg_productmanage7); ?> (<?php echo mc_rowCount('attributes WHERE `productID` = \''.$PRODUCTS->pid.'\''); ?>)"><?php echo $msg_productmanage7; ?></a>
    <a class="copy" href="?p=add-product&amp;copyp=<?php echo $PRODUCTS->pid; ?>" title="<?php echo mc_cleanDataEnt($msg_productmanage6); ?>"><?php echo $msg_productmanage6; ?></a>
    <a class="edit" href="?p=add-product&amp;edit=<?php echo $PRODUCTS->pid; ?>" title="<?php echo mc_cleanDataEnt($msg_script9); ?>"><?php echo $msg_script9; ?></a>
    <br class="clear" />
  </p>
</div>
<?php
}
define('PER_PAGE',PRODUCTS_PER_PAGE);
if ($countedRows>0 && $countedRows>PER_PAGE) {
  $PTION = new pagination($countedRows,'?p='.$cmd.mswQueryParams(array('p','next')).'&amp;next=');
  echo $PTION->display();
}
} else {
?>
<span class="noData"><?php echo $msg_productmanage15; ?></span>
<?php
}
if ($countedRows>0) {
?>
<p style="padding:20px 0 0 10px">
<input type="checkbox" name="all" value="all" onclick="toggleCheckBoxesID(this.checked,'formField')" />&nbsp;&nbsp;&nbsp;
<input type="submit" value="<?php echo mc_cleanDataEnt($msg_productmanage52); ?>" title="<?php echo mc_cleanDataEnt($msg_productmanage52); ?>" class="formbutton" />
</p>
<?php
}
?>
</form>
</div>

<p>&nbsp;</p>
<p>&nbsp;</p>
</div>
