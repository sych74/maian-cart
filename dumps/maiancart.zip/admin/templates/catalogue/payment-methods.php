<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } 
$noneGateway = array(7,8,9,10);
?>
<div id="content">

<?php 
if (isset($OK)) {
  echo actionCompleted($msg_settings111);
}
echo $msg_settings37; 
?><br /><br />

<div class="fieldHeadWrapper">
  <p><span class="float"><a href="?p=payment-methods&amp;enable=1" onclick="return confirmMessage('<?php echo mc_cleanDataEnt($msg_javascript45); ?>')" title="<?php echo mc_cleanDataEnt($msg_settings109); ?>"><?php echo $msg_settings109; ?></a> | <a href="?p=payment-methods&amp;disable=1" onclick="return confirmMessage('<?php echo mc_cleanDataEnt($msg_javascript45); ?>')" title="<?php echo mc_cleanDataEnt($msg_settings110); ?>"><?php echo $msg_settings110; ?></a></span><?php echo $msg_paymethods36.' ('.(count($mcSystemPaymentMethods)-count($noneGateway)).')'; ?>:</p>
</div>

<?php
foreach ($mcSystemPaymentMethods AS $k => $v) {
if (!in_array($v['ID'],$noneGateway)) {
?>
<div class="payMethod">

  <div class="image">
    <p>
      <?php
      if ($v['web']) {
      ?>
      <a href="<?php echo $v['web']; ?>" onclick="window.open(this);return false"><img src="templates/images/methods/<?php echo $v['img']; ?>" alt="<?php echo mc_cleanDataEnt($v['lang']); ?>" title="<?php echo mc_cleanDataEnt($v['lang']); ?>"  /></a>
      <?php
      } else {
      ?>
      <img src="templates/images/methods/<?php echo $v['img']; ?>" alt="<?php echo mc_cleanDataEnt($v['lang']); ?>" title="<?php echo mc_cleanDataEnt($v['lang']); ?>"  />
      <?php
      }
      ?>
    </p>
  </div>
  
  <div class="method">
    <p>
     <?php echo $v['lang']; ?>
    </p>
  </div>
  
  <div class="status">
    <p><?php echo $msg_settings73; ?>: <b><?php echo ($v['enable']=='yes' ? $msg_settings71 : $msg_settings72); ?></b></p>
  </div>
  
  <div class="enabled">
    <p><img src="templates/images/<?php echo ($v['enable']=='yes' ? 'method_enabled.png' : 'method_disabled.png'); ?>" alt="<?php echo mc_cleanDataEnt(($v['enable']=='yes' ? $msg_settings71 : $msg_settings72)); ?>" title="<?php echo mc_cleanDataEnt(($v['enable']=='yes' ? $msg_settings71 : $msg_settings72)); ?>" /></p>
  </div>
  
  <div class="link">
    <p>
     <?php
     if (DISPLAY_HELP_LINK) {
     ?>
     <a href="../docs/<?php echo $v['docs']; ?>.html" onclick="window.open(this);return false"><img src="templates/images/docs.png" alt="<?php echo mc_cleanDataEnt($v['lang'].' - '.$msg_settings176); ?>" title="<?php echo mc_cleanDataEnt($v['lang'].' - '.$msg_settings176); ?>" style="margin:0 20px 0 0" /></a>
     <?php
     }
     ?>
     <a href="?p=payment-methods&amp;conf=<?php echo $k; ?>"><img src="templates/images/configuration.png" alt="<?php echo mc_cleanDataEnt($v['lang'].' - '.$msg_settings74); ?>" title="<?php echo mc_cleanDataEnt($v['lang'].' - '.$msg_settings74); ?>" /></a></p>
  </div>
  
  <br class="clear" />
 
</div>
<?php
}
}
?>

<div class="fieldHeadWrapper" style="margin-top:10px">
  <p><?php echo $msg_paymethods37.' ('.count($noneGateway).')'; ?>:</p>
</div>

<?php
foreach ($mcSystemPaymentMethods AS $k => $v) {
if (in_array($v['ID'],$noneGateway)) {
?>
<div class="payMethod">

  <div class="image">
    <p>
      <?php
      if ($v['web']) {
      ?>
      <a href="<?php echo $v['web']; ?>" onclick="window.open(this);return false"><img src="templates/images/methods/<?php echo $v['img']; ?>" alt="<?php echo mc_cleanDataEnt($v['lang']); ?>" title="<?php echo mc_cleanDataEnt($v['lang']); ?>"  /></a>
      <?php
      } else {
      ?>
      <img src="templates/images/methods/<?php echo $v['img']; ?>" alt="<?php echo mc_cleanDataEnt($v['lang']); ?>" title="<?php echo mc_cleanDataEnt($v['lang']); ?>"  />
      <?php
      }
      ?>
    </p>
  </div>
  
  <div class="method">
    <p>
     <?php echo $v['lang']; ?>
    </p>
  </div>
  
  <div class="status">
    <p><?php echo $msg_settings73; ?>: <b><?php echo ($v['enable']=='yes' ? $msg_settings71 : $msg_settings72); ?></b></p>
  </div>
  
  <div class="enabled">
    <p><img src="templates/images/<?php echo ($v['enable']=='yes' ? 'method_enabled.png' : 'method_disabled.png'); ?>" alt="<?php echo mc_cleanDataEnt(($v['enable']=='yes' ? $msg_settings71 : $msg_settings72)); ?>" title="<?php echo mc_cleanDataEnt(($v['enable']=='yes' ? $msg_settings71 : $msg_settings72)); ?>" /></p>
  </div>
  
  <div class="link">
    <p>
     <?php
     if (DISPLAY_HELP_LINK) {
     ?>
     <a href="../docs/<?php echo $v['docs']; ?>.html" onclick="window.open(this);return false"><img src="templates/images/docs.png" alt="<?php echo mc_cleanDataEnt($v['lang'].' - '.$msg_settings176); ?>" title="<?php echo mc_cleanDataEnt($v['lang'].' - '.$msg_settings176); ?>" style="margin:0 20px 0 0" /></a>
     <?php
     }
     ?>
     <a href="?p=payment-methods&amp;conf=<?php echo $k; ?>"><img src="templates/images/configuration.png" alt="<?php echo mc_cleanDataEnt($v['lang'].' - '.$msg_settings74); ?>" title="<?php echo mc_cleanDataEnt($v['lang'].' - '.$msg_settings74); ?>" /></a></p>
  </div>
  
  <br class="clear" />
 
</div>
<?php
}
}
?>

<p>&nbsp;</p>
<p>&nbsp;</p>
</div>
