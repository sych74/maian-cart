<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } 
if (isset($_GET['edit'])) {
  $EDIT  = mc_getTableData('brands','id',mc_digitSan($_GET['edit']));
}
?>
<div id="content">

<?php
if (isset($OK)) {
  echo actionCompleted($msg_brand5);
}
if (isset($OKB)) {
  echo actionCompleted(str_replace('{count}',$count,$msg_brand14));
}
if (isset($OK2)) {
  echo actionCompleted($msg_brand9);
}
if (isset($OK3) && $cnt>0) {
  echo actionCompleted($msg_brand10);
}
?>

<?php echo $msg_brand11; ?><br /><br />

<form method="post" id="form" action="?p=brands<?php echo (isset($EDIT->id) ? '&amp;edit='.$EDIT->id : ''); ?>"<?php echo (!isset($_GET['edit']) ? ' enctype="multipart/form-data"' : ''); ?>>
<div class="fieldHeadWrapper">
  <p>
  <?php
  echo (isset($EDIT->enBrand) ? $msg_brand6 : $msg_brand); ?>:</p>
</div>

<div class="formFieldWrapperBrands" id="row">
  <div class="formLeft" style="width:39%">
    <label><?php echo $msg_brand2; ?>: <?php echo mc_displayHelpTip($msg_javascript159,'RIGHT'); ?></label>
    <input type="text" name="name" tabindex="<?php echo (++$tabIndex); ?>" value="<?php echo (isset($EDIT->name) ? mc_cleanData($EDIT->name) : ''); ?>" maxlength="250" class="box" /><br /><br />
    <?php
    if (!isset($_GET['edit'])) {
    ?>
    <label><?php echo $msg_brand13; ?>: <?php echo mc_displayHelpTip($msg_javascript316,'RIGHT'); ?></label>
    <input type="file" name="file" tabindex="<?php echo (++$tabIndex); ?>" value="<?php echo (isset($EDIT->name) ? mc_cleanData($EDIT->name) : ''); ?>" maxlength="250" class="box" /><br /><br />
    <?php
    }
    ?>
    <label><?php echo $msg_brand8; ?>: <?php echo mc_displayHelpTip($msg_javascript160,'RIGHT'); ?></label>
    <?php echo $msg_script5; ?> <input tabindex="<?php echo (++$tabIndex); ?>" type="radio" name="enBrand" value="yes"<?php echo (isset($EDIT->enBrand) && $EDIT->enBrand=='yes' ? ' checked="checked"' : (!isset($EDIT->enBrand) ? ' checked="checked"' : '')); ?> /> <?php echo $msg_script6; ?> <input type="radio" tabindex="<?php echo (++$tabIndex); ?>" name="enBrand" value="no"<?php echo (isset($EDIT->enBrand) && $EDIT->enBrand=='no' ? ' checked="checked"' : ''); ?> />
  </div>
  <div class="formRight" style="width:60%">  
    <label><?php echo $msg_productadd5; ?>: <?php echo mc_displayHelpTip($msg_javascript161); ?></label>
    <div class="categoryBoxes">
    <?php
    if (!isset($EDIT->id)) {
    ?>
    <input type="checkbox" name="bCat[]" tabindex="<?php echo (++$tabIndex); ?>" value="all" onclick="if(this.checked){jQuery('#catBrandList').hide()}else{jQuery('#catBrandList').show()}" /> <b><?php echo $msg_productadd35; ?></b><br />
	<?php
    } else {
    ?>
	<input type="radio" name="bCat[]" tabindex="<?php echo (++$tabIndex); ?>" value="all"<?php echo (isset($EDIT->bCat) && $EDIT->bCat=='all' ? ' checked="checked"' : ''); ?> /> <b><?php echo $msg_productadd35; ?></b><br />
	<?php
	}
	?>
	<div id="catBrandList">
    <?php
	$q_cats = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
              WHERE catLevel = '1'
              AND childOf    = '0'
              AND enCat      = 'yes'
              ORDER BY catname") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($CATS = mysql_fetch_object($q_cats)) {
    ?>
    <p id="cat_<?php echo $CATS->id; ?>"><input onclick="if(this.checked){selectChildren('cat_<?php echo $CATS->id; ?>','on')}else{selectChildren('cat_<?php echo $CATS->id; ?>','off')}" tabindex="<?php echo (++$tabIndex); ?>" type="<?php echo (isset($EDIT->id) ? 'radio' : 'checkbox'); ?>" name="bCat[]" value="<?php echo $CATS->id; ?>"<?php echo (isset($EDIT->bCat) && $EDIT->bCat==$CATS->id ? ' checked="checked"' : ''); ?> /> <?php echo mc_cleanDataEnt($CATS->catname); ?><br />
    <?php
    $q_children = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
                  WHERE catLevel = '2'
                  AND enCat      = 'yes'
                  AND childOf    = '".$CATS->id."'
                  ORDER BY catname
                  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($CHILDREN = mysql_fetch_object($q_children)) {
    ?>
    <span id="child_<?php echo $CHILDREN->id; ?>">
    &nbsp;&nbsp;<input tabindex="<?php echo (++$tabIndex); ?>" onclick="if(this.checked){selectChildren('child_<?php echo $CHILDREN->id; ?>','on')}else{selectChildren('child_<?php echo $CHILDREN->id; ?>','off')}" type="<?php echo (isset($EDIT->id) ? 'radio' : 'checkbox'); ?>" name="bCat[]" value="<?php echo $CHILDREN->id; ?>"<?php echo (isset($EDIT->bCat) && $EDIT->bCat==$CHILDREN->id ? ' checked="checked"' : ''); ?> /> <?php echo mc_cleanDataEnt($CHILDREN->catname); ?><br />
    <?php
    $q_infants = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
                  WHERE catLevel = '3'
                  AND childOf    = '{$CHILDREN->id}'
                  AND enCat      = 'yes'
                  ORDER BY catname
                  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($INFANTS = mysql_fetch_object($q_infants)) {
    ?>
    &nbsp;&nbsp;&nbsp;&nbsp;<input tabindex="<?php echo (++$tabIndex); ?>" type="<?php echo (isset($EDIT->id) ? 'radio' : 'checkbox'); ?>" name="bCat[]" value="<?php echo $INFANTS->id; ?>"<?php echo (isset($EDIT->bCat) && $EDIT->bCat==$INFANTS->id ? ' checked="checked"' : ''); ?> /> <?php echo mc_cleanDataEnt($INFANTS->catname); ?><br />
    <?php
    }
    ?>
    </span>
    <?php
    }
    ?>
    </p>
    <?php
    }
    ?>
	</div>
    </div>
  </div>
  <br class="clear" />
</div>

<p style="text-align:center;padding-top:20px">
 <input type="hidden" name="<?php echo (isset($EDIT->enBrand) ? 'update' : 'process'); ?>" value="<?php echo (isset($EDIT->enBrand) ? $EDIT->id : 'yes'); ?>" />
 <input class="formbutton" type="submit" value="<?php echo mc_cleanDataEnt((isset($EDIT->enBrand) ? $msg_brand6 : $msg_brand)); ?>" title="<?php echo mc_cleanDataEnt((isset($EDIT->enBrand) ? $msg_brand6 : $msg_brand)); ?>" /><?php echo (isset($EDIT->id) ? '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input class="formbutton2" type="button" onclick="window.location=\'?p=brands\'" value="'.mc_cleanDataEnt($msg_script11).'" title="'.mc_cleanDataEnt($msg_script11).'" />' : ''); ?>
</p>
</form><br />

<div class="fieldHeadWrapper">
  <p style="text-align:right"><span style="float:left;display:block;padding:3px 0 0 0"><?php echo $msg_brand4; ?>:</span>
  <?php echo $msg_brand16; ?>: <select onchange="if(this.value!= 0){location=this.options[this.selectedIndex].value}">
  <option value="?p=brands"><?php echo $msg_brand17; ?></option>
  <?php
  $q_cats = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
            WHERE catLevel = '1'
            AND childOf    = '0'
            AND enCat      = 'yes'
            ORDER BY catname") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  while ($CATS = mysql_fetch_object($q_cats)) {
  ?>
  <option value="?p=brands&amp;cat=<?php echo $CATS->id; ?>"<?php echo (isset($_GET['cat']) && mc_digitSan($_GET['cat'])==$CATS->id ? ' selected="selected"' : ''); ?>><?php echo mc_cleanDataEnt($CATS->catname); ?></option>
  <?php
  $q_children = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
                WHERE catLevel = '2'
                AND enCat      = 'yes'
                AND childOf    = '".$CATS->id."'
                ORDER BY catname") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  while ($CHILDREN = mysql_fetch_object($q_children)) {
  ?>
  <option value="?p=brands&amp;cat=<?php echo $CHILDREN->id; ?>"<?php echo (isset($_GET['cat']) && mc_digitSan($_GET['cat'])==$CHILDREN->id ? ' selected="selected"' : ''); ?>>- <?php echo mc_cleanDataEnt($CHILDREN->catname); ?></option>
  <?php
  $q_infants = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
               WHERE catLevel = '3'
               AND childOf    = '{$CHILDREN->id}'
               AND enCat      = 'yes'
               ORDER BY catname
               ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  while ($INFANTS = mysql_fetch_object($q_infants)) {
  ?>
  <option value="?p=brands&amp;cat=<?php echo $INFANTS->id; ?>"<?php echo (isset($_GET['cat']) && mc_digitSan($_GET['cat'])==$INFANTS->id ? ' selected="selected"' : ''); ?>>&nbsp;&nbsp;- <?php echo mc_cleanDataEnt($INFANTS->catname); ?></option>
  <?php
  }
  }
  }
  ?>
  </select>
  </p>
</div>

<form method="post" id="form2" action="?p=brands" onsubmit="return confirmMessage('<?php echo mc_cleanDataEnt($msg_javascript45); ?>')">
<?php
if (mc_rowCount('brands')>0) {
  $q_cats = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
            WHERE enCat = 'yes'
            ".(isset($_GET['cat']) ? 'AND id = \''.mc_digitSan($_GET['cat']).'\' OR childOf = \''.mc_digitSan($_GET['cat']).'\'' : '')."
            ORDER BY catname
            ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  while ($CATS = mysql_fetch_object($q_cats)) {
  $q_man = mysql_query("SELECT * FROM ".DB_PREFIX."brands 
           WHERE bCat IN('".$CATS->id."','all')
           ORDER BY name
           ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  if (mysql_num_rows($q_man)>0) {
  $parents = '';
  switch ($CATS->catLevel) {
    case '2':
    $CAT      = mc_getTableData('categories','id',$CATS->childOf);
    $parents  = $CAT->catname.'/';
    break;
    case '3':
    $INF      = mc_getTableData('categories','id',$CATS->childOf);
    $CAT      = mc_getTableData('categories','id',$INF->childOf);
    $parents  = $CAT->catname.'/'.$INF->catname.'/';
    break;
  }
  $rCount = 0;
  ?>
  <div class="catWrapper">
    <div class="catLeft" style="width:56%"><?php echo ($uDel=='yes' ? ' <input onclick="if(this.checked){selectChildren(\'brands_'.$CATS->id.'\',\'on\')}else{selectChildren(\'brands_'.$CATS->id.'\',\'off\')}" type="checkbox" name="delcats[]" value="'.$CATS->id.'" /> ' : ''); ?><?php echo mc_cleanDataEnt($CATS->catname); ?>
    <?php
    if ($parents) {
    ?>
    <span class="parents"><?php echo $parents; ?></span>
    <?php
    }
    ?>
    </div>
    <div class="catRight" id="brands_<?php echo $CATS->id; ?>" style="width:40%;float:right;max-height:200px;overflow:auto">
    <?php
    while ($BRAND = mysql_fetch_object($q_man)) {
    ?>
    <?php echo ($uDel=='yes' ? ' <input type="checkbox" name="delete[]" value="'.$BRAND->id.'" /> ' : ''); ?><a href="?p=brands&amp;edit=<?php echo $BRAND->id; ?>" title="<?php echo mc_cleanDataEnt($msg_script9.': '.$BRAND->name); ?>"><?php echo mc_cleanDataEnt($BRAND->name); ?></a> <?php echo ($BRAND->bCat=='all' ? $msg_brand19 : ''); ?><br />
    <?php
    }
    ?>
    </div>
    <br class="clear" />
  </div>
  <?php
  }
  }
  if ($uDel=='yes') {
  ?>
  <p style="text-align:center;margin:20px 0 0 0">
  <input type="hidden" name="process_del" value="yes" />
  <input class="formbutton" type="submit" value="<?php echo mc_cleanDataEnt($msg_brand18); ?>" title="<?php echo mc_cleanDataEnt($msg_brand18); ?>" />
  </p>
  <?php
  }
} else {
?>
<p class="noData"><?php echo $msg_brand3; ?></p>
<?php
}
?>
</form>

<p>&nbsp;</p>
<p>&nbsp;</p>
</div>
