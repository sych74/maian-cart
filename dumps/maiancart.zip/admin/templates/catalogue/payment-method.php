<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } ?>
<div id="content">

<?php
if (isset($OK)) {
  echo actionCompleted($msg_settings43);
}

echo $msg_settings75; 
if ($_GET['conf']=='paymate') {
?>
<p style="margin-top:20px;background:#ff9999;color:#fff;padding:15px">PLEASE READ THE NOTE IN THE <a style="color:#fff" href="../docs/payment-17.html" onclick="window.open(this);return false">DOCS</a> BEFORE USING THIS PAYMENT METHOD</p>
<?php
}
?>
<br /><br />

<form method="post" id="form" action="?p=payment-methods&amp;conf=<?php echo $_GET['conf']; ?>">
<?php
// Load payment method..
if (file_exists(PATH.'templates/catalogue/payment-methods/'.$_GET['conf'].'.php')) {
  include(PATH.'templates/catalogue/payment-methods/'.$_GET['conf'].'.php');
} else {
  echo '<p>Failed to load template: <b>templates/catalogue/payment-methods/'.$_GET['conf'].'.php</b></p>';
}
?>
</form>

</div>
