<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } ?>
<div id="content">

<?php
if (isset($OK)) {
  echo actionCompleted($msg_prodrelated9);
}
if (isset($OK2) && $cnt>0) {
  echo actionCompleted($msg_prodrelated10);
}
?>

<?php echo $msg_prodrelated; ?><br /><br />

<div class="prodTop">
  <?php
  $P = mc_getTableData('products','id',mc_digitSan($_GET['product']));
  ?>
  <p><span class="float"><?php echo mc_cleanData($P->pName); ?></span>
  <b><?php echo $msg_productpictures14; ?></b>: 
  <select onchange="if(this.value!= 0){location=this.options[this.selectedIndex].value}">
  <option value="0">- - - -</option>
  <option value="?p=product-pictures&amp;product=<?php echo mc_digitSan($_GET['product']); ?>"><?php echo $msg_productadd38; ?></option>
  <option value="?p=add-product&amp;copyp=<?php echo mc_digitSan($_GET['product']); ?>"><?php echo $msg_productpictures16; ?></option>
  <option value="?p=add-product&amp;edit=<?php echo mc_digitSan($_GET['product']); ?>"><?php echo $msg_productpictures15; ?></option>
  <option value="?p=product-attributes&amp;product=<?php echo mc_digitSan($_GET['product']); ?>"><?php echo $msg_productpictures17; ?></option>
  <?php
  if (PRODUCT_MP3_PREVIEWS) {
  ?>
  <option value="?p=product-mp3&amp;product=<?php echo mc_digitSan($_GET['product']); ?>"><?php echo $msg_productmanage19; ?></option>
  <?php
  }
  if ($P->pDownload=='no') {
  ?>
  <option value="?p=product-personalisation&amp;product=<?php echo mc_digitSan($_GET['product']); ?>"><?php echo $msg_productmanage20; ?></option>
  <?php
  }
  ?>
  </select>
  <br class="clear" />
  </p>
</div>

<form method="post" id="form" action="?p=product-related&amp;product=<?php echo mc_digitSan($_GET['product']); ?>">
<div class="fieldHeadWrapper">
  <p><?php echo $msg_prodrelated2; ?>:</p>
</div>

<div class="formFieldWrapper">
  <div class="formLeft">
    <label><?php echo $msg_prodrelated5; ?>:</label>
    <div class="categoryBoxes">
    <?php
    $cats   = array();
    $q_cats = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
              WHERE catLevel = '1'
              AND childOf    = '0'
              AND enCat      = 'yes'
              ORDER BY catname") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($CATS = mysql_fetch_object($q_cats)) {
    $cats[] = $CATS->id;
    ?>
    <input onclick="loadProducts('cat-<?php echo $CATS->id; ?>','<?php echo mc_digitSan($_GET['product']); ?>','related')" type="radio" name="pCat" value="cat-<?php echo $CATS->id; ?>"<?php echo (count($cats)==1 ? ' checked="checked"' : ''); ?> /> <?php echo mc_cleanDataEnt($CATS->catname); ?><br />
    <?php
    $q_children = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
                  WHERE catLevel = '2'
                  AND enCat      = 'yes'
                  AND childOf    = '{$CATS->id}'
                  ORDER BY catname") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($CHILDREN = mysql_fetch_object($q_children)) {
    ?>
    &nbsp;&nbsp;<input onclick="loadProducts('child-<?php echo $CHILDREN->id; ?>','<?php echo mc_digitSan($_GET['product']); ?>','related')" type="radio" name="pCat" value="child-<?php echo $CHILDREN->id; ?>" /> <?php echo mc_cleanDataEnt($CHILDREN->catname); ?><br />
    <?php
    $q_infants = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
                  WHERE catLevel = '3'
                  AND childOf    = '{$CHILDREN->id}'
                  AND enCat      = 'yes'
                  ORDER BY catname
                  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($INFANTS = mysql_fetch_object($q_infants)) {
    ?>
    &nbsp;&nbsp;&nbsp;&nbsp;<input onclick="loadProducts('infant-<?php echo $INFANTS->id; ?>','<?php echo mc_digitSan($_GET['product']); ?>','related')" type="radio" name="pCat" value="infant-<?php echo $INFANTS->id; ?>" /> <?php echo mc_cleanDataEnt($INFANTS->catname); ?><br />
    <?php
    }
    }
    }
    ?>
    </div>
  </div>
  <div class="formRight" style="float:right">  
    <label><?php echo $msg_prodrelated6; ?>:</label>
    <div class="categoryBoxes" id="products">
    <input type="checkbox" name="log" value="all" onclick="selectAll()" /> <b><?php echo $msg_prodrelated7; ?></b><br />
    <?php
    $q_products = mysql_query("SELECT SQL_CALC_FOUND_ROWS *,".DB_PREFIX."products.id AS pid 
                  FROM ".DB_PREFIX."products
                  LEFT JOIN ".DB_PREFIX."prod_category
                  ON ".DB_PREFIX."products.id   = ".DB_PREFIX."prod_category.product
                  WHERE category                          = '".$cats[0]."'
                  AND pEnable                             = 'yes'
                  AND ".DB_PREFIX."products.id != '".mc_digitSan($_GET['product'])."' 
                  GROUP BY ".DB_PREFIX."products.id
                  ORDER BY pName
                  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($PR = mysql_fetch_object($q_products)) {
    ?>
    <input type="checkbox" name="product[]" value="<?php echo $PR->pid; ?>" /> <?php echo mc_cleanDataEnt($PR->pName); ?><br />
    <?php
    }
    ?>
    </div>
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper">
  <div class="formLeft" style="width:98%">
    <label><?php echo $msg_prodrelated12; ?>: <?php echo mc_displayHelpTip($msg_javascript381,'RIGHT'); ?></label>
    <?php echo $msg_script5; ?> <input type="radio" tabindex="6" name="mirror" value="yes" checked="checked" /> <?php echo $msg_script6; ?> <input tabindex="7" type="radio" name="mirror" value="no" />
  </div>
  <br class="clear" />
</div>  

<p style="text-align:center;padding-top:20px">
 <input type="hidden" name="process" value="yes" />
 <input class="formbutton" type="submit" value="<?php echo mc_cleanDataEnt($msg_prodrelated3); ?>" title="<?php echo mc_cleanDataEnt($msg_prodrelated3); ?>" />
</p>
</form>

<br />
<div class="fieldHeadWrapper">
  <p><?php echo $msg_prodrelated4; ?>:</p>
</div>
<?php
$q_p = mysql_query("SELECT *,".DB_PREFIX."prod_relation.id AS rid FROM ".DB_PREFIX."prod_relation
                    LEFT JOIN ".DB_PREFIX."products
                    ON ".DB_PREFIX."prod_relation.related = ".DB_PREFIX."products.id
                    WHERE product  = '".mc_digitSan($_GET['product'])."' 
                    ORDER BY pName
                    ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
if (mysql_num_rows($q_p)>0) {
while ($PROD = mysql_fetch_object($q_p)) {
?>
<div class="hitsOverviewWrapper">
 <div class="productName" style="width:75%">
  <p><a href="?p=add-product&amp;edit=<?php echo $PROD->related; ?>" title="<?php echo mc_cleanDataEnt($msg_script9.': '.mc_cleanData($PROD->pName)); ?>"><?php echo mc_cleanDataEnt($PROD->pName); ?></a></p>
 </div>
 <div class="percentage" style="width:23%">
   <p><a href="?p=product-related&amp;product=<?php echo mc_digitSan($_GET['product']); ?>&amp;del=<?php echo $PROD->rid; ?>" onclick="return confirmMessage('<?php echo mc_cleanDataEnt($msg_javascript45); ?>')"><img src="templates/images/delete.png" alt="<?php echo mc_cleanDataEnt($msg_script10); ?>" title="<?php echo mc_cleanDataEnt($msg_script10); ?>" /></a></p>
 </div>
 <br class="clear" />
</div>
<?php
}
} else {
?>
<span class="noData"><?php echo $msg_prodrelated11; ?></span>
<?php
}
?>

<p>&nbsp;</p>
<p>&nbsp;</p>
</div>
