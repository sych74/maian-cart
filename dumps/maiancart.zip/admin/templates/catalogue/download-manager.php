<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } ?>
<div id="content">

<?php
if (isset($OK)) {
  echo actionCompleted($msg_cats8);
}
if (isset($OK2)) {
  echo actionCompleted($msg_cats16);
}
if (isset($OK3) && $cnt>0) {
  echo actionCompleted($msg_cats11);
}
?>

<?php echo $msg_dlmanager; ?><br /><br />

<form method="post" action="?p=dl-manager">
<div class="fieldHeadWrapper">
  <p><span class="float">[ <a href="../docs/catalogue-12.html" onclick="window.open(this);return false" title="<?php echo mc_cleanDataEnt($msg_dlmanager6); ?>"><?php echo $msg_dlmanager6; ?></a> ]</span><?php echo $msg_dlmanager2; ?>:</p>
</div>

<div class="downloadManager">
  <?php
  if (phpVersion()>=5 && function_exists('json_encode')) {
  // Check download path..
  if (is_dir($SETTINGS->globalDownloadPath.'/'.$SETTINGS->downloadFolder) &&
      is_writeable($SETTINGS->globalDownloadPath.'/'.$SETTINGS->downloadFolder)) {
  ?>
  <script type="text/javascript" charset="utf-8">
  //<![CDATA[
  jQuery(document).ready(function() {
   var f = jQuery('#finder').elfinder({
   url : 'index.php?p=dl-manager&loadElFinder=true',
   places: '',
   view: 'list',
   disableShortcuts: true,
   <?php
   // Check delete privileges..
   if ($uDel=='yes') {
   ?>
   toolbar : [['back', 'reload'],['select', 'open'],['mkdir', 'upload'],['rename'],['rm'],['icons', 'list']],
   <?php
   } else {
   ?>
   toolbar : [['back', 'reload'],['select', 'open'],['mkdir', 'upload'],['rename'],['icons', 'list']],
   <?php
   }
   ?>
   contextmenu : {
    cwd : ['reload', 'delim', 'mkdir', 'upload', 'delim', 'info'],
	<?php
	// Check delete privileges..
	if ($uDel=='yes') {
	?>
	file : ['select', 'rm', 'delim', 'rename'],
    group : ['rm', 'delim', 'archive', 'extract', 'delim', 'info']
	<?php
	} else {
	?>
    file : ['select', 'delim', 'rename'],
    group : ['archive', 'extract', 'delim', 'info']
	<?php
	}
	?>
   },
   lang : '<?php echo (ELF_LOCALE ? strtolower(ELF_LOCALE) : 'en'); ?>',
   docked : false,
   rememberLastDir: false
   });
  });
  //]]>
	</script>
  
  <div id="finder"><!-- Load Elfinder --></div>
  
  <p style="text-align:right;font-size:10px;padding:15px 0 0 0"><?php echo $msg_script3; ?>: <a href="http://elrte.org/elfinder" onclick="window.open(this);return false" title="elFinder">elFinder</a></p>
  <?php
  } else {
  ?>
  <p class="error"><?php echo str_replace(array('{sfolder}','{spath}','{path}'),
                                          array($SETTINGS->downloadFolder,
                                                $SETTINGS->globalDownloadPath,
                                                $SETTINGS->globalDownloadPath.'/'.$SETTINGS->downloadFolder
                                          ),
                                          $msg_dlmanager7); ?></p>
  <?php
  }
  } else {
  ?>
  <p class="error"><?php echo $msg_dlmanager5; ?></p>
  <?php
  }
  ?>
</div>
</form>


<p>&nbsp;</p>
<p>&nbsp;</p>
</div>
