<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } 
if (isset($_GET['edit'])) {
  $EDIT = mc_getTableData('price_points','id',mc_digitSan($_GET['edit']));
}
?>
<div id="content">

<?php
if (isset($OK)) {
  echo actionCompleted($msg_pricepoints8);
}
if (isset($OK2)) {
  echo actionCompleted($msg_pricepoints9);
}
if (isset($OK3) && $cnt>0) {
  echo actionCompleted($msg_pricepoints10);
}
?>

<?php echo $msg_pricepoints; ?><br /><br />

<form method="post" action="?p=price-points<?php echo (isset($EDIT->id) ? '&amp;edit='.$EDIT->id : ''); ?>">
<div class="fieldHeadWrapper">
  <p><?php echo (isset($EDIT->id) ? $msg_pricepoints6 : $msg_pricepoints5); ?>:</p>
</div>

<div class="formFieldWrapper">
  <div class="formLeft" style="width:33%">
    <label><?php echo $msg_pricepoints2; ?>: <?php echo mc_displayHelpTip($msg_javascript269,'RIGHT'); ?></label>
    <input tabindex="1" type="text" name="priceFrom" value="<?php echo (isset($EDIT->priceFrom) ? mc_cleanData($EDIT->priceFrom) : '0.00'); ?>" class="box" /> 
  </div>
  <div class="formLeft" style="width:33%">
    <label><?php echo $msg_pricepoints3; ?>: <?php echo mc_displayHelpTip($msg_javascript270); ?></label>
    <input tabindex="2" type="text" name="priceTo" value="<?php echo (isset($EDIT->priceTo) ? mc_cleanData($EDIT->priceTo) : '0.00'); ?>" class="box" /> 
  </div>
  <div class="formRight" style="width:33%">
    <label><?php echo $msg_pricepoints4; ?>: <?php echo mc_displayHelpTip($msg_javascript271,'LEFT'); ?></label>
    <input tabindex="3" type="text" name="priceText" value="<?php echo (isset($EDIT->priceText) ? mc_cleanData($EDIT->priceText) : ''); ?>" class="box" maxlength="200" /> 
  </div>
  <br class="clear" />
</div>

<p style="text-align:center;padding-top:20px">
 <input type="hidden" name="<?php echo (isset($EDIT->id) ? 'update' : 'process'); ?>" value="<?php echo (isset($EDIT->id) ? $EDIT->id : 'yes'); ?>" />
 <input class="formbutton" type="submit" value="<?php echo mc_cleanDataEnt((isset($EDIT->id) ? $msg_pricepoints6 : $msg_pricepoints5)); ?>" title="<?php echo mc_cleanDataEnt((isset($EDIT->id) ? $msg_pricepoints6 : $msg_pricepoints5)); ?>" /><?php echo (isset($EDIT->id) ? '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input class="formbutton2" type="button" onclick="window.location=\'?p=price-points\'" value="'.mc_cleanDataEnt($msg_script11).'" title="'.mc_cleanDataEnt($msg_script11).'" />' : ''); ?>
</p>
</form><br />
<?php
if (mc_rowCount('price_points')>0) {
?>
<script type="text/javascript">
//<![CDATA[
jQuery(document).ready(function() {
  jQuery("#sortable").sortable({
    update : function (data) {
      jQuery("#loader").load("index.php?p=price-points&order=yes&"+jQuery('#sortable').sortable('serialize'));
      jQuery('#loader_msg').show('slow');
      jQuery('#loader_msg').html('<?php echo mc_cleanDataEnt($msg_javascript273); ?>').fadeOut(6000);
    }
  });
});
//]]>
</script>
<?php
}
?>
<div class="fieldHeadWrapper">
  <p><span class="float" id="loader"></span><span class="float" id="loader_msg" style="display:none" onclick="jQuery(this).hide()"></span><?php echo $msg_pricepoints7; ?>:</p>
</div>

<div id="sortable">
<?php
$q_pp = mysql_query("SELECT * FROM ".DB_PREFIX."price_points
        ORDER BY orderBy
        ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
if (mysql_num_rows($q_pp)>0) {
  while ($POINTS = mysql_fetch_object($q_pp)) {
  ?>
  <div class="catWrapper" id="pp-<?php echo $POINTS->id; ?>" style="cursor:move" title="<?php echo mc_cleanDataEnt($msg_cats20); ?>">
    <div class="catLeft" style="width:93%"><?php echo ($POINTS->priceText ? mc_cleanData($POINTS->priceText) : mc_cleanData($POINTS->priceFrom).' - '.mc_cleanData($POINTS->priceTo)); ?></div>
    <div class="catRight" style="width:5%;text-align:center;padding:5px 0 3px 0;margin-right:0;background:#fff;float:right"><a href="?p=price-points&amp;edit=<?php echo $POINTS->id; ?>"><img src="templates/images/edit.png" alt="<?php echo mc_cleanDataEnt($msg_script9); ?>" title="<?php echo mc_cleanDataEnt($msg_script9); ?>" /></a><?php echo ($uDel=='yes' ? ' <a href="?p=price-points&amp;del='.$POINTS->id.'" onclick="return confirmMessage(\''.mc_cleanDataEnt($msg_javascript45).'\')"><img src="templates/images/delete.png" alt="'.mc_cleanDataEnt($msg_script10).'" title="'.mc_cleanDataEnt($msg_script10).'" /></a>' : ''); ?></div>
    <br class="clear" />
  </div>
  <?php
  }
} else {
?>
<span class="noData"><?php echo $msg_pricepoints11; ?></span>
<?php
}
?>
</div>

<p>&nbsp;</p>
<p>&nbsp;</p>
</div>
