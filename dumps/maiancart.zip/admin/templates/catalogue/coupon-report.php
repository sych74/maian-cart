<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } ?>
<div id="content">

<?php
if (isset($OK)) {
  echo actionCompleted($msg_settings31);
}
$PARENT = mc_getTableData('campaigns','id',mc_digitSan($_GET['code']));
?>

<?php echo $msg_coupons17; ?><br /><br />

<div class="fieldHeadWrapper">
  <p><span class="float"><a href="?p=discount-coupons" title="<?php echo mc_cleanDataEnt($msg_coupons18); ?>"><?php echo $msg_coupons18; ?></a></span><?php echo mc_cleanDataEnt($PARENT->cName); ?>:</p>
</div>

<?php
$limit = $page * COUPON_REPORTS_PER_PAGE - (COUPON_REPORTS_PER_PAGE);
$scnt  = 0;
$q_coupons = mysql_query("SELECT SQL_CALC_FOUND_ROWS *,DATE_FORMAT(`".DB_PREFIX."coupons`.`cUseDate`,'".$SETTINGS->mysqlDateFormat."') AS `udate` FROM `".DB_PREFIX."coupons`
             LEFT JOIN `".DB_PREFIX."sales`
			 ON `".DB_PREFIX."coupons`.`saleID` = `".DB_PREFIX."sales`.`id`
             WHERE `cCampaign`                  = '".mc_digitSan($_GET['code'])."'
             ORDER BY `cUseDate`
             LIMIT $limit,".COUPON_REPORTS_PER_PAGE."
             ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
$c            = mysql_fetch_object(mysql_query("SELECT FOUND_ROWS() AS `rows`"));
$countedRows  =  (isset($c->rows) ? $c->rows : '0');
if (mysql_num_rows($q_coupons)>0) {   
while ($USAGE = mysql_fetch_object($q_coupons)) {
  switch ($USAGE->discountValue) {
    case 'freeshipping':
    $string = str_replace(array('{sale}','{id}'),
                          array(
						   mc_saleInvoiceNumber($USAGE->invoiceNo),
                           $USAGE->saleID
                          ),
                          $msg_coupons25
              );
    break;
    case 'notax':
    $string = str_replace(array('{sale}','{id}'),
                          array(
						   mc_saleInvoiceNumber($USAGE->invoiceNo),
                           $USAGE->saleID
                          ),
                          $msg_coupons26
              );
    break;
    default:
    $string = str_replace(array('{discount}','{sale}','{id}'),
                          array(
						   mc_currencyFormat(mc_formatPrice($USAGE->discountValue)),
                           mc_saleInvoiceNumber($USAGE->invoiceNo),
                           $USAGE->saleID
                          ),
                          $msg_coupons20
              );
    break;
  }
  ?>
  <div class="catWrapper">
    <div class="catLeft" style="width:15%"><b><?php echo $USAGE->udate; ?></b></div>
    <div class="catRight" style="font-size:11px;width:81%;margin-right:5px"><?php echo $string; ?></div>
    <br class="clear" />
  </div>
  <?php
}
if ($countedRows>0) {
  define('PER_PAGE',COUPON_REPORTS_PER_PAGE);
  if ($countedRows>0 && $countedRows>PER_PAGE) {
    $PTION = new pagination($countedRows,'?p='.$cmd.'&amp;next=');
    echo $PTION->display();
  }
}

// Show graph..
?>
<br />
<div class="fieldHeadWrapper">
  <p><?php echo $msg_coupons8; ?>:</p>
</div>

<div class="graphStats">
  <div class="salesTrends" style="padding:5px">
    <div id="chart_coupons"></div>
    <script type="text/javascript">
     //<![CDATA[
     jQuery(document).ready(function() {  
     <?php
     $line    = array();
     $months  = array();
     $range   = 12;
     $ts      = strtotime(date("Y-m-d"));
     $max     = 0;
     for ($i=($range-1); $i>-1; $i--) {
       $y                     = date('y',strtotime('-'.$i.' months',$ts));
       $year                  = date('Y',strtotime('-'.$i.' months',$ts));
       $nm                    = date('m',strtotime('-'.$i.' months',$ts));
       $m                     = $msg_script41[date('n',strtotime('-'.$i.' months',$ts))-1];
       $m                     = str_replace("'","\'",$m);
       $months[]              = "'$m $y'";
       $line[$nm.'-'.$year]   = 0; 
     }
     $qc      = mysql_query("SELECT MONTH(`cUseDate`) as `m`,
                YEAR(`cUseDate`) AS `y`,
                count(*) AS `cpns`
                FROM `".DB_PREFIX."coupons` 
                WHERE `cCampaign` = '".mc_digitSan($_GET['code'])."'
                AND `cUseDate`    > DATE_SUB(CURDATE(),INTERVAL 11 MONTH)
                GROUP BY 2,1
                ORDER BY YEAR(`cUseDate`) DESC,MONTH(`cUseDate`) DESC 
                ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
     while ($CP = mysql_fetch_object($qc)) {
       $m                   = ($CP->m<10 ? '0'.$CP->m : $CP->m);
       $line[$m.'-'.$CP->y] = $CP->cpns;
       // Get highest count value..
       if ($CP->cpns>$max) {
         $max = $CP->cpns;
       }
     }
     ?>
     line1 = [<?php echo implode(',',$line); ?>];
     ticks = [<?php echo implode(',',$months); ?>];
     plot1 = jQuery.jqplot('chart_coupons', [line1], {
                       grid: {
                         borderWidth: 0,
                         shadow: false
                       },
                       seriesDefaults: {
                         renderer: jQuery.jqplot.BarRenderer,
                         pointLabels: { 
                           show: true ,
                           formatString: '%d'
                         },
                         rendererOptions: {
                           highlightMouseDown: false    
                         }
                       },
                       axes: {
                         yaxis: {
                           min: 0,
                           max: <?php echo ($max+1); ?>,
                           tickOptions: {
                             formatString: '%d'
                           }
                         },
                         xaxis: { 
                           rendererOptions:{
                             tickRenderer: jQuery.jqplot.CanvasAxisTickRenderer
                           },
                           ticks: ticks, 
                           renderer: jQuery.jqplot.CategoryAxisRenderer
                         }
                       }
     });
     });
     //]]>
    </script>
  </div>
  <p class="rendering" style="text-align:right;padding:15px"><?php echo $msg_script51; ?>: <a href="http://www.jqPlot.com" onclick="window.open(this);return false" title="jqPlot">jqPlot</a> &copy; Chris Leonello</p>
</div>



<?php
} else {
?>
<span class="noData"><?php echo $msg_coupons27; ?></span>
<?php
}
?>

<p>&nbsp;</p>
<p>&nbsp;</p>
</div>
