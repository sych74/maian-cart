<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } 
if (isset($_GET['edit'])) {
  $EDIT = mc_getTableData('mp3','id',mc_digitSan($_GET['edit']));
}
$folder  = (isset($_GET['folder']) ? 'content/mp3/'.$_GET['folder'] : 'content/mp3');
$mp3     = array();
$fname   = array();
//---------------------
// Get folders..
//---------------------
$dir = opendir(REL_PATH.'content/mp3');
while (false!==($read=readdir($dir))) {
  if (!in_array($read,array('.','..'))) {
    if (is_dir(REL_PATH.'content/mp3/'.$read)) {
      $fname[] = $read;
    }
  }
}
closedir($dir);
//-------------------
// Read mp3 files..
//-------------------
$dir2 = opendir(REL_PATH.$folder);
while (false!==($read2=readdir($dir2))) {
  if (substr(strtolower($read2),-4)=='.mp3') {
    $mp3[] = $read2;
  }
}
closedir($dir2);
?>
<div id="content">

<?php
if (isset($OK)) {
  echo actionCompleted(str_replace('{count}',$run,$msg_productmp34));
}
if (isset($OK2) && $cnt>0) {
  echo actionCompleted($msg_productmp35);
}
if (isset($OK3)) {
  echo actionCompleted($msg_productmp313);
}
?>

<?php echo $msg_productmp3; ?>
<br /><br />
<div class="prodTop">
  <?php
  $P = mc_getTableData('products','id',mc_digitSan($_GET['product']));
  ?>
  <p><span class="float"><?php echo mc_cleanData($P->pName); ?></span>
  <b><?php echo $msg_productpictures14; ?></b>: 
  <select onchange="if(this.value!= 0){location=this.options[this.selectedIndex].value}">
  <option value="0">- - - -</option>
  <option value="?p=product-pictures&amp;product=<?php echo mc_digitSan($_GET['product']); ?>"><?php echo $msg_productadd38; ?></option>
  <option value="?p=add-product&amp;edit=<?php echo mc_digitSan($_GET['product']); ?>"><?php echo $msg_productpictures15; ?></option>
  <option value="?p=add-product&amp;copyp=<?php echo mc_digitSan($_GET['product']); ?>"><?php echo $msg_productpictures16; ?></option>
  <option value="?p=product-attributes&amp;product=<?php echo mc_digitSan($_GET['product']); ?>"><?php echo $msg_productpictures17; ?></option>
  <option value="?p=product-related&amp;product=<?php echo mc_digitSan($_GET['product']); ?>"><?php echo $msg_productpictures18; ?></option>
  <?php
  if ($P->pDownload=='no') {
  ?>
  <option value="?p=product-personalisation&amp;product=<?php echo mc_digitSan($_GET['product']); ?>"><?php echo $msg_productmanage20; ?></option>
  <?php
  }
  ?>
  </select>
  <br class="clear" />
  </p>
</div>

<form method="post" id="form" action="?p=product-mp3&amp;product=<?php echo mc_digitSan($_GET['product']).(isset($_GET['folder']) ? '&amp;folder='.$_GET['folder'] : '').(isset($_GET['edit']) ? '&amp;edit='.mc_digitSan($_GET['edit']) : ''); ?>">
<div class="fieldHeadWrapper">
  <p>
  <span class="float"><?php 
  if (!isset($EDIT->id)) {
  echo $msg_productmp33; ?>:
  <select onchange="if(this.value!= 0){location=this.options[this.selectedIndex].value}" style="text-transform:none">
  <option value="index.php?p=product-mp3&amp;product=<?php echo mc_digitSan($_GET['product']); ?>">content/mp3/</option>
  <?php
  if (!empty($fname)) {
  foreach ($fname AS $fd) {
  ?>
  <option value="index.php?p=product-mp3&amp;product=<?php echo mc_digitSan($_GET['product']); ?>&amp;folder=<?php echo $fd; ?>"<?php echo (isset($_GET['folder']) && $_GET['folder']==$fd ? ' selected="selected"' : ''); ?>>content/mp3/<?php echo $fd; ?>/</option>
  <?php
  }
  }
  ?>
  </select>
  <?php
  }
  ?>
  </span>
  <?php echo (!empty($mp3) && !isset($EDIT->id) ? '<input type="checkbox" name="log" value="all" onclick="toggleCheckBoxes(this.checked,\'formFieldWrapper\')" title="'.mc_cleanDataEnt($msg_productmp39).'" />&nbsp;&nbsp;' : ''); ?><?php echo (isset($EDIT->id) ? $msg_productmp312 : $msg_productmp32); ?>:</p>
</div>

<?php
if (empty($mp3)) {
?>
<p><span class="noData"><?php echo str_replace('{folder}',$folder,$msg_productmp36); ?></span></p>
<?php
} else {
if (isset($EDIT->id)) {
?>
<div class="formFieldWrapper">
  <div class="formLeft" style="width:55%">
    <?php echo $EDIT->fileFolder.'/'.$EDIT->filePath; ?>
  </div>
  <div class="formLeft" style="width:40%"> 
    <?php echo $msg_productmp311; ?>: <input type="text" name="fileName" value="<?php echo mc_cleanData($EDIT->fileName); ?>" class="box" style="width:80%" />
  </div>
  <br class="clear" />
</div>
<?php
} else {
foreach ($mp3 AS $m) {
?>
<div class="formFieldWrapper">
  <div class="formLeft" style="width:5%">
     <input type="checkbox" name="mp3[]" value="<?php echo $m; ?>" />
  </div>
  <div class="formLeft" style="width:53%">
    <?php echo $folder.'/'.$m; ?>
  </div>
  <div class="formLeft" style="width:40%"> 
    <?php echo $msg_productmp311; ?>: <input type="text" name="fileName[]" value="" class="box" style="width:80%" />
  </div>
  <br class="clear" />
</div>
<?php
}
}
?>
<p style="text-align:center;padding:20px 0 20px 0">
  <input type="hidden" name="folder" value="<?php echo $folder; ?>" />
  <input type="hidden" name="<?php echo (isset($EDIT->id) ? 'update' : 'process'); ?>" value="yes" />
  <input class="formbutton" type="submit" value="<?php echo mc_cleanDataEnt((isset($EDIT->id) ? $msg_productmp312 : $msg_productmp37)); ?>" title="<?php echo mc_cleanDataEnt((isset($EDIT->id) ? $msg_productmp312 : $msg_productmp37)); ?>" />
  <?php echo (isset($EDIT->id) ? '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input class="formbutton2" type="button" onclick="window.location=\'?p=product-mp3&amp;product='.mc_digitSan($_GET['product']).'\'" value="'.mc_cleanDataEnt($msg_script11).'" title="'.mc_cleanDataEnt($msg_script11).'" />' : ''); ?>
</p>
<?php
}
?>
</form>

<script type="text/javascript">
//<![CDATA[
jQuery(document).ready(function() {
  jQuery("#sortable").sortable({
    update : function (data) {
      jQuery("#loader").load("index.php?p=product-mp3&product=<?php echo mc_digitSan($_GET['product']); ?>&order=yes&"+jQuery('#sortable').sortable('serialize'));
      jQuery('#loader_msg').show('slow');
      jQuery('#loader_msg').html('<?php echo mc_cleanDataEnt($msg_javascript273); ?>').fadeOut(6000);
    }
  });
});
//]]>
</script>

<div class="fieldHeadWrapper">
  <p><span class="float" id="loader"></span><span class="float" id="loader_msg" style="display:none" onclick="jQuery(this).hide()"></span><?php echo $msg_productmp38; ?>:</p>
</div>

<div id="sortable">
<?php
$q_mp = mysql_query("SELECT * FROM ".DB_PREFIX."mp3
        WHERE product_id = '".mc_digitSan($_GET['product'])."'
        ORDER BY orderBy
        ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
if (mysql_num_rows($q_mp)>0) {
  while ($MP3 = mysql_fetch_object($q_mp)) {
  ?>
  <div class="catWrapper" id="mp3-<?php echo $MP3->id; ?>" style="cursor:move" title="<?php echo mc_cleanDataEnt($msg_productmp314); ?>">
    <div class="catLeft" style="width:92%"><b><?php echo $MP3->fileName; ?></b><br /><?php echo $MP3->fileFolder.'/'.$MP3->filePath; ?></div>
    <div class="catRight" style="width:5%;text-align:center;padding:5px 0 3px 0;margin-right:0;background:#fff"><a href="?p=product-mp3&amp;edit=<?php echo $MP3->id; ?>&amp;product=<?php echo mc_digitSan($_GET['product']); ?>"><img src="templates/images/edit.png" alt="<?php echo mc_cleanDataEnt($msg_script9); ?>" title="<?php echo mc_cleanDataEnt($msg_script9); ?>" /></a><?php echo ($uDel=='yes' ? ' <a href="?p=product-mp3&amp;product='.mc_digitSan($_GET['product']).'&amp;del='.$MP3->id.'" onclick="return confirmMessage(\''.mc_cleanDataEnt($msg_javascript45).'\')"><img src="templates/images/delete.png" alt="'.mc_cleanDataEnt($msg_script10).'" title="'.mc_cleanDataEnt($msg_script10).'" /></a>' : '&nbsp;'); ?></div>
    <br class="clear" />
  </div>
  <?php
  }
} else {
?>
<span class="noData"><?php echo $msg_productmp310; ?></span>
<?php
}
?>
</div>

<p>&nbsp;</p>
<p>&nbsp;</p>
</div>
