<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } 
if (isset($_GET['edit'])) {
  $EDIT = mc_getTableData('campaigns','id',mc_digitSan($_GET['edit']));
  $CRS  = ($EDIT->categories ? explode(',',$EDIT->categories) : array());
}
?>
<div id="content">

<?php
if (isset($OK)) {
  echo actionCompleted($msg_coupons10);
}
if (isset($OK2)) {
  echo actionCompleted($msg_coupons11);
}
if (isset($OK3) && $cnt>0) {
  echo actionCompleted($msg_coupons12);
}
define('CALBOX', 'cExpiry');
include(PATH.'templates/date-picker.php');
?>

<?php echo $msg_coupons; ?><br /><br />

<form method="post" id="form" action="?p=discount-coupons<?php echo (isset($EDIT->id) ? '&amp;edit='.$EDIT->id : ''); ?>">
<div class="fieldHeadWrapper">
  <p><?php echo (isset($EDIT->id) ? $msg_coupons9 : $msg_coupons2); ?>:</p>
</div>

<div class="formFieldWrapper">
  <div class="formLeft" style="width:50%">
    <label><?php echo $msg_coupons3; ?>: <?php echo mc_displayHelpTip($msg_javascript55,'RIGHT'); ?></label>
    <input type="text" name="cName" tabindex="<?php echo (++$tabIndex); ?>" maxlength="250" value="<?php echo (isset($EDIT->cName) ? mc_cleanDataEnt($EDIT->cName) : ''); ?>" class="box" /> 
  </div>
  <div class="formLeft" style="width:25%">  
    <label><?php echo $msg_coupons6; ?>: <?php echo mc_displayHelpTip($msg_javascript58,'LEFT'); ?></label>
    <input type="text" name="cUsage" tabindex="<?php echo (++$tabIndex); ?>" id="cUsage" value="<?php echo (isset($EDIT->cUsage) ? $EDIT->cUsage : '0'); ?>" class="box" style="width:25%" />
  </div>
  <div class="formRight" style="width:25%">  
    <label><?php echo $msg_coupons28; ?>: <?php echo mc_displayHelpTip($msg_javascript334,'LEFT'); ?></label>
    <input type="text" name="cExpiry" tabindex="<?php echo (++$tabIndex); ?>" value="<?php echo (isset($EDIT->cExpiry) && $EDIT->cExpiry!='0000-00-00' ? mc_convertMySQLDate($EDIT->cExpiry) : ''); ?>" style="width:45%" id="cExpiry" class="box" />
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper">  
  <div class="formLeft" style="width:50%">  
    <label><?php echo $msg_coupons4; ?>: <?php echo mc_displayHelpTip($msg_javascript56,'RIGHT'); ?></label>
    <input type="text" name="cDiscountCode" tabindex="<?php echo (++$tabIndex); ?>" maxlength="50" value="<?php echo (isset($EDIT->cDiscountCode) ? $EDIT->cDiscountCode : ''); ?>" class="box" />
  </div>
  <div class="formLeft" style="width:25%">  
    <label><?php echo $msg_coupons5; ?>: <?php echo mc_displayHelpTip($msg_javascript57,'LEFT'); ?></label>
    <input type="text" name="cMin" tabindex="<?php echo (++$tabIndex); ?>" value="<?php echo (isset($EDIT->cMin) ? $EDIT->cMin : '0.00'); ?>" class="box" style="width:50%" />
  </div>
  <div class="formRight" style="width:25%">
    <label><?php echo $msg_coupons7; ?>: <?php echo mc_displayHelpTip($msg_javascript59,'LEFT'); ?></label>
    <input type="text" name="cDiscount" tabindex="<?php echo (++$tabIndex); ?>" value="<?php echo (isset($EDIT->cDiscount) ? $EDIT->cDiscount : '0.00'); ?>" style="width:50%" class="box" />
  </div>
  <br class="clear" />
</div>

<div class="formFieldWrapper">
  <div class="formLeft" style="width:50%">
    <label><?php echo $msg_coupons31; ?>: <?php echo mc_displayHelpTip($msg_javascript494,'RIGHT'); ?></label>
    <div class="categoryBoxes">
    <input type="checkbox" name="log" tabindex="<?php echo (++$tabIndex); ?>" value="all" onclick="selectAll()" /> <b><?php echo $msg_productadd35; ?></b><br />
    <?php
    $q_cats = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
              WHERE `catLevel` = '1'
              AND `childOf`    = '0'
              AND `enCat`      = 'yes'
              ORDER BY `catname`
              ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($CATS = mysql_fetch_object($q_cats)) {
    ?>
    <p id="cat_<?php echo $CATS->id; ?>"><input onclick="if(this.checked){selectChildren('cat_<?php echo $CATS->id; ?>','on')}else{selectChildren('cat_<?php echo $CATS->id; ?>','off')}" tabindex="<?php echo (++$tabIndex); ?>" type="checkbox" name="cat[]" value="<?php echo $CATS->id; ?>"<?php echo (isset($EDIT->id) && in_array($CATS->id,$CRS) ? ' checked="checked"' : ''); ?> /> <?php echo mc_cleanDataEnt($CATS->catname); ?><br />
    <?php
    $q_children = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
                  WHERE `catLevel` = '2'
                  AND `enCat`      = 'yes'
                  AND `childOf`    = '".$CATS->id."'
                  ORDER BY `catname`
                  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($CHILDREN = mysql_fetch_object($q_children)) {
    ?>
    <span id="child_<?php echo $CHILDREN->id; ?>">
    &nbsp;&nbsp;<input tabindex="<?php echo (++$tabIndex); ?>" onclick="if(this.checked){selectChildren('child_<?php echo $CHILDREN->id; ?>','on')}else{selectChildren('child_<?php echo $CHILDREN->id; ?>','off')}" type="checkbox" name="cat[]" value="<?php echo $CHILDREN->id; ?>"<?php echo (isset($EDIT->id) && in_array($CHILDREN->id,$CRS) ? ' checked="checked"' : ''); ?> /> <?php echo mc_cleanDataEnt($CHILDREN->catname); ?><br />
    <?php
    $q_infants = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
                  WHERE `catLevel` = '3'
                  AND `childOf`    = '{$CHILDREN->id}'
                  AND `enCat`      = 'yes'
                  ORDER BY `catname`
                  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($INFANTS = mysql_fetch_object($q_infants)) {
    ?>
    &nbsp;&nbsp;&nbsp;&nbsp;<input tabindex="<?php echo (++$tabIndex); ?>" type="checkbox" name="cat[]" value="<?php echo $INFANTS->id; ?>"<?php echo (isset($EDIT->id) && in_array($INFANTS->id,$CRS) ? ' checked="checked"' : ''); ?> /> <?php echo mc_cleanDataEnt($INFANTS->catname); ?><br />
    <?php
    }
    ?>
    </span>
    <?php
    }
    ?>
    </p>
    <?php
    }
    ?>
    </div>
  </div>  
  <div class="formRight">  
    <label><?php echo $msg_coupons22; ?>: <?php echo mc_displayHelpTip($msg_javascript63); ?></label>
    <?php echo $msg_script5; ?> <input type="radio" tabindex="<?php echo (++$tabIndex); ?>" name="cLive" value="yes"<?php echo (isset($EDIT->cLive) && $EDIT->cLive=='yes' ? ' checked="checked"' : (!isset($EDIT->cLive) ? ' checked="checked"' : '')); ?> /> <?php echo $msg_script6; ?> <input tabindex="<?php echo (++$tabIndex); ?>" type="radio" name="cLive" value="no"<?php echo (isset($EDIT->cLive) && $EDIT->cLive=='no' ? ' checked="checked"' : ''); ?> />
  </div>
  <br class="clear" />
</div>

<p style="text-align:center;padding-top:20px">
 <input type="hidden" name="<?php echo (isset($EDIT->id) ? 'update' : 'process'); ?>" value="yes" />
 <input class="formbutton" type="submit" tabindex="<?php echo (++$tabIndex); ?>" value="<?php echo mc_cleanDataEnt((isset($EDIT->id) ? $msg_coupons9 : $msg_coupons2)); ?>" title="<?php echo mc_cleanDataEnt((isset($EDIT->id) ? $msg_coupons9 : $msg_coupons2)); ?>" /><?php echo (isset($EDIT->id) ? '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input class="formbutton2" type="button" onclick="window.location=\'?p=discount-coupons\'" value="'.mc_cleanDataEnt($msg_script11).'" title="'.mc_cleanDataEnt($msg_script11).'" />' : ''); ?>
</p>
</form><br />

<div class="fieldHeadWrapper">
  <p><?php echo $msg_coupons13; ?>:</p>
</div>

<?php
$limit   = $page * CAMPAIGNS_PER_PAGE - (CAMPAIGNS_PER_PAGE);
$q_discounts = mysql_query("SELECT SQL_CALC_FOUND_ROWS *,DATE_FORMAT(cExpiry,'".$SETTINGS->mysqlDateFormat."') AS edate FROM ".DB_PREFIX."campaigns
               ORDER BY cName
               LIMIT $limit,".CAMPAIGNS_PER_PAGE."
               ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
$c            = mysql_fetch_object(mysql_query("SELECT FOUND_ROWS() AS rows"));
$countedRows  = (isset($c->rows) ? number_format($c->rows,0,'.','') : '0');
if (mysql_num_rows($q_discounts)>0) {
  while ($DISCOUNT = mysql_fetch_object($q_discounts)) {
  ?>
  <div class="catWrapper">
    <div class="catLeft" style="width:27%;font-weight:bold"><?php echo mc_cleanDataEnt($DISCOUNT->cName); ?></div>
    <?php
    switch ($DISCOUNT->cDiscount) {
      case 'freeshipping':
      ?>
      <div class="catRight" style="font-size:11px;width:57%;margin-right:5px"><?php echo str_replace(array('{code}','{expiry}','{usage}','{min}','{discount}','{enabled}'),array($DISCOUNT->cDiscountCode,($DISCOUNT->cExpiry!='0000-00-00' ? $DISCOUNT->edate : 'N/A'),$DISCOUNT->cUsage,mc_currencyFormat(($DISCOUNT->cMin>0 ? $DISCOUNT->cMin : '0.00')),(strpos($DISCOUNT->cDiscount,'%')===FALSE && !in_array($DISCOUNT->cDiscount,array('freeshipping','notax')) ? mc_currencyFormat($DISCOUNT->cDiscount) : (in_array($DISCOUNT->cDiscount,array('freeshipping','notax')) ? getDiscountType($DISCOUNT->cDiscount) : $DISCOUNT->cDiscount)),($DISCOUNT->cLive=='yes' ? $msg_script5 : $msg_script6)),$msg_coupons29); ?></div>
      <?php
      break;
      case 'notax':
      ?>
      <div class="catRight" style="font-size:11px;width:57%;margin-right:5px"><?php echo str_replace(array('{code}','{expiry}','{usage}','{min}','{discount}','{enabled}'),array($DISCOUNT->cDiscountCode,($DISCOUNT->cExpiry!='0000-00-00' ? $DISCOUNT->edate : 'N/A'),$DISCOUNT->cUsage,mc_currencyFormat(($DISCOUNT->cMin>0 ? $DISCOUNT->cMin : '0.00')),(strpos($DISCOUNT->cDiscount,'%')===FALSE && !in_array($DISCOUNT->cDiscount,array('freeshipping','notax')) ? mc_currencyFormat($DISCOUNT->cDiscount) : (in_array($DISCOUNT->cDiscount,array('freeshipping','notax')) ? getDiscountType($DISCOUNT->cDiscount) : $DISCOUNT->cDiscount)),($DISCOUNT->cLive=='yes' ? $msg_script5 : $msg_script6)),$msg_coupons30); ?></div>
      <?php
      break;
      default:
      ?>
      <div class="catRight" style="font-size:11px;width:57%;margin-right:5px"><?php echo str_replace(array('{code}','{expiry}','{usage}','{min}','{discount}','{enabled}','{cats}'),array($DISCOUNT->cDiscountCode,($DISCOUNT->cExpiry!='0000-00-00' ? $DISCOUNT->edate : 'N/A'),$DISCOUNT->cUsage,mc_currencyFormat(($DISCOUNT->cMin>0 ? $DISCOUNT->cMin : '0.00')),(strpos($DISCOUNT->cDiscount,'%')===FALSE && !in_array($DISCOUNT->cDiscount,array('freeshipping','notax')) ? mc_currencyFormat($DISCOUNT->cDiscount) : (in_array($DISCOUNT->cDiscount,array('freeshipping','notax')) ? getDiscountType($DISCOUNT->cDiscount) : $DISCOUNT->cDiscount)),($DISCOUNT->cLive=='yes' ? $msg_script5 : $msg_script6),($DISCOUNT->categories ? $msg_script5.', '.count(explode(',',$DISCOUNT->categories)) : $msg_script6)),$msg_coupons21); ?></div>
      <?php
      break;
    }
    ?>  
    <div class="catRight" style="width:12%;text-align:center;padding:5px 0 3px 0;background:#fff;float:right">
     <a href="?p=coupon-report&amp;code=<?php echo $DISCOUNT->id; ?>"><img src="templates/images/stats.png" alt="<?php echo mc_cleanDataEnt($msg_script12); ?>" title="<?php echo mc_cleanDataEnt($msg_script12); ?>" /></a>&nbsp;&nbsp;
     <a href="?p=discount-coupons&amp;edit=<?php echo $DISCOUNT->id; ?>"><img src="templates/images/edit.png" alt="<?php echo mc_cleanDataEnt($msg_script9); ?>" title="<?php echo mc_cleanDataEnt($msg_script9); ?>" /></a>&nbsp;&nbsp;
     <?php
     if ($uDel=='yes') {
     ?>
     <a href="?p=discount-coupons&amp;del=<?php echo $DISCOUNT->id; ?>" onclick="return confirmMessage('<?php echo mc_cleanDataEnt($msg_javascript45); ?>')"><img src="templates/images/delete.png" alt="<?php echo mc_cleanDataEnt($msg_script10); ?>" title="<?php echo mc_cleanDataEnt($msg_script10); ?>" /></a>
     <?php
     }
     ?>
    </div>
    <br class="clear" />
  </div>
  <?php
  }
  define('PER_PAGE',CAMPAIGNS_PER_PAGE);
  if ($countedRows>0 && $countedRows>PER_PAGE) {
    $PTION = new pagination($countedRows,'?p='.$cmd.'&amp;next=');
    echo $PTION->display();
  }
} else {
?>
<span class="noData"><?php echo $msg_coupons14; ?></span>
<?php
}
?>

<p>&nbsp;</p>
<p>&nbsp;</p>
</div>
