<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } ?>
<div id="content">

<?php
if (isset($OK)) {
  echo actionCompleted(str_replace('{count}',$run,$msg_productpictures8));
}
if (isset($OK2) && $cnt>0) {
  echo actionCompleted($msg_productpictures10);
}
if (isset($OK3)) {
  echo actionCompleted($msg_productpictures21);
}
?>

<?php echo $msg_productpictures; ?>
<br /><br />
<div class="prodTop">
  <?php
  $P = mc_getTableData('products','id',mc_digitSan($_GET['product']));
  ?>
  <p><span class="float"><?php echo mc_cleanData($P->pName); ?></span>
  <b><?php echo $msg_productpictures14; ?></b>: 
  <select onchange="if(this.value!= 0){location=this.options[this.selectedIndex].value}">
  <option value="0">- - - -</option>
  <option value="?p=add-product&amp;edit=<?php echo mc_digitSan($_GET['product']); ?>"><?php echo $msg_productpictures15; ?></option>
  <option value="?p=add-product&amp;copyp=<?php echo mc_digitSan($_GET['product']); ?>"><?php echo $msg_productpictures16; ?></option>
  <option value="?p=product-attributes&amp;product=<?php echo mc_digitSan($_GET['product']); ?>"><?php echo $msg_productpictures17; ?></option>
  <option value="?p=product-related&amp;product=<?php echo mc_digitSan($_GET['product']); ?>"><?php echo $msg_productpictures18; ?></option>
  <?php
  if (PRODUCT_MP3_PREVIEWS) {
  ?>
  <option value="?p=product-mp3&amp;product=<?php echo mc_digitSan($_GET['product']); ?>"><?php echo $msg_productmanage19; ?></option>
  <?php
  }
  if ($P->pDownload=='no') {
  ?>
  <option value="?p=product-personalisation&amp;product=<?php echo mc_digitSan($_GET['product']); ?>"><?php echo $msg_productmanage20; ?></option>
  <?php
  }
  ?>
  </select>
  <br class="clear" />
  </p>
</div>
<?php
if (isset($_GET['product']) && mc_digitSan($_GET['product'])>0) {
?>
<form method="post" action="?p=product-pictures&amp;product=<?php echo mc_digitSan($_GET['product']); ?>" enctype="multipart/form-data">
<div class="fieldHeadWrapper">
  <p>
  <span class="float" id="addOptions"><img style="cursor:pointer" src="templates/images/add.png" alt="<?php echo mc_cleanDataEnt($msg_rates14); ?>" title="<?php echo mc_cleanDataEnt($msg_rates14); ?>" onclick="addRemoveFieldBoxes('add','formFieldPictureWrapper')" /> <img src="templates/images/remove.png" alt="<?php echo mc_cleanDataEnt($msg_rates15); ?>" style="cursor:pointer" title="<?php echo mc_cleanDataEnt($msg_rates15); ?>" onclick="addRemoveFieldBoxes('rem','formFieldPictureWrapper')" /></span>
  <?php echo $msg_productpictures7; ?>: <a onclick="jQuery('#addOptions').hide();jQuery('#internal').hide();jQuery('#remote').show('slow');return false" class="remote" href="#" title="<?php echo mc_cleanDataEnt($msg_productpictures22); ?>"><?php echo $msg_productpictures22; ?></a></p>
</div>

<div id="remote" style="display:none">

<div class="formFieldPictureWrapper">
  <div class="formLeft" style="width:83%">
    <label><?php echo $msg_productpictures23; ?>: <?php echo mc_displayHelpTip($msg_javascript446,'RIGHT'); ?></label>
    <input type="file" name="remote" value="" class="box" /> 
  </div>
  <div class="formRight" style="width:15%;text-align:right">  
    <input onclick="jQuery('#remote').hide();jQuery('#addOptions').show();jQuery('#internal').show('slow')" class="formbutton" type="button" value="<?php echo mc_cleanDataEnt($msg_script11); ?>" title="<?php echo mc_cleanDataEnt($msg_script11); ?>" />
  </div>
  <br class="clear" />
</div>

</div>

<div id="internal">

<div id="fieldCloneArea">

<div class="formFieldPictureWrapper">
  <div class="formLeft" style="width:33%">
    <label><?php echo $msg_productpictures3; ?>: <?php echo mc_displayHelpTip($msg_javascript86,'RIGHT'); ?></label>
    <input type="file" name="image[]" value="" class="box" /> 
  </div>
  <div class="formRight" style="width:33%">  
    <label><?php echo $msg_productpictures3; ?>: <?php echo mc_displayHelpTip($msg_javascript86); ?></label>
    <input type="file" name="image[]" value="" class="box" />
  </div>
  <div class="formRight" style="width:33%">  
    <label><?php echo $msg_productpictures3; ?>: <?php echo mc_displayHelpTip($msg_javascript86,'LEFT'); ?></label>
    <input type="file" name="image[]" value="" class="box" />
  </div>
  <br class="clear" />
</div>

</div>

</div>


<div class="formFieldPictureWrapper">
  <div class="formLeft" style="width:90%">
    <label><?php echo $msg_productpictures13; ?>: <?php echo mc_displayHelpTip($msg_javascript199); ?></label>
    content/<select name="folder" id="folderList">
      <option value="products">products/ <?php echo $msg_productpictures12; ?></option>
      <?php
      $dir = opendir(REL_HTTP_PATH.PRODUCTS_FOLDER);
      while (false!==($read=readdir($dir))) {
        if (!in_array($read,array('.','..')) && is_dir(REL_HTTP_PATH.PRODUCTS_FOLDER.'/'.$read)) {
        ?>
        <option value="<?php echo $read; ?>"<?php echo (isset($EDIT->catFolder) && $EDIT->catFolder==$read ? ' selected="selected"' : ''); ?>>products/<?php echo $read; ?></option>
        <?php
        }
      }
      closedir($dir);
      ?>
    </select> <input type="button" onclick="createPictureFolder('<?php echo mc_cleanDataEnt($msg_javascript152); ?>')" class="createfolderbutton" name="<?php echo $msg_salesupdate13; ?>" value="+" />  
  </div>
  <br class="clear" />
</div>  

<p style="text-align:center;padding-top:20px">
  <input type="hidden" name="process" value="yes" />
  <input class="formbutton" type="submit" value="<?php echo mc_cleanDataEnt($msg_productpictures7); ?>" title="<?php echo mc_cleanDataEnt($msg_productpictures7); ?>" />
</p>
</form>

<br />

<div class="fieldHeadWrapper">
  <p><?php echo $msg_productpictures4; ?>:</p>
</div>

<form method="post" action="?p=product-pictures&amp;product=<?php echo mc_digitSan($_GET['product']); ?>">
<div id="prodPics">
<script type="text/javascript"> 
//<![CDATA[
jQuery(document).ready(function(){
  jQuery("a[rel='pics']").colorbox({title: '&nbsp;'});
});
//]]>
</script>
<?php
$run     = 0;
$mainImg = mc_getTableData('pictures','product_id',mc_digitSan($_GET['product']),'AND displayImg = \'yes\'');
$q_pics = mysql_query("SELECT *,".DB_PREFIX."pictures.id AS pid 
          FROM ".DB_PREFIX."pictures
          LEFT JOIN ".DB_PREFIX."products
          ON ".DB_PREFIX."pictures.product_id = ".DB_PREFIX."products.id
          WHERE product_id = '".mc_digitSan($_GET['product'])."'
          ORDER BY ".DB_PREFIX."pictures.displayImg,".DB_PREFIX."pictures.id
          ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
if (mysql_num_rows($q_pics)>0) {
?>
<ul>
<?php
while ($PICS = mysql_fetch_object($q_pics)) {
$split = explode(',',$PICS->dimensions);
$run = ++$count;
if ($PICS->remoteServer=='no') {
?>
<li<?php echo ($PICS->displayImg=='yes' ? ' class="main"' : (!isset($mainImg->id) && $run==1 ? ' class="main"' : '')); ?>>
  <span class="radio"><input type="radio" name="mainImg" value="<?php echo $PICS->pid; ?>"<?php echo ($PICS->displayImg=='yes' ? ' checked="checked"' : (!isset($mainImg->id) && $run==1 ? ' checked="checked"' : '')); ?> /> <?php echo $msg_productpictures20; ?></span>
  <a href="<?php echo $SETTINGS->ifolder.'/'.PRODUCTS_FOLDER.'/'.($PICS->folder ? mc_imageDisplayPath($PICS->folder).'/' : '').$PICS->picture_path; ?>" title="<?php echo mc_cleanDataEnt($PICS->pName); ?>" rel="pics"><img class="<?php echo ($split[1]>$split[0] ? 'thumbnail' : 'thumbnail2'); ?>" src="<?php echo $SETTINGS->ifolder.'/'.PRODUCTS_FOLDER.'/'.($PICS->folder ? mc_imageDisplayPath($PICS->folder).'/' : '').$PICS->thumb_path; ?>" alt="<?php echo mc_cleanDataEnt($PICS->pName); ?>" title="<?php echo mc_cleanDataEnt($PICS->pName); ?>" /></a>
  <span class="sizes"><?php echo $split[0].' x '.$split[1]; ?>px @ <?php echo mc_fileSizeConversion(@filesize($SETTINGS->serverPath.'/'.PRODUCTS_FOLDER.'/'.($PICS->folder ? mc_imageDisplayPath($PICS->folder).'/' : '').$PICS->picture_path)); ?></span>
  <?php
  if ($uDel=='yes') {
  ?>
  <span class="link"><a href="?p=product-pictures&amp;product=<?php echo mc_digitSan($_GET['product']); ?>&amp;delete=<?php echo $PICS->pid; ?>&amp;path=<?php echo ($PICS->folder ? mc_imageDisplayPath($PICS->folder).'/' : '').$PICS->picture_path; ?>&amp;thumb=<?php echo ($PICS->folder ? mc_imageDisplayPath($PICS->folder).'/' : '').$PICS->thumb_path; ?>&amp;di=<?php echo $PICS->displayImg; ?>" onclick="return confirmMessage('<?php echo mc_cleanDataEnt($msg_javascript45); ?>')"><img src="templates/images/delete.png" alt="<?php echo mc_cleanDataEnt($msg_productpictures6); ?>" title="<?php echo mc_cleanDataEnt($msg_productpictures6); ?>" /></a></span>
  <?php
  }
  ?>
</li>
<?php
} else {
?>
<li<?php echo ($PICS->displayImg=='yes' ? ' class="main"' : (!isset($mainImg->id) && $run==1 ? ' class="main"' : '')); ?>>
  <span class="radio"><input type="radio" name="mainImg" value="<?php echo $PICS->pid; ?>"<?php echo ($PICS->displayImg=='yes' ? ' checked="checked"' : (!isset($mainImg->id) && $run==1 ? ' checked="checked"' : '')); ?> /> <?php echo $msg_productpictures20; ?></span>
  <a href="<?php echo $PICS->remoteImg; ?>" title="<?php echo mc_cleanDataEnt($PICS->pName); ?>" rel="pics"><img class="thumbnail_remote" src="<?php echo ($PICS->remoteThumb ? $PICS->remoteThumb : $PICS->remoteImg); ?>" alt="<?php echo mc_cleanDataEnt($PICS->pName); ?>" title="<?php echo mc_cleanDataEnt($PICS->pName); ?>" /></a>
  <span class="sizes"><?php echo $msg_productpictures24; ?></span>
  <?php
  if ($uDel=='yes') {
  ?>
  <span class="link"><a href="?p=product-pictures&amp;product=<?php echo mc_digitSan($_GET['product']); ?>&amp;delete=<?php echo $PICS->pid; ?>&amp;path=<?php echo ($PICS->folder ? mc_imageDisplayPath($PICS->folder).'/' : '').$PICS->picture_path; ?>&amp;thumb=<?php echo ($PICS->folder ? mc_imageDisplayPath($PICS->folder).'/' : '').$PICS->thumb_path; ?>&amp;di=<?php echo $PICS->displayImg; ?>" onclick="return confirmMessage('<?php echo mc_cleanDataEnt($msg_javascript45); ?>')"><img src="templates/images/delete.png" alt="<?php echo mc_cleanDataEnt($msg_productpictures6); ?>" title="<?php echo mc_cleanDataEnt($msg_productpictures6); ?>" /></a></span>
  <?php
  }
  ?>
</li>
<?php
}
}
?>
</ul>
<br class="clear" />
<?php
} else {
?>
<span class="noData"><?php echo $msg_productpictures11; ?></span>
<?php
}
}
if ($run>1) {
?>
<p style="text-align:center;margin-top:20px">
  <input type="hidden" name="process_image" value="1" />
  <input type="submit" value="<?php echo mc_cleanDataEnt($msg_productpictures19); ?>" title="<?php echo mc_cleanDataEnt($msg_productpictures19); ?>" class="formbutton" />
</p>  
<?php
}
?>
</div>
</form>
<p>&nbsp;</p>
<p>&nbsp;</p>
</div>