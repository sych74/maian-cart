<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } ?>
<div id="content">

<?php
echo $msg_productexport; 
?>
<br /><br />

<div class="fieldHeadWrapper">
  <p><?php echo $msg_productexport2; ?>:</p>
</div>

<?php
if (isset($return) && $return=='none') {
?>
<p class="noData" style="margin-bottom:5px"><?php echo $msg_productexport3; ?></p>
<?php
}
?>

<form method="post" id="form" action="?p=product-export">
<div class="formFieldWrapper">
  <div class="formLeft" style="width:60%">
    <label><?php echo $msg_productadd5; ?>: <?php echo mc_displayHelpTip($msg_javascript465,'RIGHT'); ?></label>
    <div class="categoryBoxes" style="height:250px" id="cats">
    <input type="checkbox" name="log" tabindex="<?php echo (++$tabIndex); ?>" value="all" onclick="toggleCheckBoxesID(this.checked,'cats')" checked="checked" /> <b><?php echo $msg_productadd35; ?></b><br />
    <?php
    $q_cats = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
              WHERE catLevel = '1'
              AND childOf    = '0'
              AND enCat      = 'yes'
              ORDER BY catname") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($CATS = mysql_fetch_object($q_cats)) {
    ?>
    <p id="cat_<?php echo $CATS->id; ?>"><input onclick="if(this.checked){selectChildren('cat_<?php echo $CATS->id; ?>','on')}else{selectChildren('cat_<?php echo $CATS->id; ?>','off')}" tabindex="<?php echo (++$tabIndex); ?>" type="checkbox" name="category[]" value="<?php echo $CATS->id; ?>" checked="checked" /> <?php echo mc_cleanDataEnt($CATS->catname); ?><br />
    <?php
    $q_children = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
                  WHERE catLevel = '2'
                  AND enCat      = 'yes'
                  AND childOf    = '".$CATS->id."'
                  ORDER BY catname
                  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($CHILDREN = mysql_fetch_object($q_children)) {
    ?>
    <span id="child_<?php echo $CHILDREN->id; ?>">
    &nbsp;&nbsp;<input tabindex="<?php echo (++$tabIndex); ?>" onclick="if(this.checked){selectChildren('child_<?php echo $CHILDREN->id; ?>','on')}else{selectChildren('child_<?php echo $CHILDREN->id; ?>','off')}" type="checkbox" name="category[]" value="<?php echo $CHILDREN->id; ?>" checked="checked" /> <?php echo mc_cleanDataEnt($CHILDREN->catname); ?><br />
    <?php
    $q_infants = mysql_query("SELECT * FROM ".DB_PREFIX."categories 
                  WHERE catLevel = '3'
                  AND childOf    = '{$CHILDREN->id}'
                  AND enCat      = 'yes'
                  ORDER BY catname
                  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($INFANTS = mysql_fetch_object($q_infants)) {
    ?>
    &nbsp;&nbsp;&nbsp;&nbsp;<input tabindex="<?php echo (++$tabIndex); ?>" type="checkbox" name="category[]" value="<?php echo $INFANTS->id; ?>" checked="checked" /> <?php echo mc_cleanDataEnt($INFANTS->catname); ?><br />
    <?php
    }
    ?>
    </span>
    <?php
    }
    ?>
    </p>
    <?php
    }
    ?>
    </div>
  </div>
  <div class="formRight" style="width:36%"> 
   <label><?php echo $msg_productmanage60; ?>: <?php echo mc_displayHelpTip($msg_javascript466); ?></label>
   <div class="categoryBoxes" id="fields" style="height:250px">
    <input type="checkbox" name="log" tabindex="<?php echo (++$tabIndex); ?>" value="all" onclick="toggleCheckBoxesID(this.checked,'fields')" checked="checked" /> <b><?php echo $msg_productmanage61; ?></b><br />
    <?php
    // Fields to show..
    foreach (array(
     'pName'             => $msg_productadd4,
     'pMetaKeys'         => $msg_productadd18,
     'pMetaDesc'         => $msg_productadd19,
     'pTags'             => $msg_productadd11,
     'rwslug'            => $msg_newpages31,
     'pDescription'      => $msg_productadd6,
     'pShortDescription' => $msg_productadd64,
     'pCode'             => $msg_productadd7,
     'pStock'            => $msg_productadd43,
     'minPurchaseQty'    => $msg_productadd79,
     'maxPurchaseQty'    => $msg_productadd88,
     'pWeight'           => $msg_productadd42,
     'pPrice'            => $msg_productadd44,
     'pOffer'            => $msg_productadd39,
     'pDownloadPath'     => $msg_productadd9,
     'pVisits'           => $msg_productadd84,
     'pVideo'            => $msg_productadd29
    ) AS $k => $v) {
    ?>
    <input tabindex="<?php echo (++$tabIndex); ?>" type="checkbox" name="fields[]" value="<?php echo $k; ?>" checked="checked" /> <?php echo mc_cleanDataEnt($v); ?><br />
    <?php
    }
    ?>
   </div> 
  </div>
  <br class="clear" />
</div>

<p style="text-align:center;padding:20px 0 30px 0">
 <input type="hidden" name="process" value="yes" />
 <input class="formbutton" type="submit" value="<?php echo mc_cleanDataEnt($msg_productexport2); ?>" title="<?php echo mc_cleanDataEnt($msg_productexport2); ?>" />
</p>
</form>

</div>
