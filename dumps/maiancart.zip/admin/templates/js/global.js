//============================================
// Maian Cart
// Javascript/Ajax Functions
// Written by David Ian Bennett
// http://www.maianscriptworld.co.uk
//
// Incorporating jQuery functions
// Copyright (c) John Resig
// http://jquery.com/
//============================================

// Load currency display preference..
function mc_loadCurrencyDisplay(value) {
  var cur = value+'{PRICE}';
  switch (value) {
    case 'AUD': cur = '&#036;{PRICE}AUD'; break;
	case 'GBP': cur = '&pound;{PRICE}';   break;
	case 'USD': cur = '&#036;{PRICE}';    break;
	case 'JPY': cur = '&#165;{PRICE}';    break;
	case 'EUR': cur = '{PRICE}&euro;';    break;
  }
  jQuery('input[name="currencyDisplayPref"]').val(cur);
}

// Toggle child & infant categories
function toggleChildrenInfants() {
  jQuery("#catArea .child").each(function(){
    jQuery(jQuery(this)).toggle('slow');
  });
}

// Enable/disable status box..
function disableEnableBox(checked,box) {
  if (!checked){
    jQuery('#'+box).addClass('textarea_grey');
    jQuery('#'+box).prop('disabled',true);
	jQuery('#selectStat').addClass('select_grey');
    jQuery('#selectStat').prop('disabled',true);
  } else {
    jQuery('#'+box).removeClass('textarea_grey');
    jQuery('#'+box).prop('disabled',false);
	jQuery('#selectStat').removeClass('select_grey');
    jQuery('#selectStat').prop('disabled',false);
  }
}

// Greybox window loader..
function mc_Window(w_url,w_height,w_width,w_title) {
  jQuery.GB_hide();
  jQuery.GB_show(w_url, {
   height: w_height,
   width: w_width,
   caption: w_title,
   close_text: 'Close'
  });
  return false;
}

// Homepage slider..
function mc_homeSlider() {
  if (jQuery('#slider').attr('src')=='templates/images/slide-up.png') {
    jQuery('#slider').attr('src','templates/images/slide-down.png');
    jQuery('#homeArea').hide('slow');
  } else {
    jQuery('#slider').attr('src','templates/images/slide-up.png');
    jQuery('#homeArea').show('slow');
  }
}

// Show input box or textarea..
function showNewValueImportBox(id) {
  if (jQuery('#select_'+id).val()=='0') {
    return false;
  }
  switch (jQuery('#select_'+id).val()) {
    case 'pDescription':
    case 'pMetaKeys':
    case 'pMetaDesc':
    case 'pTags':
    case 'vDetails':
    jQuery('#alt_'+id).hide();
    jQuery('#alt_box_'+id).val('');
    jQuery('#alt_text_'+id).show('slow');
    break;
    default:
    jQuery('#alt_text_'+id).hide();
    jQuery('#alt_textarea_'+id).val('');
    jQuery('#alt_'+id).show('slow');
    break;
  }
}

// Copy from shipping
function copyFromShipping() {
  for (var i=1; i<9; i++) {
    if (jQuery('input[name="ship_'+i+'"]')) {
	  jQuery('input[name="bill_'+i+'"]').val(jQuery('input[name="ship_'+i+'"]').val());
	}
  }
  if (jQuery('select[name="shipSetCountry"]')) {
    jQuery('select[name="bill_9"]').val(jQuery('select[name="shipSetCountry"]').val());
  }
}

// Confirm message..
function confirmMessage(txt) {
  var confirmSub = confirm(txt);
  if (confirmSub) { 
    return true;
  } else {
    return false;
  }
}

// Select only parents..
function parentsOnly() {
  jQuery("#checkGrid input:checkbox").each(function() {
    if (jQuery(this).attr('id').substring(0,4)=='pnt_') {
      if (jQuery(this).is(':checked')) {
        jQuery(this).prop('checked',false);
      } else {
        jQuery(this).prop('checked',true);
      }
    }
  });
}

// Select only children for category list..
function selectChildren(id,type) {
  switch (type) {
    case 'on':
    jQuery("#"+id+" input:checkbox").each(function() {
      jQuery(this).prop('checked',true);
    });
    break;
    case 'off':
    jQuery("#"+id+" input:checkbox").each(function() {
      jQuery(this).prop('checked',false);
    });
    break;
  }
}

// Select countries..
function selectCountries() {
  for (var i=0; i<document.forms['form'].elements.length; i++) {
    var e = document.forms['form'].elements[i];
    if ((e.name != 'log') && (e.name != 'clearLogo') && (e.type=='checkbox') && (e.name != 'yes[]')) {
      e.checked = document.forms['form'].log.checked;
    }
  }
}

// Close div..
function closeThisDiv(div) {
  jQuery('#'+div).hide('slow');
}

// Check/uncheck array of checkboxes..
function selectAll(form) {
  for (var i=0; i<document.forms['form'].elements.length; i++) {
    var e = document.forms['form'].elements[i];
    if ((e.name != 'log') && (e.name != 'clearLogo') && (e.name != 'table[]') && (e.name != 'rpref[]') && (e.type=='checkbox')) {
      e.checked = document.forms['form'].log.checked;
    }
  }
}

// Check/uncheck array of checkboxes..
function toggleCheckBoxes(checked,field) {
  if (checked) {
    jQuery('.'+field+' input:checkbox').prop('checked',true);
  } else {
    jQuery('.'+field+' input:checkbox').prop('checked',false);
  }
}

function toggleCheckBoxesID(checked,field) {
  if (checked) {
    jQuery('#'+field+' input:checkbox').prop('checked',true);
  } else {
    jQuery('#'+field+' input:checkbox').prop('checked',false);
  }
}

// Toggles divs..
function toggle_box(id) {
  var e = document.getElementById(id);
  if(e.style.display == 'none') {
    e.style.display = 'block';
  } else {
    e.style.display = 'none';
  }
}

// Adds/removes field boxes for batch operations..
function addRemoveFieldBoxes(op,field) {
  var len   = jQuery('#fieldCloneArea .'+field).length;
  var html = jQuery('#fieldCloneArea .'+field).first().html();
  switch (op) {
    case 'add':
    jQuery('#fieldCloneArea .'+field).first().before('<div class="'+field+'">'+html+'</div>');
    jQuery('#fieldCloneArea .'+field).first().hide().fadeIn('slow');
    break;
    case 'rem':
    if (len>1) {
      jQuery('#fieldCloneArea .'+field).first().remove();
    }
    break;
  }
}

// These two functions add/remove code blocks..
// Legacy versions..
function showBoxes(x,max) {
  for (var i=1; i<=x; i++) {
    jQuery('#row'+i).show();
  }
  for (i=x+1; i<=max; i++) {
    jQuery('#row'+i).hide();
  }
}
function addFieldBoxes(x,min,max) {
  val = parseInt(document.getElementById('num').value);
  val += x;
  if (x<0) {
    if (val<min) val = min;
  } else {
    if (val>max) val = max;
  }
  document.getElementById('num').value = val.toString();
  showBoxes(val,max);
}

// Renames button on click..
function renameButton(id,text) {
  document.getElementById(id).value = text;
}
