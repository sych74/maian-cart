//============================================
// Maian Cart
// Javascript/Ajax Functions
// Written by David Ian Bennett
// http://www.maianscriptworld.co.uk
//
// Incorporating jQuery functions
// Copyright (c) John Resig
// http://jquery.com/
//
// Incorporating jQuery Impromptu
// Copyright (c) Trent Richardson
// http://trentrichardson.com
//
//============================================

//--------------------------------------------
// Save and close restricted IP addresses
//--------------------------------------------

function saveRestrictedIPs(sale) {
  jQuery('#ips').css('background','#fff url(templates/images/loading-box.gif) no-repeat 50% 50%');
  jQuery(document).ready(function() {
    jQuery.post('index.php?p=downloads&saveIP='+sale, { 
       ipaddr: jQuery('#ips').val()
      }, 
      function(data) {
	   jQuery('#ips').css('background-image','none');
	   jQuery('#ipRestrictionBox').slideUp('slow');
    }); 
  });  
  return false;
}

//--------------------------------------------
// Auto Path Fill
//--------------------------------------------

function autoPath(field) {
  jQuery('input[name="'+field+'"]').css('background','#fff url(templates/images/loading-box.gif) no-repeat 1% 50%');
  jQuery(document).ready(function() {
    jQuery.ajax({
      url: 'index.php',
      data: 'p=settings&autoFillPath=yes',
      dataType: 'html',
      success: function (data) {
	    jQuery('input[name="'+field+'"]').css('background-image','none');
		jQuery('input[name="'+field+'"]').val(data);
      }
    });
  });
  return false;
}

//--------------------------------------------
// Resend Gift Certificates
//--------------------------------------------

function mc_resendGiftCert(sale,purchase,txt) {
  var confirmSub = confirm(txt);
  if (confirmSub) { 
    jQuery('#giftArea_'+sale+'_'+purchase).css('background','#fbfbfb url(templates/images/loading-box.gif) no-repeat 99% 50%');
    jQuery(document).ready(function() {
      jQuery.ajax({
        url: 'index.php',
        data: 'p=sales-view&resendGiftCert='+sale+'&purID='+purchase,
        dataType: 'html',
        success: function (data) {
          jQuery('#giftArea_'+sale+'_'+purchase).css('background','#fbfbfb url(templates/images/gift-sent.png) no-repeat 99% 50%');
		  setTimeout(function() {
		    jQuery('#giftArea_'+sale+'_'+purchase).css('background-image','none');
          }, 1500);
        }
      });
    });
  }	
  return false;
}

//--------------------------------------------
// Custom Boxes
//--------------------------------------------

function mc_removeCustomBox(id) {
  var boxes = [];
  var posn  = [];
  var mark  = [];
  jQuery(".CBClass").each(function(i) {
    boxes[i] = jQuery(this).find('input[name="cusBox[]"]').val();
	posn[i]  = jQuery(this).find('input[name="pos[]"]').val();
	mark[i]  = jQuery(this).find('input[name="marker[]"]').val();
  });
  jQuery(document).ready(function() {
    jQuery.post('index.php?p=settings&removeCustomBox=yes', { 
       box: boxes,
	   marker: mark,
	   del: id
      }, 
      function(data) {
	   jQuery('#cus_box_'+id).remove();
	   var n = jQuery('#customBoxesLoader p').length;
	   // If no boxes exist, show message..
	   if (n==0) {
	     jQuery('#customBoxesLoader').html(data);
	   }
    }); 
  });  
  return false;
}

function mc_addCustomBox(selection) {
  var n = jQuery('#customBoxesLoader p').length;
  jQuery(document).ready(function() {
    jQuery.post('index.php?p=settings&updateCustomBoxes=yes', { 
       boxdata: selection,
	   next: n
      }, 
      function(data) {
	   jQuery('#customBoxController').slideUp(function(){
	    jQuery('select[name="temp"]').val('0')
	   });
	   var prev = jQuery('#customBoxesLoader').html();
	   jQuery('#customBoxesLoader').html((n>0 ? prev+data : data)).fadeIn(500);
    }); 
  });  
  return false;
}

//--------------------------------------------
// Generate random string
//--------------------------------------------

function genString(field) {
  var text  = '';
  var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789#[]-*";
  for (var i=0; i<40; i++) {
    text += chars.charAt(Math.floor(Math.random()*chars.length));
  }
  jQuery('#'+field).val(text);
}

//--------------------------------------------
// Next invoice number
//--------------------------------------------

function mc_nextInvoice() {
  jQuery('#invoiceNo').css('background','#fff url(templates/images/loading-box.gif) no-repeat 99% 50%');
  jQuery(document).ready(function() {
    jQuery.ajax({
      url: 'index.php',
      data: 'p=sales-view&nextInvoiceNo=yes',
      dataType: 'html',
      success: function (data) {
        jQuery('#invoiceNo').css('background-image','none');
        jQuery('#invoiceNo').val(data);
      }
    });
  });
  return false;
}

//--------------------------------------------
// Url Slugs
//--------------------------------------------

function slugSuggestions(value) {
  jQuery(document).ready(function() {
   jQuery.post('index.php?p=newpages&urlSlug=yes', { 
    slug: value
   }, 
   function(data) {
     if (data!='NONE') {
       jQuery('#rwslug').val(data);
     }
   }); 
  });  
  return false;
}

function slugCleaner() {
  var str  = jQuery('#rwslug').val();
  var slug = str.replace('/','-');
  var slug = slug.replace(' ','-');
  if (slug!=str) {
    return jQuery('#rwslug').val(slug);
  }
  return jQuery('#rwslug').val(str);
}

//--------------------------------------------
// Batch Updating Product
//--------------------------------------------

function batchAddField(type,id,field) {
  jQuery(document).ready(function() {
    jQuery.ajax({
      url: 'index.php',
      data: 'p=add-product&batchRoutines='+type+'||'+id+'||'+field,
      dataType: 'html',
      success: function (data) {
        switch (data) {
          case 'include':
          jQuery('#'+id).show('slow');
          break;
          case 'exclude':
          jQuery('#'+id).hide('slow');
          break;
        }
      }
    });
  });
  return false;
}

//--------------------------------------------
// ISBN Lookup
//--------------------------------------------

function isbnLookup() {
  if (jQuery('#pName').val()=='') {
    jQuery('#pName').focus();
    return false;
  }
  jQuery('#pName').css('background','#fff url(templates/images/loading-box.gif) no-repeat 99% 50%');
  jQuery(document).ready(function() {
    jQuery.ajax({
      url: 'index.php',
      data: 'p=add-product&isbnLookup='+jQuery('#pName').val(),
      dataType: 'json',
      success: function (data) {
        jQuery('#pName').css('background-image','none');
        switch (data['name']) {
          case 'key-error':
          mc_alertBox(data['text']);
          break;
          case 'unavailable':
          mc_alertBox(data['text']);
          break;
          case 'none':
          mc_alertBox(data['text']);
          break;
          default:
          if (data['name']!='none') {
            jQuery('#pName').val(data['name']);
          } else {
            jQuery('#pName').val('');
          }
          if (data['full_desc']!='none') {
            jQuery('#desc').val(data['full_desc']);
          } else {
            jQuery('#desc').val('');
          }
          if (data['short_desc']!='none') {
            jQuery('#short_desc').val(data['short_desc']);
          } else {
            jQuery('#short_desc').val('');
          }
          break;
        }
      }
    });
  });
  return false;   
}

//--------------------------------------------
// Attribute boxes
//--------------------------------------------

function manageAttributeBoxes(option) {
  var optionSelects = parseInt(jQuery('#attrBoxSet p').length);
  if (option=='add') {
    // Adjust select boxes for all elements..
    // Here we increase the options in the select elements..
    var opt   = '';
    var count = 0;
    for (var i=1; i<parseInt(optionSelects+2); i++) {
      opt += '<option value="'+i+'">'+i+'</option>';
      ++count;
    }
    // Append new option to all current select elements..
    if (count>0) {
      jQuery("#attrBoxSet select").each(function(){
        jQuery(this).last().append('<option value="'+count+'">'+count+'</option>');
      });
    }
    var html = '<span class="text"><input type="text" maxlength="100" name="name[]" class="box" /></span>'+
               '<span class="cost"><input type="text" name="cost[]" class="box" value="0.00" /></span>'+
               '<span class="weight"><input type="text" name="weight[]" class="box" value="0" /></span>'+
               '<span class="stock"><input type="text" name="stock[]" class="box" value="1" /></span>'+
               '<span class="order"><select name="order[]">'+opt+'</select></span><br class="clear" />';
    jQuery('#attrBoxSet').append('<p style=\'margin:5px 0 0 0\'>'+html+'</p>');
  } else {
    if (optionSelects==1) {
      return false;
    }
    jQuery('#attrBoxSet p').last().remove();
    // Remove last option from other drop downs..
    jQuery("#attrBoxSet p select").each(function(){
      jQuery(this).find('[value="'+optionSelects+'"]').remove();
    });
  }
}

//--------------------------------
// Attribute Operations
//--------------------------------

function addAttributeToSale(value,purchase,product) {
  jQuery(document).ready(function() {
   jQuery.ajax({
    url: 'index.php',
    data: 'p=sales-view&addAttribute='+value+'&product='+product,
    dataType: 'json',
    success: function (data) {
      var html = '<div id="attr_'+purchase+'_'+value+'"><input type="text" class="box" name="attr['+purchase+']['+value+']" value="'+data['name']+'" /> @ <input type="text" class="box" style="width:10%" name="attr_cost['+purchase+']['+value+']" value="'+data['cost']+'" /> <a href="#" onclick="hideAttrBox(\''+purchase+'\',\''+value+'\');return false">X</a></div>';
      jQuery('#sel_'+purchase+'_'+value).hide();
	  jQuery('#attsel_'+purchase).hide();
	  jQuery('#attsel_'+purchase).before(html);
	  jQuery('#s_'+purchase).val('0');
      jQuery('#alinks_'+purchase).show();
	}
   });
  });
  return false;
}

function hideAttrBox(purchase,attr) {
  jQuery('#attr_'+purchase+'_'+attr).remove();
  jQuery('#sel_'+purchase+'_'+attr).show();
}

function remAttrDropDown(purchase) {
  jQuery('#attsel_'+purchase).slideUp();
  jQuery('#alinks_'+purchase).show();
}

function hideAttr(purchase) {
  jQuery('#attsel_'+purchase).slideDown();
  jQuery('#alinks_'+purchase).hide();
}

function calcAttr(product,purchase) {
  jQuery('#attr_'+purchase).css('background','#fff url(templates/images/loading-box.gif) no-repeat 1% 50%');
  var total = new Array();
  jQuery('#prodAttrArea_'+purchase+' input[type="text"]').each(function(i) {
    var f = jQuery(this).attr('name');
	if (f.substring(0,9)=='attr_cost') {
      var t    = jQuery(this).val();
	  total[i] = t;
	} else {
	  total[i] = '0';
	}
  });
  jQuery(document).ready(function() {
   jQuery.ajax({
    url: 'index.php',
    data: 'p=sales-view&loadBoxTotals='+total+'&qty='+jQuery('#qty_'+purchase).val(),
    dataType: 'json',
    success: function (data) {
	  jQuery('#attr_'+purchase).css('background-image','none');
      jQuery('#attr_'+purchase).val(data['total']);
	  displayPurchaseProductPrices(purchase,'sales-view');
    }
   });
  });
  return false;
}

function calcPers(product,purchase) {
  jQuery('#pers_'+purchase).css('background','#fff url(templates/images/loading-box.gif) no-repeat 1% 50%');
  var total = new Array();
  var count = 0;
  jQuery('#pWrapper_'+purchase+' input[type="hidden"]').each(function(i) {
    var f = jQuery(this).attr('name');
	if (f.substring(0,4)=='cost') {
	  ++count;
	  var box = jQuery('#ibox_'+purchase+'_'+count).val();
	  if (box!='' && box!='no-option-selected') {
        var t    = jQuery(this).val();
	    total[i] = t;
	  } else {
	    total[i] = '0';
	  }
	} else {
	  total[i] = '0';
	}
  });
  jQuery(document).ready(function() {
   jQuery.ajax({
    url: 'index.php',
    data: 'p=sales-view&loadBoxTotals='+total+'&qty='+jQuery('#qty_'+purchase).val(),
    dataType: 'json',
    success: function (data) {
	  jQuery('#pers_'+purchase).css('background-image','none');
      jQuery('#pers_'+purchase).val(data['total']);
	  displayPurchaseProductPrices(purchase,'sales-view');
    }
   });
  });
  return false;
}

function calcWeight(sale) {
  jQuery('#cartWeight').css('background','#fff url(templates/images/loading-box.gif) no-repeat 98% 50%');
  jQuery(document).ready(function() {
   jQuery.ajax({
    url: 'index.php',
    data: 'p=sales-view&loadSaleWeight='+sale,
    dataType: 'json',
    success: function (data) {
	  jQuery('#cartWeight').css('background-image','none');
      jQuery('#cartWeight').val(data['total']);
    }
   });
  });
  return false;
}

//--------------------------------------------
// Loads preview window via jquery post
//--------------------------------------------

function mc_loadPreviewWindow(box,page) {
  jQuery(document).ready(function() {
    jQuery.post('index.php?prevTxtBox='+page, { 
       boxdata: jQuery('#'+box).val()
      }, 
      function(data) {
       var string = data.split('|||||');
       jQuery.GB_hide();
       jQuery.GB_show('index.php?prevTxtBox='+page, {
         height: 600,
         width: 900,
         caption: string[0],
         close_text: string[1]
       });
       return false;
    }); 
  });  
  return false;
}

//--------------------------------------------
// Load local files
//--------------------------------------------

function mc_loadLocalFiles() {
  jQuery('#pDownloadPath').css('background','url(templates/images/loading-box.gif) no-repeat 99% 50%');
  jQuery(document).ready(function() {
    jQuery.ajax({
      url: 'index.php',
      data: 'p=add-product&showLocalFiles=yes',
      dataType: 'html',
      success: function (data) {
        if (data!='ERR') {
          jQuery('#pDownloadPath').css('background-image','none');
          jQuery('#pathlocator').html(data);
          jQuery('#localFile').show('slow');
        } else {
          jQuery('#pDownloadPath').css('background-image','none');
          jQuery('#fileError').show();
          jQuery('#fileList').hide();
          jQuery('#localFile').show('slow');
        }
      }
    });
  });
  return false;   
}

//--------------------------------------------
// Clear and reset store logo
//--------------------------------------------

function mc_resetStoreLogo(img) {
  jQuery(document).ready(function() { 
    jQuery.ajax({
     url: 'index.php',
     data: 'p=settings&removeLogo='+img,
     dataType: 'html',
     success: function (data) {
       jQuery('#logolink').hide();
       jQuery('#logoimg').attr('src','../templates/images/logo.png');
       mc_alertBox(data);
     }
   }); 
  });
  return false;
}

//--------------------------------------------
// Delete category icon
//--------------------------------------------

function mc_deleteCategoryIcon(icon,id) {
  jQuery(document).ready(function() { 
    jQuery.ajax({
     url: 'index.php',
     data: 'p=categories&removeIcon='+id+'&icon='+icon,
     dataType: 'html',
     success: function (data) {
       jQuery('#resetArea').hide();
       jQuery('#iconImg').attr('src','templates/images/products/no-thumb-image.gif');
       mc_alertBox(data);
     }
   }); 
  });
  return false;
}

//--------------------------------------------
// ONE CLICK ENABLE/DISABLE PRODUCT
//--------------------------------------------

function mc_enableDisableProduct(id) {
  jQuery(document).ready(function() { 
    jQuery.ajax({
      url: 'index.php',
      data: 'p=manage-products&changeStatus='+id,
      dataType: 'json',
      cache: false,
      success: function (data) {
        jQuery('#endis_'+id).html(data['status']);
        mc_alertBox(data['newstatus']);
      }
    }); 
  });
  return false;
}

//--------------------------------------------
// PAGE MANAGEMENT
//--------------------------------------------

function pageManagement(id) {
  jQuery(document).ready(function() { 
    jQuery.ajax({
      url: 'index.php',
      data: 'p=newpages&changeStatus='+id,
      dataType: 'json',
      cache: false,
      success: function (data) {
        jQuery('#img_'+data['id']).attr('src', 'templates/images/'+data['flag']);
        mc_alertBox(data['status']);
      }
    }); 
  });
  return false;
}

//--------------------------------------------
// EDIT STATUS MANAGEMENT
//--------------------------------------------

function loadStatusEditBox(id) {
  jQuery(document).ready(function() { 
    jQuery.ajax({
      url: 'index.php',
      data: 'p=sales-update&loadEditText='+id,
      dataType: 'html',
      cache: false,
      success: function (data) {
        jQuery('#notes_'+id).hide();
        jQuery('#notes_text_'+id).val(data);
        jQuery('#notes_edit_'+id).show('slow');
      }
    }); 
  });
  return false;
}

function updateStatusEditBox(id) {
  jQuery('#notes_text_'+id).css('background','#fff url(templates/images/loading-box.gif) no-repeat 99% 10%');
  jQuery(document).ready(function() { 
    jQuery.ajax({
      type: 'POST',
      url: 'index.php?p=sales-update&statedit=yes&status='+id,
      data: jQuery("#stat_form_area_"+id+" > form").serialize(),
      cache: false,
      dataType: 'html',
      success: function (data) {
        jQuery('#notes_text_'+id).css('background-image','none');
        jQuery('#notes_edit_'+id).hide();
        jQuery('#notes_text_'+id).val('');
        jQuery('#notes_'+id).html(data).show('slow');
      }
    }); 
  });
  return false;
}

function closeStatusEdit(id) {
  jQuery('#notes_text_'+id).val('');
  jQuery('#notes_edit_'+id).hide();
  jQuery('#notes_'+id).show('slow');
  return false;
}

//--------------------------------------------
// SHOW/HIDE ATTRIBUTES/PERSONALISATION
//--------------------------------------------

function mc_showBlock(link,obj) {
  if (jQuery(obj).attr('class')=='show'){
    jQuery(obj).addClass('hide');
    jQuery('#'+link).show('slow');
  } else {
    jQuery(obj).removeClass('hide');
    jQuery(obj).addClass('show');
    jQuery('#'+link).hide('slow');
  }
}

//--------------------------------------------
// MARK PRODUCT FOR DELETION
//--------------------------------------------

function mc_MarkForDeletion(id) {
  jQuery('#price_'+id).val('0.00');
  jQuery('#pers_'+id).val('0.00');
  jQuery('#attr_'+id).val('0.00');
  jQuery('#highlight_'+id).html('0.00');
  jQuery('#purchase_'+id).css('border','1px solid #800000');
}

//--------------------------------------------
// RELOAD PRICES ON QTY CHANGE
//--------------------------------------------

function displayPurchaseProductPrices(id,url) {  
  jQuery('#purchase_'+id).css('border','1px solid #e5e5e5');
  jQuery(document).ready(function() { 
    jQuery.ajax({
      url: 'index.php',
      data: 'p='+url+'&rpp=yes&price='+jQuery('#price_'+id).val()+'&qty='+jQuery('#qty_'+id).val()+'&attr='+jQuery('#attr_'+id).val()+'&pers='+jQuery('#pers_'+id).val(),
      dataType: 'json',
      success: function (data) {
        jQuery('#price_'+id).val(data['price']);
        jQuery('#highlight_'+id).html(data['highlight']);
      }
    });
  }); 
}

//--------------------------------------------
// STATUS TEXT MANAGEMENT
//--------------------------------------------

function addNewStatus(txt) {
  var box = txt+':<br /><input type="text" class="impbox" id="status" name="status" maxlength="250" value="" />';
  jQuery.prompt(box, { 
    buttons: { OK: true, Close: false },
    focus: 2,
    submit: function(e,v,m,f) { 
     if (f.status) { 
      addNewStatusDB(f.status); 
     } 
    },
    top: '30%'
  });
  return false;
}

function addNewStatusDB(txt) {
  if (txt) {
    jQuery(document).ready(function() { 
      jQuery.ajax({
        type: 'POST',
        url:  'index.php?p=sales-update&status_text='+txt,
        data: jQuery("#form_field > form").serialize(),
        cache: false,
        dataType: 'json',
        success: function (data) {
          jQuery.prompt(data['message'], { 
            buttons: { Close: true },
            top: '30%' 
          });
        }
      }); 
    });
  }
  return false;
}

function loadStatusText(id) {
  jQuery(document).ready(function() {  
    jQuery.ajax({
      url: 'index.php',
      data: 'p=sales-update&load_status='+id,
      dataType: 'html',
      success: function (data) {
        jQuery('#text').val('');
        jQuery('#text').val(data);
      }
    });
  });
  return false;
}

//--------------------------------------------
// NEWSLETTER UPDATES
//--------------------------------------------

function updateEmail(email,id) {
  jQuery(document).ready(function() {  
    if (email=='') {
      jQuery('#eboxw_'+id).hide();
      jQuery('#email_'+id).show('slow');
      return false;
    }
    jQuery.ajax({
      url: 'index.php',
      data: 'p=newsletter&email='+email+'&id='+id,
      dataType: 'json',
      success: function (data) {
        switch (data['type']) {
          case 'error':
          mc_alertBox(data['message']);
          break;
          case 'ok':
          mc_alertBox(data['message']);
          jQuery('#eboxw_'+id).hide();
          jQuery('#email_'+id).html(data['email']).show('slow');
          break;
        }
      }
    }); 
  }); 
}

function saveMailTemplate() {
  jQuery(document).ready(function() {
   jQuery.ajax({
    type: 'POST',
    url: 'index.php?p=newsletter&saveTemplate=yes',
    data: jQuery("#content > form").serialize(),
    cache: false,
    dataType: 'html',
    success: function (data) {
      mc_alertBox(data);
    }
   }); 
  });  
  return false;
}

function loadTemplate(id) {
}

function showTemplates() {
  jQuery(document).ready(function() {
   jQuery.ajax({
    url: 'index.php',
    data: 'p=newsletter-mail&loadTemplates=yes',
    dataType: 'html',
    success: function (data) {
      jQuery('#templateOptions').html(data);
      jQuery('#newsTemplates').show('slow');
    }
   });
  });
  return false;
}

//--------------------------------------------------
// RE-CALCULATE TOTALS
// Recalculates totals when viewing or adding sale
//--------------------------------------------------

function sleep(milliseconds) {
  var start = new Date().getTime();
  for (var i=0; i<1e7; i++) {
    if ((new Date().getTime() - start) > milliseconds){
      break;
    }
  }
}

function recalculateManualTotals() {
  jQuery('#subTotal').css('background','#fff url(templates/images/loading-box.gif) no-repeat 99% 50%');
  jQuery('#taxPaid').css('background','#fff url(templates/images/loading-box.gif) no-repeat 99% 50%');
  jQuery('#grandTotal').css('background','#fff url(templates/images/loading-box.gif) no-repeat 99% 50%');
  jQuery('#cartWeight').css('background','#fff url(templates/images/loading-box.gif) no-repeat 99% 50%');
  jQuery('#process_add_sale').val('refresh-prices');
  jQuery(document).ready(function() { 
    jQuery.ajax({
      type: 'POST',
      url: 'index.php?p=sales-add',
      data: jQuery("#form_field > form").serialize(),
      cache: false,
      dataType: 'json',
      success: function (data) {
        jQuery('#subTotal').css('background-image','none').val(data['sub']);
        jQuery('#taxPaid').css('background-image','none').val(data['tax']);
        jQuery('#grandTotal').css('background-image','none').val(data['grand']);
        jQuery('#cartWeight').css('background-image','none').val(data['weight']);
        jQuery('#process_add_sale').val('yes');
      }
    }); 
  });
  return false;
}

function recalculateTotals(id) {
  jQuery('#subTotal').css('background','#fff url(templates/images/loading-box.gif) no-repeat 2% 50%');
  jQuery('#taxPaid').css('background','#fff url(templates/images/loading-box.gif) no-repeat 2% 50%');
  jQuery('#grandTotal').css('background','#fff url(templates/images/loading-box.gif) no-repeat 2% 50%');
  jQuery('#shipTotal').css('background','#fff url(templates/images/loading-box.gif) no-repeat 2% 50%');
  jQuery('#globalTotal').css('background','#fff url(templates/images/loading-box.gif) no-repeat 2% 50%');
  jQuery('#couponTotal').css('background','#fff url(templates/images/loading-box.gif) no-repeat 2% 50%');
  jQuery('#manualDiscount').css('background','#fff url(templates/images/loading-box.gif) no-repeat 2% 50%');
  jQuery('#cartWeight').css('background','#fff url(templates/images/loading-box.gif) no-repeat 99% 50%');
  jQuery('#process_load').val('refresh-prices');
  jQuery(document).ready(function() { 
    jQuery.ajax({
      type: 'POST',
      url: 'index.php?p=sales-view&sale='+id,
      data: jQuery("#form_field > form").serialize(),
      cache: false,
      dataType: 'json',
      success: function (data) {
        jQuery('#subTotal').css('background-image','none').val(data['sub']);
        jQuery('#taxPaid').css('background-image','none').val(data['tax']);
        jQuery('#grandTotal').css('background-image','none').val(data['grand']);
        jQuery('#shipTotal').css('background-image','none');
        jQuery('#globalTotal').css('background-image','none').val(data['global']);
        jQuery('#manualDiscount').css('background-image','none').val(data['manual']);
        jQuery('#couponTotal').css('background-image','none').val(data['coupon']);
        jQuery('#cartWeight').css('background-image','none').val(data['weight']);
        jQuery('#process_load').val('yes');
      }
    });    
  }); 
  return false;
}

//--------------------------------------------
// LOAD SHIPPING PRICE
// Loads shipping service price into box
//--------------------------------------------

function loadShippingPrice(sub_total) {
  jQuery(document).ready(function() {
    if (jQuery('#setShipRateID').val()=='pickup' || jQuery('#setShipRateID').val()=='na') {
      jQuery('#shipTotal').val('0.00');
      return false
    }
    jQuery.get('index.php', {
      p: 'sales-view',
      service: jQuery('#setShipRateID').val(),
      price: sub_total,
      weight: jQuery('#cartWeight').val(),
	  qtys: jQuery('select[name="qty[]"]').serializeArray(),
	  pids: jQuery('input[name="prod_id[]"]').serializeArray()
    },
    function(data) {
      jQuery('#shipTotal').val(data['price']);
    },'json');
  });
}

//--------------------------------------------
// SET ZONE TAX
// Updates zone tax rate if area/zone changed
//--------------------------------------------

function setZoneTax() {
  jQuery(document).ready(function() {
    jQuery.get('index.php', {
      p: 'sales-view',
      z: jQuery('#shipSetArea').val()
    },
    function(data) {
      jQuery('#tax-span').html(data['taxrate']);
      jQuery('#taxRate').val(data['taxrate']);
    },'json');
  });
}

//--------------------------------------------
// RELOAD COUNTRIES 
// Reloads countries on sales page
//--------------------------------------------

function reloadCountry() {
  jQuery(document).ready(function() {
    jQuery('#loader').html('<img src="templates/images/loading.gif" alt="" title="" />');
    jQuery('#loader2').html('<img src="templates/images/loading.gif" alt="" title="" />');
    jQuery.get('index.php', {
      p: 'sales-view',
      c: jQuery('#shipSetCountry').val()
    },
    function(data) {
      jQuery('#loader').html('');
      jQuery('#loader2').html('');
      jQuery('#shipSetArea').html('');
      jQuery('#setShipRateID').html('');
      jQuery('#tax-span').html(data['taxrate']);
      jQuery('#taxRate').val(data['taxrate']);
      jQuery('#shipSetArea').html(data['areas']);
      jQuery('#setShipRateID').html(data['services']);
      },'json');
  });
}


//--------------------------------------------
// CREATE TAGS FROM FIELDS
// Auto creates tags from product fields
//--------------------------------------------

function createTagsFromField(field) {
  jQuery(document).ready(function() {  
    if (jQuery('#'+field).val()=='') {
      return false;
    }
    jQuery('#tags').css('background','#fff url(templates/images/loading-box.gif) no-repeat 99% 5%');
    jQuery.post('index.php', {
      p: 'load-related-products',
      'create-tags': jQuery('#'+field).val(),
      field: field
    },
    function(data) {
      jQuery('#tags').css('background-image','none');
      jQuery('#tags').val(data['text'])
    },'json');
  }); 
}

//--------------------------------------------
// CREATE PICTURE FOLDER
// Creates picture folders
//--------------------------------------------

function createPictureFolder(txt) {
  var box = txt+':<br /><input type="text" class="impbox" id="folderName" name="folderName" maxlength="20" value="" />';
  jQuery.prompt(box, { 
    buttons: { OK: true, Close: false },
    focus: 2,
    submit: function(e,v,m,f) { 
     if (f.folderName) { 
      createPicFolder(f.folderName); 
     } 
    },
    top: '30%'
  });
}

function createPicFolder(folder) {
  jQuery(document).ready(function() {  
    if (folder=='') {
      return false;
    }
    jQuery.get('index.php', {
      p: 'product-pictures',
      'create-folder': folder
    },
    function(data) {
      status      = data['status'];
      error       = data['error'];
      ok          = data['ok'];
      folder      = data['folder'];
      if (status=='error') {
        jQuery.prompt(error, { 
          buttons: { Close: true },
          top: '30%' 
        });
        return false;
      } else {
        getProdImageFolderList(folder);
        jQuery.prompt(ok, { 
          buttons: { Close: true },
          top: '30%' 
        });
        return false;
      }
    },'json');
  });  
}

//--------------------------------------------
// CREATE ATTACHMENTS FOLDERS
// Creates attachment folders
//--------------------------------------------

function createAttachmentFolder(txt) {
  var box = txt+':<br /><input type="text" class="impbox" id="folderName" name="folderName" maxlength="20" value="" />';
  jQuery.prompt(box, { 
    buttons: { OK: true, Close: false },
    focus: 2,
    submit: function(e,v,m,f) { 
     if (v) { 
      createFolder(f.folderName); 
     } 
    },
    top: '30%'
  });
}

function createFolder(folder) {
  jQuery(document).ready(function() {  
    if (folder=='') {
      return;
    }
    jQuery.get('index.php', {
      p: 'sales-update',
      'create-folder': folder
    },
    function(data) {
      status      = data['status'];
      error       = data['error'];
      ok          = data['ok'];
      folder      = data['folder'];
      if (status=='error') {
        jQuery.prompt(error, { 
          buttons: { Close: true },
          top: '30%' 
        });
        return false;
      } else {
        getFolderList(folder);
        jQuery.prompt(ok, { 
          buttons: { Close: true },
          top: '30%' 
        });
        return false;
      }
      },'json');
  });
}

//--------------------------------------------
// LOAD PRODUCTS
// Loads category products
//--------------------------------------------

function loadProducts(product,current,page) {
  jQuery(document).ready(function() { 
    jQuery('#products').html('<img src="templates/images/loading.gif" alt="" title="" />');
    jQuery.ajax({
      url: 'index.php',
      data: 'p=load-related-products&cur='+current+'&pg='+page+'&pr='+product+'&sale='+(page=='sale' || page=='saled' ? current : '0')+'&dl='+(page=='saled' ? 'yes' : 'no'),
      dataType: 'html',
      success: function (data) {
        jQuery('#products').hide();
        jQuery('#products').html(data);
        jQuery('#products').show();
      }
    }); 
  });  
}

function loadSaleProducts(cat,sale,type) {
  jQuery(document).ready(function() { 
    jQuery('#products').html('<img src="templates/images/loading.gif" alt="" title="" />');
    jQuery.ajax({
      url: 'index.php',
      data: 'p=sales-view&id='+sale+'&cat='+cat+'&type='+type+'&reload=yes',
      dataType: 'html',
      success: function (data) {
        jQuery('#products').hide();
        jQuery('#products').html(data);
        jQuery('#products').show();
      }
    }); 
  });  
}

function loadHomeProducts(product) {
  jQuery(document).ready(function() { 
    jQuery('#products').html('<img src="templates/images/loading.gif" alt="" title="" />');
    jQuery.ajax({
      url: 'index.php',
      data: 'p=settings&s=4&reload=yes&pr='+product,
      dataType: 'html',
      success: function (data) {
        jQuery('#products').hide();
        jQuery('#products').html(data);
        jQuery('#products').show();
      }
    }); 
  });  
}

//--------------------------------------------
// ALTERNATIVE ALERT BOX
// via Impromptu
//--------------------------------------------

function mc_alertBox(text) {
  jQuery.prompt(text, { 
    buttons: { Close: true },
    focus: 2,
    top: '30%' 
  });
}
