<?php if (!defined('PARENT')) { die('You do not have permission to view this file!!'); } 

// Display default footer unless commercial licence in place..
if (LICENCE_VER=='locked') {
?>
<div style="background:#fff;border:2px solid #cfcfcf;color:#333;font-size:11px;text-align:center;margin:5px 0 0 0;-webkit-border-radius: 5px 5px 5px 5px;-khtml-border-radius: 5px 5px 5px 5px;-moz-border-radius: 5px 5px 5px 5px;border-radius: 5px 5px 5px 5px;">
  <p style="padding:20px 10px 20px 10px"><a style="color:#333" href="http://www.maiancart.com" title="Maian Cart v<?php echo SCRIPT_VERSION; ?>" onclick="window.open(this);return false">Maian Cart v<?php echo SCRIPT_VERSION; ?></a> &copy; 2006-<?php echo date('Y'); ?> <a style="color:#333" href="http://www.maianscriptworld.co.uk" title="Maian Script World" onclick="window.open(this);return false">Maian Script World</a>. All Rights Reserved.</p>
</div>
<?php
} else {
?>
<div id="footer">
  <?php
  echo $SETTINGS->adminFooter;
  ?>
</div>
<?php
}
?>
</div>
<p>&nbsp;</p>

<?php
if (file_exists(PATH.'templates/footer-custom.php')) {
  include_once(PATH.'templates/footer-custom.php');
}

// Scroll to top..
if (SCROLL_TO_TOP_IMG) {
?>
<script type="text/javascript">
//<![CDATA[
jQuery(document).ready(function() {
  jQuery().UItoTop();
});
//]]>
</script>
<?php
}
?>
</body>
</html>
