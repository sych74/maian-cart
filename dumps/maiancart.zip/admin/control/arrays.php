<?php

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  This File: arrays.php
  Description: Arrays

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

//========================================
// LIST OF ADMIN PAGES
// For restricted access permissions
//========================================

$userPageAccess           =   array(
// SYSTEM..
'settings'                =>  array(
                               1 => $msg_settings7,
                               3 => $msg_settings50,
                               8 => $msg_settings84,
                               2 => $msg_settings61,
                               9 => $msg_settings116,
                               4 => $msg_settings54,
                               5 => $msg_settings19,
                               6 => $msg_settings25,
                               7 => $msg_settings65
                              ),
'currency-converter'      =>  $msg_javascript30,
'newpages'                =>  $msg_javascript198,
'news'                    =>  $msg_javascript421,
'themes'                  =>  $msg_header22,
// CATALOGUE..
'add-product'             =>  $msg_javascript26,
'manage-products'         =>  $msg_productmanage59,
'gift'                    =>  $msg_header23,
'product-export'          =>  $msg_javascript27,
'dl-manager'              =>  $msg_javascript398,
'product-import'          =>  $msg_productadd3,
'categories'              =>  $msg_javascript157,
'brands'                  =>  $msg_javascript158,
'price-points'            =>  $msg_javascript266,
'payment-methods'         =>  $msg_javascript168,
'order-statuses'          =>  $msg_javascript192,
'special-offers'          =>  $msg_javascript62,
'discount-coupons'        =>  $msg_javascript29,
// SHIPPING..
'countries'               =>  $msg_javascript31,
'flatrate'                =>  $msg_javascript438,
'itemrate'                =>  $msg_javascript577,
'percent'                 =>  $msg_javascript439,
'zones'                   =>  $msg_javascript32,
'services'                =>  $msg_javascript100,
'rates'                   =>  $msg_javascript33,
'tare'                    =>  $msg_header20,
'update-rates'            =>  $msg_javascript173,
'update-tax'              =>  $msg_javascript283,
// SALES..
'sales'                   =>  $msg_javascript84,
'sales-incomplete'        =>  $msg_header21,
'sales-add'               =>  $msg_javascript355,
'sales-product-overview'  =>  $msg_javascript163,
'gift-overview'           =>  $msg_header24,
'sales-search'            =>  $msg_javascript111,
'sales-revenue'           =>  $msg_javascript425,
'sales-trends'            =>  $msg_stats21,
'sales-export'            =>  $msg_javascript129,
'sales-export-buyers'     =>  $msg_javascript134,
// TOOLS..
'update-prices'           =>  $msg_javascript60,
'update-stock'            =>  $msg_javascript61,
'low-stock-export'        =>  $msg_javascript319,
'product-status'          =>  $msg_javascript338,
'batch-move'              =>  $msg_javascript197,
'hit-count-overview'      =>  $msg_javascript164,
'stock-overview'          =>  $msg_header19,
'newsletter'              =>  $msg_javascript309,
'stats'                   =>  $msg_javascript140,
'entry-log'               =>  $msg_javascript99,
'search-log'              =>  $msg_javascript108,
'backup'                  =>  $msg_javascript393
);

//======================================
// RESTRICTED ACCESS GROUP ARRAYS
//======================================

$restrictedAccessGroups   =   array(
 0  =>  array('settings','settings_1','settings_2','settings_3','settings_4','settings_5','settings_6',
              'settings_7','settings_8','settings_9','currency-converter','newpages','pages','news','themes'
        ),
 1  =>  array ('add-product','manage-products','gift','dl-manager','product-import','categories','brands','price-points',
               'payment-methods','order-statuses','special-offers','discount-coupons','product-export','product-batch-update'
        ),
 2  =>  array('countries','zones','services','rates','tare','update-rates','update-tax'), 
 3  =>  array('sales','sale-incomplete','sales-add','sales-search','sales-product-overview','sales-revenue','sales-trends',
              'sales-export','sales-export-buyers','gift-overview'
        ),
 4  =>  array('update-prices','update-stock','low-stock-export','product-status','batch-move',
              'hit-count-overview','newsletter','stats','entry-log','search-log','backup','stock-overview'
        )               
);

//================================
// HELP PAGE LINK CONVERTERS
//================================

$helpPages                   = array(
// SYSTEM..
'settings'                   =>  'system-1',
'settings2'                  =>  'settings-3',
'settings3'                  =>  'settings-1',
'settings4'                  =>  'settings-5',
'settings5'                  =>  'settings-6',
'settings6'                  =>  'settings-7',
'settings7'                  =>  'settings-8',
'settings8'                  =>  'settings-2',
'settings9'                  =>  'settings-4',
'currency-converter'         =>  'system-3',
'newpages'                   =>  'system-4',
'users'                      =>  'system-2',
'news'                       =>  'system-5',
'themes'                     =>  'system-6',
// CATALOGUE..
'add-product'                =>  'catalogue-1',
'manage-products'            =>  'catalogue-2',
'gift'                       =>  'catalogue-17',
'gift-report'                =>  'catalogue-17',
'dl-manager'                 =>  'catalogue-12',
'product-attributes'         =>  'catalogue-13',
'product-pictures'           =>  'catalogue-2',
'product-mp3'                =>  'catalogue-2',
'product-related'            =>  'catalogue-2',
'product-import'             =>  'catalogue-10',
'product-batch-update'       =>  'catalogue-16',
'product-attributes-import'  =>  'catalogue-10',
'categories'                 =>  'catalogue-3',
'brands'                     =>  'catalogue-4',
'price-points'               =>  'catalogue-5',
'payment-methods'            =>  'payment-options',
'order-statuses'             =>  'catalogue-7',
'special-offers'             =>  'catalogue-8',
'discount-coupons'           =>  'catalogue-9',
'coupon-report'              =>  'catalogue-9',
'product-personalisation'    =>  'catalogue-11',
'product-export'             =>  'catalogue-15',
// SHIPPING..
'countries'                  =>  'shipping-1',
'zones'                      =>  'shipping-2',
'services'                   =>  'shipping-3',
'rates'                      =>  'shipping-4',
'tare'                       =>  'shipping-10',
'update-rates'               =>  'shipping-5',
'update-tax'                 =>  'shipping-6',
'flatrate'                   =>  'shipping-8',
'itemrate'                   =>  'shipping-11',
'percent'                    =>  'shipping-9',
// SALES..
'sales'                      =>  'sales-1',
'sales-incomplete'           =>  'sales-15',
'sales-add'                  =>  'sales-13',
'sales-product-overview'     =>  'sales-2',
'gift-overview'              =>  'sales-17',
'sales-search'               =>  'sales-3',
'sales-trends'               =>  'sales-6',
'sales-export'               =>  'sales-4',
'sales-export-buyers'        =>  'sales-5',
'sales-update'               =>  'sales-7',
'sales-batch'                =>  'sales-16',
'sales-view'                 =>  'sales-8',
'sales-revenue'              =>  'sales-14',
// TOOLS..
'update-prices'              =>  'tools-1',
'update-stock'               =>  'tools-2',
'low-stock-export'           =>  'tools-9',
'product-status'             =>  'tools-10',
'batch-move'                 =>  'tools-3',
'hit-count-overview'         =>  'tools-4',
'stock-overview'             =>  'tools-12',
'newsletter'                 =>  'tools-8',
'newsletter-mail'            =>  'tools-8',
'stats'                      =>  'tools-5',
'entry-log'                  =>  'tools-6',
'search-log'                 =>  'tools-7',
'backup'                     =>  'tools-11'
);

//===============================
// HELP PAGES - PAYMENT METHODS
//===============================

if (isset($_GET['p']) && $_GET['p']=='payment-methods' && isset($_GET['conf'])) {
  if (in_array($_GET['conf'],array_keys($mcSystemPaymentMethods))) {
    $helpPages['payment-methods'] = $mcSystemPaymentMethods[$_GET['conf']]['docs'];
  }
}

//============================
// CHILDREN OF MAIN PAGES
//============================

$childController             =   array(
'load-related-products'      =>  'product-related',
'coupon-report'              =>  'discount-coupons',
'downloads'                  =>  'sales-view',
'add'                        =>  'sales-view',
'add-manual'                 =>  'sales-add',
'sales-view-recal'           =>  'sales-view',
'gift'                       =>  'gift-certificates',
'gift-report'                =>  'gift-certificates',
'login'                      =>  'portal',
'logout'                     =>  'portal',
'product-attributes-import'  =>  'product-import',
'copy-attributes'            =>  'product-attributes',
'packing-slip'               =>  'invoice',
'sales-statuses'             =>  'sales-update',
'main-stop'                  =>  'main',
'newsletter-mail'            =>  'newsletter',
'newsletter-templates'       =>  'newsletter',
'update-prices-csv'          =>  'update-prices',
'update-stock-csv'           =>  'update-stock'
);

//======================================
// MONEYBOOKERS - SUPPORTED LANGUAGES
//======================================

$moneyBookersLanguages  = array(
'CN' => 'Chinese',
'CZ' => 'Czech',
'DA' => 'Danish',
'NL' => 'Dutch',
'EN' => 'English',
'FI' => 'Finnish',
'FR' => 'French',
'DE' => 'German',
'GR' => 'Greek',
'IT' => 'Italian',
'PL' => 'Polish',
'RO' => 'Romanian',
'RU' => 'Russian',
'ES' => 'Spanish',
'SV' => 'Swedish',
'TR' => 'Turkish'
);

//===================================
// EWAY - SUPPORTED LANGUAGES
//===================================

$ewayLanguages = array(
  'EN' => 'English',
  'FR' => 'French',
  'DE' => 'German',
  'ES' => 'Spanish',
  'NL' => 'Dutch'
);

//===================================
// 2CHECKOUT - SUPPORTED LANGUAGES
//===================================

$twoCheckoutLanguages = array(
  'EN' => 'English',
  'ZH' => 'Chinese',
  'DA' => 'Danish',
  'NL' => 'Dutch',
  'FR' => 'French',
  'GR' => 'German',
  'EL' => 'Greek',
  'IT' => 'Italian',
  'JP' => 'Japanese',
  'NO' => 'Norwegian',
  'PT' => 'Portuguese',
  'SL' => 'Slovenian',
  'SP' => 'Spanish'
);

//===================================
// ICEPAY - SUPPORTED LANGUAGES
//===================================

$icePayLanguages = array(
  'EN' => 'English',
  'FR' => 'French',
  'DE' => 'German',
  'ES' => 'Spanish',
  'NL' => 'Dutch'
);

//===================================
// CCNOW - SUPPORTED LANGUAGES
//===================================

$ccNowLanguages = array(
  'en' => 'English',
  'fr' => 'French',
  'de' => 'German',
  'it' => 'Italian',
  'es' => 'Spanish'
);

//===================================
// BEANSTREAM - SUPPORTED LANGUAGES
//===================================

$beanStreamLanguages = array(
  'ENG' => 'English',
  'FRE' => 'French'
);

//============================================
// SUOMEN VERKKOMAKSUT - SUPPORTED LANGUAGES
//============================================

$suomenVerkkomaksutLanguages = array(
  'en_US' => 'English',
  'fi_FI' => 'Finnish',
  'sv_SE' => 'Swedish'
);

//===================================
// RESTRICTED MENU OPTIONS
//===================================

if (isset($sysCartUser[1]) && $sysCartUser[1]=='restricted') {
} else {
  $helpPages['main'] = 'catalogue-14';
}

?>
