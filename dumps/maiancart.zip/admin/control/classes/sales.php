<?php

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  This File: sales.php
  Description: Class File

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

class sales {

var $settings;

function updateSaleIPAccess() {
  // Update sale parameters..
  mysql_query("UPDATE ".DB_PREFIX."sales SET
  `ipAccess`  = '".mc_safeImportString($_POST['ipaddr'])."'
  WHERE `id`  = '".mc_digitSan($_GET['saveIP'])."'
  LIMIT 1
  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
}

function exportRevenue() {
  global $msg_revenue12;
  // Check writeable permissions..
  if (!is_writeable(PATH.'import')) {
    die('Admin \'import\' folder is not writeable. This is required for export routines. Please update!');
  }
  $seperator  = ',';
  $csvFile    = PATH.'import/revenue-'.mc_convertBoxedDate($_GET['from']).'-'.mc_convertBoxedDate($_GET['to']).'.csv';
  $data       = $msg_revenue12.mc_defineNewline();
  // Loop through data..
  $start     = strtotime(mc_convertCalToSQLFormat($_GET['from']));
  $end       = strtotime(mc_convertCalToSQLFormat($_GET['to']));
  $loopDays  = round(($end-$start)/86400);
  $split     = explode('-',mc_convertCalToSQLFormat($_GET['from']));
  if ($loopDays>0) {
    for ($i=0; $i<($loopDays+1); $i++) {
      $ts       = strtotime(date('Y-m-d',mktime(0,0,0,$split[1],$split[2],$split[0])));
      $day      = date($this->settings->systemDateFormat,strtotime('+ '.$i.' days',$ts));
      $sday     = date('Y-m-d',strtotime('+ '.$i.' days',$ts));
      $qS       = mysql_query("SELECT 
                  SUM(`subTotal`) AS `sub`,
                  SUM(`shipTotal`) AS `ship`,
                  SUM(`taxPaid`) AS `tax`,
                  SUM(`grandTotal`) AS `grand` 
                  FROM `".DB_PREFIX."sales`
                  WHERE `saleConfirmation`  = 'yes'
                  AND `purchaseDate`        = '$sday'
                  AND `paymentStatus`       = '{$_GET['export']}'
                  GROUP BY `purchaseDate`
                  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
      $SALE     = mysql_fetch_object($qS);
      $data    .= sales::cleanCSV($day,$seperator).$seperator;
      $data    .= sales::cleanCSV((isset($SALE->sub) ? mc_formatPrice($SALE->sub) : '0.00'),$seperator).$seperator;
      $data    .= sales::cleanCSV((isset($SALE->ship) ? mc_formatPrice($SALE->ship) : '0.00'),$seperator).$seperator;
      $data    .= sales::cleanCSV((isset($SALE->tax) ? mc_formatPrice($SALE->tax) : '0.00'),$seperator).$seperator;
      $data    .= sales::cleanCSV((isset($SALE->grand) ? mc_formatPrice($SALE->grand) : '0.00'),$seperator).mc_defineNewline();
    }
    if ($data) {
      // Download..
      // Save file to server..
      $fp = fopen($csvFile, 'ab');
      if ($fp) {
        fwrite($fp,trim($data));
        fclose($fp);
      }
      // Download CSV..
      if(@ini_get('zlib.output_compression')) {
        @ini_set('zlib.output_compression', 'Off');
      }
      header('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT');
      header('Pragma: public');
	  header('Expires: 0');
	  header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
	  header('Cache-Control: private',false);
	  header('Content-Type: '.mc_getMimeType($csvFile));
	  header('Content-Type: application/force-download');
	  header('Content-Disposition: attachment; filename="'.basename($csvFile).'";');
	  header('Content-Transfer-Encoding: binary');
	  header('Content-Length: '.filesize($csvFile));
	  @ob_end_flush();
	  readfile($csvFile);
	  // Remove file after download..
	  @unlink($csvFile);
	  exit;
    }
  }  
}

function homepageGraphData() {
  global $msg_script72,$msg_script73,$msg_script41;
  $ticks  = '';
  $line1  = '';
  $line2  = '';
  $line3  = '';
  $range  = (isset($_GET['range']) && in_array($_GET['range'],array('week','month','year')) ? $_GET['range'] : ADMIN_HOME_DEFAULT_SALES_VIEW);
  switch ($range) {
    // Today..
    case 'today':
    $t   = array();
    $l1  = array();
    $l2  = array();
	$l3  = array();
    $ts  = array('00','01','02','03','04','05','06','07','08','09','10','11','12','13','14','15','16','17','18','19','20','21','22','23');
    if (!empty($ts)) {
      foreach ($ts AS $tks) {
        $l1[] = sales::homepageGraphCounts(ltrim($tks,'0'),'physical','today');
        $l2[] = sales::homepageGraphCounts(ltrim($tks,'0'),'download','today');
		$l3[] = sales::homepageGraphCounts(ltrim($tks,'0'),'virtual','today');
        $t[]  = "'$tks'";
      }
      $line1 = implode(',',$l1);
      $line2 = implode(',',$l2);
	  $line3 = implode(',',$l3);
      $ticks = implode(',',$t);
    }
    break;
    // This week..
    case 'week':
    $t      = array();
    $l1     = array();
    $l2     = array();
	$l3     = array();
    $which  = ($this->settings->jsWeekStart=='0' ? $msg_script73 : $msg_script72);
    // Determine start and end day for loop..
    if ($this->settings->jsWeekStart=='0') {
      switch (date('D')) {
        case 'Sun':
        $from  = date("Y-m-d");
        break;
        default:
        $from  = date("Y-m-d",strtotime('last sunday'));
        break;
      }
    } else {
      switch (date('D')) {
        case 'Mon':
        $from  = date("Y-m-d");
        break;
        default:
        $from  = date("Y-m-d",strtotime('last monday'));
        break;
      }
    }
    for ($i=0; $i<7; $i++) {
      $date  = date("Y-m-d",strtotime("+".$i." days",strtotime($from)));
      $l1[]  = sales::homepageGraphCounts($date,'physical','week');
      $l2[]  = sales::homepageGraphCounts($date,'download','week');
	  $l3[]  = sales::homepageGraphCounts($date,'virtual','week');
    }
    foreach ($which AS $ts) {
      $t[]  = "'$ts'";
    }
    $line1 = implode(',',$l1);
    $line2 = implode(',',$l2);
	$line3 = implode(',',$l3);
    $ticks = implode(',',$t);
    break;
    // This month..
    case 'month':
    $t            = array();
    $l1           = array();
    $l2           = array();
	$l3           = array();
    $daysInMonth  = date('t',mktime(0,0,0,date('m'),1,date('Y')));
    if ($daysInMonth>0) {
      for ($i=1; $i<$daysInMonth+1; $i++) {
        $l1[] = sales::homepageGraphCounts($i,'physical','month');
        $l2[] = sales::homepageGraphCounts($i,'download','month');
		$l3[] = sales::homepageGraphCounts($i,'virtual','month');
        $i    = ($i<10 ? '0'.$i : $i);
        $t[]  = "'$i'";
      }
      $line1 = implode(',',$l1);
      $line2 = implode(',',$l2);
	  $line3 = implode(',',$l3);
      $ticks = implode(',',$t);
    }
    break;
    // This year..
    case 'year':
    $t   = array();
    $l1  = array();
    $l2  = array();
	$l3  = array();
    if (!empty($msg_script41)) {
      for ($i=1; $i<13; $i++) {
        $l1[] = sales::homepageGraphCounts($i,'physical','year');
        $l2[] = sales::homepageGraphCounts($i,'download','year');
		$l3[] = sales::homepageGraphCounts($i,'virtual','year');
      }
      foreach ($msg_script41 AS $ts) {
        $t[]  = "'$ts'";
      }
      $line1 = implode(',',$l1);
      $line2 = implode(',',$l2);
	  $line3 = implode(',',$l3);
      $ticks = implode(',',$t);
    }
    break;
  }
  // Prevent JS error..
  if ($line1=='' || $line2=='' || $line3=='' || $ticks=='') {
    return array("'0','0','0'","'0','0','0'","'Invalid Config','Invalid Config','Invalid Config'");  
  }
  return array($line1,$line2,$line3,$ticks);
}

function homepageGraphCounts($value,$type,$range) {
  $today  = date("Y-m-d");
  $month  = date("m");
  $year   = date("Y");
  switch ($range) {
    // Today..
    case 'today':
    $SQL = "WHERE `saleConfirmation` = 'yes' AND `productType` = '$type' AND `purchaseDate` = '$today' AND HOUR(`purchaseTime`) = '$value'";
    break;
    // This week..
    case 'week':
    $SQL = "WHERE `saleConfirmation` = 'yes' AND `productType` = '$type' AND `purchaseDate` = '$value'";
    break;
    // This month..
    case 'month':
    $SQL = "WHERE `saleConfirmation` = 'yes' AND `productType` = '$type' AND MONTH(`purchaseDate`) = '$month' AND YEAR(`purchaseDate`) = '$year' AND DAY(`purchaseDate`) = '$value'";
    break;
    // This year..
    case 'year':
    $SQL = "WHERE `saleConfirmation` = 'yes' AND `productType` = '$type' AND MONTH(`purchaseDate`) = '$value' AND YEAR(`purchaseDate`) = '$year'";
    break;
  }
  $q = mysql_query("SELECT SUM(productQty) AS qty FROM ".DB_PREFIX."purchases $SQL")
       or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  $P = mysql_fetch_object($q);
  return (isset($P->qty) ? $P->qty : "0");
}

function homepageTotalDisplay($range) {
  switch ($range) {
    // Today..
    case 'today':
    $SQL = "WHERE `saleConfirmation` = 'yes' AND `purchaseDate` = '".date("Y-m-d")."'";
    break;
    // This week..
    case 'week':
    if ($this->settings->jsWeekStart=='0') {
      switch (date('D')) {
        case 'Sun':
        $from  = date("Y-m-d");
        $to    = date("Y-m-d",strtotime("+6 days",strtotime($from)));
        break;
        default:
        $from  = date("Y-m-d",strtotime('last sunday'));
        $to    = date("Y-m-d",strtotime("+6 days",strtotime($from)));
        break;
      }
    } else {
      switch (date('D')) {
        case 'Mon':
        $from  = date("Y-m-d");
        $to    = date("Y-m-d",strtotime("+6 days",strtotime($from)));
        break;
        default:
        $from  = date("Y-m-d",strtotime('last monday'));
        $to    = date("Y-m-d",strtotime("+6 days",strtotime($from)));
        break;
      }
    }
    $SQL = "WHERE `saleConfirmation` = 'yes' AND `purchaseDate` BETWEEN '$from' AND '$to'";
    break;
    // This month..
    case 'month':
    $daysInMonth  = date('t',mktime(0,0,0,date('m'),1,date('Y')));
    $from         = date("Y-m").'-01';
    $to           = date("Y-m").'-'.$daysInMonth;
    $SQL          = "WHERE `saleConfirmation` = 'yes' AND `purchaseDate` BETWEEN '$from' AND '$to'";
    break;
    // This year..
    case 'year':
    $from  = date("Y").'-01-01';
    $to    = date("Y").'-12-31';
    $SQL   = "WHERE `saleConfirmation` = 'yes' AND `purchaseDate` BETWEEN '$from' AND '$to'";
    break;
  }
  $q = mysql_query("SELECT SUM(`subTotal`) AS `sb`,SUM(`grandTotal`) AS `gt`,SUM(`taxPaid`+`shipTotal`) AS `sx` FROM `".DB_PREFIX."sales` $SQL")
       or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  $T = mysql_fetch_object($q);
  return (isset($T->sb) ? array($T->sb,$T->sx,$T->gt) : array('0.00','0.00','0.00'));
}

function downloadPageLock($sale,$status,$txt) {
  mysql_query("UPDATE `".DB_PREFIX."sales` SET
  `downloadLock`   = '".($_GET['action']=='lock' ? 'yes' : 'no')."',
  `restrictCount`  = '0'
  WHERE `id`       = '$sale'
  LIMIT 1
  ");
  // Write order status..
  if ($status && DL_LOCK_UNLOCK_STATUS) {
    sales::writeOrderStatus($sale,$txt,$status);
  }
}

function editSaleStatus() {
  mysql_query("UPDATE `".DB_PREFIX."statuses` SET
  `statusNotes`  = '".mc_safeImportString($_POST['notesEdit'])."'
  WHERE `id`     = '".mc_digitSan($_GET['status'])."'
  LIMIT 1
  ");
}

function addStatusText() {
  if ($_GET['status_text'] && $_POST['text']) {
    mysql_query("INSERT INTO ".DB_PREFIX."status_text (
    `statTitle`,
    `statText`
    ) VALUES (
    '".mc_safeImportString($_GET['status_text'])."',
    '".mc_safeImportString($_POST['text'])."'
    )");
  }
}

function updateStatusText() {
  mysql_query("UPDATE ".DB_PREFIX."status_text SET
  `statTitle` = '".mc_safeImportString($_POST['statTitle'])."',
  `statText`  = '".mc_safeImportString($_POST['statText'])."'
  WHERE id    = '".mc_digitSan($_GET['id'])."'
  LIMIT 1
  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
}

function deleteStatusText() {
  $_GET['del'] = mc_digitSan($_GET['del']);
  mysql_query("DELETE FROM ".DB_PREFIX."status_text WHERE id = '{$_GET['del']}' LIMIT 1")
  or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  tableTruncationRoutine(array('status_text'));
}

// Generate buy code for sales..
function generateUniCode($num=50,$email='',$name='') {
  $f  = mc_encrypt(date('Ymdhis').$email.$name.uniqid(rand(),1));
  $f .= mc_encrypt(time().$email.uniqid(rand(),1));
  return substr($f,0,$num);
}

function addManualSale() {
  $code         = sales::generateUniCode(50,date('dmYhis'),uniqid(rand(),1));
  $currentTime  = date("H:i:s");
  $shipType     = 'weight';
  // Adjustments for shipping type..
  switch (substr($_POST['setShipRateID'],0,4)) {
    case 'flat': 
    $shipType               = 'flat';
    $_POST['setShipRateID'] = substr($_POST['setShipRateID'],4);
    break;
    case 'perc': 
    $shipType               = 'percent';
    $_POST['setShipRateID'] = substr($_POST['setShipRateID'],4);
    break;
	case 'pert': 
    $shipType               = 'pert';
    $_POST['setShipRateID'] = substr($_POST['setShipRateID'],4);
    break;
  }
  mysql_query("INSERT INTO ".DB_PREFIX."sales (
  `invoiceNo`,
  `saleNotes`,
  `bill_1`,
  `bill_2`,
  `bill_3`,
  `bill_4`,
  `bill_5`,
  `bill_6`,
  `bill_7`,
  `bill_8`,
  `bill_9`,
  `ship_1`,
  `ship_2`,
  `ship_3`,
  `ship_4`,
  `ship_5`,
  `ship_6`,
  `ship_7`,
  `ship_8`,
  `buyerAddress`,
  `paymentStatus`,
  `gatewayID`,
  `taxPaid`,
  `taxRate`,
  `subTotal`,
  `grandTotal`,
  `shipTotal`,
  `insuranceTotal`,
  `manualDiscount`,
  `isPickup`,
  `shipSetCountry`,
  `shipSetArea`,
  `setShipRateID`,
  `shipType`,
  `cartWeight`,
  `purchaseDate`, 
  `purchaseTime`,
  `buyCode`,
  `saleConfirmation`,
  `paymentMethod`,
  `ipAddress`
  ) VALUES (
  '".mc_safeImportString($_POST['invoiceNo'])."',
  '".mc_safeImportString($_POST['saleNotes'])."',
  '".mc_safeImportString($_POST['bill_1'])."',
  '".mc_safeImportString($_POST['bill_2'])."',
  '".mc_safeImportString($_POST['bill_3'])."',
  '".mc_safeImportString($_POST['bill_4'])."',
  '".mc_safeImportString($_POST['bill_5'])."',
  '".mc_safeImportString($_POST['bill_6'])."',
  '".mc_safeImportString($_POST['bill_7'])."',
  '".mc_safeImportString($_POST['bill_8'])."',
  '".(int)($_POST['bill_9'])."',
  '".mc_safeImportString($_POST['ship_1'])."',
  '".mc_safeImportString($_POST['ship_2'])."',
  '".mc_safeImportString($_POST['ship_3'])."',
  '".mc_safeImportString($_POST['ship_4'])."',
  '".mc_safeImportString($_POST['ship_5'])."',
  '".mc_safeImportString($_POST['ship_6'])."',
  '".mc_safeImportString($_POST['ship_7'])."',
  '".mc_safeImportString($_POST['ship_8'])."',
  '',
  '{$_POST['editStatus']}',
  '".mc_safeImportString($_POST['gatewayID'])."',
  '".mc_safeImportString($_POST['taxPaid'])."',
  '".mc_safeImportString($_POST['taxRate'])."',
  '".mc_safeImportString($_POST['subTotal'])."',
  '".mc_safeImportString($_POST['grandTotal'])."',
  '".mc_safeImportString($_POST['shipTotal'])."',
  '".mc_safeImportString($_POST['insuranceTotal'])."',
  '".mc_safeImportString($_POST['globalTotal'])."',
  '".($_POST['setShipRateID']=='pickup' ? 'yes' : 'no')."',
  '{$_POST['shipSetCountry']}',
  '{$_POST['shipSetArea']}',
  '".($_POST['setShipRateID'] ? $_POST['setShipRateID'] : '0')."',
  '$shipType',
  '".mc_safeImportString($_POST['cartWeight'])."',
  '".date("Y-m-d")."',
  '$currentTime',
  '$code',
  'yes',
  '{$_POST['paymentMethod']}',
  '{$_POST['ipAddress']}'
  )") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  //---------------------------
  // Last inserted sale id..
  //---------------------------
  $id = mysql_insert_id();
  //---------------------------
  // Add purchases..
  //---------------------------
  for ($i=0; $i<count($_POST['pd']); $i++) {
    $marker = $_POST['pd'][$i];
    if ($_POST['qty'][$i]>0) {
      $split     = explode('-',$marker);
      $slot      = "'".$marker."'";
      $atslot    = "'attr-".$marker."'";
      $type      = 'product';
      $price     = mc_formatPrice($_POST['price'][$i]);
      $pr_price  = (isset($_POST['persPrice'][$i]) ? mc_formatPrice($_POST['persPrice'][$i]) : '0.00');
      $at_price  = (isset($_POST['attrPrice'][$i]) ? mc_formatPrice($_POST['attrPrice'][$i]) : '0.00');
      $P         = mc_getTableData('products','id',$split[0]);
      $C         = mc_getTableData('prod_category','product',$split[0]);
      $cat       = (isset($C->category) ? $C->category : '0');
      $weight    = $P->pWeight;
      $iFS       = $P->freeShipping;
      $d1        = $P->id.time().rand(1111,9999);
      $d2        = date('dmYHis').uniqid(rand(),1);
      mysql_query("INSERT INTO ".DB_PREFIX."purchases (
      `purchaseDate`,
      `purchaseTime`,
      `saleID`,
      `productType`,
      `productID`,
      `categoryID`,
      `salePrice`,
      `attrPrice`,
      `persPrice`,
      `productQty`,
      `productWeight`,
      `liveDownload`,
      `downloadAmount`,
      `downloadCode`,
      `buyCode`,
      `saleConfirmation`,
      `freeShipping`
      ) VALUES (
      '".date("Y-m-d")."',
      '$currentTime',
      '$id',
      '".($P->pDownload=='yes' ? 'download' : 'physical')."',
      '".$P->id."',
      '$cat',
      '$price',
      '$at_price',
      '$pr_price',
      '".$_POST['qty'][$i]."',
      '$weight',
      '".$P->pDownload."',
      '0',
      '".($P->pDownload=='yes' ? sales::generateDownloadCode($d1,$d2) : '')."',
      '$code',
      'yes',
      '$iFS'
      )") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
      $lastPurchaseID =  mysql_insert_id();
      //--------------------------
      // Add personalisation..
      //--------------------------
      if (!empty($_POST['product'])) {
        if (isset($_POST['product'][$slot])) {
          for ($j=0; $j<count($_POST['product'][$slot]); $j++) {
            if (isset($_POST['pnvalue'][$slot][$j]) && $_POST['pnvalue'][$slot][$j]!='' && $_POST['pnvalue'][$slot][$j]!='no-option-selected') {
              $ac = '0.00';
              if ($_POST['pnvalue'][$slot][$j]!='' && $_POST['pnvalue'][$slot][$j]!='no-option-selected' && $_POST['cost'][$slot][$j]>0) {
                $ac = mc_formatPrice($_POST['cost'][$slot][$j]);
              }
              mysql_query("INSERT INTO ".DB_PREFIX."purch_pers (
              `saleID`,
              `productID`,
              `purchaseID`,
              `personalisationID`,
              `visitorData`,
              `addCost`
              ) VALUES (
              '{$id}',
              '{$P->id}',
              '{$lastPurchaseID}',
              '".$_POST['persnew'][$slot][$j]."',
              '".mc_safeImportString($_POST['pnvalue'][$slot][$j])."',
              '$ac'
              )") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
            }
          }
        }
      }
      //--------------------------
      // Add attributes..
      //--------------------------
      if (!empty($_POST['attr'])) {
        // Add new if applicable..
        for ($i=0; $i<count($_POST['pd']); $i++) {
	      $pAtID = $_POST['pd'][$i];
          if (!empty($_POST['attr'][$pAtID])) {
            foreach ($_POST['attr'][$pAtID] AS $aK => $aV) {
		      if ($aV) {
                $cost = (isset($_POST['attr_cost'][$pAtID][$aK]) && $_POST['attr_cost'][$pAtID][$aK]>0 ? mc_formatPrice($_POST['attr_cost'][$pAtID][$aK]) : '0.00');
                mysql_query("INSERT INTO ".DB_PREFIX."purch_atts (
                `saleID`,
                `productID`,
                `purchaseID`,
                `attributeID`,
                `addCost`,
			    `attrName`
                ) VALUES (
                '{$id}',
                '{$_POST['prod_id'][$i]}',
                '{$lastPurchaseID}',
                '{$aK}',
                '{$cost}',
			    '".mc_safeImportString(mc_cleanData($aV))."'
                )") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
              }
            }
          }
        }
      }
    }
  }
  // Update stock levels..
  for ($s=0; $s<count($_POST['prod_id']); $s++) {
    if (isset($_POST['qtyAdjustment'][$s])) {
      $stock = (int)$_POST['qtyAdjustment'][$s];
      mysql_query("UPDATE ".DB_PREFIX."products SET
      `pStock`  = '$stock'
      WHERE id  = '{$_POST['prod_id'][$s]}'
      LIMIT 1
      ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    }
  }
  // Add status..
  if ($id>0) {
    sales::writeOrderStatus($id,$_POST['editNotes'],$_POST['editStatus']);
  }
  // Clear session vars..
  unset($_SESSION['add-phys-'.mc_encrypt(SECRET_KEY)],$_SESSION['add-down-'.mc_encrypt(SECRET_KEY)]);
  $_SESSION['add-phys-'.mc_encrypt(SECRET_KEY)] = array();   
  $_SESSION['add-down-'.mc_encrypt(SECRET_KEY)] = array(); 
  return $id;
}

function addProductToSale() {
  global $msg_viewsale73;
  $tweight = 0;
  $looper  = 0;
  $string  = str_replace('{count}',count($_POST['product']),$msg_viewsale73).mc_defineNewline();
  if (!empty($_POST['product'])) {
    foreach ($_POST['product'] AS $p) {
      $P       = mc_getTableData('products','id',$p);
      $price   = ($P->pOffer>0 ? mc_formatPrice($P->pOffer) : mc_formatPrice($P->pPrice));
      $weight  = $P->pWeight;
      $tweight = ($tweight+$weight);
      $d1      = $P->id.time().rand(1111,9999);
      $d2      = date('dmYHis').uniqid(rand(),1);
      $string .= mc_cleanData($P->pName).mc_defineNewline();
      mysql_query("INSERT INTO ".DB_PREFIX."purchases (
      `purchaseDate`,
      `purchaseTime`,
      `saleID`,
      `productType`,
      `productID`,
      `categoryID`,
      `persPrice`,
      `attrPrice`,
      `productQty`,
      `salePrice`,
      `productWeight`,
      `liveDownload`,
      `downloadAmount`,
      `downloadCode`,
      `buyCode`,
      `saleConfirmation`
      ) VALUES (
      '{$_POST['purchaseDate']}',
      '{$_POST['purchaseTime']}',
      '{$_GET['sale']}',
      '".(in_array($_POST['type'],array('physical','download')) ? $_POST['type'] : 'physical')."',
      '".$P->id."',
      '{$_POST['pCat']}',
      '0.00',
      '0.00',
      '1',
      '$price',
      '$weight',
      '{$P->pDownload}',
      '0',
      '".($P->pDownload=='yes' ? sales::generateDownloadCode($d1,$d2) : '')."',
      '{$_POST['buyCode']}',
      'yes'
      )") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
      ++$looper;
    }
  }
  // Adjust sale weight if applicable..
  if ($tweight>0) {
    mysql_query("UPDATE ".DB_PREFIX."sales SET
    `cartWeight`  = ROUND(`cartWeight`+".$tweight.",2)
    WHERE `id`    = '{$_GET['sale']}'
    LIMIT 1
    ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  }
  // Add status..
  if ($looper>0 && NEW_PRODUCT_EDIT_STATUS) {
    sales::writeOrderStatus($_GET['sale'],trim($string),$_POST['status']);
  }
}

function writeOrderStatus($sale,$notes,$status) {
  mysql_query("INSERT INTO ".DB_PREFIX."statuses (
  saleID,statusNotes,dateAdded,timeAdded,orderStatus,adminUser
  ) VALUES (
  '".mc_digitSan($sale)."','".mc_safeImportString($notes)."',
  '".date("Y-m-d")."',
  '".date("H:i:s")."',
  '".mc_safeImportString($status)."',
  '".(isset($_SESSION[mc_encrypt(SECRET_KEY).'_loggedInAs']) ? mc_safeImportString($_SESSION[mc_encrypt(SECRET_KEY).'_loggedInAs']) : 'N/A')."'
  )") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
}

function generateDownloadCode($data,$data2) {
  $f  = mc_encrypt($data);
  $f .= mc_encrypt($data2);
  return substr($f,0,50);
}

function editSale() {
  global $msg_viewsale53,$msg_viewsale92;
  $pcs         = 0;
  $weight_sub  = 0;
  $addc        = '0.00';
  $removed     = '';
  $remcount    = 0;
  $remstring   = '';
  $shipType    = 'weight';
  // Personalised items..
  if (!empty($_POST['pid'])) {
    for ($i=0; $i<count($_POST['pid']); $i++) {
      $slot = $_POST['pid'][$i];
      // Update existing..
      if (isset($_POST['pers'][$slot][$i])) {
        for ($j=0; $j<count($_POST['pers'][$slot]); $j++) {
          if ($_POST['pvalue'][$slot][$j]!='' && $_POST['pvalue'][$slot][$j]!='no-option-selected' && $_POST['qty'][$i]>0) {
            // Update..
            if (mc_rowCount('purch_pers WHERE id = \''.mc_digitSan($_POST['pers'][$slot][$j]).'\' AND saleID = \''.mc_digitSan($_GET['sale']).'\'')>0) {
              mysql_query("UPDATE ".DB_PREFIX."purch_pers SET
              visitorData  = '".mc_safeImportString($_POST['pvalue'][$slot][$j])."'
              WHERE id     = '".mc_digitSan($_POST['pers'][$slot][$j])."'
              AND saleID   = '".mc_digitSan($_GET['sale'])."'
              LIMIT 1
              ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
            } else {
              mysql_query("INSERT INTO ".DB_PREFIX."purch_pers (
              `saleID`,
              `productID`,
              `purchaseID`,
              `personalisationID`,
              `visitorData`,
              `addCost`
              ) VALUES (
              '".mc_digitSan($_GET['sale'])."',
              '{$_POST['product'][$slot][$j]}',
              '{$_POST['pidnew'][$slot][$j]}',
              '{$_POST['pers'][$slot][$j]}',
              '".mc_safeImportString($_POST['pvalue'][$slot][$j])."',
              '".($_POST['cost'][$slot][$j]>0 ? mc_formatPrice($_POST['cost'][$slot][$j]) : '0.00')."'
              )") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
            }
          } else {
            mysql_query("DELETE FROM ".DB_PREFIX."purch_pers WHERE id = '".mc_digitSan($_POST['pers'][$slot][$j])."' AND saleID = '".mc_digitSan($_GET['sale'])."' LIMIT 1")
            or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
            tableTruncationRoutine(array('purch_pers'));
          }
        }
      }
    }
  }
  // Attributes..
  if (!empty($_POST['attr'])) {
    // Remove current..
    mysql_query("DELETE FROM `".DB_PREFIX."purch_atts` WHERE `saleID` = '".mc_digitSan($_GET['sale'])."'")
    or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    tableTruncationRoutine(array('purch_atts'));
    // Add new if applicable..
    for ($i=0; $i<count($_POST['pid']); $i++) {
	  $pAtID = $_POST['pid'][$i];
      if (!empty($_POST['attr'][$pAtID])) {
        foreach ($_POST['attr'][$pAtID] AS $aK => $aV) {
		  if ($aV) {
            $cost = (isset($_POST['attr_cost'][$pAtID][$aK]) && $_POST['attr_cost'][$pAtID][$aK]>0 ? mc_formatPrice($_POST['attr_cost'][$pAtID][$aK]) : '0.00');
            mysql_query("INSERT INTO ".DB_PREFIX."purch_atts (
            `saleID`,
            `productID`,
            `purchaseID`,
            `attributeID`,
            `addCost`,
			`attrName`
            ) VALUES (
            '".mc_digitSan($_GET['sale'])."',
            '{$_POST['prod_id'][$i]}',
            '{$_POST['pid'][$i]}',
            '{$aK}',
            '{$cost}',
			'".mc_safeImportString(mc_cleanData($aV))."'
            )") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
          }
        }
      }
    }
  }
  // Update purchases..
  if (!empty($_POST['pid'])) {
    for ($i=0; $i<count($_POST['pid']); $i++) {
      if ($_POST['qty'][$i]=='0') {
        $SUB         = mc_getTableData('purchases','id',$_POST['pid'][$i],' AND `saleID` = \''.mc_digitSan($_GET['sale']).'\'');
        $PROD_INFO   = mc_getTableData('products','id',$SUB->productID);
        $weight_sub  = ($weight_sub+$SUB->productWeight);
        if (isset($PROD_INFO->id)) {
          $removed  .= mc_cleanData($PROD_INFO->pName).mc_defineNewline();
          ++$remcount;
        }
        mysql_query("DELETE FROM ".DB_PREFIX."purchases WHERE `id` = '".$_POST['pid'][$i]."' AND `saleID` = '".mc_digitSan($_GET['sale'])."' LIMIT 1")
        or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
        mysql_query("DELETE FROM ".DB_PREFIX."purch_pers WHERE `purchaseID` = '".$_POST['pid'][$i]."' AND saleID = '".mc_digitSan($_GET['sale'])."'")
        or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
        mysql_query("DELETE FROM ".DB_PREFIX."purch_atts WHERE `purchaseID` = '".$_POST['pid'][$i]."' AND saleID = '".mc_digitSan($_GET['sale'])."'")
        or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
        tableTruncationRoutine(array('purchases','purch_pers','purch_atts'));
      } else {
        mysql_query("UPDATE ".DB_PREFIX."purchases SET
        `salePrice`        = '".cleanInsertionPrice($_POST['price'][$i])."',
        `persPrice`        = '".(isset($_POST['persPrice'][$i]) ? cleanInsertionPrice($_POST['persPrice'][$i]) : '0.00')."',
        `attrPrice`        = '".(isset($_POST['attrPrice'][$i]) ? cleanInsertionPrice($_POST['attrPrice'][$i]) : '0.00')."',
        `productQty`       = '".mc_digitSan($_POST['qty'][$i])."',
        `saleConfirmation` = '".($_POST['editStatus'] ? 'yes' : $_POST['saleConfirm'])."'
        WHERE `id`         = '".mc_digitSan($_POST['pid'][$i])."'
        LIMIT 1
        ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
        ++$pcs;
      }
    }
  }
  // Update stock levels..
  if (!empty($_POST['prod_id'])) {
    for ($s=0; $s<count($_POST['prod_id']); $s++) {
      if (isset($_POST['qtyAdjustment'][$s])) {
        $stock = (int)$_POST['qtyAdjustment'][$s];
        mysql_query("UPDATE ".DB_PREFIX."products SET
        `pStock`  = '$stock'
        WHERE id  = '{$_POST['prod_id'][$s]}'
        LIMIT 1
        ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
      }
    }
  }
  // At this point, check that purchases still exist for sale..
  // If all have been set to qty 0, remove sale..
  // Updating it would be pointless..
  if ($pcs==0) {
    sales::deleteOrderSale($_GET['sale']);
    header("Location: index.php?p=sales");
    exit;
  }
  // Were any products removed..
  if ($removed) {
    $remstring  = str_replace('{count}',$remcount,$msg_viewsale92).mc_defineNewline();
    $remstring .= $removed;
  }
  // To prevent shipping errors if no shipping..
  $_POST['shipSetCountry'] = (isset($_POST['shipSetCountry']) ? $_POST['shipSetCountry'] : '0');
  $_POST['shipSetArea']    = (isset($_POST['shipSetArea']) ? $_POST['shipSetArea'] : '0');
  $_POST['setShipRateID']  = (isset($_POST['setShipRateID']) ? $_POST['setShipRateID'] : '0');
  // Adjustments for shipping type..
  switch (substr($_POST['setShipRateID'],0,4)) {
    case 'flat': 
    $shipType               = 'flat';
    $_POST['setShipRateID'] = substr($_POST['setShipRateID'],4);
    break;
    case 'perc': 
    $shipType               = 'percent';
    $_POST['setShipRateID'] = substr($_POST['setShipRateID'],4);
    break;
	case 'pert': 
    $shipType               = 'pert';
    $_POST['setShipRateID'] = substr($_POST['setShipRateID'],4);
    break;
  }
  // Update sale parameters..
  mysql_query("UPDATE ".DB_PREFIX."sales SET
  `invoiceNo`         = '".ltrim($_POST['invoiceNo'],'0')."',
  `saleNotes`         = '".mc_safeImportString($_POST['saleNotes'])."',
  `bill_1`            = '".mc_safeImportString($_POST['bill_1'])."',
  `bill_2`            = '".mc_safeImportString($_POST['bill_2'])."',
  `bill_3`            = '".mc_safeImportString($_POST['bill_3'])."',
  `bill_4`            = '".mc_safeImportString($_POST['bill_4'])."',
  `bill_5`            = '".mc_safeImportString($_POST['bill_5'])."',
  `bill_6`            = '".mc_safeImportString($_POST['bill_6'])."',
  `bill_7`            = '".mc_safeImportString($_POST['bill_7'])."',
  `bill_8`            = '".mc_safeImportString($_POST['bill_8'])."',
  `bill_9`            = '".(int)($_POST['bill_9'])."',
  `ship_1`            = '".mc_safeImportString($_POST['ship_1'])."',
  `ship_2`            = '".mc_safeImportString($_POST['ship_2'])."',
  `ship_3`            = '".mc_safeImportString($_POST['ship_3'])."',
  `ship_4`            = '".mc_safeImportString($_POST['ship_4'])."',
  `ship_5`            = '".mc_safeImportString($_POST['ship_5'])."',
  `ship_6`            = '".mc_safeImportString($_POST['ship_6'])."',
  `ship_7`            = '".mc_safeImportString($_POST['ship_7'])."',
  `ship_8`            = '".mc_safeImportString($_POST['ship_8'])."',
  `buyerAddress`      = '',
  `paymentStatus`     = '{$_POST['editStatus']}',
  `gatewayID`         = '".mc_safeImportString($_POST['gatewayID'])."',
  `taxPaid`           = '".cleanInsertionPrice($_POST['taxPaid'])."',
  `taxRate`           = '".mc_digitSan($_POST['taxRate'])."',
  `couponTotal`       = '".(isset($_POST['couponTotal']) ? cleanInsertionPrice($_POST['couponTotal']) : '0.00')."',
  `subTotal`          = '".cleanInsertionPrice($_POST['subTotal'])."',
  `grandTotal`        = '".cleanInsertionPrice($_POST['grandTotal'])."',
  `shipTotal`         = '".cleanInsertionPrice($_POST['shipTotal'])."',
  `insuranceTotal`    = '".cleanInsertionPrice($_POST['insuranceTotal'])."',
  `globalTotal`       = '".(isset($_POST['globalTotal']) ? cleanInsertionPrice($_POST['globalTotal']) : '0.00')."',
  `globalDiscount`    = '".(isset($_POST['globalDiscount']) ? $_POST['globalDiscount'] : '0')."',
  `manualDiscount`    = '".(isset($_POST['manualDiscount']) ? cleanInsertionPrice($_POST['manualDiscount']) : '0.00')."',
  `isPickup`          = '".($_POST['setShipRateID']=='pickup' ? 'yes' : 'no')."',
  `shipSetCountry`    = '{$_POST['shipSetCountry']}',
  `shipSetArea`       = '{$_POST['shipSetArea']}',
  `setShipRateID`     = '{$_POST['setShipRateID']}',
  `shipType`          = '$shipType',
  `cartWeight`        = '".($weight_sub>0 ? mc_safeImportString($_POST['cartWeight']-$weight_sub) : mc_safeImportString($_POST['cartWeight']))."',
  `purchaseDate`      = '".$_POST['years']."-".$_POST['months']."-".$_POST['days']."',  
  `purchaseTime`      = '".$_POST['hrs'].":".$_POST['mins'].":".$_POST['secs']."',  
  `paymentMethod`     = '".mc_safeImportString($_POST['paymentMethod'])."',
  `ipAddress`         = '{$_POST['ipAddress']}',
  `saleConfirmation`  = '".($_POST['editStatus'] ? 'yes' : $_POST['saleConfirm'])."'
  WHERE `id`          = '".mc_digitSan($_GET['sale'])."'
  LIMIT 1
  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  // Update purchases date/time..
  mysql_query("UPDATE ".DB_PREFIX."purchases SET
  `purchaseDate`  = '".$_POST['years']."-".$_POST['months']."-".$_POST['days']."',
  `purchaseTime`  = '".$_POST['hrs'].":".$_POST['mins'].":".$_POST['secs']."'
  WHERE `saleID`  = '".mc_digitSan($_GET['sale'])."'
  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  // Add edit status..
  if (isset($_POST['editStatus'])) {
    sales::writeOrderStatus($_GET['sale'],($remstring ? mc_safeImportString(trim($remstring)).mc_defineNewline().mc_defineNewline() : '').trim($_POST['editNotes']),$_POST['editStatus']);
  } else {
    if ($remstring) {
      sales::writeOrderStatus($_GET['sale'],mc_safeImportString(trim($remstring)),$_POST['editStatus']);
    }
  }
}

function reloadServices($getzonerate=false) {
  global $msg_javascript214,$msg_javascript215,$msg_viewsale45,$msg_viewsale95,$msg_viewsale124,$msg_viewsale96,
         $msg_viewsale125,$msg_viewsale106;
  $string = '';
  if ($this->settings->enablePickUp=='yes') {
    $string .= '<optgroup label="'.$msg_javascript214.'">';
    $string .= '<option value="pickup">'.$msg_javascript215.'</option>'.mc_defineNewline();
    $string .= '</optgroup>';
  }
  $q_zone = mysql_query("SELECT `id`,`zName`,`zRate` FROM `".DB_PREFIX."zones` 
            WHERE `zCountry` = '{$_GET['c']}'
            ORDER BY `zName`
            ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  while ($Z = mysql_fetch_object($q_zone)) {
    if ($getzonerate) {
      return ($Z->zRate=='' ? '0' : $Z->zRate);
    }
    $q_service = mysql_query("SELECT `id`,`sName` FROM `".DB_PREFIX."services`
                 WHERE `inZone` = '{$Z->id}'
                 ORDER BY `sName`
                 ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    //---------------------------------------------------------------------
    $q_flat = mysql_query("SELECT `id`,`rate` FROM ".DB_PREFIX."flat
              WHERE `inZone` = '{$Z->id}'
              LIMIT 1
              ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    $FLAT = mysql_fetch_object($q_flat);     
	//---------------------------------------------------------------------
	$q_prte = mysql_query("SELECT `id`,`rate`,`item` FROM `".DB_PREFIX."per`
              WHERE `inZone` = '{$Z->id}'
              LIMIT 1
              ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    $PER_ITEM = mysql_fetch_object($q_prte);  
    //---------------------------------------------------------------------
    $q_percent = mysql_query("SELECT * FROM `".DB_PREFIX."percent`
                 WHERE `inZone` = '{$Z->id}'
                 ORDER BY `priceFrom`*100,`priceTo`*100
                 ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
	if (mysql_num_rows($q_service)>0 || mysql_num_rows($q_percent)>0 || isset($FLAT->id) || isset($PER_ITEM->id)) {
      $string .= '<optgroup label="'.mc_cleanData($Z->zName).'">'.mc_defineNewline();
    }
	//---------------------------------------------------------------------
    // Flat
    //---------------------------------------------------------------------
    if (isset($FLAT->id)) {
      $string .= '<option value="0" disabled="disabled">(&#043;) '.$msg_viewsale95.'</option>';
      $string .= '<option value="flat'.$FLAT->id.'">'.$msg_viewsale95.' - '.mc_currencyFormat(mc_formatPrice($FLAT->rate)).'</option>';
    }
	//---------------------------------------------------------------------
    // PerItem Rate
    //---------------------------------------------------------------------
    if (isset($PER_ITEM->id)) {
      $string .= '<option value="0" disabled="disabled">(&#043;) '.$msg_viewsale124.'</option>';
      $string .= '<option value="pert'.$PER_ITEM->id.'">'.str_replace(array('{first}','{item}'),array(mc_currencyFormat(mc_formatPrice($PER_ITEM->rate)),mc_currencyFormat(mc_formatPrice($PER_ITEM->item))),$msg_viewsale125).'</option>';
    }
    //---------------------------------------------------------------------
    // Percentage based..
    //---------------------------------------------------------------------
    if (mysql_num_rows($q_percent)>0) {
      $string .= '<option value="0" disabled="disabled">(&#043;) '.$msg_viewsale96.'</option>';
      while ($PR = mysql_fetch_object($q_percent)) {
        $string .= '<option value="perc'.$PR->id.'">&nbsp;'.mc_currencyFormat(mc_formatPrice($PR->priceFrom)).' - '.mc_currencyFormat(mc_formatPrice($PR->priceTo)).' ('.$PR->percentage.'%)</option>';
      }
    }
	//---------------------------------------------------------------------
	// Services - weight based
	//---------------------------------------------------------------------
    while ($S = mysql_fetch_object($q_service)) {
      $string .= '<option value="0" disabled="disabled">(&#043;) '.mc_cleanData($S->sName).'</option>'.mc_defineNewline();
	  $q_rates = mysql_query("SELECT * FROM `".DB_PREFIX."rates`
                 WHERE `rService` = '{$S->id}'
                 ORDER BY `id`
                 ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
      while ($R = mysql_fetch_object($q_rates)) { 
        // Tare weight..
        $tareCost = '';
        $tare     = getTareWeight(0,$R->rService,array($R->rWeightFrom,$R->rWeightTo));
        if (isset($tare[0]) && $tare[0]=='yes') {
          switch (substr($tare[1],-1)) {
            case '%':
            $calc     = substr($tare[1],0,-1).'%';
            $tareCost = str_replace('{amount}',$calc,$msg_viewsale106);
            break;
            default:
            $tareCost = str_replace('{amount}',mc_currencyFormat(mc_formatPrice($tare[1])),$msg_viewsale106);
            break;
          }
        } 
      }
	  $q_rates = mysql_query("SELECT * FROM `".DB_PREFIX."rates`
                 WHERE `rService` = '{$S->id}'
                 ORDER BY `id`
                 ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
      while ($R = mysql_fetch_object($q_rates)) {             
        $string .= '<option value="'.$R->id.'">&nbsp;'.$R->rWeightFrom.' - '.$R->rWeightTo.' ('.mc_currencyFormat(mc_formatPrice($R->rCost)).$tareCost.')</option>'.mc_defineNewline();
      }
    }
    if (mysql_num_rows($q_service)>0 || mysql_num_rows($q_percent)>0 || isset($FLAT->id) || isset($PER_ITEM->id)) {
      $string .= '</optgroup>'.mc_defineNewline();
    }
  }
  if ($getzonerate) {
    return '0';
  }
  return ($string ? trim($string) : '<option value="0">'.$msg_viewsale45.'</option>');
}

function reloadCountries() {
  global $msg_viewsale45;
  $string = '';
  $q_zone = mysql_query("SELECT `id`,`zName` FROM `".DB_PREFIX."zones` 
            WHERE `zCountry` = '{$_GET['c']}'
            ORDER BY `zName`
            ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  while ($Z = mysql_fetch_object($q_zone)) {
    $q_zarea   = mysql_query("SELECT `id`,`areaName` FROM `".DB_PREFIX."zone_areas`
                 WHERE `inZone` = '{$Z->id}'
                 ORDER BY `areaName`
                 ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    if (mysql_num_rows($q_zone)>0) {
      $string .= '<optgroup label="'.mc_cleanData($Z->zName).'">'.mc_defineNewline();
    }
    while ($ZAREA = mysql_fetch_object($q_zarea)) {
      $string .= '<option value="'.$ZAREA->id.'">'.mc_cleanData($ZAREA->areaName).'</option>'.mc_defineNewline();
    }
    if (mysql_num_rows($q_zone)>0) {
      $string .= '</optgroup>'.mc_defineNewline();
    }
  }
  return ($string ? trim($string) : '<option value="0">'.$msg_viewsale45.'</option>');
}

function addActivationLog($sale,$products,$count) {
  global $msg_viewsale49;
  $user = str_replace(array('{user}','{count}'),
                      array((isset($_SESSION[mc_encrypt(SECRET_KEY).'_loggedInAs']) ? mc_safeImportString($_SESSION[mc_encrypt(SECRET_KEY).'_loggedInAs']) : 'N/A'),
                            $count
                      ),
                      $msg_viewsale49
          );
  mysql_query("INSERT INTO `".DB_PREFIX."activation_history` (
  `saleID`,`products`,`restoreDate`,`restoreTime`,`adminUser`
  ) VALUES (
  '$sale','$products','".date("Y-m-d")."',
  '".date("H:i:s")."',
  '".(isset($_SESSION[mc_encrypt(SECRET_KEY).'_loggedInAs']) ? mc_safeImportString($_SESSION[mc_encrypt(SECRET_KEY).'_loggedInAs']) : 'N/A')."'
  )") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__)); 
  // Add entry to order history..
  $lastStatus = mc_getTableData('statuses','saleID',$sale,'ORDER BY `id` DESC','orderStatus');
  if (DL_ACTIVATE_STATUS) {
    sales::writeOrderStatus($sale,trim($user),$lastStatus->orderStatus);
  }
}

function activateDownloads($code,$id) {
  mysql_query("UPDATE `".DB_PREFIX."purchases` SET
  `liveDownload`    = 'yes',
  `downloadAmount`  = '0',
  `downloadCode`    = '$code'
  WHERE `id`        = '$id'
  LIMIT 1
  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  // Reset zip limit, lock and restriction count..
  mysql_query("UPDATE `".DB_PREFIX."sales` SET
  `zipLimit`       = '0',
  `downloadLock`   = 'no',
  `restrictCount`  = '0'
  WHERE `id`       = '{$_GET['sale']}'
  LIMIT 1
  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
}

function batchUpdateOrderStatus($sale) {
  // Add status..
  sales::writeOrderStatus($sale,$_POST['text'],$_POST['status']);
  $id = mysql_insert_id();
  // Update sale to reflect change..
  mysql_query("UPDATE ".DB_PREFIX."sales SET
  `paymentStatus` = '{$_POST['status']}'
  WHERE `id`      = '{$sale}'
  LIMIT 1
  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  if ($_POST['copy_email']!='') {
    mysql_query("UPDATE ".DB_PREFIX."settings SET
    `batchMail`    = '".mc_safeImportString($_POST['copy_email'])."'
	LIMIT 1
    ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  }
  return $id;
}

function updateOrderStatus() {
  $_GET['sale'] = mc_digitSan($_GET['sale']);
  // Add status..
  sales::writeOrderStatus($_GET['sale'],$_POST['text'],$_POST['status']);
  $id = mysql_insert_id();
  // Update sale to reflect change..
  mysql_query("UPDATE ".DB_PREFIX."sales SET
  `paymentStatus`    = '{$_POST['status']}',
  `orderCopyEmails`  = '{$_POST['copy_email']}',
  `saleConfirmation` = '".($_POST['status'] ? 'yes' : $_POST['saleConfirm'])."'
  WHERE `id`         = '{$_GET['sale']}'
  LIMIT 1
  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  return $id;
}

function addStatusAttachments($id) {
  // Save attachments to server and add to database..
  $attachments = array();
  $isSaving    = (isset($_POST['save']) && $_POST['save']=='yes' ? 'yes' : 'no');
  $saveFolder  = ($isSaving=='yes' ? ($_POST['folder']==ATTACH_FOLDER ? ATTACH_FOLDER : ATTACH_FOLDER.'/'.$_POST['folder']) : ATTACH_FOLDER);
  if (!empty($_FILES['attachment']['tmp_name'])) {
    for ($i=0; $i<count($_FILES['attachment']['tmp_name']); $i++) {
      if (ATTACHMENT_FILE_CLEANUP) {
        $ext   = strrchr(strtolower($_FILES['attachment']['name'][$i]), '.');
        $name  = preg_replace('/'.ATTACHMENT_FILE_CLEANUP.'/','',substr($_FILES['attachment']['name'][$i],0,-strlen($ext)+1)).$ext;
      } else {
        $name = $_FILES['attachment']['name'][$i];
      }
      $temp  = $_FILES['attachment']['tmp_name'][$i];
      $size  = $_FILES['attachment']['size'][$i];
      $type  = $_FILES['attachment']['type'][$i];
      if ($name && $temp && $size>0) {
        if (is_uploaded_file($temp) && $isSaving=='yes') {
          move_uploaded_file($temp,PATH.$saveFolder.'/'.$name);
          if (file_exists(PATH.$saveFolder.'/'.$name)) {
            $attachments[] = PATH.$saveFolder.'/'.$name.'|||||'.$name;
          }
        } else {
          if (file_exists($temp)) {
            $attachments[] = $temp.'|||||'.$name;
          }
        }
        // Add to database..
        mysql_query("INSERT INTO `".DB_PREFIX."attachments` ( 
        `saleID`,
        `statusID`,
        `attachFolder`,
        `fileName`,
        `fileType`,
        `fileSize`,
        `isSaved` 
        ) VALUES (
        '".mc_digitSan($_GET['sale'])."',
        '$id',
        '".($isSaving=='yes' ? $saveFolder : '')."',
        '".mc_safeImportString($name)."',
        '$type',
        '".($isSaving=='yes' ? $size : '0')."',
        '$isSaving'
        )") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
      }
    }
  }
  return $attachments;
}

function clearAllAttachments($files=array()) {
  foreach ($files AS $attachments) {
    $split = explode('|||||',$attachments);
    if (file_exists($split[0])) {
      @unlink($split[0]);
    }
  }
}

function deleteOrderStatus() {
  mysql_query("DELETE FROM `".DB_PREFIX."statuses` 
  WHERE `id` = '".mc_digitSan($_GET['delete'])."'
  LIMIT 1
  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  $rows = mysql_affected_rows();
  $query = mysql_query("SELECT `attachFolder`,`fileName` FROM `".DB_PREFIX."attachments`
           WHERE `statusID` = '".mc_digitSan($_GET['delete'])."'
           ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  while ($ATT = mysql_fetch_object($query)) {
    if (file_exists(PATH.$ATT->attachFolder.'/'.$ATT->fileName)) {
      @unlink(PATH.$ATT->attachFolder.'/'.$ATT->fileName);
    }
  }
  mysql_query("DELETE FROM `".DB_PREFIX."attachments` 
  WHERE `statusID` = '".mc_digitSan($_GET['delete'])."'
  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  tableTruncationRoutine(array('statuses','attachments'));
  return $rows;
}

function createAttachmentsFolder($folder) {
  $chmod  = (CHMOD_VALUE ? CHMOD_VALUE : 0777);
  $status = 'error';
  if (is_dir(PATH.ATTACH_FOLDER) && is_writeable(PATH.ATTACH_FOLDER)) {
    $oldumask = @umask(0); 
    @mkdir(PATH.ATTACH_FOLDER.'/'.$folder,$chmod);
    @umask($oldumask); 
    if (is_dir(PATH.ATTACH_FOLDER.'/'.$folder)) {
      return 'ok';
    }
  }
  return $status;
}

function exportStatsToCSV() {
  global $msg_stats19,$msg_stats6;
  // Check writeable permissions..
  if (!is_writeable(PATH.'import')) {
    die('Admin \'import\' folder is not writeable. This is required for export routines. Please update!');
  }
  $seperator  = ',';
  $csvFile    = PATH.'import/stats-'.date('d-m-Y-His').'.csv';
  $split      = explode('|',$_GET['export']);
  $sCounts    = explode('-',$_GET['counts']);
  $data       = $msg_stats19;
  foreach ($split AS $status) {
    $split2 = explode('-',$status);
    $data  .= $seperator.strtolower(statusText($split2[0]));
  }
  $data .= mc_defineNewline();
  if ($_GET['cat']>0) {
    $CAT   = mc_getTableData('categories','id',mc_digitSan($_GET['cat']));
    $data .= sales::cleanCSV(mc_cleanData($CAT->catname),$seperator).$seperator;
  } else {
    $data .= $msg_stats6.$seperator;
  } 
  $data  .= substr($_GET['from'],8,2).'/'.substr($_GET['from'],5,2).'/'.substr($_GET['from'],0,4).$seperator;
  $data  .= substr($_GET['to'],8,2).'/'.substr($_GET['to'],5,2).'/'.substr($_GET['to'],0,4).$seperator;
  $data  .= $sCounts[0].$seperator;
  $data  .= $sCounts[1].$seperator;
  $data  .= $sCounts[2].$seperator;
  $data  .= $sCounts[3].$seperator;
  $data  .= sales::cleanCSV($_GET['gross'],$seperator).$seperator;
  $data  .= sales::cleanCSV($_GET['fees'],$seperator).$seperator;
  $data  .= sales::cleanCSV($_GET['net'],$seperator).$seperator;
  foreach ($split AS $status) {
    $split2 = explode('-',$status);
    $data  .= $split2[1].$seperator;
  }
  // Download..
  // Save file to server..
  $fp = fopen($csvFile, 'ab');
  if ($fp) {
    fwrite($fp,trim($data));
    fclose($fp);
  }
  // Download CSV..
  if(@ini_get('zlib.output_compression')) {
    @ini_set('zlib.output_compression', 'Off');
  }
  header('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT');
  header('Pragma: public');
  header('Expires: 0');
  header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
  header('Cache-Control: private',false);
  header('Content-Type: '.mc_getMimeType($csvFile));
  header('Content-Type: application/force-download');
  header('Content-Disposition: attachment; filename="'.basename($csvFile).'";');
  header('Content-Transfer-Encoding: binary');
  header('Content-Length: '.filesize($csvFile));
  @ob_end_flush();
  readfile($csvFile);
  // Remove file after download..
  @unlink($csvFile);
  exit;
}

function exportSalesToCSV($id=0) {
  global $msg_salesexport11,$cmd,$msg_sales39,$msg_sales41,$mcSystemPaymentMethods;
  $seperator  = (isset($_POST['sep']) ? $_POST['sep'] : ',');
  $header     = (isset($_POST['header']) ? $_POST['header'] : 'yes'); 
  $sales      = '';
  // Check writeable permissions..
  if (!is_writeable(PATH.'import')) {
    die('Admin \'import\' folder is not writeable. This is required for export routines. Please update!');
  }
  // Set format..
  $count        = 0;
  $sqlQuery     = 'AND `s`.`saleConfirmation` = \'yes\' ';
  if (!empty($_POST['method']) && in_array($_POST['method'],array_keys($mcSystemPaymentMethods))) {
    $sqlQuery  .= ($sqlQuery ? mc_defineNewline() : '').'AND `paymentMethod` = \''.$_POST['method'].'\'';
    ++$count;
  }
  // Check date filter..
  if (isset($_POST['from']) && isset($_POST['to']) && mc_checkValidDate($_POST['from'])!='0000-00-00' && mc_checkValidDate($_POST['to'])!='0000-00-00') { 
    if ($_POST['from'] && $_POST['to']) {
      $sqlQuery  .= ($sqlQuery ? mc_defineNewline() : '').'AND `p`.`purchaseDate` BETWEEN \''.mc_convertCalToSQLFormat($_POST['from']).'\' AND \''.mc_convertCalToSQLFormat($_POST['to']).'\'';
      ++$count;
    }
  }
  // Country filter..
  if (isset($_POST['country']) && $_POST['country']>0) {
    $sqlQuery  .= ($sqlQuery ? mc_defineNewline() : '').'AND `shipSetCountry` = \''.mc_digitSan($_POST['country']).'\'';
    ++$count;
  }
  // Range filter..
  if (isset($_POST['range']) && (is_numeric($_POST['range']) && $_POST['range']>0 || in_array($_POST['range'],array('completed','pending','refund','cancelled','despatched','shipping')))) {
    $sqlQuery  .= ($sqlQuery ? mc_defineNewline() : '').'AND `paymentStatus` = \''.$_POST['range'].'\'';
    ++$count;
  }
  if ($id>0) {
    $sqlQuery  .= ($sqlQuery ? mc_defineNewline() : '').'AND s.id = \''.$id.'\'';
  }
  // File name determined by export type..
  // For single sale, use sale invoice number..
  if ($id>0) {
    $csvFile   = PATH.'import/sale-'.mc_saleInvoiceNumber($id).'.csv';
  } else {
    $csvFile   = PATH.'import/sales-'.date('d-m-Y-His').'.csv';
  }
  if ($count==0 && $cmd=='sales-export') {
    return 'none';
  }
  // Header row..
  $query     = mysql_query("SELECT *,DATE_FORMAT(`p`.`purchaseDate`,'".$this->settings->mysqlDateFormat."') AS `sdate`,
               `p`.`id` AS `pID`
               FROM `".DB_PREFIX."sales` AS `s`,`".DB_PREFIX."purchases` AS `p`
               WHERE `s`.`id` = `p`.`saleID`
               $sqlQuery
               ORDER BY `p`.`saleID`,`p`.`id`,`p`.`productID`
               ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  if (mysql_num_rows($query)>0) {
    if ($cmd=='sales-export') {
      if ($header=='yes') {
        $headerData  = $msg_salesexport11;
      }
    } else {
      $headerData  = $msg_sales39;
    }
    while ($CSV = mysql_fetch_object($query)) {
	  if ($CSV->giftID>0) {
	  $GTF      = mc_getTableData('giftcerts','id',$CSV->giftID);
      $code     = 'N/A';
      $weight   = 'N/A';
      $pName    = (isset($GTF->name) && $GTF->name ? $GTF->name : $CSV->deletedProductName);
	  } else {
      $PRD      = mc_getTableData('products','id',$CSV->productID);
      $code     = (isset($PRD->pCode) && $PRD->pCode ? $PRD->pCode : 'N/A');
      $weight   = (isset($PRD->pWeight) && $PRD->pWeight ? $PRD->pWeight : 'N/A');
      $pName    = (isset($PRD->pName) && $PRD->pName ? $PRD->pName : $CSV->deletedProductName);
	  }
      $CTRY     = mc_getTableData('countries','id',$CSV->shipSetCountry,'','cName');
      $shipC    = (isset($CTRY->cName) ? $CTRY->cName : 'N/A');
      $CTRY     = mc_getTableData('countries','id',$CSV->bill_9,'','cName');
      $billC    = (isset($CTRY->cName) ? $CTRY->cName : 'N/A');
      $extra    = '';
      if ($CSV->globalCost>0) {
        $discount = $CSV->globalCost;
      } else {
        $discount = '0.00';
      }
      // Does this sale have attributes?
      $q_at = mysql_query("SELECT * FROM `".DB_PREFIX."purch_atts`
              WHERE `purchaseID`  = '{$CSV->pID}'
              ORDER BY `id`
              ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
      if (mysql_num_rows($q_at)>0) { 
        while ($ATTR = mysql_fetch_object($q_at)) {
          $ATR       = mc_getTableData('attributes','id',$ATTR->attributeID);
          $AG        = mc_getTableData('attr_groups','id',$ATR->attrGroup);
          $extra    .= '- '.mc_cleanData($AG->groupName.': '.$ATTR->attrName).mc_defineNewline();
        }   
      }
      // Does this sale have personalisation?
      $q_ps = mysql_query("SELECT * FROM `".DB_PREFIX."purch_pers`
              WHERE `purchaseID`  = '{$CSV->pID}'
              AND `visitorData`  != ''
              AND `visitorData`  != 'no-option-selected'
              ORDER BY `id`
              ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
      if (mysql_num_rows($q_ps)>0) { 
        if ($extra) {
          $extra = mc_defineNewline().$extra;
        }
        while ($PS = mysql_fetch_object($q_ps)) {
          $PERSONALISED  = mc_getTableData('personalisation','id',$PS->personalisationID);
          $extra        .= '- '.mc_cleanData(mc_persTextDisplay($PERSONALISED->persInstructions,true).': '.$PS->visitorData).mc_defineNewline();
        }   
      } 
      // Legacy address field and new..
      if ($CSV->buyerAddress) {
        $chopAddr    = explode(mc_defineNewline(),$CSV->buyerAddress);
        $addyFields  = sales::cleanCSV($CSV->ship_1,$seperator).$seperator.
        sales::cleanCSV((isset($chopAddr[0]) ? $chopAddr[0] : ''),$seperator).$seperator.
        sales::cleanCSV((isset($chopAddr[1]) ? $chopAddr[1] : ''),$seperator).$seperator.
        sales::cleanCSV((isset($chopAddr[2]) ? $chopAddr[2] : ''),$seperator).$seperator.
        sales::cleanCSV((isset($chopAddr[3]) ? $chopAddr[3] : ''),$seperator).$seperator.
        sales::cleanCSV((isset($chopAddr[4]) ? $chopAddr[4] : ''),$seperator).$seperator.
        sales::cleanCSV($CSV->ship_8,$seperator).$seperator.
        sales::cleanCSV($CSV->ship_2,$seperator).$seperator.
        sales::cleanCSV($shipC,$seperator).$seperator.
        sales::cleanCSV($CSV->bill_1,$seperator).$seperator.
        sales::cleanCSV((isset($chopAddr[0]) ? $chopAddr[0] : ''),$seperator).$seperator.
        sales::cleanCSV((isset($chopAddr[1]) ? $chopAddr[1] : ''),$seperator).$seperator.
        sales::cleanCSV((isset($chopAddr[2]) ? $chopAddr[2] : ''),$seperator).$seperator.
        sales::cleanCSV((isset($chopAddr[3]) ? $chopAddr[3] : ''),$seperator).$seperator.
        sales::cleanCSV((isset($chopAddr[4]) ? $chopAddr[4] : ''),$seperator).$seperator.
        sales::cleanCSV($CSV->bill_8,$seperator).$seperator.
        sales::cleanCSV($CSV->bill_2,$seperator).$seperator.
        sales::cleanCSV($billC,$seperator);
      } else {
        $addyFields  = sales::cleanCSV($CSV->ship_1,$seperator).$seperator.
        sales::cleanCSV($CSV->ship_3,$seperator).$seperator.
        sales::cleanCSV($CSV->ship_4,$seperator).$seperator.
        sales::cleanCSV($CSV->ship_5,$seperator).$seperator.
        sales::cleanCSV($CSV->ship_6,$seperator).$seperator.
        sales::cleanCSV($CSV->ship_7,$seperator).$seperator.
        sales::cleanCSV($CSV->ship_8,$seperator).$seperator.
        sales::cleanCSV($CSV->ship_2,$seperator).$seperator.
        sales::cleanCSV($shipC,$seperator).$seperator.
        sales::cleanCSV($CSV->bill_1,$seperator).$seperator.
        sales::cleanCSV($CSV->bill_3,$seperator).$seperator.
        sales::cleanCSV($CSV->bill_4,$seperator).$seperator.
        sales::cleanCSV($CSV->bill_5,$seperator).$seperator.
        sales::cleanCSV($CSV->bill_6,$seperator).$seperator.
        sales::cleanCSV($CSV->bill_7,$seperator).$seperator.
        sales::cleanCSV($CSV->bill_8,$seperator).$seperator.
        sales::cleanCSV($CSV->bill_2,$seperator).$seperator.
        sales::cleanCSV($billC,$seperator);
      }
      $sales .= sales::cleanCSV(mc_saleInvoiceNumber($CSV->invoiceNo),$seperator).$seperator.
                sales::cleanCSV($pName.($extra ? mc_defineNewline().rtrim($extra) : ''),$seperator).$seperator.
                sales::cleanCSV($code,$seperator).$seperator.
                $CSV->productQty.$seperator.
                $CSV->salePrice.$seperator.
                $CSV->persPrice.$seperator.
                $CSV->attrPrice.$seperator.
                $discount.$seperator.
                $CSV->shipTotal.$seperator.
                $CSV->taxPaid.$seperator.
                $CSV->taxRate.$seperator.
                $CSV->insuranceTotal.$seperator.
                $weight.$seperator.
                $addyFields.$seperator.
                $CSV->sdate.$seperator.
                sales::cleanCSV(mc_paymentMethodName($CSV->paymentMethod),$seperator).$seperator.
                sales::cleanCSV(($CSV->saleNotes ? $CSV->saleNotes : 'N/A'),$seperator).mc_defineNewline();   
    }
  }
  if ($sales && $headerData) {
    // Save file to server..
    $fp = fopen($csvFile, 'ab');
    if ($fp) {
      fwrite($fp,trim($headerData).mc_defineNewline().$sales);
      fclose($fp);
    }
    // Download CSV..
    if(@ini_get('zlib.output_compression')) {
      @ini_set('zlib.output_compression', 'Off');
    }
    header('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT');
    header('Pragma: public');
	header('Expires: 0');
	header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
	header('Cache-Control: private',false);
	header('Content-Type: '.mc_getMimeType($csvFile));
	header('Content-Type: application/force-download');
	header('Content-Disposition: attachment; filename="'.basename($csvFile).'";');
	header('Content-Transfer-Encoding: binary');
	header('Content-Length: '.filesize($csvFile));
	@ob_end_flush();
	readfile($csvFile);
	// Remove file after download..
	@unlink($csvFile);
	exit;
  } else {
	return 'none';
  }
}

function exportBuyersToCSV() {
  // Check writeable permissions..
  if (!is_writeable(PATH.'import')) {
    die('Admin \'import\' folder is not writeable. This is required for export routines. Please update!');
  }
  // Set format..
  $exportFormat = ($_POST['format'] ? mc_cleanData($_POST['format']) : '%name%,%email%');
  $refunded     = (isset($_POST['refunded']) && in_array($_POST['refunded'],array('yes','no')) ? $_POST['refunded'] : 'no');
  $sqlQuery     = '';
  if (!empty($_POST['range'])) {
    $filterIDs  = implode(',',$_POST['range']);
    $sqlQuery  .= ($sqlQuery ? mc_defineNewline() : '').'AND `c`.`category` IN('.$filterIDs.') ';
  }
  // Check date filter..
  if (mc_checkValidDate($_POST['from'])!='0000-00-00' && mc_checkValidDate($_POST['to'])!='0000-00-00') {
    $sqlQuery  .= ($sqlQuery ? mc_defineNewline() : '').'AND `p`.`purchaseDate` BETWEEN \''.mc_convertCalToSQLFormat($_POST['from']).'\' AND \''.mc_convertCalToSQLFormat($_POST['to']).'\'';
  }
  // Country filter..
  if ($_POST['country']>0) {
    $sqlQuery  .= ($sqlQuery ? mc_defineNewline() : '').'AND `shipSetCountry` = \''.mc_digitSan($_POST['country']).'\'';
  }
  if ($sqlQuery=='') {
    return 'none';
  }
  // Refunded data..
  if ($refunded=='no') {
    $sqlQuery  .= ($sqlQuery ? mc_defineNewline() : '').'AND `paymentStatus` != \'refund\'';
  }
  $contacts  = array();
  $csvData   = '';
  $csvFile   = PATH.'import/buyers_'.date('d-m-Y-His').'.csv';
  $query     = mysql_query("SELECT `bill_1`,`bill_2` FROM `".DB_PREFIX."sales` AS `s`,`".DB_PREFIX."purchases` AS `p`,`".DB_PREFIX."prod_category` AS `c`
               WHERE `s`.`id`              = p.saleID
               AND `p`.`productID`         = c.product
               AND `s`.`saleConfirmation`  = 'yes' 
               $sqlQuery
               GROUP BY `bill_1`
               ORDER BY `bill_1`,`bill_2`
               ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  while ($CSV = mysql_fetch_object($query)) {
    $contacts[] = str_replace(array('%name%','%email%'),
                              array(mc_cleanData($CSV->bill_1),mc_cleanData($CSV->bill_2)),$exportFormat
                              );
  }
  if (!empty($contacts)) {
    // Strip duplicates..
    $contacts = array_unique($contacts);
    // Build csv file..
    $csvData = implode(mc_defineNewline(),$contacts);
    // Save file to server..
    $fp = fopen($csvFile, 'ab');
    if ($fp) {
      fwrite($fp,trim($csvData));
      fclose($fp);
    }
    // Download CSV..
    if (@ini_get('zlib.output_compression')) {
      @ini_set('zlib.output_compression', 'Off');
    }
    header('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT');
    header('Pragma: public');
	header('Expires: 0');
	header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
	header('Cache-Control: private',false);
	header('Content-Type: '.mc_getMimeType($csvFile));
	header('Content-Type: application/force-download');
	header('Content-Disposition: attachment; filename="'.basename($csvFile).'";');
	header('Content-Transfer-Encoding: binary');
	header('Content-Length: '.filesize($csvFile));
	@ob_end_flush();
	readfile($csvFile);
	// Remove file after download..
	@unlink($csvFile);
	exit;
  } else {
	return 'none';
  }
}

// Delete sale..
function deleteOrderSale($id=0) {
  if ($id>0) {
    $_GET['delete'] = $id;
  }
  $rows  = 0;
  $del   = (isset($_GET['delete']) && is_numeric($_GET['delete']) ? $_GET['delete'] : '0');
  // Remove attachment files..
  $query = mysql_query("SELECT * FROM `".DB_PREFIX."attachments`
           WHERE `saleID` = '$del'
           ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  while ($ATT = mysql_fetch_object($query)) {
    if ($ATT->isSaved=='yes' && file_exists(PATH.$ATT->attachFolder.'/'.$ATT->fileName)) {
      @unlink(PATH.$ATT->attachFolder.'/'.$ATT->fileName);
    }
  }
  // Remove attachment data..
  mysql_query("DELETE FROM `".DB_PREFIX."attachments` WHERE `saleID` = '$del'")
  or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  // Remove status data..
  mysql_query("DELETE FROM `".DB_PREFIX."statuses` WHERE `saleID` = '$del'")
  or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  // Remove personalisation data..
  mysql_query("DELETE FROM `".DB_PREFIX."purch_pers` WHERE `saleID` = '$del'")
  or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  mysql_query("DELETE FROM `".DB_PREFIX."purchases` WHERE `saleID` = '$del'")
  or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  // Remove download activation history data..
  mysql_query("DELETE FROM `".DB_PREFIX."activation_history` WHERE `saleID` = '$del'")
  or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  // Remove click history data..
  mysql_query("DELETE FROM `".DB_PREFIX."click_history` WHERE `saleID` = '$del'")
  or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  // Remove comparisons data..
  mysql_query("DELETE FROM `".DB_PREFIX."comparisons` WHERE `saleID` = '$del'")
  or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  // Remove coupon data..
  mysql_query("DELETE FROM `".DB_PREFIX."coupons` WHERE `saleID` = '$del'")
  or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  // Remove sale data..
  mysql_query("DELETE FROM `".DB_PREFIX."sales` WHERE `id` = '$del'")
  or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  $rows = mysql_affected_rows();
  tableTruncationRoutine(array('attachments','statuses','purch_pers','purchases','activation_history',
                               'click_history','comparisons','coupons','sales')
  );
  return $rows;
}

// Adds quotes to data..
function cleanCSV($data,$del) {
  $data = str_replace('"','',$data);
  return '"'.mc_cleanData($data).'"';
}

}

?>
