<?php

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  This File: gateways.php
  Description: Class File

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

class gateways {

function updatePaymentMethods() {
  mysql_query("UPDATE `".DB_PREFIX."methods` SET
  `status`        = '".(isset($_POST['status']) && in_array($_POST['status'],array('yes','no')) ? $_POST['status'] : 'yes')."',
  `liveserver`    = '".(isset($_POST['liveserver']) ? mc_safeImportString($_POST['liveserver']) : '')."',
  `sandboxserver` = '".(isset($_POST['sandboxserver']) ? mc_safeImportString($_POST['sandboxserver']) : '')."',
  `plaintext`     = '".(isset($_POST['plaintext']) ? mc_safeImportString($_POST['plaintext']) : '')."',
  `htmltext`      = '".(isset($_POST['htmltext']) ? mc_safeImportString($_POST['htmltext']) : '')."',
  `info`          = '".(isset($_POST['info']) ? mc_safeImportString(mc_cleanBBInput($_POST['info'])) : '')."',
  `redirect`      = '".(isset($_POST['redirect']) ? mc_safeImportString($_POST['redirect']) : '')."',
  `statuses`      = '".serialize($_POST['orderStatus'])."'
  WHERE `method`  = '".mc_safeImportString($_POST['area'])."'
  LIMIT 1
  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  // Parameters. If it doesn`t exist, insert it..
  if (!empty($_POST['params'])) {
    foreach ($_POST['params'] AS $k => $v) {
      if (mc_rowCount('methods_params WHERE `method` = \''.mc_safeImportString($_POST['area']).'\' AND `param` = \''.$k.'\'')>0) {
        mysql_query("UPDATE `".DB_PREFIX."methods_params` SET
        `value`         = '".mc_safeImportString($v)."'
        WHERE `method`  = '".mc_safeImportString($_POST['area'])."'
        AND `param`     = '{$k}'
        LIMIT 1
        ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
      } else {
        mysql_query("INSERT INTO `".DB_PREFIX."methods_params` (
        `method`,`value`,`param`
        ) VALUES (
        '".mc_safeImportString($_POST['area'])."','".mc_safeImportString($v)."','{$k}'
        )") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
      }
    }
  }
}

function enableDisablePaymentMethods() {
  mysql_query("UPDATE ".DB_PREFIX."methods SET
  `status` = '".(isset($_GET['enable']) ? 'yes' : 'no')."'
  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
}

}

?>
