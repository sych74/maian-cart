<?php

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  This File: system.php
  Description: Class File

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

class systemEngine {

var $settings;

function reOrderGiftCerts() {
  if (!empty($_GET['gcode']) && is_array($_GET['gcode'])) {
    foreach ($_GET['gcode'] AS $k => $v) {
      mysql_query("UPDATE `".DB_PREFIX."giftcerts` SET
      `orderBy`  = '".($k+1)."'
      WHERE `id` = '".mc_digitSan($v)."'
      LIMIT 1
      ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    }
  }
}

function exportGiftOverviewToCSV() {
  global $msg_giftoverview12;
  // Check writeable permissions..
  if (!is_writeable(PATH.'import')) {
    die('Admin \'import\' folder is not writeable. This is required for export routines. Please update!');
  }
  $seperator  = ',';
  $csvFile    = PATH.'import/gift-certificates-'.date('d-m-Y-His').'.csv';
  $data       = $msg_giftoverview12.mc_defineNewline();
  $SQL        = 'WHERE `active` = \'yes\'';
  switch ($_GET['export']) {
    case 'redeemed':
	$SQL = "WHERE `value` != `redeemed` AND `active` = 'yes'";
	break;
	case 'disabled':
	$SQL = "WHERE `enabled` = 'no' AND `active` = 'yes'";
	break;
  }
  if (isset($_GET['keys'])) {
    $sKeys  = '%'.mc_safeImportString($_GET['keys']).'%';
    $sKeysD = mc_safeImportString($_GET['keys']);
    $SQL   .= ($SQL ? 'AND ' : 'WHERE ')."(`from_name` LIKE '{$sKeys}' OR `to_name` LIKE '{$sKeys}' OR `from_email` LIKE '{$sKeys}' OR `to_email` LIKE '{$sKeys}' OR `code` LIKE '{$sKeys}' OR `notes` LIKE '{$sKeys}' OR `dateAdded` = '{$sKeysD}')";
  }
  $q_p = mysql_query("SELECT * FROM `".DB_PREFIX."giftcodes` $SQL ORDER BY `id` DESC")
         or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  while ($GIFT = mysql_fetch_object($q_p)) {
    $data .= systemEngine::cleanCSV(mc_cleanData($GIFT->from_name),$seperator).$seperator.
	systemEngine::cleanCSV($GIFT->from_email,$seperator).$seperator.
	systemEngine::cleanCSV(mc_cleanData($GIFT->to_name),$seperator).$seperator.
	systemEngine::cleanCSV($GIFT->to_email,$seperator).$seperator.
	systemEngine::cleanCSV(date($this->settings->systemDateFormat,strtotime($GIFT->dateAdded)),$seperator).$seperator.
	systemEngine::cleanCSV($GIFT->value,$seperator).$seperator.
	systemEngine::cleanCSV($GIFT->redeemed,$seperator).$seperator.
	systemEngine::cleanCSV($GIFT->code,$seperator).$seperator.
	systemEngine::cleanCSV(mc_cleanData($GIFT->notes),$seperator).mc_defineNewline();
  }
  $fp = fopen($csvFile, 'ab');
  if ($fp) {
    fwrite($fp,trim($data));
    fclose($fp);
  }
  // Download CSV..
  if(@ini_get('zlib.output_compression')) {
    @ini_set('zlib.output_compression', 'Off');
  }
  header('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT');
  header('Pragma: public');
  header('Expires: 0');
  header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
  header('Cache-Control: private',false);
  header('Content-Type: '.mc_getMimeType($csvFile));
  header('Content-Type: application/force-download');
  header('Content-Disposition: attachment; filename="'.basename($csvFile).'";');
  header('Content-Transfer-Encoding: binary');
  header('Content-Length: '.filesize($csvFile));
  @ob_end_flush();
  readfile($csvFile);
  // Remove file after download..
  @unlink($csvFile);
  exit;
}

function deleteGiftCode() {
  mysql_query("DELETE FROM `".DB_PREFIX."giftcodes`
  WHERE `id` = '".mc_digitSan($_GET['del'])."'
  LIMIT 1
  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  $rows = mysql_affected_rows();
  tableTruncationRoutine(array('giftcodes'));
  return $rows;
}

function updateGiftCertInfo() {
  $_POST  = mc_safeImport($_POST);
  mysql_query("UPDATE `".DB_PREFIX."giftcodes` SET
  `from_name`  = '{$_POST['from_name']}',
  `to_name`    = '{$_POST['to_name']}',
  `from_email` = '{$_POST['from_email']}',
  `to_email`   = '{$_POST['to_email']}',
  `message`    = '{$_POST['message']}',
  `value`      = '".cleanInsertionPrice($_POST['value'])."',
  `redeemed`   = '".cleanInsertionPrice($_POST['redeemed'])."',
  `notes`      = '{$_POST['notes']}',
  `enabled`    = '".(isset($_POST['enabled']) && in_array($_POST['enabled'],array('yes','no')) ? $_POST['enabled'] : 'yes')."'
  WHERE `id`   = '".mc_digitSan($_POST['giftID'])."'
  LIMIT 1
  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
}

function addGiftCertificate() {
  $_POST = mc_safeImport($_POST);
  $img   = '';
  $name  = (isset($_FILES['image']['name']) ? $_FILES['image']['name'] : '');
  $temp  = (isset($_FILES['image']['tmp_name']) ? $_FILES['image']['tmp_name'] : '');
  mysql_query("INSERT INTO `".DB_PREFIX."giftcerts` (
  `name`,
  `value`,
  `image`,
  `enabled`
  ) VALUES (
  '{$_POST['name']}',
  '".cleanInsertionPrice($_POST['value'])."',
  '{$img}',
  '".(isset($_POST['enabled']) && in_array($_POST['enabled'],array('yes','no')) ? $_POST['enabled'] : 'yes')."'
  )") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  $ID = mysql_insert_id();
  // Do we have an image?
  if ($name && $temp && is_uploaded_file($temp)) {
    $ext  = substr(strrchr(strtolower($name),'.'),1);
	$fl   = 'gift-'.$ID.'.'.$ext;
	move_uploaded_file($temp,uploadServerPath().$fl);
	if (file_exists(uploadServerPath().$fl)) {
	  mysql_query("UPDATE `".DB_PREFIX."giftcerts` SET
      `image`    = '{$fl}'
      WHERE `id` = '{$ID}'
      LIMIT 1
      ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
	}
  }
}

function updateGiftCertificate() {
  $_POST  = mc_safeImport($_POST);
  $img    = $_POST['curimage'];
  $name   = (isset($_FILES['image']['name']) ? $_FILES['image']['name'] : '');
  $temp   = (isset($_FILES['image']['tmp_name']) ? $_FILES['image']['tmp_name'] : '');
  // Do we have an image?
  if ($name && $temp && is_uploaded_file($temp)) {
    // Delete existing..
	if ($_POST['curimage'] && file_exists(uploadServerPath().$_POST['curimage'])) {
	  @unlink(uploadServerPath().$_POST['curimage']);
	}
    $next = $_GET['edit'];
    $ext  = substr(strrchr(strtolower($name),'.'),1);
	$fl   = 'gift-'.$next.'.'.$ext;
	move_uploaded_file($temp,uploadServerPath().$fl);
	if (file_exists(uploadServerPath().$fl)) {
	  $img = $fl;
	}
  }
  mysql_query("UPDATE `".DB_PREFIX."giftcerts` SET
  `name`     = '{$_POST['name']}',
  `value`    = '".cleanInsertionPrice($_POST['value'])."',
  `image`    = '{$img}',
  `enabled`  = '".(isset($_POST['enabled']) && in_array($_POST['enabled'],array('yes','no')) ? $_POST['enabled'] : 'yes')."'
  WHERE `id` = '".mc_digitSan($_GET['edit'])."'
  LIMIT 1
  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
}

function deleteGiftCertificate() {
  mysql_query("DELETE FROM `".DB_PREFIX."giftcerts`
  WHERE `id` = '".mc_digitSan($_GET['del'])."'
  LIMIT 1
  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  $rows = mysql_affected_rows();
  tableTruncationRoutine(array('giftcerts'));
  return $rows;
}

function addThemeSwitch() {
  mysql_query("INSERT INTO `".DB_PREFIX."themes` (
  `theme`,
  `from`,
  `to`,
  `enabled`
  ) VALUES (
  '{$_POST['theme']}',
  '".(mc_checkValidDate(mc_convertCalToSQLFormat($_POST['from']))!='0000-00-00' ? mc_convertCalToSQLFormat($_POST['from']) : '0000-00-00')."',
  '".(mc_checkValidDate(mc_convertCalToSQLFormat($_POST['to']))!='0000-00-00' ? mc_convertCalToSQLFormat($_POST['to']) : '0000-00-00')."',
  '".(isset($_POST['enabled']) && in_array($_POST['enabled'],array('yes','no')) ? $_POST['enabled'] : 'yes')."'
  )") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
}

function updateThemeSwitch() {
  mysql_query("UPDATE `".DB_PREFIX."themes` SET
  `theme`    = '{$_POST['theme']}',
  `from`     = '".(mc_checkValidDate(mc_convertCalToSQLFormat($_POST['from']))!='0000-00-00' ? mc_convertCalToSQLFormat($_POST['from']) : '0000-00-00')."',
  `to`       = '".(mc_checkValidDate(mc_convertCalToSQLFormat($_POST['to']))!='0000-00-00' ? mc_convertCalToSQLFormat($_POST['to']) : '0000-00-00')."',
  `enabled`  = '".(isset($_POST['enabled']) && in_array($_POST['enabled'],array('yes','no')) ? $_POST['enabled'] : 'yes')."'
  WHERE `id` = '".mc_digitSan($_GET['edit'])."'
  LIMIT 1
  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
}

function deleteThemeSwitch() {
  mysql_query("DELETE FROM `".DB_PREFIX."themes` WHERE `id` = '".mc_digitSan($_GET['del'])."' LIMIT 1")
  or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  $rows = mysql_affected_rows(); 
  tableTruncationRoutine(array('themes'));
  return $rows;
}

function reOrderNewsTicker() {
  if (!empty($_GET['nt']) && is_array($_GET['nt'])) {
    foreach ($_GET['nt'] AS $k => $v) {
      mysql_query("UPDATE `".DB_PREFIX."news_ticker` SET
      `orderBy`   = '".($k+1)."'
      WHERE `id`  = '".mc_digitSan($v)."'
      LIMIT 1
      ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    }
  }
}

function addNews() {
  $_POST = mc_safeImport($_POST);
  mysql_query("INSERT INTO `".DB_PREFIX."news_ticker` (
  `newsText`,
  `enabled`,
  `orderBy`
  ) VALUES (
  '{$_POST['newsText']}',
  '".(isset($_POST['enabled']) && in_array($_POST['enabled'],array('yes','no')) ? $_POST['enabled'] : 'yes')."',
  '99999'
  )") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
}

function updateNews() {
  $_POST = mc_safeImport($_POST);
  mysql_query("UPDATE `".DB_PREFIX."news_ticker` SET
  `newsText`  = '{$_POST['newsText']}',
  `enabled`   = '".(isset($_POST['enabled']) && in_array($_POST['enabled'],array('yes','no')) ? $_POST['enabled'] : 'yes')."'
  WHERE `id`  = '".mc_digitSan($_GET['edit'])."'
  LIMIT 1
  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
}

function deleteNews() {
  mysql_query("DELETE FROM `".DB_PREFIX."news_ticker` WHERE `id` = '".mc_digitSan($_GET['del'])."' LIMIT 1")
  or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  $rows = mysql_affected_rows(); 
  tableTruncationRoutine(array('news_ticker'));
  return $rows;
}

function updateUserLogTime($id,$time) {
  mysql_query("UPDATE `".DB_PREFIX."users` SET
  `lastLogin`  = '$time'
  WHERE `id`   = '$id'
  LIMIT 1
  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
}

function exportLowStockItems() {
  global $msg_stockexport9;
  if (!empty($_POST['range'])) {
    $seperator  = ',';
    $csvFile    = PATH.'import/low-stock-items-'.date('d-m-Y-His').'.csv';
    $data       = $msg_stockexport9.mc_defineNewline();
    $from       = (int)$_POST['from'];
    $to         = (int)$_POST['to'];
    $disabled   = (isset($_POST['disabled']) && $_POST['disabled']=='no' ? 'AND `pEnable` = \'yes\'' : '');
    $query      = mysql_query("SELECT *,`".DB_PREFIX."products`.`id` AS `pid` FROM `".DB_PREFIX."products`
                  LEFT JOIN `".DB_PREFIX."prod_category`
                  ON `".DB_PREFIX."prod_category`.`product` = `".DB_PREFIX."products`.`id`
                  WHERE `category` IN(".implode(',',$_POST['range']).")
                  AND `pStock` BETWEEN '$from' AND '$to'
                  $disabled
                  GROUP BY `product`
                  ORDER BY `pName`
                  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($PRODUCT = mysql_fetch_object($query)) {
      $cats  = '';
      $qCat  = mysql_query("SELECT * FROM `".DB_PREFIX."prod_category`
               LEFT JOIN `".DB_PREFIX."categories`
               ON `".DB_PREFIX."prod_category`.`category`    = `".DB_PREFIX."categories`.`id`
               WHERE `".DB_PREFIX."prod_category`.`product`  = '{$PRODUCT->pid}'
               ORDER BY `catname`
               ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
      while ($CATS = mysql_fetch_object($qCat)) {
        $cats .= mc_cleanData($CATS->catname).$seperator;
      }
      $data .= systemEngine::cleanCSV(mc_cleanData($PRODUCT->pName),$seperator).$seperator;
      $data .= ''.$seperator;
      $data .= systemEngine::cleanCSV(substr($cats,0,-1),$seperator).$seperator;
      $data .= systemEngine::cleanCSV($PRODUCT->pStock,$seperator).$seperator.mc_defineNewline();
      $qAtt  = mysql_query("SELECT * FROM `".DB_PREFIX."attributes`
               WHERE `productID` = '{$PRODUCT->pid}'
               AND `attrStock` BETWEEN '$from' AND '$to'
               ORDER BY `orderBy`
               ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
      if (mysql_num_rows($qAtt)>0) {         
        while ($ATTRIBUTES = mysql_fetch_object($qAtt)) {
          $data .= systemEngine::cleanCSV(mc_cleanData($PRODUCT->pName),$seperator).$seperator;
          $data .= systemEngine::cleanCSV(mc_cleanData($ATTRIBUTES->attrName),$seperator).$seperator;
          $data .= systemEngine::cleanCSV(substr($cats,0,-1),$seperator).$seperator;
          $data .= systemEngine::cleanCSV($ATTRIBUTES->attrStock,$seperator).$seperator.mc_defineNewline();
        }
      }
    }
    if ($data) {
      $fp = fopen($csvFile, 'ab');
      if ($fp) {
        fwrite($fp,trim($data));
        fclose($fp);
      }
      // Download CSV..
      if(@ini_get('zlib.output_compression')) {
        @ini_set('zlib.output_compression', 'Off');
      }
      header('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT');
      header('Pragma: public');
      header('Expires: 0');
      header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
      header('Cache-Control: private',false);
      header('Content-Type: '.mc_getMimeType($csvFile));
      header('Content-Type: application/force-download');
      header('Content-Disposition: attachment; filename="'.basename($csvFile).'";');
      header('Content-Transfer-Encoding: binary');
      header('Content-Length: '.filesize($csvFile));
      @ob_end_flush();
      readfile($csvFile);
      // Remove file after download..
      @unlink($csvFile);
      exit;
    }
  }
  return 'none';
}

function addEmailAddresses() {
  $em   = array();
  $cnt  = 0;
  // Was an address entered?
  if ($_POST['email'] && preg_match("/^[_\.0-9a-zA-Z-]+@([0-9a-zA-Z][0-9a-zA-Z.-]+\.)+[a-zA-Z]{2,6}$/i", trim($_POST['email']))) {
    $em[] = trim($_POST['email']);
  }
  // Was anything uploaded..
  $temp = $_FILES['file']['tmp_name'];
  $name = $_FILES['file']['name'];
  if ($temp && $name) {
    // Read temp file..
    $read = file($temp);
    if (!empty($read)) {
      foreach ($read AS $e) {
        if (preg_match("/^[_\.0-9a-zA-Z-]+@([0-9a-zA-Z][0-9a-zA-Z.-]+\.)+[a-zA-Z]{2,6}$/i", trim($e))) {
          $em[] = trim($e);
        }
      }
    }
    // Remove temp file, we don`t need it now..
    @unlink($temp);
  }
  // Is there anything to add..
  if (!empty($em)) {
    foreach ($em AS $newMail) {
      if (mc_rowCount('newsletter WHERE `emailAddress` = \''.$newMail.'\'')==0) {
        mysql_query("INSERT INTO `".DB_PREFIX."newsletter` (`emailAddress`) VALUES ('$newMail')") 
        or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
        ++$cnt;
      }
    }
  }
  return $cnt;
}

function updateNewsTemplate() {
  $_POST        = mc_safeImport($_POST);
  $_GET['load'] = (int)$_GET['load'];
  mysql_query("UPDATE `".DB_PREFIX."newstemplates` SET
  `name`     = '{$_POST['from']}',
  `email`    = '{$_POST['email']}',
  `subject`  = '{$_POST['subject']}',
  `html`     = '{$_POST['html']}',
  `plain`    = '{$_POST['plain']}'
  WHERE `id` = '{$_GET['load']}'
  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
}

function loadNewsTemplates() {
  $html = '<option value="0">- - - - - - - -</option>';
  $query = mysql_query("SELECT * FROM `".DB_PREFIX."newstemplates` ORDER BY `subject`")
           or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  while ($NEWS = mysql_fetch_object($query)) {
    $html .= '<option value="?p=newsletter-mail&amp;load='.$NEWS->id.'">'.mc_cleanDataEnt($NEWS->subject).'</option>'.mc_defineNewline();
  }
  return $html;
}

function deleteNewsTemplate() {
  $_GET['del'] = (int)$_GET['del'];
  mysql_query("DELETE FROM `".DB_PREFIX."newstemplates` WHERE `id` = '{$_GET['del']}' LIMIT 1")
  or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  $rows = mysql_affected_rows();
  tableTruncationRoutine(array('newstemplates'));
  return $rows;
}

function addNewsTemplate() {
  $_POST = mc_safeImport($_POST);
  if (mc_rowCount('newstemplates WHERE `subject` = \''.$_POST['subject'].'\'')==0) {
    mysql_query("INSERT INTO `".DB_PREFIX."newstemplates` (
    `name`,
    `email`,
    `subject`,
    `html`,
    `plain`
    ) VALUES (
    '{$_POST['from']}',
    '{$_POST['email']}',
    '{$_POST['subject']}',
    '{$_POST['html']}',
    '{$_POST['plain']}'
    )") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    return 'OK';
  }
  return 'ERR';
}

function updateNewsletter() {
  mysql_query("UPDATE `".DB_PREFIX."newsletter` SET
  `emailAddress`  = '{$_GET['email']}'
  WHERE `id`      = '".mc_digitSan($_GET['id'])."'
  LIMIT 1
  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
}

function clearNewsletter() {
  mysql_query("DELETE FROM `".DB_PREFIX."newsletter`")
  or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  $rows = mysql_affected_rows();
  tableTruncationRoutine(array('newsletter'));
  return $rows;
}

function clearNewsletterEntry() {
  mysql_query("DELETE FROM `".DB_PREFIX."newsletter` WHERE `id` = '".mc_digitSan($_GET['del'])."' LIMIT 1")
  or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  $rows = mysql_affected_rows();
  tableTruncationRoutine(array('newsletter'));
  return $rows;
}

function exportNewsletter() {
  // Check writeable permissions..
  if (!is_writeable(PATH.'import')) {
    die('Admin \'import\' folder is not writeable. This is required for export routines. Please update!');
  }
  $q_l = mysql_query("SELECT * FROM `".DB_PREFIX."newsletter`
         GROUP BY `emailAddress`
         ORDER BY `emailAddress`
         ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  $seperator  = ',';
  $csvFile    = PATH.'import/newsletter-'.date('d-m-Y-His').'.csv';
  $data       = '';
  while ($NL = mysql_fetch_object($q_l)) {
    $data .= systemEngine::cleanCSV(mc_cleanData($NL->emailAddress),$seperator).mc_defineNewline();
  }
  $fp = fopen($csvFile, 'ab');
  if ($fp) {
    fwrite($fp,trim($data));
    fclose($fp);
  }
  // Download CSV..
  if(@ini_get('zlib.output_compression')) {
    @ini_set('zlib.output_compression', 'Off');
  }
  header('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT');
  header('Pragma: public');
  header('Expires: 0');
  header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
  header('Cache-Control: private',false);
  header('Content-Type: '.mc_getMimeType($csvFile));
  header('Content-Type: application/force-download');
  header('Content-Disposition: attachment; filename="'.basename($csvFile).'";');
  header('Content-Transfer-Encoding: binary');
  header('Content-Length: '.filesize($csvFile));
  @ob_end_flush();
  readfile($csvFile);
  // Remove file after download..
  @unlink($csvFile);
  exit;
}

function resetSearchLog() {
  mysql_query("DELETE FROM `".DB_PREFIX."search_log`")
  or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  $rows = mysql_affected_rows();
  tableTruncationRoutine(array('search_log'));
  return $rows;
}

function exportSearchLog() {
  global $msg_searchlog8;
  // Check writeable permissions..
  if (!is_writeable(PATH.'import')) {
    die('Admin \'import\' folder is not writeable. This is required for export routines. Please update!');
  }
  $q_l = mysql_query("SELECT *,count(*) AS `sr` FROM `".DB_PREFIX."search_log`
         ".(isset($_GET['zero']) ? 'WHERE `results` = \'0\'' : '')."
         GROUP BY `keyword`
         ORDER BY 1 DESC
         ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  $seperator  = ',';
  $csvFile    = PATH.'import/search-log-'.date('d-m-Y-His').'.csv';
  $data       = $msg_searchlog8.mc_defineNewline();
  while ($LOG = mysql_fetch_object($q_l)) {
    $data .= systemEngine::cleanCSV(mc_cleanData($LOG->keyword),$seperator).$seperator.
             systemEngine::cleanCSV(mc_cleanData($LOG->sr),$seperator).$seperator.
             systemEngine::cleanCSV(mc_cleanData($LOG->results),$seperator).mc_defineNewline();
  }
  $fp = fopen($csvFile, 'ab');
  if ($fp) {
    fwrite($fp,trim($data));
    fclose($fp);
  }
  // Download CSV..
  if(@ini_get('zlib.output_compression')) {
    @ini_set('zlib.output_compression', 'Off');
  }
  header('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT');
  header('Pragma: public');
  header('Expires: 0');
  header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
  header('Cache-Control: private',false);
  header('Content-Type: '.mc_getMimeType($csvFile));
  header('Content-Type: application/force-download');
  header('Content-Disposition: attachment; filename="'.basename($csvFile).'";');
  header('Content-Transfer-Encoding: binary');
  header('Content-Length: '.filesize($csvFile));
  @ob_end_flush();
  readfile($csvFile);
  // Remove file after download..
  @unlink($csvFile);
  exit;
}

function reOrderBanners() {
  if (!empty($_GET['ban']) && is_array($_GET['ban'])) {
    foreach ($_GET['ban'] AS $k => $v) {
      mysql_query("UPDATE `".DB_PREFIX."banners` SET
      `bannerOrder` = '".($k+1)."'
      WHERE `id`    = '".mc_digitSan($v)."'
      LIMIT 1
      ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    }
  }
}

function reOrderPricePoints() {
  if (!empty($_GET['pp']) && is_array($_GET['pp'])) {
    foreach ($_GET['pp'] AS $k => $v) {
      mysql_query("UPDATE `".DB_PREFIX."price_points` SET
      `orderBy`   = '".($k+1)."'
      WHERE `id`  = '".mc_digitSan($v)."'
      LIMIT 1
      ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    }
  }
}

function addPricePoint() {
  $_POST = mc_safeImport($_POST);
  // Check restriction limit for free version..
  if (LICENCE_VER=='locked') {
    if (mc_rowCount('price_points')+1>RESTR_POINTS) {
      mc_restrictionLimitRedirect();
    }
  }
  mysql_query("INSERT INTO ".DB_PREFIX."price_points (
  `priceFrom`,
	`priceTo`,
	`priceText`
  ) VALUES (
  '{$_POST['priceFrom']}',
  '{$_POST['priceTo']}',
  '{$_POST['priceText']}'
  )") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
}

function updatePricePoint() {
  $_POST = mc_safeImport($_POST);
  mysql_query("UPDATE ".DB_PREFIX."price_points SET
  `priceFrom`  = '{$_POST['priceFrom']}',
  `priceTo`    = '{$_POST['priceTo']}',
  `priceText`  = '{$_POST['priceText']}'
  WHERE id     = '".mc_digitSan($_GET['edit'])."'
  LIMIT 1
  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
}

function deletePricePoint() {
  mysql_query("DELETE FROM ".DB_PREFIX."price_points WHERE id = '".mc_digitSan($_GET['del'])."' LIMIT 1")
  or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  $rows = mysql_affected_rows(); 
  tableTruncationRoutine(array('price_points'));
  return $rows;
}

// Export log..
function exportEntryLog() {
  global $msg_entrylog7;
  // Check writeable permissions..
  if (!is_writeable(PATH.'import')) {
    die('Admin \'import\' folder is not writeable. This is required for export routines. Please update!');
  }
  $SQL = '';
  if ($_GET['export']!='all') {
    $SQL = 'WHERE userName = \''.mc_safeImportString($_GET['export']).'\'';
  }
  $q_l = mysql_query("SELECT *,DATE_FORMAT(loggedDate,'".$this->settings->mysqlDateFormat."') AS ldate FROM ".DB_PREFIX."entry_log
         $SQL
         ORDER BY id DESC,userName
         ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  $seperator  = ',';
  $csvFile    = PATH.'import/log-'.date('d-m-Y-His').'.csv';
  $data       = $msg_entrylog7.mc_defineNewline();
  while ($LOG = mysql_fetch_object($q_l)) {
    $data .= systemEngine::cleanCSV(mc_cleanData($LOG->userName),$seperator).$seperator.
             systemEngine::cleanCSV(mc_cleanData($LOG->ldate),$seperator).$seperator.
             $LOG->loggedTime.mc_defineNewline();
  }
  $fp = fopen($csvFile, 'ab');
  if ($fp) {
    fwrite($fp,trim($data));
    fclose($fp);
  }
  // Download CSV..
  if(@ini_get('zlib.output_compression')) {
    @ini_set('zlib.output_compression', 'Off');
  }
  header('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT');
  header('Pragma: public');
  header('Expires: 0');
  header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
  header('Cache-Control: private',false);
  header('Content-Type: '.mc_getMimeType($csvFile));
  header('Content-Type: application/force-download');
  header('Content-Disposition: attachment; filename="'.basename($csvFile).'";');
  header('Content-Transfer-Encoding: binary');
  header('Content-Length: '.filesize($csvFile));
  @ob_end_flush();
  readfile($csvFile);
  // Remove file after download..
  @unlink($csvFile);
  exit;
}

// Clear log..
function clearEntryLog() {
  if ($_GET['reset']!='all') {
    mysql_query("DELETE FROM ".DB_PREFIX."entry_log WHERE userName = '".mc_safeImportString($_GET['reset'])."'")
    or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    $rows = mysql_affected_rows();
  } else {
    mysql_query("DELETE FROM ".DB_PREFIX."entry_log")
    or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    $rows = mysql_affected_rows();
  }
  tableTruncationRoutine(array('entry_log'));
  return $rows;
}

// Add entry log..
function addEntryLog($user) {
  $user = mc_safeImportString($user);
  $skip = skipLogUsers();
  if (!empty($skip) && in_array(strtolower($user),$skip)) {
    return;
  }
  mysql_query("INSERT INTO ".DB_PREFIX."entry_log (
  `userName`,`loggedDate`,`loggedTime`
  ) VALUES (
  '$user','".date("Y-m-d")."','".date("H:i:s")."'
  )") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
}

// Add User..
function addUser() {
  $_POST       = mc_safeImport($_POST);
  // Check restriction limit for free version..
  if (LICENCE_VER=='locked') {
    if (mc_rowCount('users')+1>RESTR_USERS) {
      mc_restrictionLimitRedirect();
    }
  }
  $restricted  = (!empty($_POST['pages']) ? $_POST['pages'] : array('noaccess'));
  mysql_query("INSERT INTO ".DB_PREFIX."users (
  `userName`,
  `userPass`,
  `userType`,
  `userPriv`,
  `accessPages`,
  `enableUser`
  ) VALUES (
  '{$_POST['userName']}',
  '".mc_encrypt(SECRET_KEY.$_POST['userPass'])."',
  '".(isset($_POST['userType']) && in_array($_POST['userType'],array('admin','restricted')) ? $_POST['userType'] : 'restricted')."',
  '".(isset($_POST['userPriv']) && in_array($_POST['userPriv'],array('yes','no')) ? $_POST['userPriv'] : 'no')."',
  '".(isset($_POST['userType']) && $_POST['userType']=='restricted' ? implode('|',$restricted) : '')."',
  '".(isset($_POST['enableUser']) && in_array($_POST['enableUser'],array('yes','no')) ? $_POST['enableUser'] : 'no')."'
  )") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
}
  
// Update user..
function updateUser() {
  $_POST       = mc_safeImport($_POST);
  $restricted  = (!empty($_POST['pages']) ? $_POST['pages'] : array('noaccess'));
  mysql_query("UPDATE ".DB_PREFIX."users SET
  `userName`     = '{$_POST['userName']}',
  `userPass`     = '".($_POST['userPass'] ? mc_encrypt(SECRET_KEY.$_POST['userPass']) : $_POST['userPass2'])."',
  `userType`     = '".(isset($_POST['userType']) && in_array($_POST['userType'],array('admin','restricted')) ? $_POST['userType'] : 'restricted')."',
  `userPriv`     = '".(isset($_POST['userPriv']) && in_array($_POST['userPriv'],array('yes','no')) ? $_POST['userPriv'] : 'no')."',
  `accessPages`  = '".(isset($_POST['userType']) && $_POST['userType']=='restricted' ? implode('|',$restricted) : '')."',
  `enableUser`   = '".(isset($_POST['enableUser']) && in_array($_POST['enableUser'],array('yes','no')) ? $_POST['enableUser'] : 'no')."'
  WHERE id       = '".mc_digitSan($_GET['edit'])."'
  LIMIT 1
  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
}
  
// Delete user..
function deleteUser() {
  mysql_query("DELETE FROM ".DB_PREFIX."users WHERE id = '".mc_digitSan($_GET['del'])."' LIMIT 1")
  or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  $rows = mysql_affected_rows();
  tableTruncationRoutine(array('users'));
  return $rows;
}

// Add banners..
function addBanners() {
  $_POST  = mc_safeImport($_POST);
  $folder = str_replace('{theme}',THEME_FOLDER,BANNER_FOLDER);
  $temp   = $_FILES['image']['tmp_name'];
  $name   = $_FILES['image']['name'];
  $size   = $_FILES['image']['size'];
  // Get last image..
  $q      = mysql_query("SELECT `id` FROM ".DB_PREFIX."banners ORDER BY `id` DESC LIMIT 1")
            or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  $L      = mysql_fetch_object($q);
  if ($temp && $name && $size>0) {
    if (is_uploaded_file($temp)) {
      if (RENAME_BANNERS) {
        $ext   = strrchr(strtolower($name),'.');
        $file  = BANNER_PREFIX.(isset($L->id) ? ($L->id+1) : '1').$ext;
      } else {
        $file  = $name;
      }
      // If banner with same name exists, remove it..
      if (file_exists($this->settings->serverPath.'/'.$folder.'/'.$file)) {
        @unlink($this->settings->serverPath.'/'.$folder.'/'.$file);
      }
      move_uploaded_file($temp,$this->settings->serverPath.'/'.$folder.'/'.$file);
      @chmod($this->settings->serverPath.'/'.$folder.'/'.$file,AFTER_UPLOAD_CHMOD_VALUE); 
      if (file_exists($this->settings->serverPath.'/'.$folder.'/'.$file)) {
        mysql_query("INSERT INTO ".DB_PREFIX."banners (
        `bannerFile`,`bannerText`,`BannerUrl`,`bannerLive`,
        `bannerCats`,`bannerHome`,`bannerFrom`,`bannerTo`
        ) VALUES (
        '$file',
        '{$_POST['text']}',
        '{$_POST['url']}',
        '".(isset($_POST['bannerLive']) && in_array($_POST['bannerLive'],array('yes','no')) ? $_POST['bannerLive'] : 'no')."',
        '".(!empty($_POST['bannerCats']) ? implode(',',$_POST['bannerCats']) : '')."',
        '".(isset($_POST['bannerHome']) && in_array($_POST['bannerHome'],array('yes','no')) ? $_POST['bannerHome'] : 'no')."',
        '".(mc_checkValidDate(mc_convertCalToSQLFormat($_POST['bannerFrom']))!='0000-00-00' ? mc_convertCalToSQLFormat($_POST['bannerFrom']) : '0000-00-00')."',
        '".(mc_checkValidDate(mc_convertCalToSQLFormat($_POST['bannerTo']))!='0000-00-00' ? mc_convertCalToSQLFormat($_POST['bannerTo']) : '0000-00-00')."'
        )") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
        if (file_exists($temp)) {
          @unlink($temp);
        }
      }
    }
  }
}

// Update banners..
function updateBanners() {
  $_POST = mc_safeImport($_POST);
  $folder = str_replace('{theme}',THEME_FOLDER,BANNER_FOLDER);
  $temp   = $_FILES['image']['tmp_name'];
  $name   = $_FILES['image']['name'];
  $size   = $_FILES['image']['size'];
  $file   = '';
  // Get last image..
  $q      = mysql_query("SELECT `id` FROM ".DB_PREFIX."banners ORDER BY `id` DESC LIMIT 1")
            or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  $L      = mysql_fetch_object($q);
  if ($temp && $name && $size>0) {
    if (is_uploaded_file($temp)) {
      if (RENAME_BANNERS) {
        $ext   = strrchr(strtolower($name),'.');
        $file  = BANNER_PREFIX.(isset($L->id) ? ($L->id+1) : '1').$ext;
      } else {
        $file  = $name;
      }
      // If banner with same name exists, remove it..
      if (file_exists($this->settings->serverPath.'/'.$folder.'/'.$file)) {
        @unlink($this->settings->serverPath.'/'.$folder.'/'.$file);
      }
      // If old file was different, remove it..
      if ($_POST['old_img'] && file_exists($this->settings->serverPath.'/'.$folder.'/'.$_POST['old_img'])) {
        @unlink($this->settings->serverPath.'/'.$folder.'/'.$_POST['old_img']);
      }
      move_uploaded_file($temp,$this->settings->serverPath.'/'.$folder.'/'.$file);
      @chmod($this->settings->serverPath.'/'.$folder.'/'.$file,AFTER_UPLOAD_CHMOD_VALUE); 
    }
  }  
  mysql_query("UPDATE ".DB_PREFIX."banners SET
  `bannerFile` = '".($file ? $file : $_POST['old_img'])."',
  `bannerText` = '{$_POST['text']}',
  `BannerUrl`  = '{$_POST['url']}',
  `bannerLive` = '".(isset($_POST['bannerLive']) && in_array($_POST['bannerLive'],array('yes','no')) ? $_POST['bannerLive'] : 'no')."',
  `bannerCats` = '".(!empty($_POST['bannerCats']) ? implode(',',$_POST['bannerCats']) : '')."',
  `bannerHome` = '".(isset($_POST['bannerHome']) && in_array($_POST['bannerHome'],array('yes','no')) ? $_POST['bannerHome'] : 'no')."',
  `bannerFrom` = '".(mc_checkValidDate(mc_convertCalToSQLFormat($_POST['bannerFrom']))!='0000-00-00' ? mc_convertCalToSQLFormat($_POST['bannerFrom']) : '0000-00-00')."',
  `bannerTo`   = '".(mc_checkValidDate(mc_convertCalToSQLFormat($_POST['bannerTo']))!='0000-00-00' ? mc_convertCalToSQLFormat($_POST['bannerTo']) : '0000-00-00')."'
  WHERE `id`   = '".mc_digitSan($_POST['update_banners'])."'
  LIMIT 1
  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__)); 
}

// Delete banner..
function deleteBanner() {
  mysql_query("DELETE FROM ".DB_PREFIX."banners WHERE `id` = '".mc_digitSan($_GET['del'])."' LIMIT 1")
  or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  if (file_exists($this->settings->serverPath.'/'.$_GET['file'])) {
    @unlink($this->settings->serverPath.'/'.$_GET['file']);
  }
  $rows = mysql_affected_rows();
  tableTruncationRoutine(array('banners'));
  return $rows;
}

function enableDisablePages($status) {
  mysql_query("UPDATE ".DB_PREFIX."newpages SET
  `enabled`   = '".($status=='yes' ? 'no' : 'yes')."'
  WHERE `id`  = '".mc_digitSan($_GET['changeStatus'])."'
  LIMIT 1
  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  return ($status=='yes' ? 'no' : 'yes');
}

function reOrderNewPages() {
  if (!empty($_GET['pg']) && is_array($_GET['pg'])) {
    foreach ($_GET['pg'] AS $k => $v) {
      mysql_query("UPDATE ".DB_PREFIX."newpages SET
      `orderBy`     = '".($k+1)."'
      WHERE `id`    = '".mc_digitSan($v)."'
      LIMIT 1
      ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    }
  }
}

function addNewWebPage() {
  $_POST             = mc_safeImport($_POST);
  $_POST['pageText'] = mc_cleanBBInput($_POST['pageText']);
  if (!isset($_POST['customTemplate'])) {
    $_POST['customTemplate'] = '';
  }
  if (isset($_POST['linkExternal']) && $_POST['linkExternal']=='yes') {
    $_POST['landingPage'] = 'no';
  }
  mysql_query("INSERT INTO ".DB_PREFIX."newpages (
  `pageName`,
  `pageKeys`,
  `pageDesc`,
  `pageText`,
  `orderBy`,
  `enabled`,
  `linkPos`,
  `linkExternal`,
  `customTemplate`,
  `linkTarget`,
  `landingPage`,
  `leftColumn`,
  `rwslug`
  ) VALUES (
  '{$_POST['pageName']}',
  '{$_POST['pageKeys']}',
  '{$_POST['pageDesc']}',
  '{$_POST['pageText']}',
  '99999',
  '".(isset($_POST['enabled']) && in_array($_POST['enabled'],array('yes','no')) ? $_POST['enabled'] : 'yes')."',
  '".(!empty($_POST['linkPos']) ? implode(',',$_POST['linkPos']) : '1')."',
  '".(isset($_POST['linkExternal']) && in_array($_POST['linkExternal'],array('yes','no')) ? $_POST['linkExternal'] : 'yes')."',
  '{$_POST['customTemplate']}',
  '".(isset($_POST['linkTarget']) && in_array($_POST['linkTarget'],array('new','same')) ? $_POST['linkTarget'] : 'new')."',
  '".(isset($_POST['landingPage']) && in_array($_POST['landingPage'],array('yes','no')) ? $_POST['landingPage'] : 'no')."',
  '".(isset($_POST['leftColumn']) && in_array($_POST['leftColumn'],array('yes','no')) ? $_POST['leftColumn'] : 'no')."',
  '{$_POST['rwslug']}'
  )") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  $id = mysql_insert_id();
  // Remove any other landing pages..
  if (isset($_POST['landingPage']) && $_POST['landingPage']=='yes') {
    mysql_query("UPDATE ".DB_PREFIX."newpages SET
    `landingPage` = 'no'
    WHERE `id`   != '$id'
    ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  }
}

function updateWebPage() {
  $_POST             = mc_safeImport($_POST);
  $_POST['pageText'] = mc_cleanBBInput($_POST['pageText']);
  if (!isset($_POST['customTemplate'])) {
    $_POST['customTemplate'] = '';
  }
  if (isset($_POST['linkExternal']) && $_POST['linkExternal']=='yes') {
    $_POST['landingPage'] = 'no';
  }
  if ($_GET['edit']=='1') {
    $_POST['leftColumn'] = 'yes';
  }
  mysql_query("UPDATE ".DB_PREFIX."newpages SET
  `pageName`        = '{$_POST['pageName']}',
  `pageKeys`        = '{$_POST['pageKeys']}',
  `pageDesc`        = '{$_POST['pageDesc']}',
  `pageText`        = '{$_POST['pageText']}',
  `enabled`         = '".(isset($_POST['enabled']) && in_array($_POST['enabled'],array('yes','no')) ? $_POST['enabled'] : 'yes')."',
  `linkPos`         = '".(!empty($_POST['linkPos']) ? implode(',',$_POST['linkPos']) : '1')."',
  `linkExternal`    = '".(isset($_POST['linkExternal']) && in_array($_POST['linkExternal'],array('yes','no')) ? $_POST['linkExternal'] : 'yes')."',
  `customTemplate`  = '{$_POST['customTemplate']}',
  `linkTarget`      = '".(isset($_POST['linkTarget']) && in_array($_POST['linkTarget'],array('new','same')) ? $_POST['linkTarget'] : 'new')."',
  `landingPage`     = '".(isset($_POST['landingPage']) && in_array($_POST['landingPage'],array('yes','no')) ? $_POST['landingPage'] : 'no')."',
  `leftColumn`      = '".(isset($_POST['leftColumn']) && in_array($_POST['leftColumn'],array('yes','no')) ? $_POST['leftColumn'] : 'no')."',
  `rwslug`          = '{$_POST['rwslug']}'
  WHERE `id`        = '".mc_digitSan($_GET['edit'])."'
  LIMIT 1
  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  // Remove any other landing pages..
  if (isset($_POST['landingPage']) && $_POST['landingPage']=='yes') {
    mysql_query("UPDATE ".DB_PREFIX."newpages SET
    `landingPage` = 'no'
    WHERE `id`   != '".mc_digitSan($_GET['edit'])."'
    ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  }
}

function deleteWebPage() {
  if ($_GET['del']>1) {
    mysql_query("DELETE FROM `".DB_PREFIX."newpages`
    WHERE `id` = '".mc_digitSan($_GET['del'])."'
    LIMIT 1
    ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    return mysql_affected_rows();
  }
  return 0;
}

function addStatus() {
  $_POST  = mc_safeImport($_POST);
  $hs     = (isset($_POST['homepage']) && in_array($_POST['homepage'],array('yes','no')) ? $_POST['homepage'] : 'no');
  mysql_query("INSERT INTO `".DB_PREFIX."paystatuses` (
  `statname`,
  `pMethod`,
  `homepage`
  ) VALUES (
  '{$_POST['statname']}',
  '{$_POST['pMethod']}',
  '$hs'
  )") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
}

function updateStatus() {
  $_POST  = mc_safeImport($_POST);
  $hs     = (isset($_POST['homepage']) && in_array($_POST['homepage'],array('yes','no')) ? $_POST['homepage'] : 'no');
  mysql_query("UPDATE `".DB_PREFIX."paystatuses` SET
  `statname` = '{$_POST['statname']}',
  `pMethod`  = '{$_POST['pMethod']}',
  `homepage` = '$hs'
  WHERE `id` = '{$_POST['update']}'
  LIMIT 1
  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
}

function deleteStatus() {
  mysql_query("DELETE FROM `".DB_PREFIX."paystatuses`
  WHERE `id` = '".mc_digitSan($_GET['del'])."'
  LIMIT 1
  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  $rows = mysql_affected_rows();
  tableTruncationRoutine(array('paystatuses'));
  return $rows;
}

function batchUpdateTaxRates() {
  $_POST   = mc_safeImport($_POST);
  $count   = 0;
  if (!empty($_POST['zones'])) {
    $perc    = (substr($_POST['price'],-1)=='%' ? substr($_POST['price'],0,-1) : $_POST['price']);
    $type    = (isset($_POST['type']) ? $_POST['type'] : 'incr');
    switch ($type) {
      case 'fixed':
      $rates = '`zRate` = \''.$perc.'\'';
      break;
      case 'incr':
      $rates = '`zRate` = (zRate+'.$perc.')';
      break;
      default:
      $rates = '`zRate` = (zRate-'.$perc.')';
      break;
    }
    // Update tax rates..
    mysql_query("UPDATE `".DB_PREFIX."zones` SET $rates WHERE `id` IN(".implode(',',$_POST['zones']).")") 
    or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    $count = mysql_affected_rows();
    // Update tax rates..
    mysql_query("UPDATE `".DB_PREFIX."zone_areas` SET $rates WHERE `inZone` IN(".implode(',',$_POST['zones']).")") 
    or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    $count = mysql_affected_rows();
    // Fix minus values..
    mysql_query("UPDATE `".DB_PREFIX."zones` SET `zRate` = '0' WHERE `zRate` < 0") 
    or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    return $count;
  }
  return '0';
}

function batchUpdateRatesRoutine($type) {
  $which = (isset($_POST['enable']) ? $_POST['enable'] : 'yes');
  mysql_query("UPDATE `".DB_PREFIX.$type."` SET
  `enabled` = '$which'
  WHERE `inZone` IN(".implode(',',$_POST['inZone']).")
  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  return mysql_affected_rows();
}

function batchUpdateRates() {
  $_POST   = mc_safeImport($_POST);
  $count   = 0;
  $pref    = (!empty($_POST['rpref']) ? $_POST['rpref'] : array('weight'));
  $type    = (isset($_POST['type']) ? $_POST['type'] : 'incr');
  if (!empty($_POST['zones'])) {
    // Flat rates..
    if (in_array('flat',$pref)) {
      $query = mysql_query("SELECT * FROM `".DB_PREFIX."flat`
               WHERE `inZone` IN(".implode(',',$_POST['zones']).")
               ORDER BY `inZone`
               ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
      while ($FRATE = mysql_fetch_object($query)) {
        switch ($type) {
          case 'fixed':
          mysql_query("UPDATE `".DB_PREFIX."flat` SET
          `rate`     = '".cleanInsertionPrice($_POST['price'])."'
          WHERE `id` = '$FRATE->id'
          LIMIT 1
          ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
          break;
          case 'incr':
          systemEngine::increaseRateByAmount($_POST['price'],$FRATE->rate,$FRATE->id,'flat');
          break;
          default:
          systemEngine::decreaseRateByAmount($_POST['price'],$FRATE->rate,$FRATE->id,'flat');
          break;
        }
        ++$count;
      }
      // Fix minus values..
      mysql_query("UPDATE `".DB_PREFIX."flat` SET `rate` = '0.00' WHERE `rate` < 0") 
      or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    }
	// Per item rates..
    if (in_array('peri',$pref)) {
      $query = mysql_query("SELECT * FROM `".DB_PREFIX."per`
               WHERE `inZone` IN(".implode(',',$_POST['zones']).")
               ORDER BY `inZone`
               ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
      while ($PIRATE = mysql_fetch_object($query)) {
        switch ($type) {
          case 'fixed':
		  if ($_POST['price']>0) {
            mysql_query("UPDATE `".DB_PREFIX."per` SET
            `rate`     = '".cleanInsertionPrice($_POST['price'])."'
            WHERE `id` = '$PIRATE->id'
            LIMIT 1
            ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
		  }
		  // Adjustment for additional items..
		  if ($_POST['add']>0) {
		    mysql_query("UPDATE `".DB_PREFIX."per` SET
            `item`     = '".cleanInsertionPrice($_POST['add'])."'
            WHERE `id` = '$PIRATE->id'
            LIMIT 1
            ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
		  }
          break;
          case 'incr':
		  if ($_POST['price']>0) {
            systemEngine::increaseRateByAmount($_POST['price'],$PIRATE->rate,$PIRATE->id,'per_item');
		  }
		  // Adjustment for additional items..
		  if ($_POST['add']>0) {
		    systemEngine::increaseRateByAmount($_POST['add'],$PIRATE->item,$PIRATE->id,'per_item_add');
		  }
          break;
          default:
		  if ($_POST['price']>0) {
            systemEngine::decreaseRateByAmount($_POST['price'],$PIRATE->rate,$PIRATE->id,'per_item');
		  }
		  // Adjustment for additional items..
		  if ($_POST['add']>0) {
		    systemEngine::decreaseRateByAmount($_POST['add'],$PIRATE->item,$PIRATE->id,'per_item_add');
		  }
          break;
        }
        ++$count;
      }
      // Fix minus values..
      mysql_query("UPDATE `".DB_PREFIX."per` SET `rate` = '0.00' WHERE `rate` < 0") 
      or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    }
    // Percentage based rates..
    if (in_array('perc',$pref)) {
      $quer2 = mysql_query("SELECT * FROM `".DB_PREFIX."percent`
               WHERE `inZone` IN(".implode(',',$_POST['zones']).")
               ORDER BY `inZone`
               ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
      while ($PRATE = mysql_fetch_object($quer2)) {
        switch ($type) {
          case 'fixed':
          mysql_query("UPDATE `".DB_PREFIX."percent` SET
          `percentage`  = '".rateCleaner($_POST['price'])."'
          WHERE `id`    = '$PRATE->id'
          LIMIT 1
          ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
          break;
          case 'incr':
          systemEngine::increaseRateByAmount($_POST['price'],$PRATE->percentage,$PRATE->id,'perc');
          break;
          default:
          systemEngine::decreaseRateByAmount($_POST['price'],$PRATE->percentage,$PRATE->id,'perc');
          break;
        }
        ++$count;
      }
      // Fix minus values..
      mysql_query("UPDATE `".DB_PREFIX."percent` SET `percentage` = '0' WHERE `percentage` < 0") 
      or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    }
    // Weight based rates..
    if (in_array('weight',$pref)) {
      $quer3 = mysql_query("SELECT *,`".DB_PREFIX."rates`.`id` AS `rid`,`".DB_PREFIX."services`.`id` AS `sid` FROM `".DB_PREFIX."rates`
               LEFT JOIN `".DB_PREFIX."services`
               ON `".DB_PREFIX."services`.`id` = `".DB_PREFIX."rates`.`rService`
               WHERE `inZone` IN(".implode(',',$_POST['zones']).")
               ORDER BY `inZone`
               ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
      while ($RATE = mysql_fetch_object($quer3)) {
        switch ($type) {
          case 'fixed':
          mysql_query("UPDATE `".DB_PREFIX."rates` SET
          `rCost`     = '".cleanInsertionPrice($_POST['price'])."'
          WHERE `id`  = '$RATE->rid'
          LIMIT 1
          ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
          break;
          case 'incr':
          systemEngine::increaseRateByAmount($_POST['price'],$RATE->rCost,$RATE->rid,'weight');
          break;
          default:
          systemEngine::decreaseRateByAmount($_POST['price'],$RATE->rCost,$RATE->rid,'weight');
          break;
        }
        ++$count;
      }
      // Fix minus values..
      mysql_query("UPDATE `".DB_PREFIX."rates` SET `rCost` = '0.00' WHERE `rCost` < 0") 
      or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    }
    // Tare based rates..
    if (in_array('tare',$pref)) {
      $quer4 = mysql_query("SELECT *,`".DB_PREFIX."tare`.`id` AS `tid`,`".DB_PREFIX."services`.`id` AS `sid` FROM `".DB_PREFIX."tare`
               LEFT JOIN `".DB_PREFIX."services`
               ON `".DB_PREFIX."services`.`id` = `".DB_PREFIX."tare`.`rService`
               WHERE `inZone` IN(".implode(',',$_POST['zones']).")
               ORDER BY `inZone`
               ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
      while ($TARE = mysql_fetch_object($quer4)) {
        switch ($type) {
          case 'fixed':
          mysql_query("UPDATE `".DB_PREFIX."tare` SET
          `rCost`     = '".$_POST['price']."'
          WHERE `id`  = '$TARE->tid'
          LIMIT 1
          ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
          break;
          case 'incr':
          systemEngine::increaseRateByAmount($_POST['price'],$TARE->rCost,$TARE->tid,'tare');
          break;
          default:
          systemEngine::decreaseRateByAmount($_POST['price'],$TARE->rCost,$TARE->tid,'tare');
          break;
        }
        ++$count;
      }
      // Fix minus values..
      mysql_query("UPDATE `".DB_PREFIX."tare` SET `rCost` = '0.00' WHERE `rCost` < 0") 
      or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    }
  }
  return $count;
}

function increaseRateByAmount($price,$cur_price,$id,$type) {
  // Is the current price, percentage based, ie: tare weight
  if (substr($cur_price,-1)=='%') {
    $cur_price = substr($cur_price,0,-1);
    if (substr($price,-1)=='%') {
      $perc      = floor(substr($price,0,strpos($price,'%')));
      $sum       = number_format($cur_price*$perc/100,2);
      $newPrice  = mc_formatPrice($cur_price+$sum).'%';
    } else {
      $newPrice  = mc_formatPrice($cur_price+$price).'%';
    }
    if (str_replace('%','',$newPrice)<0) {
      $newPrice = '0.01%';
    }
  } else {
    if (substr($price,-1)=='%') {
      $perc      = floor(substr($price,0,strpos($price,'%')));
      $sum       = number_format($cur_price*$perc/100,2);
      $newPrice  = mc_formatPrice($cur_price+$sum);
    } else {
      $newPrice  = mc_formatPrice($cur_price+$price);
    }
    if ($newPrice<0) {
      $newPrice = '0.01';
    }
  }
  switch ($type) {
    // Flat rate..
    case 'flat':
    mysql_query("UPDATE `".DB_PREFIX."flat` SET
    `rate`     = '".cleanInsertionPrice($newPrice)."'
    WHERE `id` = '$id'
    LIMIT 1
    ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    break;
	// Per item rates..
    case 'per_item':
	case 'per_item_add':
	if ($type=='per_item') {
      mysql_query("UPDATE `".DB_PREFIX."per` SET
      `rate`     = '".cleanInsertionPrice($newPrice)."'
      WHERE `id` = '$id'
      LIMIT 1
      ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
	} else {
	  mysql_query("UPDATE `".DB_PREFIX."per` SET
      `item`     = '".cleanInsertionPrice($newPrice)."'
      WHERE `id` = '$id'
      LIMIT 1
      ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
	}
    break;
    // Percentage rate..
    case 'perc':
    mysql_query("UPDATE `".DB_PREFIX."percent` SET
    `percentage` = '".cleanInsertionPrice($newPrice)."'
    WHERE `id`   = '$id'
    LIMIT 1
    ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    break;
    // Weight rates..
    case 'weight':
    mysql_query("UPDATE `".DB_PREFIX."rates` SET
    `rCost`    = '".cleanInsertionPrice($newPrice)."'
    WHERE `id` = '$id'
    LIMIT 1
    ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    break;
    // Tare rates..
    case 'tare':
    mysql_query("UPDATE `".DB_PREFIX."tare` SET
    `rCost`    = '{$newPrice}'
    WHERE `id` = '$id'
    LIMIT 1
    ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    break;
  }
}

function decreaseRateByAmount($price,$cur_price,$id,$type) {
  // Is the current price, percentage based, ie: tare weight
  if (substr($cur_price,-1)=='%') {
    $cur_price = substr($cur_price,0,-1);
    if (substr($price,-1)=='%') {
      $perc      = floor(substr($price,0,strpos($price,'%')));
      $sum       = number_format($cur_price*$perc/100,2);
      $newPrice  = mc_formatPrice($cur_price-$sum).'%';
    } else {
      $newPrice  = mc_formatPrice($cur_price-$price).'%';
    }
    if (str_replace('%','',$newPrice)<0) {
      $newPrice = '0.01%';
    }
  } else {
    if (substr($price,-1)=='%') {
      $perc      = floor(substr($price,0,strpos($price,'%')));
      $sum       = number_format($cur_price*$perc/100,2);
      $newPrice  = mc_formatPrice($cur_price-$sum);
    } else {
      $newPrice  = mc_formatPrice($cur_price-$price);
    }
    if ($newPrice<0) {
      $newPrice = '0.01';
    }
  }
  switch ($type) {
    // Flat rate..
    case 'flat':
    mysql_query("UPDATE `".DB_PREFIX."flat` SET
    `rate`     = '".cleanInsertionPrice($newPrice)."'
    WHERE `id` = '$id'
    LIMIT 1
    ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    break;
	// Per item rates..
    case 'per_item':
	case 'per_item_add':
	if ($type=='per_item') {
      mysql_query("UPDATE `".DB_PREFIX."per` SET
      `rate`     = '".cleanInsertionPrice($newPrice)."'
      WHERE `id` = '$id'
      LIMIT 1
      ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
	} else {
	  mysql_query("UPDATE `".DB_PREFIX."per` SET
      `item`     = '".cleanInsertionPrice($newPrice)."'
      WHERE `id` = '$id'
      LIMIT 1
      ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
	}
    break;
    // Percentage rate..
    case 'perc':
    mysql_query("UPDATE `".DB_PREFIX."percent` SET
    `percentage` = '".cleanInsertionPrice($newPrice)."'
    WHERE `id`   = '$id'
    LIMIT 1
    ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    break;    
    // Weight rates..
    case 'weight':
    mysql_query("UPDATE `".DB_PREFIX."rates` SET
    `rCost`    = '".cleanInsertionPrice($newPrice)."'
    WHERE `id` = '$id'
    LIMIT 1
    ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    break;
    // Tare rates..
    case 'tare':
    mysql_query("UPDATE `".DB_PREFIX."tare` SET
    `rCost`    = '{$newPrice}'
    WHERE `id` = '$id'
    LIMIT 1
    ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    break;
  }
}

function updatePage() {
  $_POST  = mc_safeImport($_POST);
  $row    = $_POST['process'];
  mysql_query("UPDATE ".DB_PREFIX."settings SET
  $row = '{$_POST['text']}'
  LIMIT 1
  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
}

function addDiscountCoupon() {
  $_POST = mc_safeImport($_POST);
  // Check restriction limit for free version..
  if (LICENCE_VER=='locked') {
    if (mc_rowCount('campaigns')+1>RESTR_COUPONS) {
      mc_restrictionLimitRedirect();
    }
  }
  mysql_query("INSERT INTO ".DB_PREFIX."campaigns (
  `cName`,
  `cDiscountCode`,
  `cMin`,
  `cUsage`,
  `cExpiry`,
  `cDiscount`,
  `cAdded`,
  `cLive`,
  `categories`
  ) VALUES (
  '{$_POST['cName']}',
  '{$_POST['cDiscountCode']}',
  '".($_POST['cMin']>0 ? cleanInsertionPrice($_POST['cMin']) : '0')."',
  '{$_POST['cUsage']}',
  '".(mc_checkValidDate($_POST['cExpiry'])!='0000-00-00' ? mc_convertCalToSQLFormat($_POST['cExpiry']) : '0000-00-00')."',
  '".systemEngine::calculateDiscountType($_POST['cDiscount'])."',
  '".date("Y-m-d")."',
  '".(isset($_POST['cLive']) && in_array($_POST['cLive'],array('yes','no')) ? $_POST['cLive'] : 'yes')."',
  '".(!empty($_POST['cat']) ? implode(',',$_POST['cat']) : '')."'
  )") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
}

function calculateDiscountType($discount) {
  if (strpos(strtolower($discount),'free')!==FALSE) {
    return 'freeshipping';
  }
  if (strpos(strtolower($discount),'tax')!==FALSE) {
    return 'notax';
  }
  return $discount;
}

function updateDiscountCoupon() {
  $_POST  = mc_safeImport($_POST);
  mysql_query("UPDATE ".DB_PREFIX."campaigns SET
  `cName`          = '{$_POST['cName']}',
  `cDiscountCode`  = '{$_POST['cDiscountCode']}',
  `cMin`           = '".($_POST['cMin']>0 ? cleanInsertionPrice($_POST['cMin']) : '0')."',
  `cUsage`         = '{$_POST['cUsage']}',
  `cExpiry`        = '".(mc_checkValidDate($_POST['cExpiry'])!='0000-00-00' ? mc_convertCalToSQLFormat($_POST['cExpiry']) : '0000-00-00')."',
  `cDiscount`      = '".systemEngine::calculateDiscountType($_POST['cDiscount'])."',
  `cLive`          = '".(isset($_POST['cLive']) && in_array($_POST['cLive'],array('yes','no')) ? $_POST['cLive'] : 'yes')."',
  `categories`     = '".(!empty($_POST['cat']) ? implode(',',$_POST['cat']) : '')."'
  WHERE `id`       = '".mc_digitSan($_GET['edit'])."'
  LIMIT 1
  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
}

function deleteDiscountCoupon() {
  mysql_query("DELETE FROM ".DB_PREFIX."campaigns
  WHERE `id` = '".mc_digitSan($_GET['del'])."'
  LIMIT 1
  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  $rows = mysql_affected_rows();
  mysql_query("DELETE FROM ".DB_PREFIX."coupons
  WHERE `cCampaign` = '".mc_digitSan($_GET['del'])."'
  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  tableTruncationRoutine(array('campaigns','coupons'));
  return $rows;
}

function updateCurrencyConverter() {
   $keys = array_keys($_POST['cur']);
   // If empty, de-activate all currencies..
   for ($i=0; $i<count($keys); $i++) {
     $switch = (isset($_POST['iso'][$keys[$i]]) ? 'yes' : 'no');
     switch ($switch) {
	   // Enabled currency..
	   case 'yes':
	   mysql_query("UPDATE `".DB_PREFIX."currencies` SET
       `enableCur`           = 'yes',
	   `rate`                = '".mc_safeImportString($_POST['rate'][$keys[$i]])."',
       `currencyDisplayPref` = '".mc_safeImportString($_POST['pref'][$keys[$i]])."'
       WHERE `currency`      = '{$keys[$i]}'
       LIMIT 1
       ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
	   break;
	   // Disabled currency..
	   case 'no':
	   mysql_query("UPDATE `".DB_PREFIX."currencies` SET
       `enableCur`           = 'no',
	   `rate`                = '0',
       `currencyDisplayPref` = ''
       WHERE `currency`      = '{$keys[$i]}'
       LIMIT 1
       ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
	   break;
	 }  
   }
}

function addPercentRate() {
  $c = 0;
  for ($i=1; $i<($_POST['num']+1); $i++) {
    if (!empty($_POST['inZone'][$i])) {
      for ($j=0; $j<count($_POST['inZone'][$i]); $j++) {
        mysql_query("INSERT INTO ".DB_PREFIX."percent (
        `inZone`,`percentage`,`enabled`,`priceFrom`,`priceTo`
        ) VALUES (
        '{$_POST['inZone'][$i][$j]}',
        '".rateCleaner($_POST['percentage'][$i])."',
        '".(isset($_POST['enable_'.$i]) && in_array($_POST['enable_'.$i],array('yes','no')) ? $_POST['enable_'.$i] : 'no')."',
        '".cleanInsertionPrice($_POST['priceFrom'][$i])."',
        '".cleanInsertionPrice($_POST['priceTo'][$i])."'
        )") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
        ++$c;
      }
    }
  }
  return $c;
}

function updatePercentRate() {
  mysql_query("UPDATE ".DB_PREFIX."percent SET
  `inZone`      = '{$_POST['inZone'][1]}',
  `priceFrom`   = '".cleanInsertionPrice($_POST['priceFrom'][1])."',
  `priceTo`     = '".cleanInsertionPrice($_POST['priceTo'][1])."',
  `percentage`  = '".$_POST['percentage'][1]."',
  `enabled`     = '".(isset($_POST['enable_1']) && in_array($_POST['enable_1'],array('yes','no')) ? $_POST['enable_1'] : 'no')."'
  WHERE id      = '".mc_digitSan($_GET['edit'])."'
  LIMIT 1
  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  return '1';
}

function deletePercentRate() {
  mysql_query("DELETE FROM ".DB_PREFIX."percent
  WHERE id = '".mc_digitSan($_GET['del'])."'
  LIMIT 1
  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  $rows = mysql_affected_rows();
  tableTruncationRoutine(array('percent'));
  return $rows;
}

function addFlatRate() {
  $c = 0;
  $u = 0;
  if (!empty($_POST['inZone'])) {
    for ($j=0; $j<count($_POST['inZone']); $j++) {
      if (mc_rowCount('flat WHERE `inZone` = \''.$_POST['inZone'][$j].'\'')>0) {
        mysql_query("UPDATE `".DB_PREFIX."flat` SET
        `rate`         = '".$_POST['rate']."',
        `enabled`      = '".(isset($_POST['enable']) && in_array($_POST['enable'],array('yes','no')) ? $_POST['enable'] : 'no')."'
        WHERE `inZone` = '{$_POST['inZone'][$j]}'
        LIMIT 1
        ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
        ++$u;
      } else {
        mysql_query("INSERT INTO `".DB_PREFIX."flat` (
        `inZone`,`rate`,`enabled`
        ) VALUES (
        '{$_POST['inZone'][$j]}',
        '".$_POST['rate']."',
        '".(isset($_POST['enable']) && in_array($_POST['enable'],array('yes','no')) ? $_POST['enable'] : 'no')."'
        )") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
        ++$c;
      }
    }
  }
  return array($c,$u);
}

function addPerItemRate() {
  $c = 0;
  $u = 0;
  if (!empty($_POST['inZone'])) {
    for ($j=0; $j<count($_POST['inZone']); $j++) {
      if (mc_rowCount('per WHERE `inZone` = \''.$_POST['inZone'][$j].'\'')>0) {
        mysql_query("UPDATE `".DB_PREFIX."per` SET
        `rate`         = '".$_POST['rate']."',
		`item`         = '".$_POST['item']."',
        `enabled`      = '".(isset($_POST['enable']) && in_array($_POST['enable'],array('yes','no')) ? $_POST['enable'] : 'no')."'
        WHERE `inZone` = '{$_POST['inZone'][$j]}'
        LIMIT 1
        ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
        ++$u;
      } else {
        mysql_query("INSERT INTO `".DB_PREFIX."per` (
        `inZone`,`rate`,`item`,`enabled`
        ) VALUES (
        '{$_POST['inZone'][$j]}',
        '".$_POST['rate']."',
		'".$_POST['item']."',
        '".(isset($_POST['enable']) && in_array($_POST['enable'],array('yes','no')) ? $_POST['enable'] : 'no')."'
        )") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
        ++$c;
      }
    }
  }
  return array($c,$u);
}

function updateFlatRate() {
  mysql_query("UPDATE `".DB_PREFIX."flat` SET
  `inZone`   = '{$_POST['inZone']}',
  `rate`     = '".cleanInsertionPrice($_POST['rate'])."',
  `enabled`  = '".(isset($_POST['enable_1']) && in_array($_POST['enable_1'],array('yes','no')) ? $_POST['enable_1'] : 'no')."'
  WHERE `id` = '".mc_digitSan($_GET['edit'])."'
  LIMIT 1
  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  return '1';
}

function updatePerItemRate() {
  mysql_query("UPDATE `".DB_PREFIX."per` SET
  `inZone`   = '{$_POST['inZone']}',
  `rate`     = '".cleanInsertionPrice($_POST['rate'])."',
  `item`     = '".cleanInsertionPrice($_POST['item'])."',
  `enabled`  = '".(isset($_POST['enable_1']) && in_array($_POST['enable_1'],array('yes','no')) ? $_POST['enable_1'] : 'no')."'
  WHERE `id` = '".mc_digitSan($_GET['edit'])."'
  LIMIT 1
  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  return '1';
}

function deleteFlatRate() {
  mysql_query("DELETE FROM `".DB_PREFIX."flat`
  WHERE `id` = '".mc_digitSan($_GET['del'])."'
  LIMIT 1
  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  $rows = mysql_affected_rows();
  tableTruncationRoutine(array('flat'));
  return $rows;
}

function deletePerItemRate() {
  mysql_query("DELETE FROM `".DB_PREFIX."per`
  WHERE `id` = '".mc_digitSan($_GET['del'])."'
  LIMIT 1
  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  $rows = mysql_affected_rows();
  tableTruncationRoutine(array('per'));
  return $rows;
}

function addService() {
  $_POST  = mc_safeImport($_POST);
  $temp   = (isset($_FILES['file']['tmp_name']) ? $_FILES['file']['tmp_name'] : '');
  $name   = (isset($_FILES['file']['name']) ? $_FILES['file']['name'] : '');
  $zones  = count($_POST['inZone']);
  $count  = 0;
  if ($temp && $name) {
    if (is_uploaded_file($temp)) {
      $handle = fopen($temp,'r');
      while (($CSV = fgetcsv($handle,10000))!== FALSE) {
        for ($i=0; $i<$zones; $i++) {
          if ($CSV[0] && $CSV[1]) {
            mysql_query("INSERT INTO `".DB_PREFIX."services` (
            `sName`,
            `sEstimation`,
            `sSignature`,
            `inZone`,
            `enableCOD`
            ) VALUES (
            '{$CSV[0]}',
            '{$CSV[1]}',
            '".(isset($CSV[2]) && in_array($CSV[2],array('yes','no')) ? $CSV[2] : 'no')."',
            '{$_POST['inZone'][$i]}',
            '".(isset($CSV[3]) && in_array($CSV[3],array('yes','no')) ? $CSV[3] : 'no')."'
            )") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
          }
        }
        ++$count;
      }
      fclose($handle);
      if (isset($temp)) {
        @unlink($temp);
      }
    }  
  } else {
    for ($i=0; $i<$zones; $i++) {
      if ($_POST['sName'] && $_POST['sEstimation']) {
        mysql_query("INSERT INTO `".DB_PREFIX."services` (
        `sName`,
        `sEstimation`,
        `sSignature`,
        `inZone`,
        `enableCOD`
        ) VALUES (
        '{$_POST['sName']}',
        '{$_POST['sEstimation']}',
        '".(isset($_POST['sSignature']) ? $_POST['sSignature'] : 'no')."',
        '{$_POST['inZone'][$i]}',
        '".(isset($_POST['enableCOD']) ? $_POST['enableCOD'] : 'no')."'
        )") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
      }
    }
    $count = 1;
  }
  return array($count,$zones);
}

function updateService() {
  $_POST  = mc_safeImport($_POST);
  $c      = 0;
  if ($_POST['sName'] && $_POST['sEstimation'] && $_POST['inZone']>0) {
    mysql_query("UPDATE `".DB_PREFIX."services` SET
    `sName`        = '{$_POST['sName']}',
    `sEstimation`  = '{$_POST['sEstimation']}',
    `sSignature`   = '".(isset($_POST['sSignature']) ? $_POST['sSignature'] : 'no')."',
    `inZone`       = '{$_POST['inZone']}',
    `enableCOD`    = '".(isset($_POST['enableCOD']) ? $_POST['enableCOD'] : 'no')."'
    WHERE `id`     = '".mc_digitSan($_GET['edit'])."'
    LIMIT 1
    ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    ++$c;
  }
  return $c;
}

function deleteService() {
  mysql_query("DELETE FROM `".DB_PREFIX."services`
  WHERE `id` = '".mc_digitSan($_GET['del'])."'
  LIMIT 1
  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  $rows = mysql_affected_rows();
  mysql_query("DELETE FROM `".DB_PREFIX."rates`
  WHERE `rService` = '".mc_digitSan($_GET['del'])."'
  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  mysql_query("DELETE FROM `".DB_PREFIX."tare`
  WHERE `rService` = '".mc_digitSan($_GET['del'])."'
  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  tableTruncationRoutine(array('services','rates','tare'));
  return $rows;
}

function addTareRates() {
  $_POST     = mc_safeImport($_POST);
  $temp      = (isset($_FILES['file']['tmp_name']) ? $_FILES['file']['tmp_name'] : '');
  $name      = (isset($_FILES['file']['name']) ? $_FILES['file']['name'] : '');
  $services  = count($_POST['rService']);
  $count     = 0;
  if ($temp && $name) {
    if (is_uploaded_file($temp)) {
      $handle = fopen($temp,'r');
      while (($CSV = fgetcsv($handle,10000))!== FALSE) {
        for ($i=0; $i<$services; $i++) {
          if ($CSV[0]!='' && $CSV[1]!='' && isset($CSV[2])) {
            mysql_query("INSERT INTO `".DB_PREFIX."tare` (
            `rWeightFrom`,
            `rWeightTo`,
            `rCost`,
            `rService`
            ) VALUES (
            '".str_replace(array('.',','),array(),$CSV[0])."',
            '".str_replace(array('.',','),array(),$CSV[1])."',
            '".($CSV[2] ? $CSV[2] : '0.00')."',
            '{$_POST['rService'][$i]}'
            )") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
          }
        }
        ++$count;
      }
      fclose($handle);
      if (isset($temp)) {
        @unlink($temp);
      }
    }  
  } else {
    for ($i=0; $i<$services; $i++) {
      if ($_POST['rWeightFrom']!='' && $_POST['rWeightTo']!='') {
        mysql_query("INSERT INTO `".DB_PREFIX."tare` (
        `rWeightFrom`,
        `rWeightTo`,
        `rCost`,
        `rService`
        ) VALUES (
        '".str_replace(array('.',','),array(),$_POST['rWeightFrom'])."',
        '".str_replace(array('.',','),array(),$_POST['rWeightTo'])."',
        '".($_POST['rCost'] ? $_POST['rCost'] : '0.00')."',
        '{$_POST['rService'][$i]}'
        )") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
      }
    }
    $count = 1;
  }
  return array($count,$services);
}

function updateTareRates() {
  $_POST  = mc_safeImport($_POST);
  $c      = 0;
  if ($_POST['rWeightFrom']!='' && $_POST['rWeightTo']!='') {
    mysql_query("UPDATE `".DB_PREFIX."tare` SET
    `rWeightFrom`  = '".str_replace(array('.',','),array(),$_POST['rWeightFrom'])."',
    `rWeightTo`    = '".str_replace(array('.',','),array(),$_POST['rWeightTo'])."',
    `rCost`        = '".($_POST['rCost'] ? $_POST['rCost'] : '0.00')."',
    `rService`     = '{$_POST['rService']}'
    WHERE `id`     = '".mc_digitSan($_GET['edit'])."'
    LIMIT 1
    ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    ++$c;
  }
  return $c;
}

function deleteTareRates() {
  mysql_query("DELETE FROM ".DB_PREFIX."tare
  WHERE `id` = '".mc_digitSan($_GET['del'])."'
  LIMIT 1
  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  $rows = mysql_affected_rows();
  tableTruncationRoutine(array('tare'));
  return $rows;
}

function addRates() {
  $_POST     = mc_safeImport($_POST);
  $temp      = (isset($_FILES['file']['tmp_name']) ? $_FILES['file']['tmp_name'] : '');
  $name      = (isset($_FILES['file']['name']) ? $_FILES['file']['name'] : '');
  $services  = count($_POST['rService']);
  $count     = 0;
  if ($temp && $name) {
    if (is_uploaded_file($temp)) {
      $handle = fopen($temp,'r');
      while (($CSV = fgetcsv($handle,10000))!== FALSE) {
        for ($i=0; $i<$services; $i++) {
          if ($CSV[0]!='' && $CSV[1]!='' && isset($CSV[2])) {
            mysql_query("INSERT INTO `".DB_PREFIX."rates` (
            `rWeightFrom`,
            `rWeightTo`,
            `rCost`,
            `rService`
            ) VALUES (
            '".str_replace(array('.',','),array(),$CSV[0])."',
            '".str_replace(array('.',','),array(),$CSV[1])."',
            '".($CSV[2] ? cleanInsertionPrice($CSV[2]) : '0.00')."',
            '{$_POST['rService'][$i]}'
            )") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
          }
        }
        ++$count;
      }
      fclose($handle);
      if (isset($temp)) {
        @unlink($temp);
      }
    }  
  } else {
    for ($i=0; $i<$services; $i++) {
      if ($_POST['rWeightFrom']!='' && $_POST['rWeightTo']!='') {
        mysql_query("INSERT INTO `".DB_PREFIX."rates` (
        `rWeightFrom`,
        `rWeightTo`,
        `rCost`,
        `rService`
        ) VALUES (
        '".str_replace(array('.',','),array(),$_POST['rWeightFrom'])."',
        '".str_replace(array('.',','),array(),$_POST['rWeightTo'])."',
        '".($_POST['rCost'] ? cleanInsertionPrice($_POST['rCost']) : '0.00')."',
        '{$_POST['rService'][$i]}'
        )") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
      }
    }
    $count = 1;
  }
  return array($count,$services);
}

function updateRates() {
  $_POST  = mc_safeImport($_POST);
  $c      = 0;
  if ($_POST['rWeightFrom']!='' && $_POST['rWeightTo']!='') {
    mysql_query("UPDATE `".DB_PREFIX."rates` SET
    `rWeightFrom`  = '".str_replace(array('.',','),array(),$_POST['rWeightFrom'])."',
    `rWeightTo`    = '".str_replace(array('.',','),array(),$_POST['rWeightTo'])."',
    `rCost`        = '".($_POST['rCost'] ? cleanInsertionPrice($_POST['rCost']) : '0.00')."',
    `rService`     = '{$_POST['rService']}'
    WHERE `id`     = '".mc_digitSan($_GET['edit'])."'
    LIMIT 1
    ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    ++$c;
  }
  return $c;
}

function deleteRates() {
  mysql_query("DELETE FROM ".DB_PREFIX."rates
  WHERE `id` = '".mc_digitSan($_GET['del'])."'
  LIMIT 1
  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  $rows = mysql_affected_rows();
  tableTruncationRoutine(array('rates'));
  return $rows;
}

function updateZone($temp,$name) {
  $_POST['zRate']  = rateCleaner($_POST['zRate']);
  mysql_query("UPDATE ".DB_PREFIX."zones SET
  zName      = '".mc_safeImportString($_POST['zName'])."',
  zCountry   = '{$_POST['zCountry']}',
  zRate      = '{$_POST['zRate']}',
  zShipping  = '".(isset($_POST['zShipping']) ? $_POST['zShipping'] : 'no')."'
  WHERE id   = '".mc_digitSan($_GET['edit'])."'
  LIMIT 1
  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  if (($name && $temp) || $_POST['zones2']) {
    mysql_query("DELETE FROM ".DB_PREFIX."zone_areas
    WHERE inZone = '".mc_digitSan($_GET['edit'])."'
    ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    tableTruncationRoutine(array('zone_areas'));
    systemEngine::batchAddZoneAreas(mc_digitSan($_GET['edit']),$temp,$name,$_POST['zones2']);
  } else {
    mysql_query("UPDATE ".DB_PREFIX."zone_areas SET
    zRate         = '".$_POST['zRate']."',
    zShipping     = '".(isset($_POST['zShipping']) ? $_POST['zShipping'] : 'no')."'
    WHERE inZone  = '".mc_digitSan($_GET['edit'])."'
    ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  }
}

function deleteZone() {
  // Remove zone..
  mysql_query("DELETE FROM ".DB_PREFIX."zones
  WHERE `id` = '".mc_digitSan($_GET['del'])."'
  LIMIT 1
  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  $rows = mysql_affected_rows();
  // Remove zone areas..
  mysql_query("DELETE FROM ".DB_PREFIX."zone_areas
  WHERE `inZone` = '".mc_digitSan($_GET['del'])."'
  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  // Remove zone rates..
  $query = mysql_query("SELECT * FROM ".DB_PREFIX."services 
           WHERE inZone = '".mc_digitSan($_GET['del'])."'
           ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  while ($SERVICES = mysql_fetch_object($query)) {
    mysql_query("DELETE FROM ".DB_PREFIX."rates
    WHERE `rService` = '".$SERVICES->id."'
    ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    mysql_query("DELETE FROM ".DB_PREFIX."tare
    WHERE `rService` = '".$SERVICES->id."'
    ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  }
  // Remove zone services..
  mysql_query("DELETE FROM ".DB_PREFIX."services
  WHERE `inZone` = '".mc_digitSan($_GET['del'])."'
  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  tableTruncationRoutine(array('zones','zone_areas','services','rates','tare'));
  return $rows;
}

function addNewZone($temp,$name) {
  $F               = array_map('trim',($temp && $name ? file($temp) : explode(mc_defineNewline(),$_POST['zones2'])));
  $_POST['zRate']  = rateCleaner($_POST['zRate']);
  foreach ($_POST['zCountry'] AS $cid) {
    mysql_query("INSERT INTO `".DB_PREFIX."zones` (
    `zName`,`zCountry`,`zRate`,`zShipping`
    ) VALUES (
    '".mc_safeImportString($_POST['zName'])."','$cid',
    '{$_POST['zRate']}','".(isset($_POST['zShipping']) ? $_POST['zShipping'] : 'no')."'
    )") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    $id = mysql_insert_id();
    if (($name && $temp) || $_POST['zones2']) {
      foreach ($F AS $zoneName) {
        mysql_query("INSERT INTO `".DB_PREFIX."zone_areas` (
        `inZone`,`areaName`,`zCountry`,`zRate`,`zShipping`
        ) VALUES (
        '$id','".mc_safeImportString(substr($zoneName,0,250))."','$cid',
        '{$_POST['zRate']}','".(isset($_POST['zShipping']) ? mc_safeImportString($_POST['zShipping']) : 'no')."'
        )") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
      }
    }
  }
  if (isset($temp)) {
    @unlink($temp);
  }
}

function batchAddZoneAreas($zone,$temp,$name,$box) {
  $F      = array_map('trim',($temp && $name ? file($temp) : explode(mc_defineNewline(),$box)));
  foreach ($F AS $zoneName) {
    mysql_query("INSERT INTO `".DB_PREFIX."zone_areas` (
    `inZone`,`areaName`,`zCountry`,`zRate`,`zShipping`
    ) VALUES (
    '$zone','".mc_safeImportString(substr($zoneName,0,250))."','{$_POST['zCountry']}',
    '{$_POST['zRate']}','".(isset($_POST['zShipping']) ? mc_safeImportString($_POST['zShipping']) : 'no')."'
    )") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  }
  if (isset($temp)) {
    @unlink($temp);
  }
}

function addNewCountries() {
  $_POST  = mc_safeImport($_POST);
  $c      = 0;
  for ($i=0; $i<$_POST['num']; $i++) {
    if ($_POST['cName'][$i]!='' && $_POST['cISO'][$i]!='' && $_POST['cISO_2'][$i]!='' && $_POST['iso4217'][$i]!='') {
      mysql_query("INSERT INTO ".DB_PREFIX."countries (
      `cName`,
      `cISO`,
      `cISO_2`,
      `iso4217`,
      `enCountry`
      ) VALUES (
      '{$_POST['cName'][$i]}',
      '{$_POST['cISO'][$i]}',
      '{$_POST['cISO_2'][$i]}',
      '{$_POST['iso4217'][$i]}',
      '".(in_array($_POST['enCountry'][$i+1][0],array('yes','no')) ? $_POST['enCountry'][$i+1][0] : 'no')."'
      )") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
      ++$c;
    }
  }
  return $c;
}

function updateCountry() {
  if ($_POST['cName'][0]!='' && $_POST['cISO'][0]!='' && $_POST['cISO_2'][0]!='' && $_POST['iso4217'][0]!='') {
    mysql_query("UPDATE ".DB_PREFIX."countries SET
    `cName`      = '{$_POST['cName'][0]}',
    `cISO`       = '{$_POST['cISO'][0]}',
    `cISO_2`     = '{$_POST['cISO_2'][0]}',
    `iso4217`    = '{$_POST['iso4217'][0]}',
    `enCountry`  = '".(in_array($_POST['enCountry'][1][0],array('yes','no')) ? $_POST['enCountry'][1][0] : 'no')."'
    WHERE `id`   = '".mc_digitSan($_GET['edit'])."'
    LIMIT 1
    ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  }
}

function deleteCountries() {
  mysql_query("DELETE FROM `".DB_PREFIX."countries` WHERE `id` IN(".implode(',',$_POST['no']).")")
  or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  $rows = mysql_affected_rows();
  tableTruncationRoutine(array('countries'));
  return $rows;
}

function updateCountries() {
  if (!empty($_POST['no']) && isset($_POST['yes_go'])) {
    mysql_query("UPDATE ".DB_PREFIX."countries SET
    `enCountry`  = 'yes'
    WHERE `id` IN(".implode(',',$_POST['no']).")
    ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));  
  }
  if (!empty($_POST['yes']) && isset($_POST['no_go'])) {
    mysql_query("UPDATE ".DB_PREFIX."countries SET
    `enCountry` = 'no'
    WHERE `id` IN(".implode(',',$_POST['yes']).")
    ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  }
}

function resetStoreLogo() {
  if (file_exists($this->settings->serverPath.'/'.PRODUCTS_FOLDER.'/'.$_GET['removeLogo'])) {
    @unlink($this->settings->serverPath.'/'.PRODUCTS_FOLDER.'/'.$_GET['removeLogo']);
  }
  mysql_query("UPDATE ".DB_PREFIX."settings SET logoName = '' LIMIT 1");
}

function uploadWebLogo($name,$temp) {
  $logo = '';
  if (is_dir($this->settings->serverPath.'/'.PRODUCTS_FOLDER) && is_writeable($this->settings->serverPath.'/'.PRODUCTS_FOLDER)) {
    if (is_uploaded_file($temp)) {
      $ext   = strrchr($name, '.');
      $file  = 'logo-'.date('Ymdhis').strtolower($ext);
      move_uploaded_file($temp,$this->settings->serverPath.'/'.PRODUCTS_FOLDER.'/'.$file);
      if (file_exists($this->settings->serverPath.'/'.PRODUCTS_FOLDER.'/'.$file)) {
        // Some servers require permission changes..
        @chmod($this->settings->serverPath.'/'.PRODUCTS_FOLDER.'/'.$file,AFTER_UPLOAD_CHMOD_VALUE);
        return $file;
      }
    }
  }
  return $logo;
}

function updateSettings() {
  $_POST  = mc_safeImport($_POST);
  $area   = (isset($_GET['s']) ? $_GET['s'] : '1');
  switch ($area) {
    case '1':
    $leftBoxes = array();
    for ($i=0; $i<count($_POST['marker']); $i++) {
      $leftBoxes[] = array($_POST['pos'][$i],$_POST['marker'][$i]);
    }
    mysql_query("UPDATE ".DB_PREFIX."settings SET
    `website`               = '{$_POST['website']}',
    `theme`                 = '{$_POST['theme']}',
    `email`                 = '{$_POST['email']}',
    `addEmails`             = '{$_POST['addEmails']}',
    `serverPath`            = '".systemEngine::filterInstallationPaths($_POST['serverPath'])."',
    `languagePref`          = '{$_POST['languagePref']}',
    `ifolder`               = '".systemEngine::filterInstallationPaths($_POST['ifolder'])."',
    `metaKeys`              = '{$_POST['metaKeys']}',
    `metaDesc`              = '{$_POST['metaDesc']}',
    `en_rss`                = '".(isset($_POST['en_rss']) && in_array($_POST['en_rss'],array('yes','no')) ? $_POST['en_rss'] : 'yes')."',
    `rssScroller`           = '".(isset($_POST['rssScroller']) && in_array($_POST['rssScroller'],array('yes','no')) ? $_POST['rssScroller'] : 'yes')."',
    `rssScrollerUrl`        = '{$_POST['rssScrollerUrl']}',
    `rssScrollerLimit`      = '".mc_digitSan($_POST['rssScrollerLimit'])."',
    `en_modr`               = '".(isset($_POST['en_modr']) && in_array($_POST['en_modr'],array('yes','no')) ? $_POST['en_modr'] : 'no')."',
    `appendindex`           = '".(isset($_POST['appendindex']) ? 'yes' : 'no')."',
    `activateEmails`        = '".(isset($_POST['activateEmails']) && in_array($_POST['activateEmails'],array('yes','no')) ? $_POST['activateEmails'] : 'no')."',
    `enableBBCode`          = '".(isset($_POST['enableBBCode']) && in_array($_POST['enableBBCode'],array('yes','no')) ? $_POST['enableBBCode'] : 'no')."',
    `productsPerPage`       = '".mc_digitSan($_POST['productsPerPage'])."',
    `systemDateFormat`      = '{$_POST['systemDateFormat']}',
    `mysqlDateFormat`       = '{$_POST['mysqlDateFormat']}',
    `jsDateFormat`          = '{$_POST['jsDateFormat']}',
    `jsWeekStart`           = '".mc_digitSan($_POST['jsWeekStart'])."',
    `timezone`              = '{$_POST['timezone']}',
    `rssFeedLimit`          = '".mc_digitSan($_POST['rssFeedLimit'])."',
    `flashVideoWidth`       = '".mc_digitSan($_POST['flashVideoWidth'])."',
    `flashVideoHeight`      = '".mc_digitSan($_POST['flashVideoHeight'])."',
    `saleComparisonItems`   = '".mc_digitSan($_POST['saleComparisonItems'])."',
    `searchLowStockLimit`   = '".mc_digitSan($_POST['searchLowStockLimit'])."',
    `mostPopProducts`       = '".mc_digitSan($_POST['mostPopProducts'])."',
    `mostPopPref`           = '".(isset($_POST['mostPopPref']) && in_array($_POST['mostPopPref'],array('hits','sales')) ? $_POST['mostPopPref'] : 'sales')."',
    `latestProdLimit`       = '".mc_digitSan($_POST['latestProdLimit'])."',
    `latestProdDuration`    = '".(isset($_POST['latestProdDuration']) && in_array($_POST['latestProdDuration'],array('days','months','years')) ? $_POST['latestProdDuration'] : 'days')."',
    `helpTips`              = '".(isset($_POST['helpTips']) && in_array($_POST['helpTips'],array('yes','no')) ? $_POST['helpTips'] : 'yes')."',
    `enableZip`             = '".(isset($_POST['enableZip']) && in_array($_POST['enableZip'],array('yes','no')) ? $_POST['enableZip'] : 'no')."',
    `minInvoiceDigits`      = '".mc_digitSan($_POST['minInvoiceDigits'])."',
    `invoiceNo`             = '".mc_digitSan($_POST['invoiceNo'])."',
    `zipCreationLimit`      = '".($_POST['zipCreationLimit'] ? mc_digitSan($_POST['zipCreationLimit']) : '0')."',
    `zipLimit`              = '".($_POST['zipLimit'] ? mc_digitSan($_POST['zipLimit']) : '0')."',
    `zipTimeOut`            = '".($_POST['zipTimeOut'] ? mc_digitSan($_POST['zipTimeOut']) : '0')."',
    `zipMemoryLimit`        = '".($_POST['zipMemoryLimit'] ? mc_digitSan($_POST['zipMemoryLimit']) : '0')."',
    `zipAdditionalFolder`   = '".($_POST['zipAdditionalFolder'] ? $_POST['zipAdditionalFolder'] : 'additional-zip')."',
    `enEntryLog`            = '".(isset($_POST['enEntryLog']) && in_array($_POST['enEntryLog'],array('yes','no')) ? $_POST['enEntryLog'] : 'no')."',
    `enSearchLog`           = '".(isset($_POST['enSearchLog']) && in_array($_POST['enSearchLog'],array('yes','no')) ? $_POST['enSearchLog'] : 'no')."',
    `smartQuotes`           = '".(isset($_POST['smartQuotes']) && in_array($_POST['smartQuotes'],array('yes','no')) ? $_POST['smartQuotes'] : 'no')."',
    `hitCounter`            = '".(isset($_POST['hitCounter']) && in_array($_POST['hitCounter'],array('yes','no')) ? $_POST['hitCounter'] : 'no')."',
    `adminFolderName`       = '{$_POST['adminFolderName']}',
    `facebookLink`          = '{$_POST['facebookLink']}',
    `twitterLink`           = '{$_POST['twitterLink']}',
    `twitterUser`           = '{$_POST['twitterUser']}',
    `twitterLatest`         = '".(isset($_POST['twitterLatest']) && in_array($_POST['twitterLatest'],array('yes','no')) ? $_POST['twitterLatest'] : 'no')."',
    `enableRecentView`      = '".(isset($_POST['enableRecentView']) && in_array($_POST['enableRecentView'],array('yes','no')) ? $_POST['enableRecentView'] : 'yes')."',
    `savedSearches`         = '".mc_digitSan($_POST['savedSearches'])."',
    `searchSlider`          = '".serialize($_POST['searchSlider'])."',
    `searchTagsOnly`        = '".(isset($_POST['searchTagsOnly']) && in_array($_POST['searchTagsOnly'],array('yes','no')) ? $_POST['searchTagsOnly'] : 'no')."',
	`disqusShortName`       = '{$_POST['disqusShortName']}',
    `disqusDevMode`         = '".(isset($_POST['disqusDevMode']) && in_array($_POST['disqusDevMode'],array('yes','no')) ? $_POST['disqusDevMode'] : 'yes')."',
    `thumbWidth`            = '".mc_digitSan($_POST['thumbWidth'])."',
    `thumbHeight`           = '".mc_digitSan($_POST['thumbHeight'])."', 
    `thumbQuality`          = '".mc_digitSan($_POST['thumbQuality'])."',
    `thumbQualityPNG`       = '".mc_digitSan($_POST['thumbQualityPNG'])."',
	`aspectRatio`           = '".(isset($_POST['aspectRatio']) && in_array($_POST['aspectRatio'],array('yes','no')) ? $_POST['aspectRatio'] : 'yes')."',
    `renamePics`            = '".(isset($_POST['renamePics']) && in_array($_POST['renamePics'],array('yes','no')) ? $_POST['renamePics'] : 'yes')."',
	`tmbPrefix`             = '".$_POST['tmbPrefix']."',
	`imgPrefix`             = '".$_POST['imgPrefix']."',
    `maxProductChars`       = '".mc_digitSan($_POST['maxProductChars'])."',
    `leftBoxOrder`          = '".(!empty($leftBoxes) ? serialize($leftBoxes) : '')."',
    `parentCatHomeDisplay`  = '".(isset($_POST['parentCatHomeDisplay']) && in_array($_POST['parentCatHomeDisplay'],array('yes','no')) ? $_POST['parentCatHomeDisplay'] : 'no')."',
    `isbnAPI`               = '{$_POST['isbnAPI']}',
    `freeTextDisplay`       = '{$_POST['freeTextDisplay']}',
    `excludeFreePop`        = '".(isset($_POST['excludeFreePop']) && in_array($_POST['excludeFreePop'],array('yes','no')) ? $_POST['excludeFreePop'] : 'no')."',
    `priceTextDisplay`      = '{$_POST['priceTextDisplay']}',
    `en_sitemap`            = '".(isset($_POST['en_sitemap']) && in_array($_POST['en_sitemap'],array('yes','no')) ? $_POST['en_sitemap'] : 'yes')."',
    `sitemapPref`           = '".(isset($_POST['sitemapPref']) && in_array($_POST['sitemapPref'],array('list','cat')) ? $_POST['sitemapPref'] : 'cat')."',
    `cubeUrl`               = '{$_POST['cubeUrl']}',
    `cubeAPI`               = '{$_POST['cubeAPI']}',
	`menuCatCount`          = '".(isset($_POST['menuCatCount']) && in_array($_POST['menuCatCount'],array('yes','no')) ? $_POST['menuCatCount'] : 'no')."',
	`menuBrandCount`        = '".(isset($_POST['menuBrandCount']) && in_array($_POST['menuBrandCount'],array('yes','no')) ? $_POST['menuBrandCount'] : 'no')."',
	`catGiftPos`            = '{$_POST['catGiftPos']}',
	`showBrands`            = '".(isset($_POST['showBrands']) && in_array($_POST['showBrands'],array('yes','no')) ? $_POST['showBrands'] : 'no')."'
    LIMIT 1
    ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    break;
    case '2':
    $logo   = $_POST['logo'];
    // Is there a logo present..
    $name   = $_FILES['logo']['name'];
    $temp   = $_FILES['logo']['tmp_name'];
    $size   = $_FILES['logo']['size'];
    // Upload..
    if ($name && $temp && $size>0) {
      $logo = systemEngine::uploadWebLogo($name,$temp);
    }
    mysql_query("UPDATE ".DB_PREFIX."settings SET
    `logoName`       = '$logo',
    `addThisModule`  = '".$_POST['addThisModule']."'
    LIMIT 1
    ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    break;
    case '3':
    mysql_query("UPDATE ".DB_PREFIX."settings SET
    `baseCurrency`             = '".substr($_POST['baseCurrency'],0,3)."',
    `currencyDisplayPref`      = '{$_POST['currencyDisplayPref']}',
    `gatewayMode`              = '".(isset($_POST['gatewayMode']) && in_array($_POST['gatewayMode'],array('live','test')) ? $_POST['gatewayMode'] : 'test')."',
    `logErrors`                = '".(isset($_POST['logErrors']) && in_array($_POST['logErrors'],array('yes','no')) ? $_POST['logErrors'] : 'yes')."',
    `logFolderName`            = '{$_POST['logFolderName']}',
    `enablePickUp`             = '".(isset($_POST['enablePickUp']) && in_array($_POST['enablePickUp'],array('yes','no')) ? $_POST['enablePickUp'] : 'no')."',
    `shipCountry`              = '".mc_digitSan($_POST['shipCountry'])."',
    `enableSSL`                = '".(isset($_POST['enableSSL']) && in_array($_POST['enableSSL'],array('yes','no')) ? $_POST['enableSSL'] : 'no')."',
    `pendingAsComplete`        = '".(isset($_POST['pendingAsComplete']) && in_array($_POST['pendingAsComplete'],array('yes','no')) ? $_POST['pendingAsComplete'] : 'no')."',
    `freeShipThreshold`        = '".cleanInsertionPrice($_POST['freeShipThreshold'])."',
    `downloadFolder`           = '{$_POST['downloadFolder']}',
    `downloadRestrictIP`       = '".(isset($_POST['downloadRestrictIP']) && in_array($_POST['downloadRestrictIP'],array('yes','no')) ? $_POST['downloadRestrictIP'] : 'no')."',
	`downloadRestrictIPLog`    = '".(isset($_POST['downloadRestrictIPLog']) && in_array($_POST['downloadRestrictIPLog'],array('yes','no')) ? $_POST['downloadRestrictIPLog'] : 'no')."',
	`downloadRestrictIPLock`   = '".mc_digitSan($_POST['downloadRestrictIPLock'])."',
	`downloadRestrictIPMail`   = '".(isset($_POST['downloadRestrictIPMail']) ? 'yes' : 'no')."',
    `downloadRestrictIPGlobal` = '{$_POST['downloadRestrictIPGlobal']}',
	`globalDownloadPath`       = '".systemEngine::filterInstallationPaths($_POST['globalDownloadPath'])."',
    `globalDiscount`           = '".mc_digitSan($_POST['globalDiscount'])."',
    `globalDiscountExpiry`     = '".(mc_checkValidDate($_POST['globalDiscountExpiry'])!='0000-00-00' ? mc_convertCalToSQLFormat($_POST['globalDiscountExpiry']) : '0000-00-00')."',
    `freeDownloadRestriction`  = '".mc_digitSan($_POST['freeDownloadRestriction'])."',
    `enableCheckout`           = '".(isset($_POST['enableCheckout']) && in_array($_POST['enableCheckout'],array('yes','no')) ? $_POST['enableCheckout'] : 'yes')."',
    `showOutofStock`           = '".(isset($_POST['showOutofStock']) && in_array($_POST['showOutofStock'],array('cat','yes','no')) ? $_POST['showOutofStock'] : 'yes')."',
    `optInNewsletter`          = '".(isset($_POST['optInNewsletter']) && in_array($_POST['optInNewsletter'],array('yes','no')) ? $_POST['optInNewsletter'] : 'no')."',
    `reduceDownloadStock`      = '".(isset($_POST['reduceDownloadStock']) && in_array($_POST['reduceDownloadStock'],array('yes','no')) ? $_POST['reduceDownloadStock'] : 'no')."',
    `offerInsurance`           = '".(isset($_POST['offerInsurance']) && in_array($_POST['offerInsurance'],array('yes','no')) ? $_POST['offerInsurance'] : 'yes')."',
    `insuranceAmount`          = '".(substr($_POST['insuranceAmount'],-1)=='%' ? substr($_POST['insuranceAmount'],0,-1) : $_POST['insuranceAmount'])."',
    `insuranceFilter`          = '{$_POST['insuranceFilter']}',
    `insuranceOptional`        = '".(isset($_POST['insuranceOptional']) && in_array($_POST['insuranceOptional'],array('yes','no')) ? $_POST['insuranceOptional'] : 'no')."',
    `insuranceValue`           = '{$_POST['insuranceValue']}',
    `insuranceInfo`            = '{$_POST['insuranceInfo']}',
    `minCheckoutAmount`        = '{$_POST['minCheckoutAmount']}',
    `qtyStockThreshold`        = '".mc_digitSan($_POST['qtyStockThreshold'])."',
    `productStockThreshold`    = '".mc_digitSan($_POST['productStockThreshold'])."',
    `showAttrStockLevel`       = '".(isset($_POST['showAttrStockLevel']) && in_array($_POST['showAttrStockLevel'],array('yes','no')) ? $_POST['showAttrStockLevel'] : 'no')."',
    `autoClear`                = '".mc_digitSan($_POST['autoClear'])."',
	`freeAltRedirect`          = '{$_POST['freeAltRedirect']}'
    LIMIT 1
    ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    // Clear special offers if global discount is set..
    if ($_POST['globalDiscount']>0) {
      if (isset($_POST['clearSpecialOffers']) && $_POST['clearSpecialOffers']=='yes') {
        mysql_query("UPDATE ".DB_PREFIX."products SET
        `pOffer`        = '',
        `pOfferExpiry`  = ''
        ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
      }
    }
    // Update local countries..
    if (!empty($_POST['pickup'])) {
      mysql_query("UPDATE ".DB_PREFIX."countries SET
      `localPickup` = 'yes'
      WHERE `id` IN(".implode(',',$_POST['pickup']).")
      ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
      mysql_query("UPDATE ".DB_PREFIX."countries SET
      `localPickup` = 'no'
      WHERE `id` NOT IN(".implode(',',$_POST['pickup']).")
      ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    } else {
      mysql_query("UPDATE ".DB_PREFIX."countries SET
      `localPickup` = 'no'
      ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    }
    break;
    case '4':
    mysql_query("UPDATE ".DB_PREFIX."settings SET
    `homeProdValue`  = '".mc_digitSan($_POST['homeProdValue'])."',
    `homeProdType`   = '".(isset($_POST['homeProdType']) && in_array($_POST['homeProdType'],array('random','latest')) ? $_POST['homeProdType'] : 'latest')."',
    `homeProdCats`   = '".(!empty($_POST['homeProdCats']) ? implode(',',$_POST['homeProdCats']) : '')."',
    `homeProdIDs`    = '".(substr($_POST['homeProdIDs'],-1)==',' ? substr($_POST['homeProdIDs'],0,-1) : $_POST['homeProdIDs'])."'
    LIMIT 1
    ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    break;
    case '5':
    mysql_query("UPDATE ".DB_PREFIX."settings SET
    `cName`           = '{$_POST['cName']}',
    `cWebsite`        = '{$_POST['cWebsite']}',
    `cTel`            = '{$_POST['cTel']}',
    `cFax`            = '{$_POST['cFax']}',
    `cAddress`        = '{$_POST['cAddress']}',
    `cOther`          = '{$_POST['cOther']}',
    `cReturns`        = '{$_POST['cReturns']}',
    `contactDisplay`  = '".(!empty($_POST['contact']) ? implode(',',$_POST['contact']) : '')."'
    LIMIT 1
    ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    break;
    case '6':
    mysql_query("UPDATE ".DB_PREFIX."settings SET
    `smtp`           = '".(isset($_POST['smtp']) ? $_POST['smtp'] : 'no')."',
    `smtp_host`      = '{$_POST['smtp_host']}',
    `smtp_user`      = '{$_POST['smtp_user']}',
    `smtp_pass`      = '{$_POST['smtp_pass']}',
    `smtp_port`      = '{$_POST['smtp_port']}'
    LIMIT 1
    ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    break;
    case '7':
    mysql_query("UPDATE ".DB_PREFIX."settings SET
    `adminFooter`    = '{$_POST['adminFooter']}',
    `publicFooter`   = '{$_POST['publicFooter']}'
    LIMIT 1
    ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    break;
    case '8':
    $_POST['offlineText'] = mc_cleanBBInput($_POST['offlineText']);
    mysql_query("UPDATE ".DB_PREFIX."settings SET
    `enableCart`   = '".(isset($_POST['enableCart']) && in_array($_POST['enableCart'],array('yes','no')) ? $_POST['enableCart'] : 'yes')."',
    `offlineDate`  = '".(mc_checkValidDate($_POST['offlineDate'])!='0000-00-00' ? mc_convertCalToSQLFormat($_POST['offlineDate']) : '0000-00-00')."',
    `offlineText`  = '{$_POST['offlineText']}',
    `offlineIP`    = '{$_POST['offlineIP']}'
    LIMIT 1
    ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    break;
    case '9':
    break;
  }
}

function filterInstallationPaths($path) {
  if (substr($path,-1)=='/') {
    $path = substr_replace($path,'',-1);
  }
  if (substr($path,-1)=='\\') {
    $path = substr_replace($path,'',-2);
  }
  return $path;
}

// Cleans CSV..adds quotes if data contains delimiter..
function cleanCSV($data,$del) {
  $data = str_replace('"','',$data);
  return '"'.mc_cleanData($data).'"';
}

}

?>
