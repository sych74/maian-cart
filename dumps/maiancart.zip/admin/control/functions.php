<?php

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  This File: functions.php
  Description: Functions

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

// Build JSON object from array..
function jsonHandler($arr) {
  return json_encode($arr);
}

// Hide/show fields for batch updating..
function hideShowBatchOperation($identifier,$field) {
  global $msg_productmanage57,$msg_productmanage58;
  if (defined('BATCH_EDIT_MODE')) {
    return '<a onclick="batchAddField(\'include\',\''.$identifier.'\',\''.$field.'\');return false" href="#" class="batch_yes" title="'.mc_cleanDataEnt($msg_productmanage57).'">+</a> <a onclick="batchAddField(\'exclude\',\''.$identifier.'\',\''.$field.'\');return false" class="batch_no" title="'.mc_cleanDataEnt($msg_productmanage58).'">-</a> ';
  }
  return '';
}

// Left box text..
function mc_leftBoxText($key) {
  global $msg_public_header8,$msg_public_header6,$msg_public_header13,$msg_public_header35,
         $msg_public_header3,$msg_public_header22,$msg_public_header15,$msg_public_header34;
  $arr       = array(
   'recent'  => $msg_public_header8,
   'links'   => $msg_public_header6,
   'brands'  => $msg_public_header13,
   'rss'     => $msg_public_header35,
   'cat'     => $msg_public_header3,
   'points'  => $msg_public_header22,
   'popular' => $msg_public_header15,
   'tweets'  => $msg_public_header34
  );
  return $arr[$key];
}

// Clear file cache..
function clearFileCache() {
  global $cmd,$SETTINGS;
  if (file_exists(PATH.'import/mc_FileCache.cache')) {
    @unlink(PATH.'import/mc_FileCache.cache');
  }
  // Clear import cache..
  if ($cmd=='main') {
    $dir = opendir(PATH.'import/');
    while (false!==($read=readdir($dir))) {
      if (substr(strtolower($read),-4)=='.txt') {
        $split = explode('-',$read);
        if (substr($split[1],0,8)<date('Ymd')) {
          @unlink(PATH.'import/'.$read);
        }
      }
    }
    closedir($dir);
  }
}

// Read download directory recursively..
function downloadDirScanner($p,$root,$cur='') {
  global $dString;
  $rootfiles  = '';
  $exclude    = array('.','..','.DS_Store','Thumbs.db');
  $handle     = opendir($p);
  if ($handle) {
    while(false !==($fn=readdir($handle))) {
      if (!in_array($fn, $exclude)) {
        if (is_dir($p.$fn.'/')) {
          if (strcmp($fn,'.')!=0 && strcmp($fn,'.')!=0 ) {
            if ($cur=='') {
              $f = substr($p.$fn,strlen($root)+1);
            } else {
              $f = $cur;
            }
            $dir = opendir($p.$fn);
            if ($dir) {
              while (false!==($read=readdir($dir))) {
                if (!in_array($read,array('.','..')) && !is_dir($p.$fn.'/'.$read)) {
                  $dString .= '<option value="'.$f.'/'.$read.'">'.$f.'/'.$read.'</option>'.mc_defineNewline();
                }
              }
              closedir($dir);
            }
            downloadDirScanner("$p$fn/", $root,$cur);
          }
        } else {
          $rootfiles .= '<option value="'.$fn.'">'.$fn.'</option>'.mc_defineNewline();
        }
      }
    }
    closedir($handle);
  }
  return trim($dString.$rootfiles);
}

// BB Code link..
function showBBCodeLink($internal=false,$textbox='',$page='') {
  global $msg_javascript141,$msg_script66,$SETTINGS,$msg_script68;
  $preview = '<a class="preview" href="#" onclick="mc_loadPreviewWindow(\''.$textbox.'\',\''.$page.'\');return false" title="'.mc_cleanDataEnt($msg_script68).'">'.mc_cleanDataEnt($msg_script68).'</a>';
  if ($SETTINGS->enableBBCode=='yes') {
    if ($internal) {
      return '<span class="bbCode"><a href="?bbCode=int" title="'.mc_cleanDataEnt($msg_script66).'">'.mc_cleanDataEnt($msg_script66).'</a>'.$preview.'</span>';
    } else {
      return '<span class="bbCode"><a href="?bbCode=yes" onclick="mc_Window(this.href,\''.BBCODE_WINDOW_HEIGHT.'\',\''.BBCODE_WINDOW_WIDTH.'\',this.title);return false;" title="'.mc_cleanDataEnt($msg_script66).'">'.mc_cleanDataEnt($msg_script66).'</a>'.$preview.'</span>';
    }
  } else {
    return ($preview ? '<span class="bbCode">'.$preview.'</span>' : '');
  }
}

// Payment method name..
function mc_paymentMethodName($method) {
  global $msg_admin_global,$mcSystemPaymentMethods,$msg_admin_global2;
  switch($method) {
    case 'free':
    return $msg_admin_global2;
    break;
    default:
    return (isset($mcSystemPaymentMethods[$method]) ? $mcSystemPaymentMethods[$method]['lang'] : $msg_admin_global);
    break;
  }
}

// Check for new version..
function mc_softwareVersionCheck() {
  global $SETTINGS;
  $url = 'http://www.maianscriptworld.co.uk/version-check.php?id=11';
  if (function_exists('curl_init')) {
    $ch = @curl_init();
    @curl_setopt($ch,CURLOPT_URL,$url);
    @curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
    $result = @curl_exec($ch);
    @curl_close ($ch);
    if ($result) {
      if ($result!=$SETTINGS->softwareVersion) {
        echo 'Installed Version: '.$SETTINGS->softwareVersion.mc_defineNewline();
        echo 'Current Version: '.$result.mc_defineNewline().mc_defineNewline();
        echo 'Your version is out of date.'.mc_defineNewline().mc_defineNewline();
        echo 'Download new version at:'.mc_defineNewline();
        echo 'www.maiancart.com';
        // Show message for beta releases..
        if (mc_ionCubeLock()=='unlocked'){
          $beta  = mc_checkBetaVersion();
          $bv    = mc_getBetaVersion();
          if ($beta=='yes') {
            echo mc_defineNewline().mc_defineNewline();
            echo '(Ignore check. Using beta version: '.$bv.')';
          }
        }
        exit;
      } else {
        echo 'Current Version: '.$SETTINGS->softwareVersion.mc_defineNewline().mc_defineNewline().'You are currently using the latest version';
        exit;
      }
      exit;
    }
  } else {
    if (@ini_get('allow_url_fopen') == '1') {
      $result = @file_get_contents($url);
      if ($result) {
        if ($result!=$SETTINGS->softwareVersion) {
          echo 'Installed Version: '.$SETTINGS->softwareVersion.mc_defineNewline();
          echo 'Current Version: '.$result.mc_defineNewline().mc_defineNewline();
          echo 'Your version is out of date.'.mc_defineNewline().mc_defineNewline();
          echo 'Download new version at:'.mc_defineNewline();
          echo 'www.maiancart.com';
          // Show message for beta releases..
          if (mc_ionCubeLock()=='unlocked'){
            $beta  = mc_checkBetaVersion();
            $bv    = mc_getBetaVersion();
            if ($beta=='yes') {
              echo mc_defineNewline().mc_defineNewline();
              echo '(Ignore check. Using beta version: '.$bv.')';
            }
          }
          exit;
        } else {
          echo 'Current Version: '.$SETTINGS->softwareVersion.mc_defineNewline().mc_defineNewline().'You are currently using the latest version';
          exit;
        }
        exit;
      }
    }
  }
  echo 'Server check functions not available.'.mc_defineNewline().mc_defineNewline();
  echo 'Please visit maiancart.com to check for updates';
  exit;
}

// Restriction limit redirect..
function mc_restrictionLimitRedirect() {
  header ("Location: index.php?restriction=yes");
  exit;
}

// Get product display image..
function storeProductImg($id,$PRODUCTS,$link=true,$giftImg='') {
  global $SETTINGS;
  // Type won`t exist on add screen..
  if (isset($PRODUCTS->productType) && $PRODUCTS->productType=='virtual') {
    $pic = '<img src="templates/images/no-product-image.gif" alt="'.mc_cleanDataEnt($PRODUCTS->pName).'" title="'.mc_cleanDataEnt($PRODUCTS->pName).'" />';
	if ($giftImg && file_exists($SETTINGS->serverPath.'/'.PRODUCTS_FOLDER.'/'.$giftImg)) {
	  $pic = '<img src="'.$SETTINGS->ifolder.'/'.PRODUCTS_FOLDER.'/'.$giftImg.'" alt="'.mc_cleanDataEnt($PRODUCTS->pName).'" title="'.mc_cleanDataEnt($PRODUCTS->pName).'" />';
	}
  } else {
    $IMG = mc_getTableData('pictures','product_id',$id,'ORDER BY displayImg,id');
    $pic = '<img src="templates/images/no-product-image.gif" alt="'.mc_cleanDataEnt($PRODUCTS->pName).'" title="'.mc_cleanDataEnt($PRODUCTS->pName).'" />';
    if (isset($IMG->id)) {
      $ops = (isset($IMG->remoteServer) ? $IMG->remoteServer : 'no');
      switch ($ops) {
        case 'yes':
        $pic = ($link ? '<a onclick="jQuery(this).colorbox({title: \'&nbsp;\'})" href="'.$IMG->remoteImg.'" >' : '').'<img src="'.($IMG->remoteThumb ? $IMG->remoteThumb : $IMG->remoteImg).'" alt="'.mc_cleanDataEnt($PRODUCTS->pName).'" title="'.mc_cleanDataEnt($PRODUCTS->pName).'" />'.($link ? '</a>' : '');
        break;
        default:
	    if (file_exists($SETTINGS->serverPath.'/'.PRODUCTS_FOLDER.'/'.($IMG->folder ? mc_imageDisplayPath($IMG->folder).'/' : '').$IMG->picture_path) &&
            file_exists($SETTINGS->serverPath.'/'.PRODUCTS_FOLDER.'/'.($IMG->folder ? mc_imageDisplayPath($IMG->folder).'/' : '').$IMG->thumb_path)) {
          $pic = ($link ? '<a onclick="jQuery(this).colorbox({title: \'&nbsp;\'})" href="'.$SETTINGS->ifolder.'/'.PRODUCTS_FOLDER.'/'.($IMG->folder ? mc_imageDisplayPath($IMG->folder).'/' : '').$IMG->picture_path.'" >' : '').'<img src="'.$SETTINGS->ifolder.'/'.PRODUCTS_FOLDER.'/'.($IMG->folder ? mc_imageDisplayPath($IMG->folder).'/' : '').$IMG->thumb_path.'" alt="'.mc_cleanDataEnt($PRODUCTS->pName).'" title="'.mc_cleanDataEnt($PRODUCTS->pName).'" />'.($link ? '</a>' : '');
        }
        break;
      }
    }
  }
  return $pic;
}

// Table truncation routine..
function tableTruncationRoutine($tables=array()) {
  if (!empty($tables)) {
    foreach ($tables AS $t) {
      if (mc_rowCount($t)==0) {
        mysql_query("TRUNCATE TABLE ".DB_PREFIX.$t)
        or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
      }
    }
  }
}

// Get tare weight..
function getTareWeight($weight,$service,$multiple=array()) {
  if (isset($multiple[0],$multiple[1])) {
  $query   = mysql_query("SELECT * FROM `".DB_PREFIX."tare`
             WHERE `rWeightFrom`             <= $multiple[0]
             AND `rWeightTo`                 >= $multiple[1]
             AND `rService`                   = '{$service}'
             LIMIT 1
             ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  } else {
  $query   = mysql_query("SELECT * FROM `".DB_PREFIX."tare`
             WHERE `rWeightFrom`             <= $weight
             AND `rWeightTo`                 >= $weight
             AND `rService`                   = '{$service}'
             LIMIT 1
             ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  }
  $TARE = mysql_fetch_object($query);
  if (isset($TARE->id)) {
    return array('yes',$TARE->rCost);
  }
  return array('no','0.00');
}

// Enter dates in box to correct format..
function enterDatesBox($date) {
  global $SETTINGS;
  if ($date=='') {
    return '';
  }
  switch ($SETTINGS->jsDateFormat) {
    case 'DD-MM-YYYY':
    $tdate = date('d-m-Y',strtotime($date));
    break;
    case 'DD/MM/YYYY':
    $tdate = date('d/m/Y',strtotime($date));
    break;
    case 'YYYY-MM-DD':
    $tdate = $date;
    break;
    case 'YYYY/MM/DD':
    $tdate = date('Y/m/d',strtotime($date));
    break;
    case 'MM-DD-YYYY':
    $tdate = date('m-d-Y',strtotime($date));
    break;
    case 'MM/DD/YYYY':
    $tdate = date('m/d/Y',strtotime($date));
    break;
  }
  return $tdate;
}

function clearImportFolder() {
  $dir = opendir(PATH.'import');
  while (false!==($read=readdir($dir))) {
    if (!in_array($read,array('.','..','index.html','index.htm','.htaccess'))) {
      @unlink(PATH.'import/'.$read);
    }
  }
  closedir($dir);
}

function skipLogUsers() {
  $skip = array();
  if (ENTRY_LOG_SKIP_USERS) {
    if (strpos(ENTRY_LOG_SKIP_USERS,',')!==FALSE) {
      $skip = array_map('trim',explode(',',strtolower(ENTRY_LOG_SKIP_USERS)));
    } else {
      $skip[] = strtolower(ENTRY_LOG_SKIP_USERS);
    }
  }
  return $skip;
}

function deletePermissions() {
  if (file_exists(PATH.'control/access.inc.php') && !in_array(PATH.'control/access.inc.php',get_included_files())) {
    include_once(PATH.'control/access.inc.php');
  }
  if (defined('USERNAME') && defined('PASSWORD') && isset($_SESSION[mc_encrypt(SECRET_KEY).'_global_user']) && 
      isset($_SESSION[mc_encrypt(SECRET_KEY).'_loggedInAs']) &&
      $_SESSION[mc_encrypt(SECRET_KEY).'_loggedInAs']==USERNAME &&
      $_SESSION[mc_encrypt(SECRET_KEY).'_global_user']==mc_encrypt(SECRET_KEY.mc_encrypt('gl0bal'))) {
    return 'yes';
  } else {
    if (isset($_SESSION[mc_encrypt(SECRET_KEY).'_del_priv']) && in_array($_SESSION[mc_encrypt(SECRET_KEY).'_del_priv'],array('yes','no'))) {
      return $_SESSION[mc_encrypt(SECRET_KEY).'_del_priv'];
    }
  }  
  return 'no';  
}

function pagePermissions($thisAccessPage,$header=true) {
  global $sysCartUser;
  if (isset($sysCartUser[1]) && $sysCartUser[1]=='restricted') {
    if (!in_array($thisAccessPage,$sysCartUser[3]) || $sysCartUser[3]=='noaccess') {
	  if ($header) {
        header('HTTP/1.0 403 Forbidden');
        header('Content-type: text/html; charset=utf-8');
        echo '<h1>Permission Denied</h1>';
        exit;
	  } else {
	    return 'no';
	  }
    }
  }
  return 'yes';
}

function getUser() {
  if (file_exists(PATH.'control/access.inc.php') && !in_array(PATH.'control/access.inc.php',get_included_files())) {
    include_once(PATH.'control/access.inc.php');
  }
  $user = array();
  // Check cookie..
  if (isset($_COOKIE[mc_encrypt(SECRET_KEY.DB_NAME)]) && !isset($_SESSION[mc_encrypt(SECRET_KEY).'_loggedInAs'])) {
    $a = unserialize($_COOKIE[mc_encrypt(SECRET_KEY.DB_NAME)]);
    foreach ($a AS $k => $v) {
      $_SESSION[$k] = $v;
    } 
  }
  if (defined('USERNAME') && defined('PASSWORD') &&
      isset($_SESSION[mc_encrypt(SECRET_KEY).'_loggedInAs']) && 
      $_SESSION[mc_encrypt(SECRET_KEY).'_loggedInAs']==USERNAME && 
      isset($_SESSION[mc_encrypt(SECRET_KEY).'_global_user']) &&
      $_SESSION[mc_encrypt(SECRET_KEY).'_global_user']==mc_encrypt(SECRET_KEY.mc_encrypt('gl0bal'))) {
      $user[0]  = USERNAME;
      $user[1]  = 'global';
      $user[2]  = '';
      $user[3]  = array();
      $user[4]  = '';
  } else {
    if (isset($_SESSION[mc_encrypt(SECRET_KEY).'_loggedInAs']) &&
        isset($_SESSION[mc_encrypt(SECRET_KEY).'_user_type']) &&
        in_array($_SESSION[mc_encrypt(SECRET_KEY).'_user_type'],array('admin','restricted')) &&
        isset($_SESSION[mc_encrypt(SECRET_KEY).'_del_priv']) &&
        in_array($_SESSION[mc_encrypt(SECRET_KEY).'_del_priv'],array('yes','no')) &&
        isset($_SESSION[mc_encrypt(SECRET_KEY).'_accessPages'])) {
      $user[0]  = $_SESSION[mc_encrypt(SECRET_KEY).'_loggedInAs'];
      $user[1]  = $_SESSION[mc_encrypt(SECRET_KEY).'_user_type'];
      $user[2]  = $_SESSION[mc_encrypt(SECRET_KEY).'_del_priv'];
      $user[3]  = $_SESSION[mc_encrypt(SECRET_KEY).'_accessPages'];
      $user[4]  = $_SESSION[mc_encrypt(SECRET_KEY).'lastLoggedInTime'];
    }
  }
  return $user;
}

function delPrivileges() {
  global $sysCartUser;
  if (isset($sysCartUser[1]) && $sysCartUser[1]=='global') {
    return 'yes';
  }
  if (isset($sysCartUser[2]) && $sysCartUser[2]=='yes') {
    return 'yes';
  }
  return 'no';
}

function isWebmasterLoggedIn($user,$login=false) {
  if (!$login) {
    if (!isset($user[0],$user[1],$user[2],$user[3])) {
      header("Location: index.php?p=login");
      exit;
    }
  } else {
    if (isset($user[0],$user[1],$user[2],$user[3])) {
      header("Location: index.php");
      exit;
    }
  }
}

function userManagementType($type) {
  global $msg_users7,$msg_users8;
  switch($type) {
    case 'admin':
    return $msg_users7;
    break;
    case 'restricted':
    return $msg_users8;
    break;
  }
}

function getDiscountType($discount) {
  global $msg_coupons23,$msg_coupons24;
  switch ($discount) {
    case 'freeshipping':
    return $msg_coupons23;
    break;
    case 'notax':
    return $msg_coupons24;
    break;
  }
}

// Get flat rate zones..
function getFlatRateZones($table='flat') {
  $zones = array();     
  $q_zon = mysql_query("SELECT `inZone` FROM `".DB_PREFIX.$table."`") 
           or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  while ($Z = mysql_fetch_object($q_zon)) {
    $zones[] = $Z->inZone; 
  }
  return $zones;
}

// Get offer count..
function getCatOfferCount($id) {
  $count = 0;
  $q_products = mysql_query("SELECT `".DB_PREFIX."products`.`id` AS `pid` FROM `".DB_PREFIX."products`
                LEFT JOIN `".DB_PREFIX."prod_category`
                ON `".DB_PREFIX."products`.`id`   = `".DB_PREFIX."prod_category`.`product`
                WHERE `category`                          = '$id'
                AND `pEnable`                             = 'yes'
                AND `pOffer`                              > 0
                GROUP BY `".DB_PREFIX."products`.`id`
                ORDER BY `pName`
                ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  while ($P = mysql_fetch_object($q_products)) {
    ++$count;        
  }
  return $count;
}

// Get categories for product..full links or id numbers..
function getProductCategories($id,$name=true) {
  $cats = array();
  $query = mysql_query("SELECT `catname`,`".DB_PREFIX."categories`.`id` AS `cid` FROM `".DB_PREFIX."categories`
           LEFT JOIN `".DB_PREFIX."prod_category`
           ON `".DB_PREFIX."categories`.`id`            = `".DB_PREFIX."prod_category`.`category`
           WHERE `".DB_PREFIX."prod_category`.`product` = '$id'
           AND `enCat`                                  = 'yes'
           ORDER BY `".DB_PREFIX."categories`.`catname`
           ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  while ($C = mysql_fetch_object($query)) {
    if ($name) {
      $cats[] = '<a href="?p=categories&amp;edit='.$C->cid.'" title="'.mc_cleanDataEnt($C->catname).'">'.mc_cleanData($C->catname).'</a>';
    } else {
      $cats[] = $C->cid;
    }
  }
  return (!empty($cats) ? ($name ? implode(', ',$cats) : $cats) : '');
}

// Get product images folder..
function getProductImagesFolder($product) {
  $PROD  = mc_getTableData('products','id',$product);
  $FOLD  = mc_getTableData('categories','id',$PROD->pCat);
  return (isset($FOLD->catFolder) && $FOLD->catFolder ? $FOLD->catFolder : 'products');
}

// Sale gift certs..
function mc_saleGiftCerts($sale,$purchase) {
  global $msg_invoice37;
  $att = '';
  $query = mysql_query("SELECT * FROM `".DB_PREFIX."giftcodes`
           WHERE `saleID`    = '$sale'
           AND `purchaseID`  = '$purchase'
           ORDER BY `id`
		   LIMIT 1
           ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  if (mysql_num_rows($query)>0) {
    $att  = '<span class="saleAttributes">'.mc_defineNewline();
    $GC   = mysql_fetch_object($query);
    $att .= '<span class="attribute">'.str_replace(array('{name}','{to_name}'),array(mc_cleanDataEnt($GC->from_name),mc_cleanDataEnt($GC->to_name)),$msg_invoice37).'</span>'.mc_defineNewline();
    $att .= '</span>'.mc_defineNewline();
  }
  return mc_defineNewline().trim($att);
}

// Sale attribute purchases..
function mc_saleAttributes($sale,$purchase,$product,$slip=false,$p_total=0) {
  global $msg_viewsale87,$msg_sales42;
  $att = '';
  $query = mysql_query("SELECT * FROM `".DB_PREFIX."purch_atts`
           WHERE `saleID`    = '$sale'
           AND `purchaseID`  = '$purchase'
           AND `productID`   = '$product'
           ORDER BY `id`
           ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  if (mysql_num_rows($query)>0) {
  $att = '<span class="saleAttributes">'.mc_defineNewline();
  while ($ATTRIBUTES = mysql_fetch_object($query)) {
    if (!$slip) {
      $att .= '<span class="attribute">'.mc_cleanDataEnt($ATTRIBUTES->attrName).($ATTRIBUTES->addCost>0 ? ' (+'.mc_currencyFormat(mc_formatPrice($ATTRIBUTES->addCost)).')' : '').'</span>'.mc_defineNewline();
    } else {
      $att .= '<span class="attribute">+ '.mc_cleanDataEnt($ATTRIBUTES->attrName).'</span>'.mc_defineNewline();
    }
  }
  if ($p_total>0) {
    $att .= '<span class="attribute">'.$msg_viewsale87.' (+'.mc_currencyFormat(mc_formatPrice($p_total)).') '.str_replace('{id}',$sale,$msg_sales42).'</span>'.mc_defineNewline();
  }
  $att .= '</span>'.mc_defineNewline();
  } else {
    // If no attributes, but personalisation, show separately..
    if ($p_total>0) {
      $att  = '<span class="saleAttributes">'.mc_defineNewline();
      $att .= '<span class="attribute">'.$msg_viewsale87.' (+'.mc_currencyFormat(mc_formatPrice($p_total)).') '.str_replace('{id}',$sale,$msg_sales42).'</span>'.mc_defineNewline();
      $att .= '</span>'.mc_defineNewline();
    }
  }
  return mc_defineNewline().trim($att);
}

// Get stat counts..
function getStatusStatCount($status) {
  global $fromDate,$toDate,$cat;
  $q_cnt = mysql_query("SELECT count(*) AS `p_count` FROM `".DB_PREFIX."sales`
           LEFT JOIN `".DB_PREFIX."purchases`
           ON `".DB_PREFIX."sales`.`id`                    = `".DB_PREFIX."purchases`.`saleID`
           WHERE `paymentStatus`                           = '$status'
           AND `".DB_PREFIX."purchases`.`purchaseDate`     BETWEEN '".mc_convertCalToSQLFormat($fromDate)."' AND '".mc_convertCalToSQLFormat($toDate)."'
           AND `".DB_PREFIX."sales`.`saleConfirmation`     = 'yes'
           AND `".DB_PREFIX."purchases`.`saleConfirmation` = 'yes'
           ".($cat>0 ? 'AND `categoryID` = \''.$cat.'\'' : '')."
           ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  $CNT = mysql_fetch_object($q_cnt);
  return (isset($CNT->p_count) && $CNT->p_count>0 ? number_format($CNT->p_count) : 0);
}

// Get category..
function getCategoryName($id) {
  $S = mc_getTableData('categories','id',$id);
  return (isset($S->catname) ? mc_cleanData($S->catname) : '');
}

// Get shipping area..
function getShippingArea($id) {
  $A = mc_getTableData('zone_areas','id',$id);
  return (isset($A->areaName) ? mc_cleanData($A->areaName) : '');
}

// Adjust text for sale status..
function statusText($status) {
  global $msg_script26,$msg_script27,$msg_script28,$msg_script63,$msg_script64,$msg_script74;
  if (is_numeric($status)) {
    $STAT = mc_getTableData('paystatuses','id',$status);
    return (isset($STAT->statname) ? mc_cleanData($STAT->statname) : $msg_script29);
  } else { 
    switch ($status) {
      case 'completed':
      return $msg_script26;
      break;
      case 'refund':
      return $msg_script28;
      break;
      case 'pending':
      return $msg_script27;
      break;
      case 'cancelled':
      return $msg_script63;
      break;
      case 'despatched':
      return $msg_script64;
      break;
      case 'shipping':
      return $msg_script74;
      break;
      default:
      return 'N/A';
      break;
    }
  }
}

// Get physical/download goods count..
function physDownCount($field) {
  if ($field=='none') {
    return '0';
  } else {
    $sales = array_map('trim',explode(',',$field));
    return count($sales);
  }
}

// Get first product..
function getFirstProduct() {
  $query = mysql_query("SELECT * FROM `".DB_PREFIX."products` ORDER BY `id` LIMIT 1") 
           or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  $row = mysql_fetch_object($query);
  return (isset($row->id) ? $row->id : 0);
}

// Clean prices..remove commas..
function cleanInsertionPrice($price) {
  $price = str_replace(',','',$price);
  return mc_formatPrice($price);
}

// Rate cleaner..strip percentage symbols..
function rateCleaner($rate) {
  $rate = str_replace(array('%'),array(),$rate);
  return $rate;
}

// Server path to root folder..
function uploadServerPath() {
  global $SETTINGS;
  if (!is_dir($SETTINGS->serverPath)) {
    die('The following is <b>NOT</b> a valid server path for your installation: "'.$SETTINGS->serverPath.'". Please check and update your <a href="?p=settings">settings</a>.');
  }
  return $SETTINGS->serverPath.'/'.PRODUCTS_FOLDER.'/';
}

// Get countries..
function loadCountries($who='no',$id='',$edit=false) {
  global $msg_countries17;
  $ct    = array();
  if ($id=='blank') {
    return $ct;
  }
  $q_cnt = mysql_query("SELECT * FROM `".DB_PREFIX."countries`
           WHERE `enCountry` = '".$who."' 
           ORDER BY `cName`
		   ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  while ($COUNTRIES = mysql_fetch_object($q_cnt)) {
    if ($edit) {
      $ct[] = '<input type="checkbox" onclick="changeButtonCount(this.form,\'single\')" name="'.$who.'[]" value="'.$COUNTRIES->id.'" /> <a title="'.mc_cleanDataEnt($msg_countries17.': '.$COUNTRIES->cName).'" class="edit_country" href="?p=countries&amp;edit='.$COUNTRIES->id.'">'.mc_cleanDataEnt($COUNTRIES->cName).'</a>'.mc_defineNewline();
    } else {
      $ct[] = '<input type="checkbox" name="'.$who.'[]" value="'.$COUNTRIES->id.'" /> '.mc_cleanDataEnt($COUNTRIES->cName).mc_defineNewline();
    }
  }
  return $ct;
}

// Display box if action is done..
function actionCompleted($text) {
  global $msg_script8;
  if (!ENABLE_SYSTEM_MESSAGES) {
    return '';
  }
  return '
  <div id="actionComplete">
    <p>'.$text.' (<a href="#" onclick="closeThisDiv(\'actionComplete\');return false" title="'.mc_cleanDataEnt($msg_script8).'">'.$msg_script8.'</a>)</p>
  </div>
  ';
}

// Display box if action is done..for errors..
function actionCompletedError($text) {
  global $msg_script8;
  if (!ENABLE_SYSTEM_MESSAGES) {
    return '';
  }
  return '
  <div id="actionCompleteError">
    <p>'.$text.' (<a href="#" onclick="closeThisDiv(\'actionCompleteError\');return false" title="'.mc_cleanDataEnt($msg_script8).'">'.$msg_script8.'</a>)</p>
  </div>
  ';
}

// Display box if action is done for products..
function actionCompletedProducts($text,$id) {
  global $msg_script8,$msg_productadd22,$msg_productadd23,$msg_productadd24,$msg_productadd52,
         $msg_productadd27,$msg_productadd28,$msg_productadd47,$msg_productadd48,$msg_productadd51;
  if (!ENABLE_SYSTEM_MESSAGES) {
    return '';
  }
  return '
  <div id="actionComplete">
    <p>'.$text.' (<a href="#" onclick="closeThisDiv(\'actionComplete\');return false" title="'.mc_cleanDataEnt($msg_script8).'">'.$msg_script8.'</a>)</p>
    <div class="menuBar">
      <ul>
        <li class="start">'.$msg_productadd52.':</li>
        <li><a href="?p=add-product&amp;edit='.$id.'" title="'.mc_cleanDataEnt($msg_productadd22).'">'.$msg_productadd22.'</a>&nbsp;&nbsp;&nbsp;/ </li>
        <li><a href="?p=add-product&amp;copy='.$id.'" title="'.mc_cleanDataEnt($msg_productadd23).'">'.$msg_productadd23.'</a>&nbsp;&nbsp;&nbsp;/ </li>
        <li><a href="?p=product-attributes&amp;product='.$id.'" title="'.mc_cleanDataEnt($msg_productadd28).'">'.$msg_productadd28.'</a>&nbsp;&nbsp;&nbsp;/ </li>
        <li><a href="?p=product-pictures&amp;product='.$id.'" title="'.mc_cleanDataEnt($msg_productadd27).'">'.$msg_productadd27.'</a>&nbsp;&nbsp;&nbsp;/ </li>
        <li><a href="?p=product-related&amp;product='.$id.'" title="'.mc_cleanDataEnt($msg_productadd47).'">'.$msg_productadd47.'</a>&nbsp;&nbsp;&nbsp;/ </li>
        <li><a href="?p=product-mp3&amp;product='.$id.'" title="'.mc_cleanDataEnt($msg_productadd48).'">'.$msg_productadd48.'</a>&nbsp;&nbsp;&nbsp;/ </li>
        <li><a href="?p=product-personalisation&amp;product='.$id.'" title="'.mc_cleanDataEnt($msg_productadd51).'">'.$msg_productadd51.'</a></li>
      </ul> 
      <br class="clear" />
    </div>
  </div>
  ';
}

?>
