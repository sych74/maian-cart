<?php

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  This File: product-csv.php
  Description: System File

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

if (!defined('PARENT')) {
  include(PATH.'control/modules/header/403.php');
}

if (isset($_POST['process'])) {
}
  
$pageTitle = $msg_productadd3.': '.$pageTitle;
  
include(PATH.'templates/header.php');
include(PATH.'templates/catalogue/product-csv.php');
include(PATH.'templates/footer.php');

?>
