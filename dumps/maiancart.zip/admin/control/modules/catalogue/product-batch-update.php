<?php

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  This File: product-batch-update.php
  Description: System File

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

if (!defined('PARENT')) {
  include(PATH.'control/modules/header/403.php');
}

// Load language file(s)..
include(MCLANG.'catalogue/product-batch-update.php');

// Upload CSV file and update products..
if (isset($_POST['process'])) {
  // Adjust time limit to help prevent timeout on large files..
  @ini_set('memory_limit', '100M');
  @set_time_limit(0); 
  // Refresh if no file was uploaded..
  if ($_FILES['file']['name']=='') {
    header("Location: index.php?p=product-batch-update");
    exit;
  }
  $lines  = ($_POST['lines'] ? str_replace(array('.',','),array(),mc_cleanData($_POST['lines'])) : '0');
  $del    = ($_POST['del'] ? mc_cleanData($_POST['del']) : ',');
  $enc    = ($_POST['enc'] ? mc_cleanData($_POST['enc']) : '"');
  $count  = $MCPROD->batchUpdateProductsFromCSV($lines,$del,$enc);
  $OK     = true;
}
  
$pageTitle  = mc_cleanDataEnt($msg_productmanage66).': '.$pageTitle;
  
include(PATH.'templates/header.php');
include(PATH.'templates/catalogue/product-batch-update.php');
include(PATH.'templates/footer.php');

?>
