<?php

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  This File: gift-certificates.php
  Description: System File

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

if (!defined('PARENT')) {
  include(PATH.'control/modules/header/403.php');
}

// Load language file(s)..
include(MCLANG.'catalogue/gift-certificates.php');

// Re-order..
if (isset($_GET['order'])) {
  $MCSYS->reOrderGiftCerts();
  exit;
}

// Gift cert info..
if (isset($_GET['viewGift'])) {
  // Update..
  if (isset($_POST['process'])) {
    $MCSYS->updateGiftCertInfo();
    $OK = true;
  }
  $GIFT = mc_getTableData('giftcodes','code',$_GET['viewGift']);
  include(PATH.'templates/windows/gift-certificate.php');
  exit;
}

// Gift cert info (initial sale)..
if (isset($_GET['viewSaleGift'])) {
  // Update..
  if (isset($_POST['process'])) {
    $MCSYS->updateGiftCertInfo();
    $OK = true;
  }
  include(PATH.'templates/windows/gift-certificate-sale.php');
  exit;
}

// Add discount coupon..
if (isset($_POST['process'])) {
  if ($_POST['name'] && $_POST['value']>0) {
    $MCSYS->addGiftCertificate();
    $OK = true;
  } else {
    header("Location: index.php?p=gift");
    exit;
  }
}
  
// Update discount coupon..
if (isset($_POST['update'])) {
  if ($_POST['name'] && $_POST['value']>0) {
    $MCSYS->updateGiftCertificate();
    $OK2 = true;
  } else {
    header("Location: index.php?p=gift");
    exit;
  }
}
  
// Delete discount coupon..
if (isset($_GET['del']) && $uDel=='yes') {
  $cnt = $MCSYS->deleteGiftCertificate();
  $OK3 = true;
}
  
$pageTitle     = ($cmd=='cert-report' ? mc_cleanDataEnt($msg_javascript29).' '.$msg_script12 : mc_cleanDataEnt($msg_header23)).': '.$pageTitle;
  
include(PATH.'templates/header.php');
include(PATH.'templates/catalogue/'.($cmd=='gift' ? 'gift-certificates' : 'gift-report').'.php');
include(PATH.'templates/footer.php');

?>
