<?php

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  This File: product-pictures.php
  Description: System File

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

if (!defined('PARENT')) {
  include(PATH.'control/modules/header/403.php');
}

// Load language file(s)..
include(MCLANG.'catalogue/product-pictures.php');
include(MCLANG.'catalogue/product-manage.php');
include(MCLANG.'shipping/shipping-rates.php');
include(MCLANG.'sales/sales-update.php');

// Create folder..
if (isset($_GET['create-folder'])) {
  // Remove any none alphanumeric characters from folder name. Keep numbers & letters only..
  $folder = preg_replace('/[^a-zA-Z0-9]+/','',$_GET['create-folder']);
  // Create folder..
  if ($folder) {
    if ($folder=='products') {
      $folder = 'products2';
    }
    $status = $MCCAT->createCategoryFolder($folder);
  }
  echo jsonHandler(
   array(
    'message' => 'create-folder-category',
    'status'  => $status,
    'error'   => $msg_javascript201,
    'ok'      => $msg_javascript154,
    'folder'  => ($folder ? $folder : 'none')
   )
  ); 
  exit;            
}
  
if (isset($_POST['process'])) {
  $run = $MCPROD->addProductPictures();
  if ($run>0) {
    $OK = true;
  } else {
    header("Location: index.php?p=product-pictures&product=".$_GET['product']);
    exit;
  }
}
  
if (isset($_GET['delete']) && $uDel=='yes') {
  $cnt = $MCPROD->deleteProductPicture();
  $OK2 = true;
}
  
if (isset($_POST['process_image'])) {
  $MCPROD->updateDisplayImage();
  $OK3 = true;
}
  
$pageTitle     = mc_cleanDataEnt($msg_javascript28).': '.$pageTitle;
$colorbox      = true;
$loadJQuery    = true;
$createFolder  = true;
  
include(PATH.'templates/header.php');
include(PATH.'templates/catalogue/product-pictures.php');
include(PATH.'templates/footer.php');

?>
