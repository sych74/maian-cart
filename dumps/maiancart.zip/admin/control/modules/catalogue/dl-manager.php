<?php

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  This File: dl-manager.php
  Description: System File

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

if (!defined('PARENT')) {
  include(PATH.'control/modules/header/403.php');
}

// Load language file(s)..
include(MCLANG.'catalogue/download-manager.php');

if (isset($_GET['loadElFinder'])) {
  include (PATH.'control/classes/elFinder.php');
  $opts         =  array(
  'root'        => $SETTINGS->globalDownloadPath.'/'.$SETTINGS->downloadFolder,
	'URL'         => $SETTINGS->ifolder,
	'rootAlias'   => mc_cleanDataEnt($SETTINGS->downloadFolder)
  );
  $ELFINDER  = new elFinder($opts); 
  $ELFINDER->run();
  exit;
}

$pageTitle     = mc_cleanDataEnt($msg_javascript398).': '.$pageTitle;
$loadElFinder  =  true;  
  
include(PATH.'templates/header.php');
include(PATH.'templates/catalogue/download-manager.php');
include(PATH.'templates/footer.php');

?>
