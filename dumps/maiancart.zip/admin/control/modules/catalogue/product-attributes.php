<?php

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  This File: product-attributes.php
  Description: System File

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

if (!defined('PARENT')) {
  include(PATH.'control/modules/header/403.php');
}

// Load language file(s)..
include(MCLANG.'catalogue/product-pictures.php');
include(MCLANG.'catalogue/product-manage.php');
include(MCLANG.'catalogue/product-attributes.php');
include(MCLANG.'catalogue/product-related.php');
include(MCLANG.'shipping/shipping-rates.php');
include(MCLANG.'sales/sales-view.php');

// Copy attributes..
if ($cmd=='copy-attributes') {
  if (isset($_POST['process']) && !empty($_POST['product'])) {
    $MCPROD->copyAttributes();
    $OK = true;
  }
  include(PATH.'templates/windows/copy-attributes.php');
  exit;
}

// Add New Group..
if (isset($_POST['add_new_group'])) {
  $MCPROD->addAttributeGroup();
  $OK4 = true;
}

// Add attributes..
if (isset($_POST['process'])) {
  $run = $MCPROD->addAttributes();
  if ($run>0) {
    $OK = true;
  }
}

// Update groups..
if (isset($_POST['update_groups'])) {
  $MCPROD->updateAttributeGroups();
  $OK5 = true;
}
  
// Update attributes..
if (isset($_POST['update'])) {
  $run = $MCPROD->addAttributes(true);
  $OK2 = true;
}
  
// Delete groups..
if (isset($_GET['del']) && $uDel=='yes') {
  $cnt = $MCPROD->deleteAttributeGroups();
  $OK3 = true;
}

// Delete attributes
if (isset($_GET['delattr']) && $uDel=='yes') {
  $cnt = $MCPROD->deleteAttributes();
  $OK6 = true;
}
  
$pageTitle     = mc_cleanDataEnt($msg_javascript54).': '.$pageTitle;
$loadJQuery    = true;
$loadGreyBox   = true;
  
include(PATH.'templates/header.php');
include(PATH.'templates/catalogue/product-attributes.php');
include(PATH.'templates/footer.php');

?>
