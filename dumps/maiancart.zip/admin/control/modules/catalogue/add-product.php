<?php

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  This File: add-product.php
  Description: System File

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

if (!defined('PARENT')) {
  include(PATH.'control/modules/header/403.php');
}

// Load language file(s)..
include(MCLANG.'catalogue/product-pictures.php');
include(MCLANG.'catalogue/product-manage.php');
include(MCLANG.'catalogue/product-pictures.php');
include(MCLANG.'sales/sales-update.php');

// Code check..
if (isset($_GET['codeCheck'])) {
  $CHECK = mc_getTableData('products','pCode',mc_safeImportString(trim($_GET['codeCheck'])),(isset($_GET['edit']) ? ' AND id != \''.(int)$_GET['edit'].'\'' : ''));
  echo (isset($CHECK->id) ? 'exists' : 'ok');
  exit;
}

// ISBN Lookup..
if (isset($_GET['isbnLookup'])) {
  $json = $ISBN->isbnLookup();
  echo jsonHandler(
   array(
    'name'       => $json[0],
    'short_desc' => $json[1],
    'full_desc'  => $json[2],
    'text'       => $json[3]
   )
  ); 
  exit;
}

// Batch update field selection..
if (isset($_GET['batchRoutines'])) {
  $data = explode('||',$_GET['batchRoutines']);
  if (!isset($_SESSION['batchFieldPrefs'])) {
    $_SESSION['batchFieldPrefs'] = array();
    if ($data[0]=='exclude') {
      $_SESSION['batchFieldPrefs'][] = $data[2];
    }
  } else {
    switch ($data[0]) {
      case 'include':
      if (in_array($data[2],$_SESSION['batchFieldPrefs'])) {
        // Flip array..
        $flip = array_flip($_SESSION['batchFieldPrefs']);
        // Remove key..
        unset($flip[$data[2]]);
        // Re-flip..
        $flip = array_flip($flip);
        // Update session array..
        $_SESSION['batchFieldPrefs'] = $flip;
      }
      break;
      case 'exclude':
      if (!in_array($data[2],$_SESSION['batchFieldPrefs'])) {
        $_SESSION['batchFieldPrefs'][] = $data[2];
      }
      break;
    }
  }
  echo $data[0];
  exit;
}

// Load local files..
if (isset($_GET['showLocalFiles'])) {
  // If list is cached, return cache list..
  if (file_exists(PATH.'import/mc_FileCache.cache')) {
    echo file_get_contents(PATH.'import/mc_FileCache.cache');
    exit;
  }
  $dString  = '';
  $options  = downloadDirScanner($SETTINGS->globalDownloadPath.'/'.$SETTINGS->downloadFolder.'/',
                                 $SETTINGS->globalDownloadPath.'/'.$SETTINGS->downloadFolder);
  if ($options) {
    $fp = @fopen(PATH.'import/mc_FileCache.cache', 'ab');
    if ($fp) {
      @fwrite($fp,'<option value="0">- - - - - - - - </option>'.mc_defineNewline().$options);
      @fclose($fp);
    }
    echo '<option value="0">- - - - - - - - </option>'.mc_defineNewline().$options;
  } else {
    echo 'ERR';
  }
  exit;
}

// Auto tags..
if (isset($_POST['create-tags'])) {
  // Generate tags..
  $tags  = array();
  $txt   = explode(' ',$_POST['create-tags']);
  $txt   = array_map('trim',$txt);
  if (!empty($txt)) {
    foreach ($txt AS $words) {
      // Skip anything not containing letters..
      if (preg_match('%^[A-Za-z]+$%', $words)) {
        // Remove trailing commas/periods from words..
        if (substr($words,-1)==',' || substr($words,-1)=='.') {
          $words = substr($words,0,-1);
        }
        if (AUTO_TAGS_TEXT_LIMIT>0) {
          if (strlen($words) >= AUTO_TAGS_TEXT_LIMIT) {
            $tags[] = (CAPITALISE_TAGS ? ucfirst(strtolower($words)) : strtolower($words));
          }
        } else {
          $tags[] = (CAPITALISE_TAGS ? ucfirst(strtolower($words)) : strtolower($words));
        }
      }
    }
  }
  // Remove duplicates..
  echo jsonHandler(
   array(
    'message' => 'auto-create_tags',
    'text'    => (!empty($tags) ? implode(', ',array_unique($tags)) : ' '),
    'field'   => mc_cleanDataEnt($_POST['field'])
   )
  ); 
  exit;
}
  
// Add product
if (isset($_POST['process'])) {
  if ($_POST['pName']) {
    $newProductID  = $MCPROD->addNewProduct();
    $OK            = true;
  }
}

// Batch update products..
if (isset($_POST['productIDs']) && isset($_POST['productsUpdated']) && $_POST['productsUpdated']>0) {
  $fields = $MCPROD->batchUpdateProducts();
  $OK3    = true;
}
  
// Update product..
if (isset($_POST['update'])) {
  if ($_POST['pName']) {
    $MCPROD->updateProduct();
    $OK2 = true;
  }
}
  
$pageTitle     = (isset($_GET['edit']) ? $msg_productadd15 : mc_cleanDataEnt($msg_javascript26)).': '.$pageTitle;
$loadJQuery    = true;
$loadCalendar  = true;
$createFolder  = true;
$loadGreyBox   = true;
  
include(PATH.'templates/header.php');
include(PATH.'templates/catalogue/product-add.php');
include(PATH.'templates/footer.php');

?>
