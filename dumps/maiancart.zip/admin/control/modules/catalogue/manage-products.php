<?php

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  This File: manage-products.php
  Description: System File

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

if (!defined('PARENT')) {
  include(PATH.'control/modules/header/403.php');
}

// Load language file(s)..
include(MCLANG.'catalogue/product-manage.php');

// Notes..
if (isset($_GET['notes'])) {
  // Update notes..
  if (isset($_POST['notes'])) {
    $MCPROD->updateProductNotes();
    echo $msg_productmanage64;
    exit;
  }
  include(PATH.'templates/windows/product-notes.php');
  exit;
}

// Enable/disable..
if (isset($_GET['changeStatus']) && is_numeric($_GET['changeStatus'])) {
  $P = mc_getTableData('products','id',$_GET['changeStatus']);
  switch ($P->pEnable) {
    case 'yes':
    $MCPROD->mc_changeProductStatus('no');
    echo jsonHandler(
     array(
      'status'    => $msg_productmanage23,
      'newstatus' => $msg_productmanage40.' '.$msg_productmanage23
     )
    ); 
    break;
    case 'no':
    $MCPROD->mc_changeProductStatus('yes');
    echo jsonHandler(
     array(
      'status'    => $msg_productmanage22,
      'newstatus' => $msg_productmanage40.' '.$msg_productmanage22
     )
    ); 
    break;
  }
  exit;
}

if (isset($_GET['delete'])) {
  $cnt = $MCPROD->deleteProduct();
  $OK  = true;
}
  
$pageTitle    = mc_cleanDataEnt($msg_javascript27).': '.$pageTitle;
$loadJQuery   = true;
$colorbox     = true;
$loadGreyBox  = true;
  
include(PATH.'templates/header.php');
include(PATH.'templates/catalogue/product-manage.php');
include(PATH.'templates/footer.php');

?>
