<?php

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  This File: product-export.php
  Description: System File

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

if (!defined('PARENT')) {
  include(PATH.'control/modules/header/403.php');
}

// Load language file(s)..
include(MCLANG.'catalogue/product-add.php');
include(MCLANG.'catalogue/product-export.php');
 
// Export products..  
if (isset($_POST['process'])) {
  @ini_set('memory_limit', '100M');
  @set_time_limit(0); 
  $return = $MCPROD->exportProductsToCSV();
}  
  
$pageTitle   = mc_cleanDataEnt($msg_productmanage59).': '.$pageTitle;
  
include(PATH.'templates/header.php');
include(PATH.'templates/catalogue/'.$cmd.'.php');
include(PATH.'templates/footer.php');

?>
