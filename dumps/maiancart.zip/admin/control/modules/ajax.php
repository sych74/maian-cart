<?php

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  This File: ajax.php
  Description: Aax Functions

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

if (!defined('PARENT')) {
  include(PATH.'control/modules/header/403.php');
}

if ($cmd=='switch') {
  include(MCLANG.'catalogue/product-import.php');
  $query = mysql_query("SELECT *,".DB_PREFIX."products.id AS pid FROM ".DB_PREFIX."products,".DB_PREFIX."prod_category
           WHERE category                = '".mc_digitSan($_GET['cat'])."'
           AND ".DB_PREFIX."products.id  = ".DB_PREFIX."prod_category.product
           AND pEnable                   = 'yes'
           GROUP BY product
           ORDER BY pName
           ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  while ($P = mysql_fetch_object($query)) {
    echo "obj.options[obj.options.length] = new Option('".str_replace(array("'","&amp;"),array("\'","&"),mc_cleanData($P->pName))."','".$P->pid."');".mc_defineNewline();
  }
  if (mysql_num_rows($query)==0) {
    echo "obj.options[obj.options.length] = new Option('".str_replace(array("'","&amp;"),array("\'","&"),mc_cleanData($msg_import52))."','0');".mc_defineNewline();
  }
}

if ($cmd=='brandlist') {
  include(MCLANG.'catalogue/brands.php');
  $query = mysql_query("SELECT * FROM ".DB_PREFIX."brands
           WHERE bCat   = '".mc_digitSan($_GET['cat'])."'
           AND enBrand  = 'yes'
           ORDER BY name
           ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
  echo "obj.options[obj.options.length] = new Option('$msg_brand12','0');".mc_defineNewline();
  while ($M = mysql_fetch_object($query)) {
    echo "obj.options[obj.options.length] = new Option('".str_replace(array("'","&amp;"),array("\'","&"),mc_cleanData($M->name))."','".$M->id."');".mc_defineNewline();
  }
  if (mysql_num_rows($query)==0) {
    echo "obj.options[obj.options.length] = new Option('".str_replace(array("'","&amp;"),array("\'","&"),mc_cleanData($msg_brand15))."','0');".mc_defineNewline();
  }
}

if ($cmd=='refresh-folders') {
  include(MCLANG.'sales/sales-update.php');
  echo "obj.options[obj.options.length] = new Option('attachments/{$_GET['folder']}','{$_GET['folder']}');".mc_defineNewline();
  echo "obj.options[obj.options.length] = new Option('$msg_salesupdate14','attachments');".mc_defineNewline();
  $dir = opendir(PATH.'attachments');
  while (false!==($read=readdir($dir))) {
    if (!in_array($read,array('.','..')) && is_dir(PATH.'attachments/'.$read) && $read!=$_GET['folder']) {
      echo "obj.options[obj.options.length] = new Option('attachments/$read','$read');".mc_defineNewline();
    }
  }
  closedir($dir);
}

if ($cmd=='refresh-folders-cats') {
  include(MCLANG.'catalogue/product-pictures.php');
  echo "obj.options[obj.options.length] = new Option('products/{$_GET['folder']}','{$_GET['folder']}');".mc_defineNewline();
  echo "obj.options[obj.options.length] = new Option('products/ $msg_productpictures12','products');".mc_defineNewline();
  $dir = opendir($SETTINGS->serverPath.'/'.PRODUCTS_FOLDER);
  while (false!==($read=readdir($dir))) {
    if (!in_array($read,array('.','..')) && is_dir($SETTINGS->serverPath.'/'.PRODUCTS_FOLDER.'/'.$read) && $read!=$_GET['folder']) {
      echo "obj.options[obj.options.length] = new Option('products/$read','$read');".mc_defineNewline();
    }
  }
  closedir($dir);
}

?>
