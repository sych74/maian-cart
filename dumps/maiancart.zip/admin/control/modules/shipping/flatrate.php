<?php

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  This File: flatrate.php
  Description: System File

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

if (!defined('PARENT')) {
  include(PATH.'control/modules/header/403.php');
}

// Load language file(s)..
include(MCLANG.'shipping/shipping-flatrate.php');

// Add rates..
if (isset($_POST['process'])) {
  $run = $MCSYS->addFlatRate();
  if ($run[0]>0 || $run[1]>0) {
    $OK = true;
  }
}
  
// Update rates..
if (isset($_POST['update'])) {
  $run = $MCSYS->updateFlatRate();
  if ($run>0) {
    $OK2 = true;
  }
}

// Batch update..
if (isset($_POST['enabdis'])) {
  $run = $MCSYS->batchUpdateRatesRoutine('flat');
  $OK2 = true;
}
  
// Delete rates..
if (isset($_GET['del']) && $uDel=='yes') {
  $cnt = $MCSYS->deleteFlatRate();
  $OK3 = true;
}
  
$pageTitle   = mc_cleanDataEnt($msg_javascript438).': '.$pageTitle;
$loadJQuery  = true;
  
include(PATH.'templates/header.php');
include(PATH.'templates/shipping/shipping-flatrate.php');
include(PATH.'templates/footer.php');

?>
