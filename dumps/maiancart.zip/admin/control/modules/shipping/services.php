<?php

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  This File: services.php
  Description: System File

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

if (!defined('PARENT')) {
  include(PATH.'control/modules/header/403.php');
}

// Load language file(s)..
include(MCLANG.'shipping/shipping-services.php');

// Add service..
if (isset($_POST['process'])) {
  $run = $MCSYS->addService();
  if ($run[0]>0 && $run[1]>0) {
    $OK = true;
  }
}
  
// Update service..
if (isset($_POST['update'])) {
  $run = $MCSYS->updateService();
  if ($run>0) {
    $OK2 = true;
  }
}
  
// Delete service..
if (isset($_GET['del']) && $uDel=='yes') {
  $cnt = $MCSYS->deleteService();
  $OK3 = true;
}
  
$pageTitle   = mc_cleanDataEnt($msg_javascript100).': '.$pageTitle;
$loadJQuery  = true;
  
include(PATH.'templates/header.php');
include(PATH.'templates/shipping/shipping-services.php');
include(PATH.'templates/footer.php');

?>
