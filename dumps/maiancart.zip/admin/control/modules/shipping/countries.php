<?php

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  This File: countries.php
  Description: System File

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

if (!defined('PARENT')) {
  include(PATH.'control/modules/header/403.php');
}

// Load language file(s)..
include(MCLANG.'shipping/shipping-countries.php');

// Add new countries..
if (isset($_POST['add_country'])) {
  $count = $MCSYS->addNewCountries();
  $OK2   = true;
}

// Edit country..
if (isset($_POST['update_country'])) {
  $MCSYS->updateCountry();
  $OK3   = true;
}

// Delete selected..
if (isset($_POST['deleteSelected']) && !empty($_POST['no']) && $uDel=='yes') {
  $count = $MCSYS->deleteCountries();
  $OK4   = true;
}

// Add countries..
if (isset($_POST['yes_go']) || isset($_POST['no_go']) && !isset($_POST['deleteSelected'])) {
  $MCSYS->updateCountries();
  $OK = true;
}
  
$pageTitle = mc_cleanDataEnt($msg_javascript31).': '.$pageTitle;
  
include(PATH.'templates/header.php');
include(PATH.'templates/shipping/shipping-countries.php');
include(PATH.'templates/footer.php');

?>
