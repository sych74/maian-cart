<?php

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  This File: itemrate.php
  Description: System File

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

if (!defined('PARENT')) {
  include(PATH.'control/modules/header/403.php');
}

// Load language file(s)..
include(MCLANG.'shipping/shipping-itemrate.php');

// Add rates..
if (isset($_POST['process'])) {
  $run = $MCSYS->addPerItemRate();
  if ($run[0]>0 || $run[1]>0) {
    $OK = true;
  }
}
  
// Update rates..
if (isset($_POST['update'])) {
  $run = $MCSYS->updatePerItemRate();
  if ($run>0) {
    $OK2 = true;
  }
}

// Batch update..
if (isset($_POST['enabdis'])) {
  $run = $MCSYS->batchUpdateRatesRoutine('per');
  $OK2 = true;
}
  
// Delete rates..
if (isset($_GET['del']) && $uDel=='yes') {
  $cnt = $MCSYS->deletePerItemRate();
  $OK3 = true;
}
  
$pageTitle   = mc_cleanDataEnt($msg_javascript577).': '.$pageTitle;
$loadJQuery  = true;
  
include(PATH.'templates/header.php');
include(PATH.'templates/shipping/shipping-itemrate.php');
include(PATH.'templates/footer.php');

?>
