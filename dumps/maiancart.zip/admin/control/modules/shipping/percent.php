<?php

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  This File: percent.php
  Description: System File

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

if (!defined('PARENT')) {
  include(PATH.'control/modules/header/403.php');
}

// Load language file(s)..
include(MCLANG.'shipping/shipping-percent.php');

// Add rates..
if (isset($_POST['process'])) {
  $cnt = $MCSYS->addPercentRate();
  if ($cnt>0) {
    $OK = true;
  }
}
  
// Update rates..
if (isset($_POST['update'])) {
  $run = $MCSYS->updatePercentRate();
  if ($run>0) {
    $OK2 = true;
  }
}

// Batch update..
if (isset($_POST['enabdis'])) {
  $run = $MCSYS->batchUpdateRatesRoutine('percent');
  $OK2 = true;
}
  
// Delete rates..
if (isset($_GET['del']) && $uDel=='yes') {
  $cnt = $MCSYS->deletePercentRate();
  $OK3 = true;
}
  
$pageTitle   = mc_cleanDataEnt($msg_javascript439).': '.$pageTitle;
$loadJQuery  = true;
  
include(PATH.'templates/header.php');
include(PATH.'templates/shipping/shipping-percent.php');
include(PATH.'templates/footer.php');

?>
