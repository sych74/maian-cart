<?php

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  This File: main.php
  Description: System File

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

if (!defined('PARENT')) {
  include(PATH.'control/modules/header/403.php');
}

// Load language file(s)..
include(MCLANG.'sales/view-sales.php');

// Preview text..
if (isset($_GET['prevTxtBox'])) {
  if (isset($_POST['boxdata'])) {
    $_SESSION['previewBoxText'] = mc_cleanData($_POST['boxdata']);
    echo mc_cleanDataEnt($msg_script68).'|||||'.mc_cleanDataEnt($msg_script8);
  } else {
    switch($_GET['prevTxtBox']) {
      case 'newsletter':
      include(PATH.'templates/windows/preview-newsletter.php');
      break;
      default:
      include(PATH.'templates/windows/preview.php');
      break;
    }
  }
  exit;
}

// BBCode window..
if (isset($_GET['bbCode'])) {
  include(PATH.'templates/windows/bbcode.php');
  exit;
}

// Version check..
if (isset($_GET['versionCheck'])) {
  mc_softwareVersionCheck();
}

// Display message if restriction is reached..
if ($cmd=='main-stop' && LICENCE_VER=='locked') {
  $pageTitle = 'Free Version Restriction: '.$pageTitle;
  include(PATH.'templates/header.php');
  include(PATH.'control/modules/system/controller.php');
  include(PATH.'templates/footer.php');
  exit;
}

// Run some security checks..
$sec = array();
if (is_dir(REL_PATH.'install/') && DEV_STATUS=='OFF') {
  $sec[] = $msg_script16;
}
if (SECRET_KEY=='abc1234' && DEV_STATUS=='OFF') {
  $sec[] = $msg_script18;
}

$loadGreyBox  = true;
  
include(PATH.'templates/header.php');
include(PATH.'templates/system/main'.(isset($sysCartUser[1]) && $sysCartUser[1]=='restricted' ? '-restricted' : '').'.php');
include(PATH.'templates/footer.php');

?>
