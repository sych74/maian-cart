<?php

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  This File: currency-converter.php
  Description: System File

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

if (!defined('PARENT')) {
  include(PATH.'control/modules/header/403.php');
}

// Load language file(s)..
include(MCLANG.'system/currency-converter.php');

// Update currency converter..
if (isset($_POST['process'])) {
  $MCSYS->updateCurrencyConverter();
  $OK = true;
}

if (isset($_GET['processAuto'])) {
  $MCSYS->updateCurrencyConverter();
  $MCCRV->downloadExchangeRates();
  echo 'OK';
  exit;
}
  
$pageTitle = mc_cleanDataEnt($msg_javascript30).': '.$pageTitle;
$uiBlock   = true;

include(PATH.'templates/header.php');
include(PATH.'templates/system/currency-converter.php');
include(PATH.'templates/footer.php');

?>
