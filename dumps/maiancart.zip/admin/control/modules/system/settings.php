<?php

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  This File: settings.php
  Description: System File

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

if (!defined('PARENT')) {
  include(PATH.'control/modules/header/403.php');
}

include(MCLANG.'catalogue/categories.php');
include(MCLANG_REL.'header.php');

// Auto fill..
if (isset($_GET['autoFillPath'])) {
  echo substr(AUTO_FILL_PATH,0,-20);
  exit;
}

// Remove custom box..
if (isset($_GET['removeCustomBox'])) {
  $arr = array();
  // Loop and rebuild..
  for ($i=0; $i<count($_POST['box']); $i++) {
    if ($_POST['box'][$i]!=$_POST['del']) {
	  $arr[] = $_POST['marker'][$i];
	}
  }
  mysql_query("UPDATE `".DB_PREFIX."settings` SET `leftBoxCustom` = '".(!empty($arr) ? serialize($arr) : '')."'");
  echo '<span class="italics">'.$msg_settings282.'</span>';
  exit;
}

// Custom box info..
if (isset($_GET['updateCustomBoxes'])) {
  $arr   = ($SETTINGS->leftBoxCustom ? unserialize($SETTINGS->leftBoxCustom) : array());
  $arr[] = $_POST['boxdata'];
  $html  = '<p style="margin-bottom:5px" id="cus_box_'.$_POST['next'].'">
  <input type="hidden" name="cusBox[]" value="'.$_POST['next'].'" />
  <input type="hidden" name="marker[]" value="'.mc_cleanDataEnt($_POST['boxdata']).'" />
  <input type="text" name="pos[]" value="0" class="box" style="width:5%" /> '.$_POST['boxdata'].' [<a href="#" onclick="mc_removeCustomBox(\''.$_POST['next'].'\');return false">X</a>]
  </p>';
  mysql_query("UPDATE `".DB_PREFIX."settings` SET `leftBoxCustom` = '".serialize($arr)."'");
  echo trim($html);
  exit;
}

// Clear logo..
if (isset($_GET['removeLogo'])) {
  $MCSYS->resetStoreLogo();
  echo $msg_settings194;
  exit;
}

// Check..
if (isset($_GET['s']) && !in_array($_GET['s'],range(2,9))) {
  header("Location: index.php?p=settings");
  exit;
}

if (isset($_GET['s']) && $_GET['s']==4) {
  if (isset($_GET['reload']) && $_GET['reload']=='yes') {
    $id    = substr($_GET['pr'],strpos($_GET['pr'],'-')+1,strlen($_GET['pr']));
    $html  = '';
    $all   = '';
    $prod  = array();
    $vars  = array();
    $q_products = mysql_query("SELECT *,`".DB_PREFIX."products`.`id` AS `pid` 
                  FROM `".DB_PREFIX."products`
                  LEFT JOIN `".DB_PREFIX."prod_category`
                  ON `".DB_PREFIX."products`.`id`  = `".DB_PREFIX."prod_category`.`product`
                  WHERE `category`                 = '$id'
                  AND `pEnable`                    = 'yes'
                  GROUP BY `".DB_PREFIX."products`.`id`
                  ORDER BY `pName`
                  ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    while ($PR = mysql_fetch_object($q_products)) {
      $html .= '<b>'.$PR->pid.'</b> - '.mc_cleanData($PR->pName).'<br />';
    }
    echo ($html ? mc_cleanData($all.$html) : mc_cleanData($msg_settings210));
    exit;
  }
}

// Permissions..
if (isset($_GET['s']) && in_array($_GET['s'],range(1,9))) {
  pagePermissions('settings_'.$_GET['s']);
} else {
  pagePermissions('settings_1');
}

// Re-Order Banners..
if (isset($_GET['s']) && $_GET['s']=='9' && isset($_GET['order'])) {
  $MCSYS->reOrderBanners();
  exit;
}

// Add banners..
if (isset($_POST['process_banners'])) {
  $MCSYS->addBanners();
  $OK = true;
}

// Update banners..
if (isset($_POST['update_banners'])) {
  $MCSYS->updateBanners();
  $OK2 = true;
}

// Delete banner..
if (isset($_GET['del']) && is_numeric($_GET['del']) && $uDel=='yes') {
  $cnt = $MCSYS->deleteBanner();
  $OK4 = true;
}

// Update settings..
if (isset($_POST['process'])) {
  $MCSYS->updateSettings();
  $OK = true;
}
  
$pageTitle = mc_cleanDataEnt($msg_javascript106).': '.$pageTitle;
if (isset($_GET['s']) && in_array($_GET['s'],array(3,8))) {
  $loadCalendar  = true;
  $loadGreyBox   = true;
}
if (isset($_GET['s']) && in_array($_GET['s'],array(9))) {
  $colorbox      = true;
  $loadJQuery    = true;
}

include(PATH.'templates/header.php');
include(PATH.'templates/system/settings'.(isset($_GET['s']) ? $_GET['s'] : '').'.php');
include(PATH.'templates/footer.php');

?>
