<?php

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  This File: users.php
  Description: System File

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

if (!defined('PARENT')) {
  include(PATH.'control/modules/header/403.php');
}

// Load language file(s)..
include(MCLANG.'system/users.php');

// Permissions..
if (!isset($sysCartUser[1]) || (isset($sysCartUser[1]) && $sysCartUser[1]=='restricted')) {
  header('HTTP/1.0 403 Forbidden');
	header('Content-type: text/html; charset=utf-8');
  echo '<h1>Permission Denied</h1>';
  exit;
}

// Add user..
if (isset($_POST['process']) && $_POST['userName'] && $_POST['userPass']) {
  $MCSYS->addUser();
  $OK = true;
}
  
// Update user..
if (isset($_POST['update']) && $_POST['userName']) {
  $MCSYS->updateUser();
  $OK2 = true;
}
  
// Delete user..
if (isset($_GET['del']) && is_numeric($_GET['del']) && $uDel=='yes') {
  $cnt = $MCSYS->deleteUser();
  $OK3 = true;
}
  
$pageTitle     = mc_cleanDataEnt($msg_javascript254).': '.$pageTitle;
  
include(PATH.'templates/header.php');
include(PATH.'templates/system/users.php');
include(PATH.'templates/footer.php');

?>
