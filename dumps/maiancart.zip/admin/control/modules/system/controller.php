<?php

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  This File: controller.php
  Description: System File

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

if (!defined('PARENT')) {
  include(PATH.'control/modules/header/403.php');
}

// Restriction Message..
if (isset($_GET['restriction'])) {

?>
<div id="content">

  <div id="actionCompleteError" style="border:1px dashed #6b9fb3;background:#f8f8f8">
  
    <p style="text-align:right">Free Version Restriction</p>
  
  </div>

  <div>
  
  You have reached a free version restriction limit. A few restrictions are imposed in the free version of this system, which are detailed <a href="http://www.maiancart.com/features.html" onclick="window.open(this);return false">here</a>.<br /><br />
  If you would like to remove these restrictions, a commercial licence is required. Here are the main benefits of supporting this software:<br /><br />
  
  <ul style="list-style:none;margin:0;padding:0">
  
    <li style="text-indent:20px;line-height:25px;font-size:14px;text-transform:uppercase">@ FREE upgrades for life. You only pay once regardless of features in future versions.</li>
      
    <li style="text-indent:20px;line-height:25px;font-size:14px;text-transform:uppercase">@ All features unlocked &amp; unlimited.</li>
      
    <li style="text-indent:20px;line-height:25px;font-size:14px;text-transform:uppercase">@ Commercial upgrade also includes copyright removal.</li>
    
    <li style="text-indent:20px;line-height:25px;font-size:14px;text-transform:uppercase">@Notifications when new versions are released.</li>
      
    <li style="text-indent:20px;line-height:25px;font-size:14px;text-transform:uppercase">@ No subscriptions or recurring billing.</li>
    
  </ul> 
   
  <br />
  
  If this doesn`t interest you, you may continue to use this free version as long as you like. This message will keep appearing should you exceed any restrictions.<br /><br />
  
  To buy a commercial licence, click <a href="http://www.maiancart.com/purchase.html" onclick="window.open(this);return false">here</a>.<br /><br />
  
  Thank you.
  
  </div>

</div>
<?php
}

// Locked message..
if (isset($_GET['locked'])) {

?>
<div id="content">

  <div id="actionCompleteError" style="border:1px dashed #6b9fb3;background:#f8f8f8">
  
    <p style="background:url(templates/images/locked.png) no-repeat 0 50%;text-align:right">Software Auto Locked</p>
    
  </div>

  <div>
  
  This software has auto locked. This only happens when the database has been tampered with to exceed the free version restrictions. A few restrictions are imposed in the free version of this system, which are detailed <a href="http://www.maiancart.com/features.html" onclick="window.open(this);return false">here</a>.<br /><br />
  If you would like to remove these restrictions, a commercial licence is required. Here are the main benefits of supporting this software:<br /><br />
  
  <ul style="list-style:none;margin:0;padding:0">
  
    <li style="text-indent:20px;line-height:25px;font-size:14px;text-transform:uppercase">@ FREE upgrades for life. You only pay once regardless of features in future versions.</li>
      
    <li style="text-indent:20px;line-height:25px;font-size:14px;text-transform:uppercase">@ All features unlocked &amp; unlimited.</li>
      
    <li style="text-indent:20px;line-height:25px;font-size:14px;text-transform:uppercase">@ Commercial upgrade also includes copyright removal.</li>
    
    <li style="text-indent:20px;line-height:25px;font-size:14px;text-transform:uppercase">@Notifications when new versions are released.</li>
      
    <li style="text-indent:20px;line-height:25px;font-size:14px;text-transform:uppercase">@ No subscriptions or recurring billing.</li>
    
  </ul> 
   
  <br />
  
  If this doesn`t interest you, you may continue to use this free version so long as you reverse any manual database changes you made.<br /><br />
  
  <b>PLEASE REMOVE ANY MANUAL UPDATES TO YOUR DATABASE.</b><br /><br />
  
  To buy a commercial licence, click <a href="http://www.maiancart.com/purchase.html" onclick="window.open(this);return false">here</a>.<br /><br />
  
  Thank you.
  
  </div>

</div>
<?php
}
?>
