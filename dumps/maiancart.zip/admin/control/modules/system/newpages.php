<?php

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  This File: newpages.php
  Description: System File

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

if (!defined('PARENT')) {
  include(PATH.'control/modules/header/403.php');
}

// Load language file(s)..
include(MCLANG.'system/new-pages.php');
include(MCLANG.'catalogue/categories.php');

if (isset($_GET['urlSlug'])) {
  echo ($SETTINGS->en_modr=='no' || !ENABLE_SLUG_SUGGESTION ? 'NONE' : substr(mc_seoUrl(mc_cleanData($_POST['slug'])),0,250));
  exit;
}

if (isset($_GET['changeStatus'])) {
  $PG      = mc_getTableData('newpages','id',(int)$_GET['changeStatus']);
  $status  = (isset($PG->enabled) ? $PG->enabled : 'no');
  $name    = (isset($PG->pageName) ? '"'.$PG->pageName.'"'.mc_defineNewline().mc_defineNewline() : '');
  $msg     = $MCSYS->enableDisablePages($status);
  switch ($msg) {
    case 'yes':
    echo jsonHandler(
     array(
      'status' => $name.$msg_javascript369,
      'id'     => (int)$_GET['changeStatus'],
      'flag'   => 'page_enabled.gif'
     )
    );  
    break;
    case 'no':
    echo jsonHandler(
     array(
      'status' => $name.$msg_javascript368,
      'id'     => (int)$_GET['changeStatus'],
      'flag'   => 'page_disabled.gif'
     )
    );  
    break;
  }
  exit;
}

if (isset($_GET['order'])) {
  $MCSYS->reOrderNewPages();
  exit;
}

if (isset($_POST['process'])) {
  if ($_POST['pageName']) {
    $MCSYS->addNewWebPage();
    $OK = true;
  }
}
  
if (isset($_POST['update'])) {
  if ($_POST['pageName']) {
    $MCSYS->updateWebPage();
    $OK2 = true;
  }
}
  
if (isset($_GET['del']) && $uDel=='yes') {
  $cnt = $MCSYS->deleteWebPage();
  $OK3 = true;
}
  
$pageTitle   = mc_cleanDataEnt($msg_javascript198).': '.$pageTitle;
$loadJQuery  = true;
$loadGreyBox = true;
  
include(PATH.'templates/header.php');
include(PATH.'templates/system/new-pages.php');
include(PATH.'templates/footer.php');

?>
