<?php

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  This File: sales-revenue.php
  Description: System File

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

if (!defined('PARENT')) {
  include(PATH.'control/modules/header/403.php');
}

// Load language file(s)..
include(MCLANG.'sales/sales-revenue.php');
include(MCLANG.'sales/sales-search.php');
include(MCLANG.'catalogue/product-manage.php');

// Export hits..
if (isset($_GET['export'])) {
  $MCSALE->exportRevenue();
}
  
$pageTitle     = mc_cleanDataEnt($msg_javascript425).': '.$pageTitle;
$loadCalendar  = true; 
  
include(PATH.'templates/header.php');
include(PATH.'templates/sales/sales-revenue.php');
include(PATH.'templates/footer.php');

?>
