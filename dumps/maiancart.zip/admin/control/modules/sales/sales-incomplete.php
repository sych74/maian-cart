<?php

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  This File: sales-incomplete.php
  Description: System File

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

if (!defined('PARENT')) {
  include(PATH.'control/modules/header/403.php');
}

// Load language file(s)..
include(MCLANG.'sales/view-sales.php');
include(MCLANG.'sales/sales-view.php');
include(MCLANG.'sales/sales-incomplete.php');
include(MCLANG.'catalogue/product-manage.php');

if (isset($_GET['ordered'])) {
  include(PATH.'templates/windows/sale-products.php');
  exit;
}

if (isset($_GET['delete'])) {
  $cnt  = $MCSALE->deleteOrderSale();
  $OK   = true;
}
  
$pageTitle    = mc_cleanDataEnt($msg_header21).': '.$pageTitle;
$loadGreyBox  = true;
  
include(PATH.'templates/header.php');
include(PATH.'templates/sales/sales-incomplete.php');
include(PATH.'templates/footer.php');

?>
