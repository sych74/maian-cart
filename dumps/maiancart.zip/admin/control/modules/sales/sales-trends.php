<?php

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  This File: trends.php
  Description: System File

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

if (!defined('PARENT')) {
  include(PATH.'control/modules/header/403.php');
}

include(MCLANG.'sales/view-sales.php');

$pageTitle     = mc_cleanDataEnt($msg_stats21).': '.$pageTitle;

include(PATH.'templates/header.php');
include(PATH.'templates/sales/sales-trends.php');
include(PATH.'templates/footer.php');

?>
