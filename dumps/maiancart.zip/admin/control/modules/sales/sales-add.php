<?php

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  This File: sales-add.php
  Description: System File

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

if (!defined('PARENT')) {
  include(PATH.'control/modules/header/403.php');
}

// Load language file(s)..
include(MCLANG.'sales/view-sales.php');
include(MCLANG.'sales/sales-add.php');
include(MCLANG.'sales/sales-view.php');
include(MCLANG.'tools/update-prices.php');
include(MCLANG.'catalogue/product-related.php');

// Reset personalisation..
if (isset($_GET['rpp'])) {
  $pers  = (isset($_GET['pers']) ? $_GET['pers'] : '0.00');
  $attr  = (isset($_GET['attr']) ? $_GET['attr'] : '0.00');
  echo jsonHandler(
   array(
    'price'       => mc_formatPrice($_GET['price']),
    'highlight'   => mc_currencyFormat(mc_formatPrice((($_GET['price']*$_GET['qty'])+$pers+$attr),true)),
    'total_price' => mc_formatPrice((($_GET['price']*$_GET['qty'])+$pers+$attr))
   )
  ); 
  exit;
}

// Refresh prices..
if (isset($_POST['process_add_sale']) && $_POST['process_add_sale']=='refresh-prices') {
  $ship    = mc_formatPrice($_POST['shipTotal']);
  $tax     = mc_formatPrice($_POST['taxRate']);
  $area    = (isset($_POST['shipSetArea']) ? mc_digitSan($_POST['shipSetArea']) : '0');
  $gift    = (isset($_POST['couponTotal']) ? mc_formatPrice($_POST['couponTotal']) : '0.00');
  $global  = (isset($_POST['globalTotal']) ? mc_formatPrice($_POST['globalTotal']) : '0.00');
  $ins     = (isset($_POST['insuranceTotal']) ? mc_formatPrice($_POST['insuranceTotal']) : '0.00');
  $price   = '0.00';
  $disc    = '0.00';
  $pers    = '0.00';
  $attr    = '0.00';
  if ($area>0) {
    $A  = mc_getTableData('zone_areas','id',$area,'','inZone');
    $Z  = mc_getTableData('zones','id',$A->inZone,'','zShipping');
  }
  // Re-add prices..
  if (!empty($_POST['t_price'])) {
    for ($i=0; $i<count($_POST['t_price']); $i++) {
      if ($_POST['t_price'][$i]>0 && $_POST['qty'][$i]>0) {
        $price = $price+mc_formatPrice($_POST['t_price'][$i]*$_POST['qty'][$i]);
      }
    }
  }
  // Attributes..
  if (!empty($_POST['attrPrice'])) {
    foreach ($_POST['attrPrice'] AS $ap) {
      $attr = $attr+mc_formatPrice($ap);
    }
  }
  // Personalisation cost..
  if (!empty($_POST['persPrice'])) {
    foreach ($_POST['persPrice'] AS $pp) {
      $pers = $pers+mc_formatPrice($pp);
    }
  }
  // Adjust price..
  $price = mc_formatPrice($price+$pers+$attr);
  // Discounts..
  if ($gift>0 || $global>0) {
    $disc = ($gift>0 ? $gift : $global);
  }
  // Calculations..
  if (isset($Z->zShipping) && $Z->zShipping=='yes') {
    $sprice  = mc_formatPrice($price-$disc);
    $taxCal  = ($tax>0 ? number_format($tax*mc_formatPrice($sprice+$ship)/100,2,'.','') : '0.00');
    $total   = mc_formatPrice($sprice+$ship+$taxCal+$ins);
  } else {
    $sprice  = mc_formatPrice($price-$disc);
    $taxCal  = ($tax>0 ? number_format($tax*mc_formatPrice($sprice)/100,2,'.','') : '0.00');
    $total   = mc_formatPrice($sprice+$taxCal+$ship+$ins);
  }
  $weight  = 0;
  if (!empty($_POST['pid'])) {
    $weight = mc_sumCount('purchases WHERE id IN('.implode(',',$_POST['pid']).')','productWeight');
  }
  echo jsonHandler(
   array(
    'sub'    => mc_formatPrice($price),
    'tax'    => $taxCal,
    'grand'  => mc_formatPrice($total),
    'weight' => ($weight>0 ? number_format($weight,2,'.','') : '0'),
    'text'   => $msg_javascript248
   )
  ); 
  exit;
}
 
// Load products.. 
if ($cmd=='add-manual') {
  if (isset($_POST['process'])) {
    if (!empty($_POST['product'])) {
      switch($_POST['type']) {
        case 'physical':
        $cur = array();
        if (!empty($_SESSION['add-phys-'.mc_encrypt(SECRET_KEY)])) {
          $cur = $_SESSION['add-phys-'.mc_encrypt(SECRET_KEY)];
        }
        $_SESSION['add-phys-'.mc_encrypt(SECRET_KEY)] = array_merge($_POST['product'],$cur);
        break;
        case 'download':
        $cur = array();
        if (!empty($_SESSION['add-down-'.mc_encrypt(SECRET_KEY)])) {
          $cur = $_SESSION['add-down-'.mc_encrypt(SECRET_KEY)];
        }
        $_SESSION['add-down-'.mc_encrypt(SECRET_KEY)] = array_merge($_POST['product'],$cur);
        break;
      }
      $OK = true;
    } else {
      header("Location: index.php?p=add-manual&type=".$_POST['type']);
      exit;
    }
  }
  include(PATH.'templates/windows/sale-add-products-manual.php');
  exit;
}

// Clear
if (isset($_GET['clear'])) {
  unset($_SESSION['add-phys-'.mc_encrypt(SECRET_KEY)],$_SESSION['add-down-'.mc_encrypt(SECRET_KEY)]);
  $_SESSION['add-phys-'.mc_encrypt(SECRET_KEY)] = array();   
  $_SESSION['add-down-'.mc_encrypt(SECRET_KEY)] = array();   
  header("Location: index.php?p=sales-add");
  exit;
}
  
// Reload countries..
if (isset($_GET['c'])) {
  $_GET['c'] = mc_digitSan($_GET['c']);
  echo jsonHandler(
   array(
    'areas'    => $MCSALE->reloadCountries(),
    'services' => $MCSALE->reloadServices(),
    'taxrate'  => $MCSALE->reloadServices(true)
   )
  );
  exit; 
}
  
// Reload tax rate..
if (isset($_GET['z'])) {
  $_GET['z'] = mc_digitSan($_GET['z']);
  $ZONE      = mc_getTableData('zone_areas','id',$_GET['z']);
  echo jsonHandler(
   array(
    'taxrate' => (isset($ZONE->zRate) && $ZONE->zRate!='' ? $ZONE->zRate : '0')
   )
  );
  exit;   
}
  
// Add sale and load edit page..
if (isset($_POST['process_add_sale']) && $_POST['process_add_sale']=='yes') {
  $id            = $MCSALE->addManualSale();
  $OK_ADD        = true;
  $_GET['sale']  = $id;
  $SALE          = mc_getTableData('sales','id',
                                $id,
                                '',
                                '*,DATE_FORMAT(purchaseDate,\''.$SETTINGS->mysqlDateFormat.'\') AS `pdate`'
                   );
  $pageTitle     = $pageTitle = $msg_viewsale74.' (#'.mc_saleInvoiceNumber($SALE->invoiceNo).'): '.$pageTitle;
  $colorbox      = true;
  $loadCalendar  = true;
  $loadGreyBox   = true;
  include(PATH.'templates/header.php');
  include(PATH.'templates/sales/sales-view.php');
  include(PATH.'templates/footer.php');
  exit;
}
  
// Load service price..
if (isset($_GET['service'])) {
  $C = '0.00';
  switch (substr($_GET['service'],0,4)) {
    case 'flat':
    $F = mc_getTableData('flat','id',(int)substr($_GET['service'],4));
    $C = (isset($F->rate) ? $F->rate : '0.00');
    break;
    case 'perc':
    $P = mc_getTableData('percent','id',(int)substr($_GET['service'],4));
    $C = number_format(($_GET['price']*$P->percentage)/100,2,'.','');
    break;
    default:
    $S = mc_getTableData('rates','id',(int)$_GET['service']);
    // Tare weight..
    $tareCost  = '0.00';
    if ($_GET['weight']>0) {
      $tare      = getTareWeight($_GET['weight'],$S->rService);
      if ($tare[0]=='yes') {
        switch (substr($tare[1],-1)) {
          case '%':
          $calc     = substr($tare[1],0,-1);
          $tareCost = number_format(($S->rCost*$calc)/100,2,'.','');
          break;
          default:
          $tareCost = mc_formatPrice($tare[1]);
          break;
        }
      }
    }
    $C = (isset($S->rCost) ? mc_formatPrice($S->rCost+$tareCost) : '0.00');
    break;
  }
  echo jsonHandler(
   array(
    'price' => $C
   )
  );
  exit;   
}
  
$pageTitle     = $pageTitle = mc_cleanDataEnt($msg_javascript355).': '.$pageTitle;
$colorbox      = true;
$loadGreyBox   = true;
  
include(PATH.'templates/header.php');
include(PATH.'templates/sales/sales-add.php');
include(PATH.'templates/footer.php');

?>
