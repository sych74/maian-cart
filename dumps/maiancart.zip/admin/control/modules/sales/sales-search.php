<?php

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  This File: sales-search.php
  Description: System File

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

if (!defined('PARENT')) {
  include(PATH.'control/modules/header/403.php');
}

// Load language file(s)..
include(MCLANG.'sales/sales-overview.php');
include(MCLANG.'sales/sales-search.php');
include(MCLANG.'sales/view-sales.php');
include(MCLANG.'catalogue/product-manage.php');

$searchFilter = '';
  
if (isset($_GET['process'])) {
  $_GET = mc_safeImport($_GET);
  if (isset($_GET['invoice']) && $_GET['invoice'] && is_numeric($_GET['invoice'])) {
    $searchFilter = 'AND LOWER(`invoiceNo`) = \''.ltrim(mc_saleInvoiceNumber(strtolower($_GET['invoice'])),'0').'\' ';
  }
  if (isset($_GET['code']) && $_GET['code']) {
    $searchFilter .= ($searchFilter ? mc_defineNewline() : '').'AND LOWER(`couponCode`) = \''.strtolower($_GET['code']).'\' OR LOWER(`gatewayID`) = \''.strtolower($_GET['code']).'\' ';
  }
  if (isset($_GET['from']) && isset($_GET['to'])) {
    if (mc_checkValidDate($_GET['from'])!='0000-00-00' && mc_checkValidDate($_GET['to'])!='0000-00-00') {
      $searchFilter .= ($searchFilter ? mc_defineNewline() : '').'AND `purchaseDate` BETWEEN \''.mc_convertCalToSQLFormat($_GET['from']).'\' AND \''.mc_convertCalToSQLFormat($_GET['to']).'\' ';
    }
  }
  if (isset($_GET['name']) && $_GET['name']) {
    $searchFilter .= ($searchFilter ? mc_defineNewline() : '').'AND LOWER(`bill_1`) LIKE \'%'.strtolower($_GET['name']).'%\' ';
  }
  if (isset($_GET['email']) && $_GET['email'] && preg_match("/^[_\.0-9a-zA-Z-]+@([0-9a-zA-Z][0-9a-zA-Z.-]+\.)+[a-zA-Z]{2,6}$/i", $_GET['email'])) {
    $searchFilter .= ($searchFilter ? mc_defineNewline() : '').'AND LOWER(`bill_2`) LIKE \'%'.strtolower($_GET['email']).'%\' ';
  }
  if ($searchFilter) {
    $SEARCH = true;
  } else {
    header("Location: index.php?p=sales-search");
    exit;
  }
}
  
$pageTitle     = mc_cleanDataEnt($msg_javascript111).': '.$pageTitle;
$loadCalendar  = true;
$loadGreyBox   = true;
  
include(PATH.'templates/header.php');
include(PATH.'templates/sales/sales-search.php');
include(PATH.'templates/footer.php');

?>
