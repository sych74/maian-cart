<?php

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  This File: invoice.php
  Description: System File

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

if (!defined('PARENT')) {
  include(PATH.'control/modules/header/403.php');
}

// Load language file(s)..
include(MCLANG.'sales/invoice-packingslip.php');

$SALE = mc_getTableData('sales','id',
                      mc_digitSan($_GET['sale']),
                      '',
                      '*,DATE_FORMAT(purchaseDate,\''.$SETTINGS->mysqlDateFormat.'\') AS pdate'
        );
if ($cmd=='invoice' && isset($SALE->id)) {
  $ZONE   = mc_getTableData('zone_areas','id',$SALE->shipSetArea);
  $title  = $msg_invoice.': #'.mc_saleInvoiceNumber($SALE->invoiceNo);
  include(PATH.'templates/windows/invoice.php');
  exit;;
}
if ($cmd=='packing-slip' && isset($SALE->id)) {
  $ZONE   = mc_getTableData('zone_areas','id',$SALE->shipSetArea);
  $title  = $msg_invoice15.': #'.mc_saleInvoiceNumber($SALE->invoiceNo);
  include(PATH.'templates/windows/packing-slip.php');
  exit;
}

echo $msg_sales12;

?>
