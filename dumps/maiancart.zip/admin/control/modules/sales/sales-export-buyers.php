<?php

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  This File: sales-export-buyers.php
  Description: System File

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

if (!defined('PARENT')) {
  include(PATH.'control/modules/header/403.php');
}

// Load language file(s)..
include(MCLANG.'sales/sales-export.php');
include(MCLANG.'sales/sales-search.php');
include(MCLANG.'sales/view-sales.php');

if (isset($_POST['process'])) {
  $return = $MCSALE->exportBuyersToCSV();
}
  
$pageTitle     = mc_cleanDataEnt($msg_javascript134).': '.$pageTitle;
$loadCalendar  = true;
  
include(PATH.'templates/header.php');
include(PATH.'templates/sales/sales-export-buyers.php');
include(PATH.'templates/footer.php');

?>
