<?php

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  This File: sales-batch.php
  Description: System File

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

if (!defined('PARENT')) {
  include(PATH.'control/modules/header/403.php');
}

// Load language file(s)..
include(MCLANG.'sales/view-sales.php');
include(MCLANG.'sales/sales-batch.php');
include(MCLANG_REL.'emails.php');
include(MCLANG.'catalogue/product-manage.php');

if (isset($_POST['process']) && !empty($_POST['batch'])) {
  include(REL_PATH.'control/gateways/handler.php');
  $GWY            = new paymentHandler();
  $GWY->settings  = $SETTINGS;
  foreach ($_POST['batch'] AS $orderID) {
    // Get order info..
	$ORDER    = mc_getTableData('sales','id',$orderID);
    // Create arrays of digits/letters..
    $a        = array_merge(range('a','z'),range(1,9));
    shuffle($a);
    $append   = $a[4].$a[23];
    // Find/replace..
    $find     = array(
	 '{ORDER-NO}',
	 '{DATE}',
	 '{NAME}',
     '{DOWNLOADS}',
     '{ORDER}'
    );
    $replace  = array(
	 mc_saleInvoiceNumber($ORDER->invoiceNo),
	 date($SETTINGS->systemDateFormat,strtotime($ORDER->purchaseDate)),
	 $ORDER->bill_1,
     $SETTINGS->ifolder.'/?vOrder='.$orderID.'-'.$ORDER->buyCode.$append,
     $GWY->buildProductOrder($orderID)
    );
	$_POST['text'] = str_replace($find,$replace,$_POST['text']);
	// Update order..
    $id            = $MCSALE->batchUpdateOrderStatus($orderID);
    if ($ORDER->bill_1 && $ORDER->bill_2) {
      $MCMAIL->sendMail($ORDER->bill_1,
                        $ORDER->bill_2,
                        mc_cleanData($SETTINGS->website),
                        $SETTINGS->email,
                        str_replace($find,$replace,$_POST['title']),
                        $_POST['text']
               );         
      
    }
    if ($_POST['copy_email']!='') {
      $copy = mc_getCopyAddresses($_POST['copy_email']);
      if (!empty($copy)) {
        foreach ($copy AS $ce) {
          $MCMAIL->sendMail(mc_cleanData($SETTINGS->website),
                            $ce,
                            mc_cleanData($SETTINGS->website),
                            $SETTINGS->email,
                            str_replace($find,$replace,$_POST['title']).$msg_salesbatch15,
                            $_POST['text']
                   );
        }
      }
    }
  }
  $OK = true;
}

if (empty($_POST['batch'])) {
  header("Location: index.php?p=sales");
  exit;
}
  
$pageTitle     = $msg_salesbatch2.': '.$pageTitle;
$loadGreyBox   = true;
$createFolder  = true;
  
include(PATH.'templates/header.php');
include(PATH.'templates/sales/sales-batch.php');
include(PATH.'templates/footer.php');

?>
