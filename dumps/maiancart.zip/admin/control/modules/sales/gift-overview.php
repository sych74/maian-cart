<?php

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  This File: gift-overview.php
  Description: System File

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

if (!defined('PARENT')) {
  include(PATH.'control/modules/header/403.php');
}

// Load language file(s)..
include(MCLANG.'sales/gift-overview.php');

// Export hits..
if (isset($_GET['export'])) {
  $MCSYS->exportGiftOverviewToCSV();
}

if (isset($_GET['del'])) {
  $cnt = $MCSYS->deleteGiftCode();
  $OK  = true;
}

$pageTitle     = mc_cleanDataEnt($msg_header24).': '.$pageTitle;
$colorbox      = true;
$loadGreyBox   = true;
  
include(PATH.'templates/header.php');
include(PATH.'templates/sales/gift-overview.php');
include(PATH.'templates/footer.php');

?>
