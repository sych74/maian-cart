<?php

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  This File: sales-view.php
  Description: System File

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

if (!defined('PARENT')) {
  include(PATH.'control/modules/header/403.php');
}

// Load language file(s)..
include(MCLANG.'sales/view-sales.php');
include(MCLANG.'sales/sales-view.php');
include(MCLANG.'tools/update-prices.php');
include(MCLANG.'catalogue/product-related.php');

// Update IP addresses..
if (isset($_GET['saveIP'])) {
  $MCSALE->updateSaleIPAccess();
  exit;
}

// Resend gift certificates..
if (isset($_GET['resendGiftCert'])) {
  include(REL_PATH.'control/classes/products.php');
  include(REL_PATH.'control/classes/cart.php');
  include(REL_PATH.'control/classes/gift.php');
  $sale   = (int)$_GET['resendGiftCert'];
  $pur    = (int)$_GET['purID'];
  $MCGIFT = new giftCertificate();
  $q_cert = mysql_query("SELECT * FROM ".DB_PREFIX."giftcodes
            WHERE `saleID`   = '{$sale}'
			AND `purchaseID` = '{$pur}'
		    ORDER BY `id`
            ");
  while ($GIFT_CERTS = mysql_fetch_object($q_cert)) {
    // Create code if it doesn`t exist..
    $giftCode = ($GIFT_CERTS->code ? $GIFT_CERTS->code : $MCGIFT->codeCreator($GIFT_CERTS->id));
    // Activate if not activated..
	$MCGIFT->activateCertificate($giftCode,$GIFT_CERTS->id);
	// Mail tags..
    $MCMAIL->addTag('{TO_NAME}',$GIFT_CERTS->to_name);
    $MCMAIL->addTag('{FROM_NAME}',$GIFT_CERTS->from_name);
    $MCMAIL->addTag('{CURRENCY}',$SETTINGS->baseCurrency);
    $MCMAIL->addTag('{VALUE}',$GIFT_CERTS->value);
    $MCMAIL->addTag('{GIFT_CODE}',$giftCode);
	$MCMAIL->addTag('{CUSTOM_MESSAGE}',($GIFT_CERTS->message ? $GIFT_CERTS->message : $public_checkout137));
    // Resend email..
    $MCMAIL->sendMail(
     mc_cleanData($GIFT_CERTS->to_name),
     mc_cleanData($GIFT_CERTS->to_email),
     mc_cleanData($GIFT_CERTS->from_name),
     mc_cleanData($GIFT_CERTS->from_email),
     str_replace(array('{website}','{from_name}','{to_name}'),
     array(
      mc_cleanData($SETTINGS->website),
      mc_cleanData($GIFT_CERTS->from_name),
      mc_cleanData($GIFT_CERTS->to_name)
     ),
     $msg_emails23
     ),
     $MCMAIL->template(MCLANG_REL.'email-templates/gift-certificate.txt')
    );
  }
  exit;
}

// View gateway parameters..
if (isset($_GET['gatewayParams'])) {
  include(PATH.'templates/windows/gateway-params.php');
  exit;
}

// Tally up totals..
if (isset($_GET['loadBoxTotals'])) {
  echo jsonHandler(
   array(
    'total' => ($_GET['loadBoxTotals'] ? mc_formatPrice($_GET['qty']*array_sum(explode(',',$_GET['loadBoxTotals']))) : '0.00')
   )
  );
  exit;
}

// Sale weight..
if (isset($_GET['loadSaleWeight'])) {
  $weight                 = '0';
  $_GET['loadSaleWeight'] = (int)$_GET['loadSaleWeight'];
  if ($_GET['loadSaleWeight']>0) {
    $q      = mysql_query("SELECT SUM(`productWeight`) AS `w` FROM `".DB_PREFIX."purchases` WHERE `saleID` = '{$_GET['loadSaleWeight']}'")
              or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    $W      = mysql_fetch_object($q);
	$wght   = (isset($W->w) ? $W->w : '0');
	$q2     = mysql_query("SELECT SUM(`attrWeight`) AS `w` FROM `".DB_PREFIX."purch_atts` WHERE `saleID` = '{$_GET['loadSaleWeight']}'")
              or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    $W2     = mysql_fetch_object($q2);
	$wght2  = (isset($W2->w) ? $W2->w : '0');
	$weight = @number_format($wght+$wght2,2,'.','');
  }
  echo jsonHandler(
   array(
    'total'  => $weight
   )
  );
  exit;
}

// Next invoice number..
if (isset($_GET['nextInvoiceNo'])) {
  include_once(REL_PATH.'control/gateways/handler.php');
  $GW           = new paymentHandler();
  $GW->settings = $SETTINGS;
  echo mc_saleInvoiceNumber($GW->getInvoiceNo());
  exit;
}

// Add attribute..
if (isset($_GET['addAttribute'])) {
  $AT = mc_getTableData('attributes','id',(int)$_GET['addAttribute'],'AND `productID` = \''.(int)$_GET['product'].'\'');
  echo jsonHandler(
   array(
    'name'  => mc_cleanData($AT->attrName),
    'cost'  => $AT->attrCost
   )
  );
  exit;
}

// Shipping Label..
if (isset($_GET['shipLabel'])) {
  $_GET['shipLabel'] = (int)$_GET['shipLabel'];
  $pageTitle         = $msg_viewsale105;
  include(PATH.'templates/windows/shipping-label.php');
  exit;
}

// Reset personalisation..
if (isset($_GET['rpp'])) {
  $pers  = (isset($_GET['pers']) ? $_GET['pers'] : '0.00');
  $attr  = (isset($_GET['attr']) ? $_GET['attr'] : '0.00');
  echo jsonHandler(
   array(
    'price'       => mc_formatPrice($_GET['price']),
    'highlight'   => mc_currencyFormat(mc_formatPrice((($_GET['price']*$_GET['qty'])+$pers+$attr),true)),
    'total_price' => mc_formatPrice((($_GET['price']*$_GET['qty'])+$pers+$attr))
   )
  ); 
  exit;
}

// Print personalisation window..
if (isset($_GET['print-personalisation']) || isset($_GET['view-personalisation'])) {
  $_GET['print-personalisation'] = (isset($_GET['view-personalisation']) ? mc_digitSan($_GET['view-personalisation']) : mc_digitSan($_GET['print-personalisation']));
  include(PATH.'templates/windows/personalisation-print-friendly.php');
  exit;
}

// Refresh prices..
if (isset($_POST['process']) && $_POST['process']=='refresh-prices') {
  $ship    = mc_formatPrice($_POST['shipTotal']);
  $tax     = mc_formatPrice($_POST['taxRate']);
  $area    = (isset($_POST['shipSetArea']) ? mc_digitSan($_POST['shipSetArea']) : '0');
  $gift    = (isset($_POST['couponTotal']) ? mc_formatPrice($_POST['couponTotal']) : '0.00');
  $global  = (isset($_POST['globalTotal']) ? mc_formatPrice($_POST['globalTotal']) : '0.00');
  $manual  = (isset($_POST['manualDiscount']) ? mc_formatPrice($_POST['manualDiscount']) : '0.00');
  $ins     = (isset($_POST['insuranceTotal']) ? mc_formatPrice($_POST['insuranceTotal']) : '0.00');
  $price   = '0.00';
  $disc    = '0.00';
  $pers    = '0.00';
  $attr    = '0.00';
  if ($area>0) {
    $A  = mc_getTableData('zone_areas','id',$area,'','inZone');
    $Z  = mc_getTableData('zones','id',$A->inZone,'','zShipping');
  }
  // Re-add prices..
  if (!empty($_POST['price'])) {
    for ($i=0; $i<count($_POST['price']); $i++) {
      if ($_POST['price'][$i]>0 && $_POST['qty'][$i]>0) {
        $price = $price+mc_formatPrice($_POST['price'][$i]*$_POST['qty'][$i]);
      }
    }
  }
  // Attributes..
  if (!empty($_POST['attrPrice'])) {
    foreach ($_POST['attrPrice'] AS $ap) {
      $attr = $attr+mc_formatPrice($ap);
    }
  }
  // Personalisation cost..
  if (!empty($_POST['persPrice'])) {
    foreach ($_POST['persPrice'] AS $pp) {
      $pers = $pers+mc_formatPrice($pp);
    }
  }
  // Adjust price..
  $price = mc_formatPrice($price+$pers+$attr);
  // For global percentage, calculate based on price..
  if (isset($_POST['globalDiscount']) && $_POST['globalDiscount']>0) {
    $global = number_format(($price*$_POST['globalDiscount'])/100,2,'.','');
  }
  // Discounts..
  if ($gift>0 || $global>0 || $manual>0) {
    $disc = ($gift>0 ? $gift : ($manual>0 ? $manual : $global));
  }
  // Calculations..
  if (isset($Z->zShipping) && $Z->zShipping=='yes') {
    $sprice  = mc_formatPrice($price-$disc);
    $taxCal  = ($tax>0 ? number_format($tax*mc_formatPrice($sprice+$ship)/100,2,'.','') : '0.00');
    $total   = mc_formatPrice($sprice+$ship+$taxCal+$ins);
  } else {
    $sprice  = mc_formatPrice($price-$disc);
    $taxCal  = ($tax>0 ? number_format($tax*mc_formatPrice($sprice)/100,2,'.','') : '0.00');
    $total   = mc_formatPrice($sprice+$taxCal+$ship+$ins);
  }
  $weight  = 0;
  if (!empty($_POST['pid'])) {
    $weight = mc_sumCount('purchases WHERE id IN('.implode(',',$_POST['pid']).')','productWeight');
  }
  echo jsonHandler(
   array(
    'sub'    => mc_formatPrice($price),
    'tax'    => $taxCal,
    'grand'  => mc_formatPrice($total),
    'global' => mc_formatPrice($global),
    'coupon' => mc_formatPrice($gift),
    'manual' => mc_formatPrice($manual),
    'weight' => ($weight>0 ? number_format($weight,2,'.','') : '0'),
    'text'   => $msg_javascript248
   )
  );
  exit; 
}
  
// Add product to sale..
if ($cmd=='add') {
  if (isset($_POST['process'])) {
    $_GET['sale'] = mc_digitSan($_GET['sale']);
    if (!empty($_POST['product']) && $_GET['sale']>0) {
      $MCSALE->addProductToSale();
      $OK = true;
    } else {
      header("Location: index.php?p=add&sale=".$_GET['sale']."&type=".$_POST['type']);
      exit;
    }
  }
  include(PATH.'templates/windows/sale-add-products.php');
  exit;
}
  
// Reset downloads..
if ($cmd=='downloads') {
  $_GET['sale'] = mc_digitSan($_GET['sale']);
  if (isset($_POST['process']) && $_GET['sale']>0) {
    $productString  = '';
    $products       = array();
    if (!empty($_POST['id'])) {
      foreach ($_POST['id'] AS $id) {
        $PURCHASE       = mc_getTableData('purchases','id',$id);
        $PRD            = mc_getTableData('products','id',$PURCHASE->productID);
        // Assign order string and products array..
        $products[]     = 'p'.$PURCHASE->productID;
        $productString .= mc_cleanData($PRD->pName).(ENABLE_HTML_IN_EMAILS ? '<br />' : mc_defineNewline());
        // Create unique download code..
        $code           = mc_encrypt(uniqid(rand(),1).date('dmYhis').$id);
        // Activate download..
        $MCSALE->activateDownloads($code,$id);
      }
      // Create arrays of digits/letters..
      $a      = array_merge(range('a','z'),range(1,9));
      shuffle($a);
      $append = $a[4].$a[23];
      // Add activation log..
      $MCSALE->addActivationLog($_GET['sale'],implode('|',$products),count($products));
      // Send e-mail to buyer..
      $SALE = mc_getTableData('sales','id',$_GET['sale']);
      if ($SALE->bill_2) {
        $MCMAIL->addTag('{PRODUCTS}',rtrim($productString));
        $MCMAIL->addTag('{D_URL}',$SETTINGS->ifolder.'/?vOrder='.$_GET['sale'].'-'.$SALE->buyCode.$append);
        $MCMAIL->addTag('{NAME}',$SALE->bill_1);
        $MCMAIL->sendMail($SALE->bill_1,
                          $SALE->bill_2,
                          mc_cleanData($SETTINGS->website),
                          $SETTINGS->email,
                          str_replace(array('{website}','{order}'),
                                      array(mc_cleanData($SETTINGS->website),mc_saleInvoiceNumber($SALE->invoiceNo)),
                                      $msg_viewsale35
                          ),
                          $MCMAIL->template(MCLANG.'email-templates/download-reactivation.txt')
                 );
      }
      $OK = true;
    } else {
      header("Location: index.php?p=downloads&sale=".$_GET['sale']);
      exit;
    }
  }
  // Lock/unlock download page..
  if (isset($_GET['action']) && in_array($_GET['action'],array('lock','unlock'))) {
    switch ($_GET['action']) {
      case 'lock':
      $MCSALE->downloadPageLock($_GET['sale'],$_GET['status'],$msg_viewsale83);
      $OK2 = true;
      break;
      case 'unlock':
      $MCSALE->downloadPageLock($_GET['sale'],$_GET['status'],$msg_viewsale84);
      $OK3 = true;
      break;
    }
  }
  include(PATH.'templates/windows/sale-downloads.php');
  exit;
}
  
// Reload countries..
if (isset($_GET['c'])) {
  $_GET['c'] = mc_digitSan($_GET['c']);
  echo jsonHandler(
   array(
    'areas'    => $MCSALE->reloadCountries(),
    'services' => $MCSALE->reloadServices(),
    'taxrate'  => $MCSALE->reloadServices(true)
   )
  );
  exit; 
}
  
// Reload tax rate..
if (isset($_GET['z'])) {
  $_GET['z'] = mc_digitSan($_GET['z']);
  $ZONE      = mc_getTableData('zone_areas','id',$_GET['z']);
  echo jsonHandler(
   array(
    'taxrate' => (isset($ZONE->zRate) && $ZONE->zRate!='' ? $ZONE->zRate : '0')
   )
  );
  exit;  
}
  
// Edit sale..
if (isset($_POST['process']) && $_POST['process']=='yes') {
  $MCSALE->editSale();
  $OK = true;
}
  
// Load service price..
if (isset($_GET['service'])) {
  $C = '0.00';
  switch (substr($_GET['service'],0,4)) {
    case 'flat':
    $F = mc_getTableData('flat','id',(int)substr($_GET['service'],4));
    $C = (isset($F->rate) ? $F->rate : '0.00');
    break;
	case 'pert':
    $F = mc_getTableData('per','id',(int)substr($_GET['service'],4));
    $R = (isset($F->rate) ? $F->rate : '0.00');
	$E = (isset($F->item) ? $F->item : '0.00');
	$X = '';
	for ($i=0; $i<count($_GET['pids']); $i++) {
	  if ($i>0) {
	    $qty      = $_GET['qtys'][$i]['value'];
		$product  = $_GET['pids'][$i]['value'];
		$prodInfo = mc_getTableData('products','id',$product);
		// Check this product doesn`t have free shipping and also isn`t a download..
		if ($prodInfo->pDownload=='no' && $prodInfo->freeShipping=='no') {
		  $X = ($X+($E*$qty));
		}
	  }
	}
	$C = number_format(($R+$X),2,'.','');
	break;
    case 'perc':
    $P = mc_getTableData('percent','id',(int)substr($_GET['service'],4));
    $C = number_format(($_GET['price']*$P->percentage)/100,2,'.','');
    break;
    default:
    $S = mc_getTableData('rates','id',(int)$_GET['service']);
    // Tare weight..
    $tareCost  = '0.00';
    if ($_GET['weight']>0) {
      $tare      = getTareWeight($_GET['weight'],$S->rService);
      if ($tare[0]=='yes') {
        switch (substr($tare[1],-1)) {
          case '%':
          $calc     = substr($tare[1],0,-1);
          $tareCost = number_format(($S->rCost*$calc)/100,2,'.','');
          break;
          default:
          $tareCost = mc_formatPrice($tare[1]);
          break;
        }
      }
    }
    $C = (isset($S->rCost) ? mc_formatPrice($S->rCost+$tareCost) : '0.00');
    break;
  }
  echo jsonHandler(
   array(
    'price' => $C
   )
  );
  exit;  
}
  
// Products added? Show message..
if (isset($_GET['products-added'])) {
  $OK2 = true;
}

// Get sale data..
$SALE = mc_getTableData('sales','id',
                     mc_digitSan($_GET['sale']),
                     '',
                     '*,DATE_FORMAT(purchaseDate,\''.$SETTINGS->mysqlDateFormat.'\') AS pdate'
        );

if (!isset($SALE->id)) {
  include(PATH.'control/modules/header/403.php');
}
		
$pageTitle     = $pageTitle = $msg_viewsale74.' (#'.mc_saleInvoiceNumber($SALE->invoiceNo).'): '.$pageTitle;
$colorbox      = true;
$loadGreyBox   = true;
  
include(PATH.'templates/header.php');
include(PATH.'templates/sales/sales-view.php');
include(PATH.'templates/footer.php');

?>
