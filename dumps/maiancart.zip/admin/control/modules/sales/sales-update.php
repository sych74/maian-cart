<?php

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  This File: sales-update.php
  Description: System File

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

if (!defined('PARENT')) {
  include(PATH.'control/modules/header/403.php');
}

// Load language file(s)..
include(MCLANG.'sales/view-sales.php');
include(MCLANG.'sales/sales-update.php');
include(MCLANG_REL.'emails.php');
include(MCLANG.'catalogue/product-manage.php');

// Status text management..
if (isset($_GET['loadEditText']) && is_numeric($_GET['loadEditText'])) {
  $S = mc_getTableData('statuses','id',$_GET['loadEditText']);
  echo mc_cleanData($S->statusNotes);
  exit;
}

if (isset($_POST['notesEdit']) && isset($_GET['statedit']) 
    && isset($_GET['status']) && is_numeric($_GET['status'])) {
  $MCSALE->editSaleStatus();
  echo nl2br(mc_cleanData($_POST['notesEdit']));
  exit;
}

// Sales status management..
if (isset($_GET['status_text'])) {
  $MCSALE->addStatusText();
  echo jsonHandler(
   array(
    'message' => $msg_salesupdate26
   )
  );  
  exit;
}

if (isset($_GET['load_status']) && is_numeric($_GET['load_status'])) {
  $S = mc_getTableData('status_text','id',$_GET['load_status']);
  echo mc_cleanData($S->statText);
  exit;
}

if ($cmd=='sales-statuses') {
  if (isset($_POST['process'])) {
    $MCSALE->updateStatusText();
    $OK = true;
  }
  
  if (isset($_GET['del'])) {
    $MCSALE->deleteStatusText();
    header("Location: ?p=sales-statuses&deldone=yes");
    exit;
  }
  
  include(PATH.'templates/windows/sales-statuses.php');
  exit;
}

if (isset($_GET['print']) && is_numeric($_GET['print'])) {
  include(PATH.'templates/windows/statuses-print-friendly.php');
  exit;
}

if (isset($_POST['process'])) {
  include(REL_PATH.'control/gateways/handler.php');
  $GWY            = new paymentHandler();
  $GWY->settings  = $SETTINGS;
  // Create arrays of digits/letters..
  $a        = array_merge(range('a','z'),range(1,9));
  shuffle($a);
  $append   = $a[4].$a[23];
  // Find/replace..
  $find     = array(
   '{DOWNLOADS}',
   '{ORDER}'
  );
  $replace  = array(
   $SETTINGS->ifolder.'/?vOrder='.$_GET['sale'].'-'.$_POST['buyCode'].$append,
   $GWY->buildProductOrder($_GET['sale'])
  );
  $_POST['text'] = str_replace($find,$replace,$_POST['text']);
  // Update order..
  $id       = $MCSALE->updateOrderStatus();
  // Add attachments..
  $files    = $MCSALE->addStatusAttachments($id);
  // Add attachments..
  if (!empty($files)) {
    $MCMAIL->attachments = $files;
  }
  if (isset($_POST['email']) && $_POST['bill_2']) {
    $MCMAIL->sendMail($_POST['buyer'],
                      $_POST['bill_2'],
                      mc_cleanData($SETTINGS->website),
                      $SETTINGS->email,
                      $_POST['title'],
                      $_POST['text']
             );         
      
  }
  if ($_POST['copy_email']!='') {
    $copy = mc_getCopyAddresses($_POST['copy_email']);
    if (!empty($copy)) {
      foreach ($copy AS $ce) {
        $MCMAIL->sendMail(mc_cleanData($SETTINGS->website),
                          $ce,
                          mc_cleanData($SETTINGS->website),
                          $SETTINGS->email,
                          $_POST['title'].$msg_salesupdate21,
                          $_POST['text']
                 );
      }
    }
  }
  // Clear attachments..
  if (isset($_POST['save']) && $_POST['save']=='no') {
    $MCSALE->clearAllAttachments($files);
  }
  $OK = true;
}
  
if (isset($_GET['delete']) && $uDel=='yes') {
  $cnt = $MCSALE->deleteOrderStatus();
  $DEL = true;
}
  
// Create folder..
if (isset($_GET['create-folder'])) {
  // Remove any none alphanumeric characters from folder name. Keep numbers & letters only..
  $folder = preg_replace('/[^a-zA-Z0-9\s]/','',$_GET['create-folder']);
  // Create folder..
  if ($folder) {
    $status = $MCSALE->createAttachmentsFolder($folder);
  }
  echo jsonHandler(
   array(
    'message' => 'create-folder',
    'status'  => $status,
    'error'   => $msg_javascript153,
    'ok'      => $msg_javascript154,
    'folder'  => ($folder ? $folder : 'none')
   )
  ); 
  exit;            
}
  
$pageTitle     = $msg_salesupdate2.': '.$pageTitle;
$loadGreyBox   = true;
$createFolder  = true;
  
include(PATH.'templates/header.php');
include(PATH.'templates/sales/sales-update.php');
include(PATH.'templates/footer.php');

?>
