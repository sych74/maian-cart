<?php

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  This File: batch-move.php
  Description: System File

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

if (!defined('PARENT')) {
  include(PATH.'control/modules/header/403.php');
}

include(MCLANG.'tools/product-move.php');

if (isset($_POST['process']) && $_POST['destination']>0) {
  if (!empty($_POST['products'])) {
    $MCPROD->batchMoveProductsBetweenCategories();
    $_GET['cat'] = $_POST['destination'];
    $OK          = true;
  }
}
  
$pageTitle = mc_cleanDataEnt($msg_javascript197).': '.$pageTitle;
  
include(PATH.'templates/header.php');
include(PATH.'templates/tools/product-move.php');
include(PATH.'templates/footer.php');

?>
