<?php

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  This File: backup.php
  Description: System File

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

if (!defined('PARENT')) {
  include(PATH.'control/modules/header/403.php');
}

// Load language file(s)..
include(MCLANG.'tools/backup.php');
include(REL_PATH.'control/classes/db-backup.php');

// Backup..
if (isset($_POST['process'])) {
  if (!is_writeable(PATH.'import') || !is_dir(PATH.'import')) {
    die ('"<b>'.PATH.'import'.'</b>" must exist and be writeable. Please check directory and permissions..');
  }
  $time      = date('H:i:s');
  $download  = (isset($_POST['download']) ? $_POST['download'] : 'yes');
  $compress  = (isset($_POST['compress']) ? $_POST['compress'] : 'yes');
  // Force download if off and no emails..
  if ($download=='no' && $_POST['emails']=='') {
    $download = 'yes';
  }
  // If emails entered, download is always no..
  if ($_POST['emails']) {
    $download = 'no';
  }
  // File path..
  if ($compress=='yes') {
    $filepath  = PATH.'import/store-backup-'.date(mc_backupDateFormat(true)).'-'.str_replace(':','-',$time).'.gz';
  } else {
    $filepath  = PATH.'import/store-backup-'.date(mc_backupDateFormat(true)).'-'.str_replace(':','-',$time).'.sql';
  }
  // Save backup..
  $BACKUP            = new dbBackup($filepath,($compress=='yes' ? true : false));
  $BACKUP->settings  = $SETTINGS;
  $BACKUP->doDump();
  // Copy email addresses if set..
  if ($SETTINGS->smtp=='yes' && $_POST['emails'] && file_exists($filepath)) {
    $emails = array();
    if (strpos($_POST['emails'],',')!==FALSE) {
      $emails = array_map('trim',explode(',',$_POST['emails']));
    } else {
      $emails[] = $_POST['emails'];
    }
    foreach ($emails AS $send) {
      $MAILER             = new PHPMailer();
      $MAILER->IsSMTP();
      $MAILER->IsHTML(false);
      $MAILER->Port       = ($SETTINGS->smtp_port ? $SETTINGS->smtp_port : '25');
      $MAILER->Host       = ($SETTINGS->smtp_host ? $SETTINGS->smtp_host : 'localhost');
      $MAILER->SMTPAuth   = ($SETTINGS->smtp_user && $SETTINGS->smtp_pass ? true : false);
      $MAILER->Username   = $SETTINGS->smtp_user;
      $MAILER->Password   = $SETTINGS->smtp_pass;
      $MAILER->From       = $SETTINGS->email;
      $MAILER->FromName   = mc_cleanData($SETTINGS->website);
      $MAILER->AddReplyTo($SETTINGS->email,mc_cleanData($SETTINGS->website));
      $MAILER->AddAddress($send,$send);
      $MAILER->WordWrap   = 1000;
      $MAILER->Subject    = str_replace(array('{website}','{date}','{time}'),
                                        array(mc_cleanData($SETTINGS->website),
                                              date(mc_backupDateFormat()),
                                              $time
                                        ),
                                        $msg_script67
                            );
      $MAILER->Body       = str_replace(array('{STORE}','{DATE_TIME}','{VERSION}','{FILE}'),
                                        array(mc_cleanData($SETTINGS->website),
                                              date(mc_backupDateFormat()).' @ '.$time,
                                              SCRIPT_VERSION,
                                              basename($filepath)
                                        ),
                                        file_get_contents(MCLANG.'email-templates/backup.txt')
                            );
      $MAILER->AddAttachment($filepath,basename($filepath));
      $MAILER->Send();
    }
  }
  // Download..
  if ($download=='yes') {
    if(@ini_get('zlib.output_compression')) {
      @ini_set('zlib.output_compression', 'Off');
    }
    $type  = ($compress=='yes' ? 'application/x-compressed' : 'text/plain');
    header('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT');
    header('Pragma: public');
	  header('Expires: 0');
	  header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
	  header('Cache-Control: private',false);
	  header('Content-Type: '.$type);
	  header('Content-Type: application/force-download');
	  header('Content-Disposition: attachment; filename="'.basename($filepath).'";');
	  header('Content-Transfer-Encoding: binary');
	  header('Content-Length: '.filesize($filepath));
	  @ob_end_flush();
	  readfile($filepath);
    @unlink($filepath);
	  exit;
  } else {
    @unlink($filepath);
    $OK = true;
  }
}
  
$pageTitle     = mc_cleanDataEnt($msg_javascript393).': '.$pageTitle;
$loadCalendar  = true;
  
include(PATH.'templates/header.php');
include(PATH.'templates/tools/backup.php');
include(PATH.'templates/footer.php');

?>
