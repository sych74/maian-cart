<?php

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  This File: update-status.php
  Description: System File

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

if (!defined('PARENT')) {
  include(PATH.'control/modules/header/403.php');
}

// Load language file(s)..
include(MCLANG.'tools/update-statuses.php');
include(MCLANG.'tools/update-prices.php');
include(MCLANG.'catalogue/product-related.php');

if (isset($_POST['process'])) {
  if (!empty($_POST['range'])) {
    $MCPROD->updateProductStatuses();
    $OK = true;
  }
}
  
$pageTitle     = mc_cleanDataEnt($msg_javascript338).': '.$pageTitle;
$loadJQuery    = true;
  
include(PATH.'templates/header.php');
include(PATH.'templates/tools/product-status.php');
include(PATH.'templates/footer.php');

?>
