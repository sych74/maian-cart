<?php

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  This File: hit-count-overview.php
  Description: System File

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

if (!defined('PARENT')) {
  include(PATH.'control/modules/header/403.php');
}

include(MCLANG.'tools/hit-count-overview.php');
include(MCLANG.'catalogue/product-manage.php');

// Reset hits..
if (isset($_GET['reset']) && $uDel=='yes') {
  $MCPROD->resetProductHits();
  $OK = true;
}
  
// Export hits..
if (isset($_GET['export'])) {
  $MCPROD->exportHitsToCSV();
}
  
$pageTitle     = mc_cleanDataEnt($msg_javascript164).': '.$pageTitle;
$loadCalendar  = true;
  
include(PATH.'templates/header.php');
include(PATH.'templates/tools/hit-count-overview.php');
include(PATH.'templates/footer.php');

?>
