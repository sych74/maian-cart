<?php

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  This File: entry-log.php
  Description: System File

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

if (!defined('PARENT')) {
  include(PATH.'control/modules/header/403.php');
}

// Load language file(s)..
include(MCLANG.'tools/entry-log.php');

if (isset($_GET['reset']) && $uDel=='yes') {
  $cnt = $MCSYS->clearEntryLog();
  $OK  = true;
}

if (isset($_GET['export'])) {
  $MCSYS->exportEntryLog();
}

$pageTitle     = mc_cleanDataEnt($msg_javascript99).': '.$pageTitle;
  
include(PATH.'templates/header.php');
include(PATH.'templates/tools/entry-log.php');
include(PATH.'templates/footer.php');

?>
