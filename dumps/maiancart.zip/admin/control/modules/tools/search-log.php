<?php

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  This File: search-log.php
  Description: System File

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

if (!defined('PARENT')) {
  include(PATH.'control/modules/header/403.php');
}

// Load language file(s)..
include(MCLANG.'tools/search-log.php');

// Reset hits..
if (isset($_GET['clear']) && $uDel=='yes') {
  $cnt = $MCSYS->resetSearchLog();
  $OK  = true;
}
  
// Export hits..
if (isset($_GET['export'])) {
  $MCSYS->exportSearchLog();
}
  
$pageTitle     = mc_cleanDataEnt($msg_javascript108).': '.$pageTitle;
$loadCalendar  = true;
  
include(PATH.'templates/header.php');
include(PATH.'templates/tools/search-log.php');
include(PATH.'templates/footer.php');

?>
