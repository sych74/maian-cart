<?php

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  This File: stock-overview.php
  Description: System File

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

if (!defined('PARENT')) {
  include(PATH.'control/modules/header/403.php');
}

include(MCLANG.'tools/stock-overview.php');
include(MCLANG.'catalogue/product-manage.php');

// Update stock..
if (isset($_POST['process'])) {
  $MCPROD->updateProductStock();
  $OK = true;
}

// Export stock..
if (isset($_GET['export'])) {
  $MCPROD->exportStockOverviewToCSV();
}

$pageTitle     = mc_cleanDataEnt($msg_header19).': '.$pageTitle;
$loadCalendar  = true;
  
include(PATH.'templates/header.php');
include(PATH.'templates/tools/stock-overview.php');
include(PATH.'templates/footer.php');

?>
