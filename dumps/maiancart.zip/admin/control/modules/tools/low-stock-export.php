<?php

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  This File: low-stock-export.php
  Description: System File

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

if (!defined('PARENT')) {
  include(PATH.'control/modules/header/403.php');
}

// Load language file(s)..
include(MCLANG.'tools/low-stock-export.php');

// Export..
if (isset($_POST['process'])) {
  $return = $MCSYS->exportLowStockItems();
}
  
$pageTitle     = mc_cleanDataEnt($msg_javascript319).': '.$pageTitle;
$loadCalendar  = true;
  
include(PATH.'templates/header.php');
include(PATH.'templates/tools/low-stock-export.php');
include(PATH.'templates/footer.php');

?>
