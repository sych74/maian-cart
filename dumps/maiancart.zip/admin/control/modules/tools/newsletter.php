<?php

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  This File: newsletter.php
  Description: System File

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

if (!defined('PARENT')) {
  include(PATH.'control/modules/header/403.php');
}

// Load language file(s)..
include(MCLANG.'tools/newsletter.php');

// Save template..
if (isset($_GET['saveTemplate'])) {
  $r = $MCSYS->addNewsTemplate();
  echo ($r=='OK' ? $msg_newsletter30 : $msg_newsletter31);
  exit;
}

// Load templates..
if (isset($_GET['loadTemplates'])) {
  $r = $MCSYS->loadNewsTemplates();
  echo $r;
  exit;
}

// Template loader..
if ($cmd=='newsletter-templates') {
  if (isset($_POST['process'])) {
    $_GET['load'] = $_GET['update'];
    $MCSYS->updateNewsTemplate();
    $OK = true;
  }
  if (isset($_GET['del'])) {
    $MCSYS->deleteNewsTemplate();
    header("Location: ?p=newsletter-templates&deldone=yes");
    exit;
  }
  include(PATH.'templates/windows/mail-templates.php');
  exit;
}

// Mailer..
if ($cmd=='newsletter-mail') {
  if (isset($_POST['process'])) {
    $sent            = 0;
    $attach          = array();
    $_POST['email']  = ($_POST['email'] ? $_POST['email'] : $SETTINGS->email);
    $_POST['from']   = ($_POST['from'] ? $_POST['from'] : $SETTINGS->website);
    $q               = mysql_query("SELECT * FROM ".DB_PREFIX."newsletter 
                       GROUP BY emailAddress 
                       ORDER BY emailAddress
                       ") or die(mc_MySQLError(mysql_errno(),mysql_error(),__LINE__,__FILE__));
    if (mysql_num_rows($q)>0) {
      // Deal with attachments..
      for ($i=0; $i<count($_FILES['attachment']['tmp_name']); $i++) {
        $name = $_FILES['attachment']['name'][$i];
        $temp = $_FILES['attachment']['tmp_name'][$i];
        if (is_uploaded_file($temp) && $name && is_writeable(PATH.'import')) {
          move_uploaded_file($temp,PATH.'import/'.$name);
          if (file_exists(PATH.'import/'.$name)) {
            $attach[] = PATH.'import/'.$name;
          }
        }
      }
      // Loop and send..
      while ($REC = mysql_fetch_object($q)) {
        ++$sent;
        // Messages..
        $html               = str_replace('{unsubscribe}',$SETTINGS->ifolder.'/?optOut='.$REC->emailAddress,$_POST['html']);
        $plain              = str_replace('{unsubscribe}',$SETTINGS->ifolder.'/?optOut='.$REC->emailAddress,$_POST['plain']);
        // Send..
        $MAILER             = new PHPMailer();
        $MAILER->IsSMTP();
        $MAILER->IsHTML(true);
        $MAILER->Port       = ($SETTINGS->smtp_port ? $SETTINGS->smtp_port : '25');
        $MAILER->Host       = ($SETTINGS->smtp_host ? $SETTINGS->smtp_host : 'localhost');
        $MAILER->SMTPAuth   = ($SETTINGS->smtp_user && $SETTINGS->smtp_pass ? true : false);
        $MAILER->Username   = $SETTINGS->smtp_user;
        $MAILER->Password   = $SETTINGS->smtp_pass;
        $MAILER->From       = $_POST['email'];
        $MAILER->FromName   = $_POST['from'];
        $MAILER->AddReplyTo($_POST['email'],$_POST['from']);
        $MAILER->AddAddress($REC->emailAddress,$REC->emailAddress);
        $MAILER->WordWrap   = 1000;
        $MAILER->Subject    = $_POST['subject'];
        $MAILER->AltBody    = mc_cleanData($plain);
        $MAILER->MsgHTML(mc_cleanData($html));
        // Attachments..
        if (!empty($attach)) {
          foreach ($attach AS $file) {
            $MAILER->AddAttachment($file,basename($file));
          }
        }
        $MAILER->Send();
      }
      // Clear attachments..
      if (!empty($attach)) {
        foreach ($attach AS $f) {
          @unlink($f);
        }
      }
    }
    // Update news template..
    if (isset($_POST['updateTemp'])) {
      $MCSYS->updateNewsTemplate();
    }
    $OK = true;
  }
  $pageTitle     = mc_cleanDataEnt($msg_javascript309).' - '.mc_cleanDataEnt($msg_newsletter11).': '.$pageTitle;
  $loadGreyBox   = true;
  include(PATH.'templates/header.php');
  include(PATH.'templates/tools/newsletter-mailer.php');
  include(PATH.'templates/footer.php');
  exit;
}

if (isset($_GET['email']) && isset($_GET['id']) && is_numeric($_GET['id'])) {
  if (!preg_match("/^[_\.0-9a-zA-Z-]+@([0-9a-zA-Z][0-9a-zA-Z.-]+\.)+[a-zA-Z]{2,6}$/i", $_GET['email'])) {
    echo jsonHandler(
     array(
      'message' => $msg_javascript310,
      'type'    => 'error'
     )
    );  
  } else {
    $MCSYS->updateNewsletter();
    echo jsonHandler(
     array(
      'message' => $msg_javascript311,
      'type'    => 'ok',
      'email'   => $_GET['email']
     )
    );
  }
  exit;
}

if (isset($_POST['process'])) {
  $cnt  = $MCSYS->addEmailAddresses();
  $OK3  = true;
}

if (isset($_GET['clear']) && $uDel=='yes') {
  $cnt = $MCSYS->clearNewsletter();
  $OK  = true;
}

if (isset($_GET['del']) && $uDel=='yes') {
  $cnt = $MCSYS->clearNewsletterEntry();
  $OK2  = true;
}

if (isset($_GET['export'])) {
  $MCSYS->exportNewsletter();
}

$pageTitle     = mc_cleanDataEnt($msg_javascript309).': '.$pageTitle;

include(PATH.'templates/header.php');
include(PATH.'templates/tools/newsletter.php');
include(PATH.'templates/footer.php');

?>
