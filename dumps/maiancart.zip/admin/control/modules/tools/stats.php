<?php

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  This File: stats.php
  Description: System File

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

if (!defined('PARENT')) {
  include(PATH.'control/modules/header/403.php');
}

include(MCLANG.'sales/view-sales.php');
include(MCLANG.'sales/sales-search.php');

if (isset($_GET['export'])) {
  $MCSALE->exportStatsToCSV();
}
  
$pageTitle     = mc_cleanDataEnt($msg_javascript140).': '.$pageTitle;
$loadCalendar  = true;
  
include(PATH.'templates/header.php');
include(PATH.'templates/tools/stats.php');
include(PATH.'templates/footer.php');

?>
