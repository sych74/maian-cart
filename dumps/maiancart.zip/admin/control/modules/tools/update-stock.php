<?php

/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  Script: Maian Cart
  Programmed & Designed by: David Ian Bennett
  E-Mail: support@maianscriptworld.co.uk
  Software Website: http://www.maiancart.com
  Script Portal: http://www.maianscriptworld.co.uk

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  This File: update-stock.php
  Description: System File

  ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

if (!defined('PARENT')) {
  include(PATH.'control/modules/header/403.php');
}

// Load language file(s)..
include(MCLANG.'tools/update-stock.php');
include(MCLANG.'tools/update-prices.php');
include(MCLANG.'catalogue/product-related.php');

if (isset($_POST['import_from_csv'])) {
  $updated  = $MCPROD->batchUpdateStockFromCSV();
  $OK       = true;
}

if (isset($_POST['process'])) {
  if ($_POST['stock'] && isset($_POST['pCat'])) {
    $MCPROD->updateStockLevels();
    $OK = true;
  }
}
  
$pageTitle     = mc_cleanDataEnt($msg_javascript61).': '.$pageTitle;
$loadCalendar  = true;
$loadJQuery    = true;
  
include(PATH.'templates/header.php');
include(PATH.'templates/tools/product-stock'.($cmd=='update-stock-csv' ? '-import' : '').'.php');
include(PATH.'templates/footer.php');

?>
